param([ValidateSet('Inspect','Run')][string]$Action='Inspect')
$ErrorActionPreference='Stop'
if($Action -eq 'Inspect'){
    [ordered]@{Host='Launcher.exe';UsesInProcessPowerShell=$true;GameParentSpoofed=$false;OriginalParentCheckChanged=$false;GameStarted=$false} | ConvertTo-Json
    return
}
if($env:OS -ne 'Windows_NT' -or ![Environment]::Is64BitProcess){throw 'WINDOWS_X64_POWERSHELL_REQUIRED'}
if(Get-Process -Name CabalMain -ErrorAction SilentlyContinue){throw 'Vispirms aizver CABAL klientu.'}
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if(!(Test-Path -LiteralPath $compiler)){throw 'WINDOWS_DOTNET_FRAMEWORK_COMPILER_MISSING'}
$source=Join-Path $PSScriptRoot 'Client291-LauncherHost-v4_9_4.cs'
$launcher=Join-Path $PSScriptRoot 'Launcher.exe'
$automation=[System.Management.Automation.PowerShell].Assembly.Location
'KOMPILAJU_MUSU_LAUNCHER; ORIGINALAIS_KLIENTS_NETIEK_PARRAKSTITS'
& $compiler /nologo /target:exe /platform:x64 /optimize+ ("/reference:"+$automation) ("/out:"+$launcher) $source
if($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $launcher)){throw 'LAUNCHER_HOST_BUILD_FAILED'}
Start-Process -FilePath $launcher -WorkingDirectory $PSScriptRoot -Verb RunAs
