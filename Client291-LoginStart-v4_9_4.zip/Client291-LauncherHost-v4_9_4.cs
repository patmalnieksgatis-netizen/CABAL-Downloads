// Our actual launch host. CabalMain is created by this Launcher.exe process;
// no parent-process attributes, process renaming or parent-check modifications.
using System;
using System.Diagnostics;
using System.IO;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Reflection;
using System.Threading;

public static class Client291LauncherHostV494 {
    static volatile int gamePID;
    static void Print(PSObject item) {
        if(item==null)return;
        string line=item.ToString();Console.WriteLine(line);
        const string prefix="TEST_PID=";
        int parsed;
        if(line.StartsWith(prefix,StringComparison.Ordinal) && Int32.TryParse(line.Substring(prefix.Length),out parsed))
            gamePID=parsed;
    }
    public static int Main(string[] args) {
        int result=0;
        try {
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT || !Environment.Is64BitProcess)
                throw new Exception("WINDOWS_X64_LAUNCHER_REQUIRED");
            string self=Process.GetCurrentProcess().MainModule.FileName;
            if(!Path.GetFileName(self).Equals("Launcher.exe",StringComparison.OrdinalIgnoreCase))
                throw new Exception("ACTUAL_LAUNCHER_HOST_NAME_REQUIRED");
            string folder=Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string script=Path.Combine(folder,"Start-Client291-LoginStart-v4_9_4.ps1");
            if(!File.Exists(script))throw new Exception("LOCAL_LAUNCH_SCRIPT_MISSING");
            Console.WriteLine("CLIENT291_LAUNCHER_V4_9_4; NATIVE_PARENT=Launcher.exe");
            InitialSessionState initial=InitialSessionState.CreateDefault();
            initial.ExecutionPolicy=Microsoft.PowerShell.ExecutionPolicy.Bypass;
            using(Runspace runspace=RunspaceFactory.CreateRunspace(initial)) {
                runspace.Open();
                using(PowerShell shell=PowerShell.Create()) {
                    shell.Runspace=runspace;
                    shell.AddCommand(script).AddParameter("Action","Run");
                    PSDataCollection<PSObject> output=new PSDataCollection<PSObject>();
                    output.DataAdded+=delegate(object sender,DataAddedEventArgs e){Print(output[e.Index]);};
                    shell.Streams.Error.DataAdded+=delegate(object sender,DataAddedEventArgs e){
                        Console.WriteLine("HOST_ERROR="+shell.Streams.Error[e.Index].ToString());
                    };
                    IAsyncResult execution=shell.BeginInvoke<PSObject,PSObject>(null,output);
                    shell.EndInvoke(execution);
                    if(shell.HadErrors)result=1;
                }
            }
            // Keep the real parent alive if observation ends while the game runs.
            if(gamePID>0) {
                try {
                    using(Process game=Process.GetProcessById(gamePID)) {
                        if(!game.HasExited && game.MainModule.FileName.Equals(@"F:\CABAL_291_TEST\Bin\x64\CabalMain.exe",StringComparison.OrdinalIgnoreCase)) {
                            Console.WriteLine("NOVEROSANA_PABEIGTA; LAUNCHER_PALIEK_ATVERTS_KAMER_SPELE_DARBOJAS");
                            game.WaitForExit();
                        }
                    }
                } catch(ArgumentException) { } catch(InvalidOperationException) { }
            }
        } catch(Exception e) {Console.WriteLine("HOST_KLUDA="+e.GetBaseException().Message);result=1;}
        Console.WriteLine("LAUNCHER_PABEIGTS; ENTER_LAI_AIZVERTU");
        try {Console.ReadLine();} catch { }
        return result;
    }
}
