V4.9.4 - ACTUAL LAUNCHER HOST AND NATIVE PER-LAUNCH CONTRACT

Only F:\CABAL_291_TEST and test VM192.168.56.101. Close the previous game.
Run Palaist-291-v4_9_4.cmd as administrator. It compiles OUR Launcher.exe in
this extracted folder with the existing Windows .NET Framework compiler.
Our host runs the controller in-process; CabalMain is naturally created by
Launcher.exe, not powershell.exe. Actual parent PID is checked. No parent
attribute, process renaming or modification of the native parent check.

V4.9.3 captured Main7C963C requesting WM_CLOSE. This is a delayed close when
a native guard has been armed. Actual Main27DE5C rejects powershell.exe as
parent; it accepts the exact launcher.exe name, case-insensitively. That
failure can arm the guard during post-World initialization. Keeping the
original verifier and providing the real expected launch host fixes this
identified mismatch. Another return-address guard can also arm the counter;
its flags are now sampled to distinguish any remaining cause.

The native startup also checks an existing HKCU Software\ESTsoft\CabalOnline
installationCheck DWORD, expects1 and consumes it to0. Our launcher follows
this per-launch contract ONLY for an existing DWORD0/1:0 is temporarily set1,
1 is left unchanged. No installation key or absent value is created. Unknown
types/values are refused. Native consumption restores a prior0; failure
cleanup restores our unconsumed1 to0. Other registry values are untouched.
Readback and restore status are reported. Original Main/SDK/DXVK hashes are
verified before arming this existing native launch token.

Login the existing fresh account, choose its character and enter World.
Leave it open90seconds. The observer then ends while the real launcher
stays alive for the game's lifetime. Return Downloads/Client291-LoginStart-
v4_9_4-*.json from REPORT and say whether World stayed open. Keep the
launcher window open while the game runs.

V4.9.2 protocol edits, original World/CharacterList blobs and V4.9.3 close
observer are unchanged. No shutdown flag/counter write, close bypass or
change to the parent/registry verifier is applied to the game. Existing
custom costume names/rename and positive legacy pet state remain unsupported.
No server install/restart/SQL changes or original game-file replacements.
Own Launcher.exe is compiled locally, not supplied as a game binary.

Actual Main parent-comparator/registry-function44 emulation checks pass;
locale/Win32 registry APIs are synthetic stubs. Host/component C# compile,
PS parse/Inspect and launch-value guards pass. Actual Windows .NET Framework
host build, parent/marker consumption and sustained World remain unverified.
The first Windows run is required; no stability success is claimed here.
