// Own narrow Guardian integration. No shared transport callbacks, SQL patches,
// item grants, opcode registrations, native global NOPs or PolyHook ABI guesses.
#include "guardian_arcana_policy.h"
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <climits>
#include <dirent.h>
#include <dlfcn.h>
#include <link.h>
#include <openssl/evp.h>
#include <sys/mman.h>
#include <unistd.h>

namespace {
using Word=std::uintptr_t;
using Storage=std::uint32_t(*)(void*,Word*);
using Mode=std::uint32_t(*)(Word);
using Hold=std::uint64_t(*)(void*,std::int32_t*,std::uint64_t,std::uint32_t*,char*,std::uint8_t);
using Put=std::uint64_t(*)(void*,std::uint64_t,std::int32_t*,std::uint32_t*,char*,std::uint64_t);
using Can=unsigned char(*)(Word,std::uint32_t,std::uint64_t*,char,std::uint64_t,std::uint64_t);
using Apply=char(*)(Word);
using Recalc=void(*)(Word,char*);
using Equip=void(*)(Word,std::uint64_t,std::uint64_t*);
using Unequip=void(*)(Word,std::uint16_t);
Storage original_move=nullptr,original_swap=nullptr;
Mode original_mode=nullptr;
Hold original_hold=nullptr,guardian_hold=nullptr;
Put original_put=nullptr,guardian_put=nullptr;
Can original_can=nullptr;
Apply original_apply=nullptr;
Recalc original_recalc=nullptr;
Equip original_equip=nullptr;
Unequip original_unequip=nullptr;
constexpr const char* world_sha="caec7772acd22fd8918cfac386845c644451781e48c51975eaefed334c6705c3";
constexpr const char* core_sha="6679e46aa2ee915d97de9501ba027cae3eec153f1cd82e7c16ed47221c63ecab";
constexpr const char* costume_sha="8743fe8b01496484a357b72bc4fadb1531d044954857f82cc0539779f21c5f8a";
constexpr const char* item_sha="0c91422986344bd533be8edd701afb77e70b158a3cfbf39094f9fad0ca94c669";

std::uint32_t storage_move(void* layer,Word* ctx) {
    auto* p=ctx?reinterpret_cast<unsigned char*>(ctx[1]):nullptr;
    guardian::PacketMap mapping(p,p?guardian::load<std::uint16_t>(p+2):0,0x875);
    return original_move(layer,ctx);
}
std::uint32_t storage_swap(void* layer,Word* ctx) {
    auto* p=ctx?reinterpret_cast<unsigned char*>(ctx[1]):nullptr;
    guardian::PacketMap mapping(p,p?guardian::load<std::uint16_t>(p+2):0,0x876);
    return original_swap(layer,ctx);
}
__attribute__((noinline)) std::uint32_t equipment_mode(Word context) {
    const auto result=original_mode(context);
    const Word caller=reinterpret_cast<Word>(__builtin_return_address(0));
    if (!result && caller>=0x8c18f0 && caller<=0x8c1920 && context>0x2be6c &&
        guardian::occupied(reinterpret_cast<void*>(context-0x2be6c))) return 1;
    return result;
}
std::uint64_t hold(void* user,std::int32_t* from,std::uint64_t unused,std::uint32_t* item,char* op,std::uint8_t exception) {
    const bool enable=user && from && from[0]==1 && from[1]==guardian::backing_slot && guardian::occupied(user);
    guardian::EffectAlias alias(user,enable);
    return (enable?guardian_hold:original_hold)(user,from,unused,item,op,exception);
}
std::uint64_t put(void* user,std::uint64_t unused,std::int32_t* to,std::uint32_t* item,char* op,std::uint64_t exception) {
    const bool enable=user && to && item && to[0]==1 && to[1]==guardian::backing_slot &&
        guardian::is_guardian(guardian::load<std::uint64_t>(item));
    guardian::EffectAlias alias(user,enable);
    return (enable?guardian_put:original_put)(user,unused,to,item,op,exception);
}
unsigned char can_equip(Word user,std::uint32_t slot,std::uint64_t* item,char strong,std::uint64_t unused,std::uint64_t tail) {
    if(slot==guardian::backing_slot && item && guardian::is_guardian(guardian::load<std::uint64_t>(item))) slot=guardian::effect_slot;
    return original_can(user,slot,item,strong,unused,tail);
}
char apply(Word user) {
    guardian::EffectAlias alias(reinterpret_cast<void*>(user),guardian::occupied(reinterpret_cast<void*>(user)));
    return original_apply(user);
}
void recalc(Word user,char* flags) {
    guardian::EffectAlias alias(reinterpret_cast<void*>(user),guardian::occupied(reinterpret_cast<void*>(user)));
    original_recalc(user,flags);
}
void equip(Word user,std::uint64_t slot,std::uint64_t* item) {
    if(slot==guardian::backing_slot && item && guardian::is_guardian(guardian::load<std::uint64_t>(item))) slot=guardian::client_slot;
    original_equip(user,slot,item);
}
void unequip(Word user,std::uint16_t slot) {
    if(slot==guardian::backing_slot) slot=guardian::client_slot;
    original_unequip(user,slot);
}

bool hash_matches(const char* name,const char* expected) {
    FILE* file=std::fopen(name,"rb");if(!file) return false;
    EVP_MD_CTX* ctx=EVP_MD_CTX_new();
    bool okay=ctx && EVP_DigestInit_ex(ctx,EVP_sha256(),nullptr)==1;
    unsigned char bytes[16384],digest[32];unsigned length=0;std::size_t n;
    while(okay && (n=std::fread(bytes,1,sizeof bytes,file))!=0) okay=EVP_DigestUpdate(ctx,bytes,n)==1;
    okay=okay && !std::ferror(file) && EVP_DigestFinal_ex(ctx,digest,&length)==1 && length==32;
    if(ctx) EVP_MD_CTX_free(ctx);
    std::fclose(file);
    char hex[65]={};if(okay) for(unsigned i=0;i<32;i++)std::snprintf(hex+i*2,3,"%02x",digest[i]);
    return okay && std::strcmp(hex,expected)==0;
}
struct Loaded { bool core=false,costume=false; };
int loaded_module(dl_phdr_info* info,std::size_t,void* data) {
    auto& loaded=*static_cast<Loaded*>(data);
    const char* path=info->dlpi_name; const char* name=std::strrchr(path,'/');name=name?name+1:path;
    if(std::strcmp(name,"lib.so")==0)loaded.core=hash_matches(path,core_sha);
    if(std::strcmp(name,"EP36CostumeCore_v1_5_3020fix.so")==0)loaded.costume=hash_matches(path,costume_sha);
    return 0;
}
bool single_thread() {
    DIR* dir=opendir("/proc/self/task");if(!dir)return false;
    unsigned count=0;while(auto* e=readdir(dir))if(e->d_name[0]>='0' && e->d_name[0]<='9')++count;
    closedir(dir);return count==1;
}
void log(const char* state) {
    std::fprintf(stderr,"EP39_GUARDIAN_V1=%s\n",state);
    if(FILE* f=std::fopen("/var/log/cabal/GuardianArcana-v1.log","a")){
        const char* nonce=std::getenv("CABAL_GUARDIAN_V1_ID");
        std::fprintf(f,"EP39_GUARDIAN_V1=%s PID=%ld ID=%s\n",state,static_cast<long>(getpid()),nonce?nonce:"");std::fclose(f);
    }
}
[[noreturn]] void refuse(const char* reason) { log(reason);_exit(78); }
struct HookSpec { const char* name;Word address;unsigned bytes;int relocation;Word branch;unsigned char expected[32]; };
#include "guardian_native_profile.h"
constexpr unsigned hooks=sizeof(profile)/sizeof(profile[0]);
static_assert(hooks==10);
Word original[hooks]{};
unsigned char* code=nullptr;
void absolute_jump(unsigned char* out,Word destination) {
    out[0]=0xff;out[1]=0x25;std::memset(out+2,0,4);guardian::store<Word>(out+6,destination);
}
bool rel32(unsigned char* destination,Word at,Word target) {
    const std::int64_t delta=static_cast<std::int64_t>(target)-static_cast<std::int64_t>(at+4);
    if(delta<INT32_MIN || delta>INT32_MAX)return false;
    guardian::store<std::int32_t>(destination,static_cast<std::int32_t>(delta));return true;
}
bool prepare() {
    code=static_cast<unsigned char*>(mmap(nullptr,4096,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_32BIT,-1,0));
    if(code==MAP_FAILED){code=nullptr;return false;}
    const Word callbacks[]={reinterpret_cast<Word>(storage_move),reinterpret_cast<Word>(storage_swap),reinterpret_cast<Word>(equipment_mode),
        reinterpret_cast<Word>(hold),reinterpret_cast<Word>(put),reinterpret_cast<Word>(can_equip),reinterpret_cast<Word>(apply),
        reinterpret_cast<Word>(recalc),reinterpret_cast<Word>(equip),reinterpret_cast<Word>(unequip)};
    for(unsigned i=0;i<hooks;i++){
        auto* relay=code+i*128;auto* trampoline=relay+32;const auto& p=profile[i];
        if(std::memcmp(reinterpret_cast<const void*>(p.address),p.expected,sizeof p.expected)!=0)return false;
        unsigned char displacement[4];if(!rel32(displacement,p.address+1,reinterpret_cast<Word>(relay)))return false;
        absolute_jump(relay,callbacks[i]);std::memcpy(trampoline,p.expected,p.bytes);
        if(p.relocation>=0 && !rel32(trampoline+p.relocation,reinterpret_cast<Word>(trampoline+p.relocation),p.branch))return false;
        absolute_jump(trampoline+p.bytes,p.address+p.bytes);original[i]=reinterpret_cast<Word>(trampoline);
        if(i==3 || i==4){auto* allowed=relay+64;allowed[0]=0xb8;guardian::store<std::uint32_t>(allowed+1,guardian::backing_slot);
            absolute_jump(allowed+5,p.address+21);}
    }
    original_move=reinterpret_cast<Storage>(original[0]);original_swap=reinterpret_cast<Storage>(original[1]);
    original_mode=reinterpret_cast<Mode>(original[2]);original_hold=reinterpret_cast<Hold>(original[3]);
    original_put=reinterpret_cast<Put>(original[4]);original_can=reinterpret_cast<Can>(original[5]);
    original_apply=reinterpret_cast<Apply>(original[6]);original_recalc=reinterpret_cast<Recalc>(original[7]);
    original_equip=reinterpret_cast<Equip>(original[8]);original_unequip=reinterpret_cast<Unequip>(original[9]);
    guardian_hold=reinterpret_cast<Hold>(code+3*128+64);guardian_put=reinterpret_cast<Put>(code+4*128+64);
    return mprotect(code,4096,PROT_READ|PROT_EXEC)==0;
}
bool install() {
    const long page=sysconf(_SC_PAGESIZE);if(page<=0)return false;
    Word pages[hooks]{};unsigned count=0;
    for(const auto& p:profile){Word base=p.address&~Word(page-1);bool found=false;for(unsigned i=0;i<count;i++)found|=pages[i]==base;if(!found)pages[count++]=base;}
    unsigned writable=0;
    for(;writable<count;writable++)if(mprotect(reinterpret_cast<void*>(pages[writable]),page,PROT_READ|PROT_WRITE|PROT_EXEC)!=0)break;
    if(writable!=count){for(unsigned i=0;i<writable;i++)mprotect(reinterpret_cast<void*>(pages[i]),page,PROT_READ|PROT_EXEC);return false;}
    bool okay=true;
    for(unsigned i=0;i<hooks;i++){
        unsigned char patch[16];std::memset(patch,0x90,sizeof patch);patch[0]=0xe9;
        okay=rel32(patch+1,profile[i].address+1,reinterpret_cast<Word>(code+i*128)) && okay;
        if(!okay)break;
        std::memcpy(reinterpret_cast<void*>(profile[i].address),patch,profile[i].bytes);
        okay=std::memcmp(reinterpret_cast<void*>(profile[i].address),patch,profile[i].bytes)==0;
        if(!okay)break;
    }
    if(!okay)for(const auto& p:profile)std::memcpy(reinterpret_cast<void*>(p.address),p.expected,p.bytes);
    for(unsigned i=0;i<count;i++)if(mprotect(reinterpret_cast<void*>(pages[i]),page,PROT_READ|PROT_EXEC)!=0)okay=false;
    return okay;
}
#ifndef GUARDIAN_TEST
__attribute__((constructor)) void initialize() {
    const char* enabled=std::getenv("CABAL_GUARDIAN_V1");if(!enabled || std::strcmp(enabled,"1")!=0)return;
    // A Python startup wrapper can have WorldSvr_01_01 as comm as well. Only
    // activate inside the native executable, never its shell/Python launcher.
    char executable[PATH_MAX]={};
    const auto length=readlink("/proc/self/exe",executable,sizeof executable-1);
    if(length<=0)return;
    const char* name=std::strrchr(executable,'/');name=name?name+1:executable;
    if(std::strncmp(name,"WorldSvr",8)!=0)return;
    if(!single_thread())refuse("STARTUP_NOT_SINGLE_THREAD");
    if(!hash_matches("/proc/self/exe",world_sha))refuse("WORLD_HASH_DIFFERS");
    Loaded loaded;dl_iterate_phdr(loaded_module,&loaded);
    if(!loaded.core || !loaded.costume)refuse("EXISTING_CORE_OR_COSTUME_DIFFERS");
    if(!hash_matches("/etc/cabal/Data/Item2.scp",item_sha))refuse("NATIVE_ITEM_DATA_DIFFERS");
    if(!prepare())refuse("HOOK_PREFIX_OR_ALLOCATION_DIFFERS");
    if(!install())refuse("HOOK_TRANSACTION_FAILED");
    log("READY");
}
#endif
}
