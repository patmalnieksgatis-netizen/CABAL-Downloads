"""Install/restore only the isolated test channel's Guardian startup addition.

The outer packager supplies MODULE_BASE64 and MODULE_SHA; this file does not
contain or download third-party libraries, game executables or credentials.
"""
import ast
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tempfile
import time
import uuid

MODULE_BASE64 = '__GUARDIAN_MODULE_BASE64__'
MODULE_SHA = '__GUARDIAN_MODULE_SHA256__'
ROOT = Path('/usr/lib/cabal/guardian-v1')
MODULE = ROOT/'GuardianArcana-v1.so'
ENTRY = Path('/usr/bin/WorldSvr_01_01')
RECEIPT = ROOT/'installed.json'
TRIAL = Path('/etc/cabal/migration_tools/ep36-costume-trial-v1/receipt.json')
WORLD = 'caec7772acd22fd8918cfac386845c644451781e48c51975eaefed334c6705c3'
CORE = '6679e46aa2ee915d97de9501ba027cae3eec153f1cd82e7c16ed47221c63ecab'
COSTUME = '8743fe8b01496484a357b72bc4fadb1531d044954857f82cc0539779f21c5f8a'
ITEM = '0c91422986344bd533be8edd701afb77e70b158a3cfbf39094f9fad0ca94c669'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(body):
    return hashlib.sha256(body).hexdigest()


def read(path, maximum=32*1024**2):
    s=path.lstat()
    require(stat.S_ISREG(s.st_mode) and s.st_uid==0 and not s.st_mode&0o022 and s.st_size<=maximum,
            'UNSAFE_INPUT_'+path.name)
    return path.read_bytes()


def write(path, body, mode):
    if path.exists() or path.is_symlink():
        read(path)
    fd,name=tempfile.mkstemp(prefix='.guardian-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(body);f.flush();os.fsync(f.fileno())
        os.chmod(name,mode);os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def pid(name):
    p=subprocess.run(['supervisorctl','pid',name],capture_output=True,text=True,timeout=10)
    require(p.returncode in (0,7) and p.stdout.strip().isdigit(),'SERVICE_PID_UNAVAILABLE_'+name)
    return int(p.stdout.strip())


def control(action):
    p=subprocess.run(['supervisorctl',action,'WorldSvr_01_01'],capture_output=True,timeout=35)
    require(p.returncode==0 or (action=='stop' and pid('WorldSvr_01_01')==0),'WORLD_'+action.upper()+'_FAILED')


def loaded(p, name):
    matches=set()
    for line in (Path('/proc')/str(p)/'maps').read_text().splitlines():
        words=line.split()
        if len(words)>=6 and words[5].startswith('/') and Path(words[5]).name==name:
            matches.add(words[5])
    require(len(matches)==1,'LOADED_MODULE_NOT_UNIQUE_'+name)
    return Path(next(iter(matches)))


def listening(p):
    inodes=set()
    for f in (Path('/proc')/str(p)/'fd').iterdir():
        try: link=os.readlink(f)
        except OSError: continue
        m=re.fullmatch(r'socket:\[(\d+)\]',link)
        if m:inodes.add(m[1])
    for name in ('tcp','tcp6'):
        for line in (Path('/proc')/str(p)/'net'/name).read_text().splitlines()[1:]:
            w=line.split()
            if len(w)>9 and w[3]=='0A' and w[9] in inodes:return True
    return False


def health(login, nonce, installed):
    deadline=time.monotonic()+50;stable_pid=0;since=0
    while time.monotonic()<deadline:
        try:
            p=pid('WorldSvr_01_01')
            require(p>0 and pid('LoginSvr_01')==login,'WORLD_NOT_STABLE')
            require(digest((Path('/proc')/str(p)/'exe').read_bytes())==WORLD,'WORLD_CHANGED')
            maps=(Path('/proc')/str(p)/'maps').read_text()
            if installed:
                require(str(MODULE) in maps,'GUARDIAN_NOT_LOADED')
                path=Path('/var/log/cabal/GuardianArcana-v1.log')
                with path.open('rb') as f:
                    f.seek(max(0,path.stat().st_size-32768)); tail=f.read()
                marker=f'EP39_GUARDIAN_V1=READY PID={p} ID={nonce}\n'.encode('ascii')
                require(marker in tail,'GUARDIAN_NOT_READY')
            else:
                require(str(MODULE) not in maps,'GUARDIAN_STILL_LOADED')
            require(listening(p),'WORLD_LISTENER_NOT_READY')
            if p!=stable_pid:stable_pid=p;since=time.monotonic()
            if time.monotonic()-since>=8:return p
        except (RuntimeError,OSError,subprocess.SubprocessError):
            stable_pid=0;since=0
        time.sleep(1)
    raise RuntimeError('CHANNEL_STARTUP_NOT_VERIFIED')


def plan_launcher(before, nonce):
    source=before.decode('utf-8')
    tree=ast.parse(source)
    calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)
           and isinstance(n.func.value,ast.Name) and n.func.value.id=='os'
           and n.func.attr in ('execve','execvpe') and len(n.args)==3 and isinstance(n.args[2],ast.Name)]
    require(len(calls)==1 and 'CABAL_GUARDIAN_V1' not in source,'WORLD_LAUNCHER_LAYOUT_REQUIRES_REVIEW')
    call=calls[0]; rows=source.splitlines(keepends=True);row=rows[call.lineno-1]
    require(re.match(r'^\s*os\.execv(?:e|pe)\(',row) is not None,'WORLD_EXEC_STATEMENT_REQUIRES_REVIEW')
    indent=row[:len(row)-len(row.lstrip())]; environment=call.args[2].id
    addition=(f"{indent}{environment}['LD_PRELOAD']=({environment}.get('LD_PRELOAD','')+' {MODULE}').strip()\n"
              f"{indent}{environment}['CABAL_GUARDIAN_V1']='1'\n"
              f"{indent}{environment}['CABAL_GUARDIAN_V1_ID']='{nonce}'\n")
    rows.insert(call.lineno-1,addition);after=''.join(rows).encode('utf-8')
    compile(after,'guardian_world_launcher','exec')
    return after


def main(action):
    require(os.geteuid()==0,'ROOT_REQUIRED')
    require(action in ('--apply','--check','--restore'),'ACTION_REQUIRED')
    p=pid('WorldSvr_01_01');login=pid('LoginSvr_01')
    require(login>0 and (p>0 or action=='--restore'),'START_TEST_SERVER_FIRST')
    if action!='--restore':
        require(digest((Path('/proc')/str(p)/'exe').read_bytes())==WORLD,'WORLD_PROFILE_DIFFERS')
        require(digest(read(loaded(p,'lib.so')))==CORE,'CORE_PROFILE_DIFFERS')
        require(digest(read(loaded(p,'EP36CostumeCore_v1_5_3020fix.so')))==COSTUME,'COSTUME_PROFILE_DIFFERS')
        require(digest(read(Path('/etc/cabal/Data/Item2.scp')))==ITEM,'NATIVE_ITEM_DEFINITIONS_DIFFER')
    current=read(ENTRY,65536);entry_mode=stat.S_IMODE(ENTRY.stat().st_mode)
    if ROOT.exists():
        s=ROOT.lstat();require(stat.S_ISDIR(s.st_mode) and s.st_uid==0 and not s.st_mode&0o077,'UNSAFE_GUARDIAN_DIRECTORY')
    if RECEIPT.exists():
        receipt=json.loads(read(RECEIPT,262144))
        require(receipt['module_sha256']==MODULE_SHA and digest(read(MODULE))==MODULE_SHA,'GUARDIAN_MODULE_CHANGED')
        require(receipt['after_entry']==digest(current),'LAUNCHER_CHANGED_AFTER_GUARDIAN_INSTALL')
        if action!='--restore':
            health(login,receipt['nonce'],True)
            print('GUARDIAN_ALREADY_INSTALLED; USE_V496_LAUNCHER');return
        old=read(ROOT/'launcher-before.py',65536)
        require(digest(old)==receipt['before_entry'],'GUARDIAN_BACKUP_CHANGED')
        if receipt['trial_before'] is not None:
            require(digest(read(TRIAL,262144))==receipt['trial_after'],'TRIAL_RECEIPT_CHANGED')
        control('stop')
        try:
            write(ENTRY,old,receipt['entry_mode'])
            if receipt['trial_before'] is not None:write(TRIAL,read(ROOT/'trial-before.json',262144),receipt['trial_mode'])
            control('start');health(login,'',False)
        except Exception:
            raise RuntimeError('RESTORE_NOT_CONFIRMED; ORIGINAL_BACKUP_RETAINED')
        RECEIPT.rename(ROOT/'restored.json')
        print('GUARDIAN_RESTORED; ORIGINAL_CORE_COSTUME_AND_WORLD_RETAINED');return
    require(action!='--restore','GUARDIAN_NOT_INSTALLED')
    nonce=uuid.uuid4().hex;after=plan_launcher(current,nonce)
    payload=base64.b64decode(MODULE_BASE64,validate=True)
    require(payload.startswith(b'\x7fELF\x02') and digest(payload)==MODULE_SHA,'GUARDIAN_PAYLOAD_INVALID')
    trial_before=None;trial_after=None;trial_mode=None
    if TRIAL.exists():
        trial_before=read(TRIAL,262144);value=json.loads(trial_before)
        require(value.get('launcher_sha256')==digest(current),'EXISTING_TRIAL_RECEIPT_DIFFERS')
        value['launcher_sha256']=digest(after)
        trial_after=(json.dumps(value,indent=2)+'\n').encode('utf-8');trial_mode=stat.S_IMODE(TRIAL.stat().st_mode)
    print('GUARDIAN_PREFLIGHT_OK; WORLD_CORE_COSTUME_ITEM_PROFILE_VERIFIED',flush=True)
    if action=='--check':
        print('GUARDIAN_CHECK_ONLY; NOTHING_CHANGED');return
    ROOT.mkdir(mode=0o700,exist_ok=True)
    require(not (ROOT/'launcher-before.py').exists() and not (ROOT/'restored.json').exists(),'OLD_GUARDIAN_BACKUP_PRESENT_REVIEW_REQUIRED')
    write(ROOT/'launcher-before.py',current,0o600)
    if trial_before is not None:write(ROOT/'trial-before.json',trial_before,0o600)
    write(MODULE,payload,0o700)
    require(read(ENTRY,65536)==current,'LAUNCHER_CHANGED_BEFORE_INSTALL')
    if trial_before is not None:require(read(TRIAL,262144)==trial_before,'TRIAL_CHANGED_BEFORE_INSTALL')
    receipt=dict(schema=1,nonce=nonce,module_sha256=MODULE_SHA,before_entry=digest(current),
                 after_entry=digest(after),entry_mode=entry_mode,trial_before=digest(trial_before) if trial_before is not None else None,
                 trial_after=digest(trial_after) if trial_after is not None else None,trial_mode=trial_mode)
    write(ROOT/'prepared.json',(json.dumps(receipt,indent=2)+'\n').encode(),0o600)
    print('RESTARTING_TEST_WORLD_CHANNEL_ONLY; LOGIN_AND_SQL_RETAINED',flush=True)
    stopped=False;changed=False
    try:
        control('stop');stopped=True
        require(read(ENTRY,65536)==current,'LAUNCHER_CHANGED_WHILE_STOPPING')
        changed=True;write(ENTRY,after,entry_mode)
        if trial_after is not None:write(TRIAL,trial_after,trial_mode)
        control('start');receipt['pid']=health(login,nonce,True)
        write(RECEIPT,(json.dumps(receipt,indent=2)+'\n').encode(),0o600)
    except Exception:
        if stopped:
            try:
                if pid('WorldSvr_01_01')>0:control('stop')
                if changed:
                    write(ENTRY,current,entry_mode)
                    if trial_before is not None:write(TRIAL,trial_before,trial_mode)
                control('start');health(login,'',False)
            except Exception:
                raise RuntimeError('GUARDIAN_INSTALL_FAILED_AND_RESTORE_NOT_CONFIRMED; BACKUP_RETAINED')
        raise RuntimeError('GUARDIAN_NOT_INSTALLED; ORIGINAL_LAUNCHER_RESTORED')
    print('GUARDIAN_INSTALLED; START_V496_AND_TEST_GUARDIAN_EQUIP_UNEQUIP_RELOGIN')


if __name__=='__main__':
    try:
        require(len(sys.argv)==2,'ACTION_REQUIRED');main(sys.argv[1])
    except (RuntimeError,OSError,ValueError,subprocess.SubprocessError) as error:
        # Fixed failures only; never print launcher sources or configuration.
        detail=str(error) if isinstance(error,RuntimeError) else type(error).__name__
        raise SystemExit('GUARDIAN_STOPPED: '+detail)
