GUARDIAN ARCANA V1 + CLIENT291 V4.9.6

1. Aizver CABAL. Atpako visu ZIP JAUNA mape.
2. Palaid Uzstadit-Guardian-v1.cmd un ievadi 192.168.56.101 SSH root paroli.
3. Turpini tikai tad, ja redzams GUARDIAN_INSTALLED vai GUARDIAN_ALREADY_INSTALLED.
4. Palaid Palaist-291-v4_9_6.cmd ka administrators. Atstaj Launcher logu atvertu.
5. Kathleen: uzvelc Guardian Arcana, nonem, uzvelc atkal. Izej no tela un ieej atkal.
   Parbaudi, vai Arcana paliek tresaja slota un stats mainas/pazud atbilstosi.

Atgriesana: VISPIRMS nonem Guardian uz inventaru visiem testa teliem un izej
no speles, lai serveris saglaba stāvokli. Tad palaid Atjaunot-Pirms-Guardian.cmd.
Vecais serveris bez modula neatbalsta uzvilktu Guardian glabasanas slotu.
Pec atjaunosanas
vari izmantot savu ieprieksejo V4.9.5 palaideju. Originalais servera palaidejs
un ta receipt tiek saglabati servera /usr/lib/cabal/guardian-v1/.

Tikai testa VM UUID un esosas World/core/Costume/Item2 versijas. Nesaderigas
versijas atsaka pirms uzstadisanas. Ja jauna World starta parbaude neiziet,
uzstaditajs atjauno ieprieksejo palaideju un palaiz kanalu ar veco konfiguraciju.
Ja atjaunosana nav apstiprinata, skripts pasaka to; tad atsuti precizo izvadi.

Modulis pievieno tikai Guardian slotu; pilns EP39 LibSvr netiek ieladets.
Nav itemu pieskiruma, SQL/progresa/valutas izmainu. Originalie klienta faili
netiek parrakstiti. Esošie kostimi un Cresti tiek saglabati.

Lokali parbaudits pret saglabato native World un originalo291 telu saraksta
reader; tava Windows/VM pirmais gameplay tests vel nav izpildits.
Ja uzstaditajs apstajas, atsuti izvadi; launcher vai biblioteka nav jakopē ar roku.
