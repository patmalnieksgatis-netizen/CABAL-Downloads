Original PlayCabal291 x64 state read: F:\CABAL_291_TEST only.
Close ALL Cabal windows. Extract ALL files, run Palaist-Nolasisanu.cmd.
Original Main/Ogg/DXVK file hashes required BEFORE launch; audio-swap target is
refused. Wait20s. At prompt use LOCAL291TEST / Test291only and click Login once.
Wait60s. Leave game open; return generated Client291-SDK-State-*.json.
Only additional state fields are DWORDs at known SDK object9CC320 offsets0/8.
Offset0 is read again to mark observed changes. Predicate/accessor instruction
hashes are checked against the supplied capture before interpreting fields.
Existing bounded code/image reads validate module layout. No password/account
buffers or general memory dump. No additional function-graph expansion.
No SDK/client/xdata replacements, memory patches, hooks, injection, server
changes or process termination. Only report files are written here.
Samples are separate non-atomic reads, not an exact function-call trace.
Equality in a sample is not proof of authenticated login or current branch.
The meanings/initialization of these fields are not yet established.
