@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Read-SDK-State.ps1"
echo.
pause
