/* Own bounded CharacterList133 adapter. Freestanding x64, one Win64 callback.
 * No imports, allocation, file/network I/O, threads or original client bytes.
 * Context and four private work buffers are supplied by the controller. */
#include <stdint.h>
#include <stddef.h>
#define MSABI __attribute__((ms_abi))
#define HIDDEN __attribute__((visibility("hidden")))
enum { HEADER=44, OLD=0x7a7, CORE=0x7c3, NEW=0x86f, OUT=HEADER+16*NEW, WORK=0x9000 };
enum { OK_OLD=1, OK_CORE=2, OK_NEW=3, BAD_FRAME=10, BAD_ACCOUNT=11,
       BAD_CHARACTER=12, BAD_NAME=13, BAD_COUNT=14, BAD_SLOT=15, BUSY=16, BAD_UNWIND=17 };
typedef void (MSABI *Reader)(const unsigned char *);
typedef void *(MSABI *GetModule)(const char *);
typedef void *(MSABI *GetProc)(void *,const char *);
typedef unsigned char (MSABI *AddTable)(void *,uint32_t,uint64_t);
struct BridgeContext {
    Reader reader;
    const uint32_t *account;
    GetModule get_module;
    GetProc get_proc;
    volatile uint32_t unwind,busy,seen,converted,passed,rejected,last_status,last_length,last_characters,completed;
};
extern struct BridgeContext bridge_context HIDDEN;
extern unsigned char bridge_buffers[4][WORK] HIDDEN;
extern unsigned char bridge_function_table[] HIDDEN;
extern uint32_t bridge_function_count HIDDEN;
_Static_assert(sizeof(struct BridgeContext)==72,"CONTEXT_SIZE");
_Static_assert(offsetof(struct BridgeContext,unwind)==32,"CONTEXT_STATS");
_Static_assert(OUT==34588 && 0x77+51*30==0x671 && 0x671+51*10==NEW,"291_LAYOUT");
static uint16_t u16(const unsigned char *p){return (uint16_t)p[0]|(uint16_t)p[1]<<8;}
static uint32_t u32(const unsigned char *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void copy(unsigned char *d,const unsigned char *s,unsigned n){for(unsigned i=0;i<n;i++)d[i]=s[i];}

/* The callback receives one decoded packet, just like the original callback.
 * The socket decoder owns framing. Only the three exact complete layouts are
 * accepted; declared lengths and every consumed count/index are checked here. */
static unsigned convert(const unsigned char *p,unsigned char *out,uint32_t account,unsigned *characters){
    unsigned length=u16(p+2),stride,shift,prefix,appearance,limit,kind;
    if(u16(p)!=0xb7e2 || u16(p+4)!=133)return BAD_FRAME;
    if(length==HEADER+16*OLD){stride=OLD;shift=0;prefix=0x4f;appearance=0x5d1;limit=47;kind=OK_OLD;}
    else if(length==HEADER+16*CORE){stride=CORE;shift=28;prefix=0x6b;appearance=0x5ed;limit=47;kind=OK_CORE;}
    else if(length==OUT){stride=NEW;shift=0;prefix=0x77;appearance=0x671;limit=51;kind=OK_NEW;}
    else return BAD_FRAME;
    if(!account || account>0x7fffffffU/16)return BAD_ACCOUNT;
    unsigned occupied=0,count=0;
    /* Validate the whole source before copying anything into client models. */
    for(unsigned row=0;row<16;row++){
        const unsigned char *s=p+HEADER+row*stride;uint32_t id=u32(s);
        if(!id)continue;
        unsigned bit=1U<<(id&15);
        if(id>0x7fffffffU || id/16!=account || (occupied&bit))return BAD_CHARACTER;
        occupied|=bit;count++;
        unsigned name=kind==OK_NEW?0x2f:0x27,terminated=0;
        for(unsigned j=0;j<17;j++)if(!s[name+j])terminated=1;
        if(!terminated)return BAD_NAME;
        unsigned eq=s[prefix-2],ap=s[prefix-1];
        if(eq>limit || ap>limit)return BAD_COUNT;
        uint64_t used=0;
        for(unsigned j=0;j<eq;j++){
            unsigned slot=u16(s+prefix+j*30+24);
            if(slot>=limit || (used&(UINT64_C(1)<<slot)))return BAD_SLOT;
            used|=UINT64_C(1)<<slot;
        }
        used=0;
        for(unsigned j=0;j<ap;j++){
            unsigned slot=u16(s+appearance+j*10);
            if(slot>=limit || (used&(UINT64_C(1)<<slot)))return BAD_SLOT;
            used|=UINT64_C(1)<<slot;
        }
    }
    for(unsigned i=0;i<OUT;i++)out[i]=0;
    copy(out,p,HEADER);out[2]=(unsigned char)OUT;out[3]=(unsigned char)(OUT>>8);
    for(unsigned row=0;row<16;row++){
        const unsigned char *s=p+HEADER+row*stride;unsigned char *d=out+HEADER+row*NEW;
        if(!u32(s))continue;
        if(kind==OK_NEW){copy(d,s,NEW);continue;}
        copy(d,s,12);                    /* ID and actual native time. */
        copy(d+0x14,s+0x0c,0x34);       /* style, level, name, honor. */
        if(kind==OK_CORE){
            copy(d+0x48,s+0x40,4);       /* actual existing page field. */
            copy(d+0x4c,s+0x44,24);      /* six actual outfit values. */
        }
        /* New second time and seventh outfit stay neutral zero. */
        copy(d+0x68,s+0x40+shift,8);     /* Alz. */
        copy(d+0x70,s+0x48+shift,5);     /* World and packed position. */
        d[0x75]=s[prefix-2];d[0x76]=s[prefix-1];
        copy(d+0x77,s+prefix,(unsigned)d[0x75]*30);
        copy(d+0x671,s+appearance,(unsigned)d[0x76]*10);
    }
    *characters=count;return kind;
}

void MSABI __attribute__((aligned(16))) client291_characterlist(const unsigned char *packet){
    struct BridgeContext *c=&bridge_context;
    __atomic_fetch_add(&c->seen,1,__ATOMIC_RELAXED);
    c->last_length=u16(packet+2);
    unsigned expected=0;
    if(__atomic_compare_exchange_n(&c->unwind,&expected,1,0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE)){
        void *module=c->get_module("ntdll.dll");
        AddTable add=module?(AddTable)c->get_proc(module,"RtlAddFunctionTable"):(AddTable)0;
        unsigned good=add && add(bridge_function_table,bridge_function_count,
                                (uint64_t)(uintptr_t)c-0x4000);
        __atomic_store_n(&c->unwind,good?2:3,__ATOMIC_RELEASE);
    }
    while(__atomic_load_n(&c->unwind,__ATOMIC_ACQUIRE)==1)__asm__ __volatile__("pause");
    if(c->unwind!=2){c->last_status=BAD_UNWIND;__atomic_fetch_add(&c->rejected,1,__ATOMIC_RELAXED);return;}
    unsigned lease=4;
    for(unsigned i=0;i<4;i++){
        unsigned bit=1U<<i;
        if(!(__atomic_fetch_or(&c->busy,bit,__ATOMIC_ACQ_REL)&bit)){lease=i;break;}
    }
    if(lease==4){c->last_status=BUSY;__atomic_fetch_add(&c->rejected,1,__ATOMIC_RELAXED);return;}
    unsigned characters=0;
    unsigned status=convert(packet,bridge_buffers[lease],*c->account,&characters);
    c->last_status=status;c->last_characters=characters;
    if(status<=OK_NEW){
        if(status==OK_NEW)__atomic_fetch_add(&c->passed,1,__ATOMIC_RELAXED);
        else __atomic_fetch_add(&c->converted,1,__ATOMIC_RELAXED);
        /* Original reader consumes/copies the entire packet synchronously. */
        c->reader(bridge_buffers[lease]);
        __atomic_fetch_add(&c->completed,1,__ATOMIC_RELAXED);
    }else __atomic_fetch_add(&c->rejected,1,__ATOMIC_RELAXED);
    __atomic_fetch_and(&c->busy,~(1U<<lease),__ATOMIC_RELEASE);
}
