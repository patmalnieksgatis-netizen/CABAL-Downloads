V4.6 WORLD FORMATA DIAGNOSTIKA; WORLD DATI NETIEK PIELIETOTI

Merks: noteikt ienakosa World142 bloka formatu, pirms klienta World lasitajs
izmanto nepareizo indeksu255 un saboja atminu. Sis nav World ieiesanas labojums.
Izmanto stradajoso V4.5 Login/CH/telu adapteri un dabisko SDK inicializaciju.
Vieniga jauna Main izmaina:142 callback registracija uz savu metadatu parbaudi.
SDK World/resource/file hooks paliek vieta; sakotnejo World reader si versija
neizsauc, tadel si meginajuma World ieiesana ir apzinati aptureta.
Nemainam klienta originalos failus, serveri vai SQL.

1. Aizver CABAL; testa VM192.168.56.101 darbojas.
2. Palaid Palaist-291-WorldProfile-v4_6.cmd ar administratora tiesibam.
3. Ielogojies ar to pasu testa kontu, izvelies CH un telu.
4. Spied ieiet pasaule vienu reizi. Gaidi WORLD_DATI_NOLASITI.
5. Atsuti Downloads/Client291-LoginStart-v4_6-*.json vai konsoles izvadi.

Izvada tikai garumu, skaititajus, ierakstu indeksus, formata kandidatu maskas
un ipasnieka atbilstibas boolean. Neizvada vardus, konta/tela ID, paroles,
atslegas, sesijas laukus vai paketes/atminas saturu. Avota pakete netiek mainita.
Masks ir kandidati, nevis pilna formata saderibas pieradijums.

NameMask biti0..4: native2F4E, lib2F87, Core2F9B,2912FB1,13530/35B9.
SourceShapeMask biti0..2: native/lib/Core kandidata varda un pirmo piecu
mainigo grupu apjomu/slotu parbaudes; velakas grupas si parbaude neapliecina.
NativeCounts/CoreCounts: equipment,locked,inventory,skills,quickslots.
TargetCounts: equipment,presetEquipment,extra9B,mask,extraEquipment,locked,
inventory,vehicle,skills,quickslots,mercenary.
RecordIndices: piecu v291 lasito iestatijumu ierakstu pirmais baits;256 nozime
ka atbilstošais bloks neietilpst avota pakete, nevis no paketes nolasitu indeksu.
Status1: metadati nolasiti, World apstrade aptureta;10: galvene/apjoms neatbilst;
17: Windows unwind registracija neizdevas. Unwind2 ir registresanas panakums.
Complete true un para Generation apstiprina stabilu nolasijumu.

Own C sources/build metadata are included for reproducibility in CABAL-EP45.
The ZIP contains no original game/client/SDK binaries or private evidence.
Local own-code ABI/guard-page and actual registration guards pass; actual
Windows V4.6 execution and incoming142 source profile remain unverified.
