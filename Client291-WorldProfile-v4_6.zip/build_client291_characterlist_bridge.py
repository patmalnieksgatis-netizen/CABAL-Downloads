"""Build our freestanding Win64-ABI callback; no supplied game code is linked."""
import hashlib
import json
import subprocess
import struct
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
def run(args):return subprocess.check_output(args,text=True)
def unwind_info(body):
    """Strictly encode this compiler's simple Win64 prologue; reject surprises."""
    at=0;codes=[];last=0
    while at<len(body):
        b=body[at:];reg=None;size=0
        if 0x50<=b[0]<=0x57:reg=b[0]-0x50;size=1
        elif len(b)>=2 and b[0]==0x41 and 0x50<=b[1]<=0x57:reg=b[1]-0x50+8;size=2
        if reg is not None:
            assert reg in (3,5,6,7,12,13,14,15),'UNSUPPORTED_PUSH'
            at+=size;codes.append(bytes((at,reg<<4)));last=at;continue
        if b[:3] in (b'\x48\x83\xec',b'\x48\x81\xec'):
            size=4 if b[1]==0x83 else 7
            amount=b[3] if size==4 else struct.unpack_from('<I',b,3)[0]
            assert amount%8==0 and 8<=amount<=128,'UNSUPPORTED_STACK_ALLOCATION'
            at+=size;codes.append(bytes((at,((amount//8-1)<<4)|2)));last=at;continue
        if len(b)>=3 and b[0] in (0x48,0x49,0x4c,0x4d) and b[1] in (0x89,0x8b) and b[2]>=0xc0:
            at+=3;continue
        break
    assert last<=255 and len(codes)<=255
    out=bytes((1,last,len(codes),0))+b''.join(reversed(codes))
    return out+bytes((-len(out))%4)
def main():
    source=ROOT/'tools/client291_characterlist_bridge.c'
    with tempfile.TemporaryDirectory(prefix='client291-bridge-build-') as name:
        tmp=Path(name);obj=tmp/'bridge.o';elf=tmp/'bridge.elf';binary=tmp/'bridge.bin';link=tmp/'bridge.ld'
        link.write_text('ENTRY(client291_characterlist)\nSECTIONS { . = 0; .text : { *(.text*) } .rodata : { *(.rodata*) } /DISCARD/ : { *(.comment*) *(.note*) *(.eh_frame*) } ASSERT(. < 0x3000,"CODE_TOO_LARGE") bridge_function_table = 0x3000; bridge_function_count = 0x3ff0; bridge_context = 0x4000; bridge_buffers = 0x5000; }\n')
        run(['gcc','-std=c11','-m64','-mabi=ms','-Os','-ffreestanding','-fPIE','-fno-builtin','-fno-stack-protector','-fno-unwind-tables','-fno-asynchronous-unwind-tables','-fno-tree-loop-distribute-patterns','-mno-red-zone','-maccumulate-outgoing-args','-c',str(source),'-o',str(obj)])
        run(['ld','-nostdlib','-T',str(link),str(obj),'-o',str(elf)])
        assert not run(['nm','-u',str(elf)]).strip(),'UNRESOLVED_EXTERNAL'
        assert 'There are no relocations' in run(['readelf','-r',str(elf)]),'RUNTIME_RELOCATIONS'
        entry=None
        for line in run(['nm','-n',str(elf)]).splitlines():
            fields=line.split()
            if len(fields)==3 and fields[2]=='client291_characterlist':entry=int(fields[0],16)
        assert entry is not None and entry<0x4000
        run(['objcopy','-O','binary','--only-section=.text','--only-section=.rodata',str(elf),str(binary)])
        body=bytearray(binary.read_bytes());assert 0<len(body)<0x3000
        functions=[]
        for line in run(['nm','-S','-n','--defined-only',str(elf)]).splitlines():
            fields=line.split()
            if len(fields)==4 and fields[2] in ('t','T'):
                functions.append((int(fields[0],16),int(fields[1],16),fields[3]))
        assert 1<=len(functions)<=16
        infos=[unwind_info(body[at:at+size]) for at,size,_ in functions]
        body.extend(bytes(0x3ff4-len(body)));cursor=0x3100;details=[]
        for i,((at,size,name),info) in enumerate(zip(functions,infos)):
            assert cursor+len(info)<0x3ff0
            struct.pack_into('<III',body,0x3000+i*12,at,at+size,cursor)
            body[cursor:cursor+len(info)]=info
            details.append(dict(name=name,start=at,end=at+size,unwind_rva=cursor,unwind_hex=info.hex()));cursor+=len(info)
        struct.pack_into('<I',body,0x3ff0,len(functions))
        destination=ROOT/'protocol/generated/client291-characterlist-bridge.bin';destination.write_bytes(body)
        metadata=dict(status='OWN_FREESTANDING_CODE_WINDOWS_UNVERIFIED',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),entry_rva=entry,context_rva=0x4000,context_bytes=72,buffers_rva=0x5000,allocation_bytes=0x30000,code_protect_bytes=0x4000,workspace_bytes=0x9000,workspace_count=4,target_packet_bytes=34588,unwind_functions=details,original_game_code_linked=False,imports=[],runtime_relocations=[])
        (ROOT/'protocol/generated/client291-characterlist-bridge.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata))
if __name__=='__main__':main()
