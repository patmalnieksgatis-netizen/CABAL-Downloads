/* Own World142 format observation gate. Reads bounded numeric metadata only.
 * Never calls the original World reader, changes packets, exports names/IDs,
 * opens files/sockets or alters any game/SDK state. Not a World translator. */
#include <stdint.h>
#include <stddef.h>
#define MSABI __attribute__((ms_abi))
#define INLINE static inline __attribute__((always_inline))
#define HIDDEN __attribute__((visibility("hidden")))
typedef void *(MSABI *GetModule)(const char *);
typedef void *(MSABI *GetProc)(void *,const char *);
typedef unsigned char (MSABI *AddTable)(void *,uint32_t,uint64_t);
struct Context {
    GetModule get_module; GetProc get_proc; const uint32_t *account;
    volatile uint32_t unwind,busy,seen,status,bytes,magic,opcode,owner_matches;
    volatile uint32_t native_counts[5],core_counts[5],target_counts[11];
    volatile uint32_t indices[5],name_lengths[5],name_mask,source_shape_mask,generation,hold;
};
extern struct Context bridge_context HIDDEN;
extern unsigned char bridge_function_table[] HIDDEN;
extern uint32_t bridge_function_count HIDDEN;
_Static_assert(offsetof(struct Context,unwind)==24,"STATS_OFFSET");
_Static_assert(sizeof(struct Context)==200,"CONTEXT_BYTES");
INLINE uint16_t u16(const unsigned char *p){return (uint16_t)p[0]|(uint16_t)p[1]<<8;}
INLINE uint32_t u32(const unsigned char *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
INLINE unsigned name_ok(const unsigned char *p,unsigned n,unsigned at){
    if(at>=n)return 0;
    unsigned count=p[at];
    if(count<2 || count>17 || count>n-at)return 0;
    for(unsigned j=1;j<count;j++)if(p[at+j]<32 || p[at+j]==127)return 0;
    return 1;
}
/* Candidate evidence only: verifies name, first variable groups and slot bounds.
 * Later World state is deliberately not declared compatible by these checks. */
INLINE unsigned source_shape(const unsigned char *p,unsigned n,unsigned tail,unsigned shift){
    if(!name_ok(p,n,tail))return 0;
    unsigned eq=p[0x356],locked=p[0x357+shift],inv=u16(p+0x358+shift),
             skills=u16(p+0x35c+shift),quick=u16(p+0x35e + shift);
    if(eq>47 || locked>47 || inv>522 || skills>628 || quick>160)return 0;
    unsigned cursor=tail+p[tail];
    for(unsigned group=0;group<5;group++){
        unsigned count,stride,slot,cap;
        if(!group){count=eq;stride=30;slot=24;cap=47;}
        else if(group==1){count=locked;stride=2;slot=0;cap=47;}
        else if(group==2){count=inv;stride=30;slot=24;cap=522;}
        else if(group==3){count=skills;stride=5;slot=3;cap=628;}
        else {count=quick;stride=4;slot=0;cap=0;}
        if(cursor>n || count>(n-cursor)/stride)return 0;
        if(cap)for(unsigned j=0;j<count;j++)if(u16(p+cursor+j*stride+slot)>=cap)return 0;
        cursor+=count*stride;
    }
    return 1;
}
void MSABI __attribute__((aligned(16))) client291_worldgate(const unsigned char *p){
    struct Context *c=&bridge_context;
    __atomic_fetch_add(&c->seen,1,__ATOMIC_RELAXED);
    unsigned expected=0;
    if(__atomic_compare_exchange_n(&c->unwind,&expected,1,0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE)){
        void *m=c->get_module("ntdll.dll");
        AddTable add=m?(AddTable)c->get_proc(m,"RtlAddFunctionTable"):(AddTable)0;
        unsigned good=add && add(bridge_function_table,bridge_function_count,(uint64_t)(uintptr_t)c-0x4000);
        __atomic_store_n(&c->unwind,good?2:3,__ATOMIC_RELEASE);
    }
    while(__atomic_load_n(&c->unwind,__ATOMIC_ACQUIRE)==1)__asm__ __volatile__("pause");
    if(c->unwind!=2){c->status=17;return;}
    if(__atomic_exchange_n(&c->busy,1,__ATOMIC_ACQ_REL))return;
    __atomic_fetch_add(&c->generation,1,__ATOMIC_ACQ_REL);
    /* Callback framing is owned by the native decoder. Check all later reads. */
    unsigned n=u32(p+2);c->bytes=n;c->magic=u16(p);c->opcode=u16(p+6);c->status=10;
    c->owner_matches=0;c->name_mask=0;c->source_shape_mask=0;
    for(unsigned i=0;i<5;i++){c->native_counts[i]=0;c->core_counts[i]=0;c->indices[i]=256;c->name_lengths[i]=0;}
    for(unsigned i=0;i<11;i++)c->target_counts[i]=0;
    if(c->magic==0xc8f3 && c->opcode==142 && n>=0x37c && n<=0x4d000){
        uint32_t id=u32(p+0xaa),account=*c->account;
        c->owner_matches=account && id && id<=0x7fffffffU && id/16==account;
        c->native_counts[0]=p[0x356];c->native_counts[1]=p[0x357];
        c->native_counts[2]=u16(p+0x358);c->native_counts[3]=u16(p+0x35c);c->native_counts[4]=u16(p+0x35e);
        c->core_counts[0]=p[0x356];c->core_counts[1]=p[0x358];
        c->core_counts[2]=u16(p+0x359);c->core_counts[3]=u16(p+0x35d);c->core_counts[4]=u16(p+0x35f);
        c->target_counts[0]=p[0x356];c->target_counts[1]=p[0x357];c->target_counts[2]=p[0x358];
        c->target_counts[3]=u32(p+0x359);c->target_counts[4]=p[0x35d];c->target_counts[5]=p[0x35e];
        c->target_counts[6]=u16(p+0x35f);c->target_counts[7]=u16(p+0x361);
        c->target_counts[8]=u16(p+0x363);c->target_counts[9]=u16(p+0x365);c->target_counts[10]=u32(p+0x367);
        if(n>=0x2fa9)for(unsigned i=0;i<5;i++)c->indices[i]=p[0x2edc+i*41];
        for(unsigned i=0;i<5;i++){
            unsigned at=i==0?0x2f4e:i==1?0x2f87:i==2?0x2f9b:i==3?0x2fb1:0x35b9;
            if(name_ok(p,n,at))c->name_lengths[i]=p[at];
            if(name_ok(p,n,at))c->name_mask|=1U<<i;
            if(i<3 && source_shape(p,n,at,i?1:0))c->source_shape_mask|=1U<<i;
        }
        c->status=1; /* WORLD_CAPTURED_NOT_APPLIED, regardless of candidate mask. */
    }
    __atomic_fetch_add(&c->generation,1,__ATOMIC_RELEASE);
    __atomic_store_n(&c->busy,0,__ATOMIC_RELEASE);
    /* Controller observes a complete snapshot, then closes only its owned child.
     * Keep this receive callback from advancing to subsequent World messages. */
    while(__atomic_load_n(&c->hold,__ATOMIC_ACQUIRE))__asm__ __volatile__("pause");
}
