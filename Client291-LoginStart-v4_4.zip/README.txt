Client291 LoginStart v4.4 - native EP36 channel public build profile.
Close CABAL. Keep test VM192.168.56.101 running. Extract ALL files to a NEW folder.
Run Palaist-291-v4_4.cmd as administrator. Only F:\CABAL_291_TEST and pinned originals.
Preserves V4.3 startup/Login/3383/completed17 compatibility.
Adds one guarded C2S102 CALL->MOV EAX620313112, the current user-read native profile.
Only request DWORD+18 changes; packet header/session/link fields remain original.
Global resource/build state, server checks/configuration, passwords and SQL remain unchanged.
Native Login and World logs report NonClient during the supplied V4.3 CH attempt.
No game-file/server/SQL changes or installation. Close game to discard RAM edits.
All5 actual pre-edit integrity digests required; existing natural SDK worker retained.
When prompted use test account inside game, choose CH, then character and world if available.
No passwords in console. No account/password buffers or packet payload collection/upload.
REPORT= shows Downloads\Client291-LoginStart-v4_4-*.json.
Actual Windows V4.4/CH/character/world result remains pending.
