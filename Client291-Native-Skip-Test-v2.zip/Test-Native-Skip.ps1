# Reversible native-audio comparison. Uses only the user's existing hash-pinned DLL.
param([ValidateSet('Observe','Inspect','ApplyOnly','Restore')][string]$Action='Observe')
& {
    $ErrorActionPreference='Stop'
    try {
    if(![Environment]::Is64BitProcess){throw 'USE_X64_POWERSHELL'}
    $root=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('F:\CABAL_291_TEST')
    $bin=Join-Path $root 'Bin\x64'
    $exe=Join-Path $bin 'CabalMain.exe'
    $target=Join-Path $bin 'libogg.dll'
    $audio=Join-Path $bin 'libogg_d_64bit.dll'
    $state=Join-Path $root '.client291-native-skip-v2'
    $backup=Join-Path $state 'original-libogg.dll'
    $original='ceafa8291dcf090856a215285114270fea1a8978bc2d2b26b33bcb7b3ac5c2a9'
    $native='377c3572d658c7eb4e0dd9261c498cb6b0849ee54062cb426350b2745c1f85ac'
    function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash}
    function Need([bool]$ok,[string]$message){if(!$ok){throw $message}}
    function Swap([string]$source,[string]$from,[string]$to){
        Need ((Hash $target) -eq $from) 'TARGET_CHANGED_BEFORE_SWAP'
        $id=[Guid]::NewGuid().ToString('N')
        $temp=Join-Path $bin ('.native-audio-'+$id+'.tmp')
        $saved=Join-Path $state ('before-'+$id+'.dll')
        try {
            Copy-Item -LiteralPath $source -Destination $temp
            Need ((Hash $temp) -eq $to -and (Hash $target) -eq $from) 'SWAP_PREFLIGHT_DIFFERS'
            [IO.File]::Replace($temp,$target,$saved)
            if((Hash $target) -ne $to -or (Hash $saved) -ne $from){
                $rejected=Join-Path $state ('rejected-'+$id+'.dll')
                [IO.File]::Replace($saved,$target,$rejected)
                throw 'SWAP_VERIFICATION_FAILED; PREVIOUS_TARGET_RESTORED'
            }
        } finally {if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp}}
    }
    $current=Hash $target
    Need ($current -in @($original,$native)) 'UNKNOWN_LIBOGG; NOTHING_CHANGED'
    if($Action -ne 'Inspect'){
        Need (@(Get-Process -Name CabalMain -ErrorAction SilentlyContinue).Count -eq 0) 'VISPIRMS_AIZVER_CABAL_LOGUS; NOTHING_STOPPED'
    }
    if($Action -eq 'Restore'){
        if($current -eq $original){'ORIGINAL_OGG_ALREADY_PRESENT';return}
        Need ((Hash $backup) -eq $original) 'ORIGINAL_BACKUP_DIFFERS; NOTHING_CHANGED'
        Swap $backup $native $original
        'ORIGINAL_PLAYCABAL_OGG_RESTORED; MAIN_D3D_SERVER_UNCHANGED'
        return
    }
    $checks=@{
        'CabalMain.exe'='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
        'd3d9.dll'='216058f9320d0667d551f4cea840ee539396449ef8c8e89fe481e4f0ddb628ae'
        'libogg_d_64bit.dll'=$native
        'libvorbis.dll'='0be764a1060e597344b8ca5e0bc5492cd739f2feac3b63915cfecb531fe2b330'
    }
    foreach($name in $checks.Keys){
        Need ((Hash (Join-Path $bin $name)) -eq $checks[$name]) ('REQUIRED_ORIGINAL_FILE_DIFFERS='+$name)
    }
    if(Test-Path -LiteralPath $state){Need ((Hash $backup) -eq $original) 'BACKUP_DIFFERS; NOTHING_CHANGED'}
    else{Need ($current -eq $original) 'NATIVE_SKIP_WITHOUT_ORIGINAL_BACKUP; NOTHING_CHANGED'}
    if($Action -eq 'Inspect'){'NATIVE_SKIP_PREFLIGHT_OK; NO_CLIENT_CHANGES';return}
    if(!(Test-Path -LiteralPath $state)){
        New-Item -ItemType Directory -Path $state | Out-Null
        Copy-Item -LiteralPath $target -Destination $backup
        Need ((Hash $backup) -eq $original) 'BACKUP_COPY_DIFFERS'
    }
    if($current -ne $native){Swap $audio $original $native}
    'NATIVE_SKIP_TEST_APPLIED; PUBLISHER_OGG_PRESERVED_IN_BACKUP'
    'BACKUP='+$backup
    'RESTORE_COMMAND=powershell.exe -NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Action Restore'
    if($Action -eq 'ApplyOnly'){return}
    $checks['libogg.dll']=$native
    if (!('Client291NativeSkipRead' -as [type])) {
        Add-Type @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class Client291NativeSkipRead {
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr h, IntPtr a, byte[] b, UIntPtr n, out UIntPtr got);
    public static byte[] Read(IntPtr h, long a, int n) {
        if (a<65536 || a>0x7fffffffffffL || n<1 || n>256) throw new Exception("READ_BOUNDS");
        byte[] b=new byte[n]; UIntPtr got;
        if (!ReadProcessMemory(h,new IntPtr(a),b,new UIntPtr((uint)n),out got))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        if (got.ToUInt64()!=(ulong)n) throw new Exception("PARTIAL_READ");
        return b;
    }
    public static uint U32(IntPtr h,long a) { return BitConverter.ToUInt32(Read(h,a,4),0); }
    public static string Arg(IntPtr h,int index) {
        if(index<1 || index>3)throw new Exception("ARG_INDEX_BOUNDS");
        uint count=U32(h,0x1412844c8);
        if(count<4 || count>64)throw new Exception("ARGC_DIFFERS");
        long table=BitConverter.ToInt64(Read(h,0x1412844d0,8),0);
        long text=BitConverter.ToInt64(Read(h,checked(table+index*8),8),0);
        byte[] value=new byte[32];int length=0;
        for(;length<32;length++){
            byte next=Read(h,checked(text+length),1)[0];
            if(next==0)return System.Text.Encoding.ASCII.GetString(value,0,length);
            if(next<32 || next>126)throw new Exception("UNEXPECTED_ARG_TEXT");
            value[length]=next;
        }
        throw new Exception("ARG_TOO_LONG");
    }
    public static string Mode(IntPtr h) {
        long p=BitConverter.ToInt64(Read(h,0x14120f7a0,8),0);
        if(p<65536 || p>0x7fffffffffffL) return "UNINITIALIZED";
        byte[] b=Read(h,p,12);uint sum=b[4],value=0;
        for(int i=0;i<4;i++){sum+=b[i];value|=(uint)(b[i]^b[4])<<(i*8);}
        return sum==BitConverter.ToUInt32(b,8)?value.ToString():"CHECKSUM_DIFFERS";
    }
    public static string Text(IntPtr h,long a) {
        byte[] b=Read(h,a,32); ulong n=BitConverter.ToUInt64(b,16),cap=BitConverter.ToUInt64(b,24);
        if(n==0) return "EMPTY";
        if(n>255 || cap<n || cap>4096) return "UNSUPPORTED_STRING";
        string s=System.Text.Encoding.ASCII.GetString(Read(h,cap<16?a:BitConverter.ToInt64(b,0),(int)n));
        return System.Text.RegularExpressions.Regex.IsMatch(s,@"^[A-Za-z0-9._:-]{1,255}$")?s:"UNEXPECTED_ENDPOINT_TEXT";
    }
}
'@
    }
    function Profile {
        $before=[Client291NativeSkipRead]::Mode($h)
        $source=[Client291NativeSkipRead]::Text($h,0x140d94f78)
        $port=[Client291NativeSkipRead]::U32($h,0x140dd5b08)
        $cache=[Client291NativeSkipRead]::Text($h,0x14126ad10)
        $cachePort=[Client291NativeSkipRead]::U32($h,0x14126ad30)
        $after=[Client291NativeSkipRead]::Mode($h)
        [ordered]@{ ModeBefore=$before; SourceIP=$source; SourcePort=$port;
            CachedIP=$cache; CachedPort=$cachePort; ModeAfter=$after;
            NativeVersionCell=[Client291NativeSkipRead]::U32($h,0x14120f7b0) } | ConvertTo-Json -Compress
    }
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$exe; $start.Arguments='breaklee skip gameguard'
    $start.WorkingDirectory=$bin; $start.UseShellExecute=$false
    'LAUNCH_ARGS='+$start.Arguments
    $game=[Diagnostics.Process]::Start($start)
    try {
        $h=$game.Handle
        'TEST_PID='+$game.Id
        'GAIDI_20_SEKUNDES; LOGIN_PAGAIDAM_NESPIED; ENTER_NAV_JASPIEZ'
        $until=[DateTime]::UtcNow.AddSeconds(20)
        while([DateTime]::UtcNow -lt $until){
            if($game.HasExited){throw ('TEST_CLIENT_EXITED='+$game.ExitCode)}
            Start-Sleep -Milliseconds 250
        }
        if([Text.Encoding]::ASCII.GetString([Client291NativeSkipRead]::Read($h,0x140000000,2)) -cne 'MZ'){
            throw 'EXPECTED_IMAGE_BASE_DIFFERS'
        }
        $entry=[Client291NativeSkipRead]::Read($h,0x14069afd8,5)
        'ENDPOINT_ENTRY_HEX='+[BitConverter]::ToString($entry)
        if([BitConverter]::ToString($entry) -cne '48-89-5C-24-08'){
            throw 'NATIVE_ENDPOINT_STILL_DETOURED; GAME_LEFT_OPEN; RESTORE_COMMAND_PRINTED_ABOVE'
        }
        $arg1=[Client291NativeSkipRead]::Arg($h,1)
        $arg2=[Client291NativeSkipRead]::Arg($h,2)
        $arg3=[Client291NativeSkipRead]::Arg($h,3)
        if($arg1 -cne 'breaklee' -or $arg2 -cne 'skip' -or $arg3 -cne 'gameguard'){
            throw 'BUILTIN_SKIP_ARGUMENTS_NOT_VERIFIED; GAME_LEFT_OPEN'
        }
        $sha=[Security.Cryptography.SHA256]::Create()
        try{$skipHash=[BitConverter]::ToString($sha.ComputeHash([Client291NativeSkipRead]::Read($h,0x1402b5da0,68))).Replace('-','').ToLowerInvariant()}
        finally{$sha.Dispose()}
        if($skipHash -cne '81e265bc46f676d645228fbaf1347e880f57be7cc72343a7f55339e9a7fca9b5'){
            throw 'NATIVE_SKIP_HELPER_DIFFERS; GAME_LEFT_OPEN'
        }
        'BUILTIN_SKIP_ARGUMENTS_VERIFIED='+$arg1+' '+$arg2+' '+$arg3
        'NATIVE_SKIP_HELPER_ORIGINAL'
        'NATIVE_ENDPOINT_ENTRY_CONFIRMED'
        'PHASE=BEFORE_REQUESTED_LOGIN' 
        $previous=Profile
        $previous
        'TAGAD_LOGIN: ID=LOCAL291TEST; PAROLE=Test291only; SPIED_LOGIN_VIENU_REIZI'
        'NOVEROSANA_60_SEKUNDES; ENTER_NAV_JASPIEZ; ATSTAJ_SPELI_ATVERTU'
        $until=[DateTime]::UtcNow.AddSeconds(60)
        $changes=0
        $seen=New-Object 'System.Collections.Generic.HashSet[string]' 
        while([DateTime]::UtcNow -lt $until){
            if($game.HasExited){throw ('TEST_CLIENT_EXITED='+$game.ExitCode)}
            $current=Profile
            if($current -cne $previous){
                'PROFILE_CHANGE_UTC='+[DateTime]::UtcNow.ToString('o')
                $current
                $previous=$current
                $changes++
                if($changes -ge 32){'CHANGE_LIMIT_REACHED';break}
            }
            foreach($line in @(& "$env:SystemRoot\System32\netstat.exe" -ano -p TCP)){
                $fields=$line.Trim() -split '\s+'
                if($fields.Count -eq 5 -and $fields[0] -eq 'TCP' -and
                   $fields[4] -eq [string]$game.Id -and $fields[2] -eq '192.168.56.101:35003'){
                    $row=$fields -join ' '
                    if($seen.Add($row)){'GAME_CLONE_TCP='+$row}
                }
            }
            Start-Sleep -Milliseconds 500
        }
        if($game.HasExited){throw ('TEST_CLIENT_EXITED='+$game.ExitCode)}
        if(!$seen.Count){'NO_GAME_CLONE_TCP_ROW_OBSERVED; SHORT_CONNECTIONS_MAY_BE_MISSED'}
        'PHASE=AFTER_REQUESTED_LOGIN' 
        Profile
        foreach($name in $checks.Keys){
            if((Get-FileHash -LiteralPath (Join-Path $bin $name) -Algorithm SHA256).Hash -ne $checks[$name]){
                throw ('DISK_FILE_CHANGED_DURING_OBSERVATION='+$name)
            }
        }
        'NATIVE_SKIP_TEST_COMPLETE; MAIN_D3D_AUDIO_SOURCE_VERIFIED; GAME_LEFT_OPEN; AUTHENTICATION_UNVERIFIED'
    } finally { $game.Dispose() }
    } catch {
        'TEST_ERROR='+$_.Exception.GetBaseException().Message
        'ERROR_LOCATION='+$_.InvocationInfo.PositionMessage
        'GAME_NOT_AUTOMATICALLY_STOPPED; USE_RESTORE_IF_TEST_WAS_APPLIED'
        throw
    }
} | Tee-Object -FilePath (Join-Path $PSScriptRoot ('Client291-Native-Skip-Run-'+(Get-Date -Format yyyyMMdd-HHmmss)+'.txt'))
