@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test-Native-Skip.ps1" -Action Restore
echo.
pause
