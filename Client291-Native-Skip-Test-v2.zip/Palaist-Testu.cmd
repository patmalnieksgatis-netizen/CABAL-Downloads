@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test-Native-Skip.ps1"
echo.
pause
