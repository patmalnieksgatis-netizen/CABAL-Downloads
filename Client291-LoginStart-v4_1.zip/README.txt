Client291 LoginStart v4.1 - isolated runtime candidate; Login/world NOT VERIFIED.
Close CABAL. Extract ALL files into a NEW folder. Run Palaist-291-v4_1.cmd as administrator.
Test VM192.168.56.101:35003 must be running. Only F:\CABAL_291_TEST and pinned original files.
No game-file or server changes. Original files remain. Closing game discards runtime changes.
V4.0 reached the private gate/SDK hooks, but incorrectly waited for the constructor-started checker before Main.
V4.1 keeps that actual Windows-verified gate. It refuses native BAD/uninitialized markers.
Pending is allowed ONLY at verified private entry BEFORE Main, with ALL FIVE actual code digests verified first.
No current/good/bad marker is written; normal SDK constructor/worker completes status after Main runs.
Only affected code digests are recomputed after the guarded native-network/SDK/version edits.
The script waits for natural GOOD before asking you to log in. BAD is never treated as pending/good.
When prompted and Login appears, use your test account, select character and try world entry.
No password in console. No credentials or packet payload collection/upload.
Observes90seconds; REPORT= gives Downloads\Client291-LoginStart-v4_1-*.json path.
On startup failure only its own new child is stopped. No debugger, replacement DLL or injected thread.
Server version282 is a configured profile, not new live readback.
Native pending lifecycle/five-range preflight are NOT Windows-executed for this revision yet.
