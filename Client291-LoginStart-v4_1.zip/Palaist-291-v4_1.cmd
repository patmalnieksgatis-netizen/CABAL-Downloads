@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Client291-LoginStart.ps1" -Action Run
pause
