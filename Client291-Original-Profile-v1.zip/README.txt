Client291 original profile observation (x64 F:\CABAL_291_TEST only).
Close all Cabal windows. Extract ALL files. Double-click Palaist-Nolasisanu.cmd.
Wait20s without Login. At the prompt use LOCAL291TEST / Test291only and click Login once.
Wait60s and leave game open. Return the Client291-Original-Profile-*.txt report and UI error.
Only original Main/Ogg/DXVK hashes accepted. No client-file or process-memory writes,
DLL installation, hooks, injection, process termination or server changes.
A report is written beside this script; extracting/running does not install a fix.
Fields are sampled every500ms; missing transient changes are possible. Snapshots
are separate reads, not atomic. Matching ModeBefore/After does not prove no
intermediate mode change. CachedIP is not a wire destination. No authenticated
login or gameplay claim follows from these fields alone.
