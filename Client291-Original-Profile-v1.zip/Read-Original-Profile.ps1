# Read-only original-client mode/source/cache sampling. No DLL or memory writes.
& {
    $ErrorActionPreference = 'Stop'
    if (![Environment]::Is64BitProcess) { throw 'USE_X64_POWERSHELL' }
    if (Get-Process -Name CabalMain -ErrorAction SilentlyContinue) {
        throw 'Vispirms aizver Cabal speles logus.'
    }
    $exe = 'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe'
    $bin = Split-Path -Parent $exe
    $checks = @{
        'CabalMain.exe'='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
        'libogg.dll'='ceafa8291dcf090856a215285114270fea1a8978bc2d2b26b33bcb7b3ac5c2a9'
        'd3d9.dll'='216058f9320d0667d551f4cea840ee539396449ef8c8e89fe481e4f0ddb628ae'
    }
    foreach ($name in $checks.Keys) {
        if ((Get-FileHash -LiteralPath (Join-Path $bin $name) -Algorithm SHA256).Hash -ne $checks[$name]) {
            throw ('ORIGINAL_FILE_DIFFERS=' + $name)
        }
    }
    if (!('Client291ProfileRead' -as [type])) {
        Add-Type @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class Client291ProfileRead {
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr h, IntPtr a, byte[] b, UIntPtr n, out UIntPtr got);
    public static byte[] Read(IntPtr h, long a, int n) {
        if (a<65536 || a>0x7fffffffffffL || n<1 || n>256) throw new Exception("READ_BOUNDS");
        byte[] b=new byte[n]; UIntPtr got;
        if (!ReadProcessMemory(h,new IntPtr(a),b,new UIntPtr((uint)n),out got))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        if (got.ToUInt64()!=(ulong)n) throw new Exception("PARTIAL_READ");
        return b;
    }
    public static uint U32(IntPtr h,long a) { return BitConverter.ToUInt32(Read(h,a,4),0); }
    public static string Mode(IntPtr h) {
        long p=BitConverter.ToInt64(Read(h,0x14120f7a0,8),0);
        if(p<65536 || p>0x7fffffffffffL) return "UNINITIALIZED";
        byte[] b=Read(h,p,12);uint sum=b[4],value=0;
        for(int i=0;i<4;i++){sum+=b[i];value|=(uint)(b[i]^b[4])<<(i*8);}
        return sum==BitConverter.ToUInt32(b,8)?value.ToString():"CHECKSUM_DIFFERS";
    }
    public static string Text(IntPtr h,long a) {
        byte[] b=Read(h,a,32); ulong n=BitConverter.ToUInt64(b,16),cap=BitConverter.ToUInt64(b,24);
        if(n==0) return "EMPTY";
        if(n>255 || cap<n || cap>4096) return "UNSUPPORTED_STRING";
        string s=System.Text.Encoding.ASCII.GetString(Read(h,cap<16?a:BitConverter.ToInt64(b,0),(int)n));
        return System.Text.RegularExpressions.Regex.IsMatch(s,@"^[A-Za-z0-9._:-]{1,255}$")?s:"UNEXPECTED_ENDPOINT_TEXT";
    }
}
'@
    }
    function Profile {
        $before=[Client291ProfileRead]::Mode($h)
        $source=[Client291ProfileRead]::Text($h,0x140d94f78)
        $port=[Client291ProfileRead]::U32($h,0x140dd5b08)
        $cache=[Client291ProfileRead]::Text($h,0x14126ad10)
        $cachePort=[Client291ProfileRead]::U32($h,0x14126ad30)
        $after=[Client291ProfileRead]::Mode($h)
        [ordered]@{ ModeBefore=$before; SourceIP=$source; SourcePort=$port;
            CachedIP=$cache; CachedPort=$cachePort; ModeAfter=$after } | ConvertTo-Json -Compress
    }
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$exe; $start.Arguments='breaklee'
    $start.WorkingDirectory=$bin; $start.UseShellExecute=$false
    $game=[Diagnostics.Process]::Start($start)
    try {
        $h=$game.Handle
        'TEST_PID='+$game.Id
        'GAIDI_20_SEKUNDES; LOGIN_PAGAIDAM_NESPIED; ENTER_NAV_JASPIEZ'
        $until=[DateTime]::UtcNow.AddSeconds(20)
        while([DateTime]::UtcNow -lt $until){
            if($game.HasExited){throw ('ORIGINAL_CLIENT_EXITED='+$game.ExitCode)}
            Start-Sleep -Milliseconds 250
        }
        if([Text.Encoding]::ASCII.GetString([Client291ProfileRead]::Read($h,0x140000000,2)) -cne 'MZ'){
            throw 'EXPECTED_IMAGE_BASE_DIFFERS'
        }
        'PHASE=BEFORE_REQUESTED_LOGIN'
        $previous=Profile
        $previous
        'TAGAD_LOGIN: ID=LOCAL291TEST; PAROLE=Test291only; SPIED_LOGIN_VIENU_REIZI'
        'NOVEROSANA_60_SEKUNDES; ENTER_NAV_JASPIEZ; ATSTAJ_SPELI_ATVERTU'
        $until=[DateTime]::UtcNow.AddSeconds(60)
        $changes=0
        while([DateTime]::UtcNow -lt $until){
            if($game.HasExited){throw ('ORIGINAL_CLIENT_EXITED='+$game.ExitCode)}
            $current=Profile
            if($current -cne $previous){
                'PROFILE_CHANGE_UTC='+[DateTime]::UtcNow.ToString('o')
                $current
                $previous=$current
                $changes++
                if($changes -ge 32){'CHANGE_LIMIT_REACHED';break}
            }
            Start-Sleep -Milliseconds 500
        }
        if($game.HasExited){throw ('ORIGINAL_CLIENT_EXITED='+$game.ExitCode)}
        'PHASE=AFTER_REQUESTED_LOGIN'
        Profile
        foreach($name in $checks.Keys){
            if((Get-FileHash -LiteralPath (Join-Path $bin $name) -Algorithm SHA256).Hash -ne $checks[$name]){
                throw ('DISK_FILE_CHANGED_DURING_OBSERVATION='+$name)
            }
        }
        'READ_ONLY_COMPLETE; ORIGINAL_FILES_VERIFIED; GAME_LEFT_OPEN; AUTHENTICATION_UNVERIFIED'
    } finally { $game.Dispose() }
} | Tee-Object -FilePath (Join-Path $PSScriptRoot ('Client291-Original-Profile-'+(Get-Date -Format yyyyMMdd-HHmmss)+'.txt'))
