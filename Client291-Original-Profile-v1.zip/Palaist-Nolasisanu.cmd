@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Read-Original-Profile.ps1"
echo.
pause
