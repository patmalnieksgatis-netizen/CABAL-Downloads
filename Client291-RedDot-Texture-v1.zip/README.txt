Client291: sarkano mobu simbolu tekstura

1. Aizver CABAL.
2. Atpako ZIP atseviska mape un palaid Novakt-RedDot.cmd.
3. Pie RED_DOT_TEKSTURA_NOMAINITA palaid speli ar esošo V4.9.6 palaideju.

Mainas tikai F:\CABAL_291_TEST\Data\UI\theme1\UI_Texture8.dds.
Originala kopija paliek Documents\CABAL291-Texture-Backups.
Atjaunot-RedDot-Originalu.cmd atjauno parbaudito originalu.

Sis ir ieprieks apstiprinata v282 vizuala labojuma EXACT faila variants.
Uzstaditajs to uzliks tikai tad, ja tava291 originala tekstura ir pilnigi identiska
ta zinamajam sakumfailam. Pie 291_TEKSTURA_ATSKIRAS failu nemaina: atsuti
F:\CABAL_291_TEST\Data\UI\theme1\UI_Texture8.dds, lai pielagotu tavu variantu.
Nekope un neparsaauc .bin failu ar roku, apejot šo parbaudi.

Faila hash/ZIP parbaudits; konkretais291 vizualais rezultats vel japārbauda spele.
Netiek mainiti servera faili, mobu spejas, datubaze vai Guardian integracija.
