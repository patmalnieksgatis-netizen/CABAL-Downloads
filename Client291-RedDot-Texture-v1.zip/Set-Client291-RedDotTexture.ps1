﻿param([ValidateSet('Apply','Restore')][string]$Action='Apply')
$ErrorActionPreference='Stop'
$root='F:\CABAL_291_TEST'
$relative='Data\UI\theme1\UI_Texture8.dds'
$target=Join-Path $root $relative
$beforeSHA='35fc63919ae47b3ab6a8be2c0325eb97a0378dd280f1c3bd1fd857a567569f64'
$fixedSHA='a2fa70349b3dd445b0762465902abf25faefdac3a128c0d0de0c66d977f524e7'
$backupFolder=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'CABAL291-Texture-Backups'
$backup=Join-Path $backupFolder 'UI_Texture8-before-red-dot.dds'
function File-SHA([string]$path) {
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Check-Path([string]$path) {
    $entry=Get-Item -LiteralPath $path -Force
    if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw ('SAISTITA_MAPE_VAI_FAILS; NEKAS_NAV_MAINITS; '+$path)
    }
}
if ($env:OS -ne 'Windows_NT') { throw 'PALAIz_WINDOWS_DATORA' }
if (Get-Process -Name CabalMain -ErrorAction SilentlyContinue) { throw 'VISPIRMS_AIZVER_CABAL_SPELI' }
foreach ($path in @($root,(Join-Path $root 'Data'),(Join-Path $root 'Data\UI'),(Join-Path $root 'Data\UI\theme1'),$target)) { Check-Path $path }
$current=File-SHA $target
if ($Action -eq 'Restore') {
    if ($current -eq $beforeSHA) { Write-Host 'RED_DOT_ORIGINALS_JAU_ATJAUNOTS'; return }
    if ($current -ne $fixedSHA) { throw ('CITS_TEKSTURAS_FAILS; ATJAUNOSANA_NAV_VEIKTA; SHA256='+$current) }
    Check-Path $backupFolder; Check-Path $backup
    if ((File-SHA $backup) -ne $beforeSHA) { throw 'ORIGINALA_KOPIJA_NEATBILST; NEKAS_NAV_MAINITS' }
    [IO.File]::Copy($backup,$target,$true)
    if ((File-SHA $target) -ne $beforeSHA) { throw 'ATJAUNOSANAS_PARBAUDE_NEIZDEVAS' }
    Write-Host 'RED_DOT_ORIGINALS_ATJAUNOTS'
    return
}
if ($current -eq $fixedSHA) { Write-Host 'RED_DOT_LABOJUMS_JAU_UZLIKTS'; return }
if ($current -ne $beforeSHA) {
    Write-Host ('SHA256='+$current)
    Write-Host ('ATSUTI_SO_FAILU='+$target)
    throw '291_TEKSTURA_ATSKIRAS; FAILS_NAV_MAINITS; ATSUTI_UI_Texture8.dds'
}
$payload=Join-Path $PSScriptRoot 'UI_Texture8.red-dot-fix.bin'
Check-Path $payload
if ((File-SHA $payload) -ne $fixedSHA) { throw 'LABOJUMA_FAILS_NEATBILST; NEKAS_NAV_MAINITS' }
[IO.Directory]::CreateDirectory($backupFolder) | Out-Null
Check-Path $backupFolder
if (Test-Path -LiteralPath $backup) {
    Check-Path $backup
    if ((File-SHA $backup) -ne $beforeSHA) { throw 'ESOŠA_ORIGINALA_KOPIJA_ATSKIRAS; NEKAS_NAV_MAINITS' }
} else {
    [IO.File]::Copy($target,$backup,$false)
}
if ((File-SHA $backup) -ne $beforeSHA) { throw 'ORIGINALA_KOPIJA_NAV_APSTIPRINATA; NEKAS_NAV_MAINITS' }
# Recheck immediately before the only client write, retaining a verified backup.
if ((File-SHA $target) -ne $beforeSHA) { throw 'TEKSTURA_MAINIJAS_PARBAUDES_LAIKA; NEKAS_NAV_MAINITS' }
try {
    [IO.File]::Copy($payload,$target,$true)
    if ((File-SHA $target) -ne $fixedSHA) { throw 'TEKSTURAS_NOMAINAS_PARBAUDE_NEIZDEVAS' }
} catch {
    $reason=$_.Exception.Message
    try {
        if ((File-SHA $target) -ne $beforeSHA) { [IO.File]::Copy($backup,$target,$true) }
        if ((File-SHA $target) -ne $beforeSHA) { throw 'ORIGINALA_HASH_NEATBILST' }
    } catch {
        throw ('NOMAINA_UN_ATJAUNOSANA_NAV_APSTIPRINATA; ORIGINALS='+$backup)
    }
    throw ('NOMAINA_NEIZDEVAS; ORIGINALS_ATJAUNOTS; '+$reason)
}
Write-Host 'RED_DOT_TEKSTURA_NOMAINITA; PARBAUDI_SPELE'
Write-Host ('ORIGINALA_KOPIJA='+$backup)
