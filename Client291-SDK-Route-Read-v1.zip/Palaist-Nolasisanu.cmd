@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Read-SDK-Route.ps1"
echo.
pause
