Original SDK x64 read-only observation: F:\CABAL_291_TEST only.
Restore original PlayCabal libogg.dll first if the native-audio test is active.
Close ALL Cabal windows, extract all files, run Palaist-Nolasisanu.cmd.
Preflight pins original Main/Ogg/DXVK hashes; foreign files are refused BEFORE
launch. Wait20s. At prompt use LOCAL291TEST / Test291only and click Login once.
Wait60s, leave game open, return Client291-SDK-Route-*.json and any console error.
The capture reads the known1024-byte SDK endpoint body plus THREE fixed512-byte
helpers5E3300, AD14E2 and5C3450 (2560 executable bytes total), one known4-byte
branch flag, and mode/source/cache. Image/region/layout guards remain required.
No password/account buffers, full process dump or recursive function capture.
No client/SDK/xdata file replacement, hooks, process writes, injection, server
changes or process termination. Only reports written beside the script.
Current source/cache snapshots are separate reads, not a call trace. A cached
IP is not a wire destination; code presence is not proof of an executed branch.
Windows execution of these additional helper reads remains to be verified.
