V4.8 - WORLD INACTIVE ROW CHECK CORRECTION; WINDOWS WORLD ENTRY UNVERIFIED

Only F:\CABAL_291_TEST and test VM192.168.56.101. Original game/server/SQL
files are unchanged. Keeps the verified V4.5 Login/CH/character adapter.

Close CABAL, leave test VM running. Run Palaist-291-v4_8.cmd as administrator.
Log in with the same test account, choose CH, character and enter World once.
On accepted conversion the game stays open. Tell us what appears and return
Downloads/Client291-LoginStart-v4_8-*.json (exact path printed as REPORT).
Dispatch counters do not prove completed World entry.

V4.7 deliberately refused status14 at Core+1880. That byte check did not prove
an active pet. The actual old v282 consumer skips a complete83-byte row when
its first signed DWORD is <=0, including negative sentinel/nonzero body bytes.
V4.8 follows that measured rule for all three rows. Positive kinds are still
refused, not deleted or migrated. Every source byte stays private in RAM.

PetPositiveMask/PetNegativeMask use bits0..2 for the three old rows; no item IDs
are exported. QuestCount and LegacyPassNonzeroMask record the other known
unsupported states in the same snapshot, even if positive pet rows refuse.
Active quests and legacy EventPass progress still need format reconciliation.
Do not create/reset an account to work around this diagnostic.

Keeps all V4.7 classic spans/44 stream validations, native return/arguments,
original SDK hooks, immutable64 leases and exact final-list count recovery.
New five setting rows have valid keys0..4. No installation is performed.
Specific compatibility refusal records metadata and closes only its own client.

Status1 prepared,2 dispatched;10 frame,11 name,12 count,13 slot,14 positive
old pet/item kind,15 quests,16 old EventPass,17 unwind,18 stream extent,
19 unexplained tail,20 buffer limit. Count for14/16 is a bounded state mask.

219 checks execute our Win64 blob against a native-reader host stub. A private
test also executes the old v282 row predicate (64 inactive combinations and
7 positive masks; positive item lookup returns a null stub). Neither test runs
the full game, SDK or Windows renderer. Actual World entry remains unverified.
ZIP contains only our source, own compiled code and build metadata.
