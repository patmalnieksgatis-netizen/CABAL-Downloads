$ErrorActionPreference = 'Stop'
Write-Host 'KATHLEEN: DRAGONIUM DM SETS + 3 ARCANA +20; SANEMSANA PASTA'
Write-Host 'ALZ UN FORCEGEM NETIEK MAINITI; ATKARTOTA PALAISANA NEDUBLE ITEMUS'
$python = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Send-Kathleen-Equipment.py'))
$rows = @($python | & ssh root@192.168.56.101 python3 - --apply)
$sshExit = $LASTEXITCODE
$rows | ForEach-Object { Write-Host $_ }
$file = Join-Path $env:USERPROFILE ('Downloads\Kathleen-Equipment-result-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
[IO.File]::WriteAllLines($file,[string[]]$rows,[Text.UTF8Encoding]::new($false))
Write-Host ('REPORT=' + $file)
if ($sshExit -ne 0 -or -not ($rows | Where-Object { $_.StartsWith('KATHLEEN_EQUIPMENT_TRANSACTION_CONFIRMED;') })) { throw 'PIESKIRUMS_NAV_APSTIPRINATS; ATSUTI_IZVADI' }
Write-Host 'PASTA_PIESKIRUMS_APSTIPRINATS; IELOGOJIES_KA_KATHLEEN_UN_SANEM_PASTA_PIELIKUMUS'
