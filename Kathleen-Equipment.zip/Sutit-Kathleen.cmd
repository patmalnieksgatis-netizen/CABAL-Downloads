@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Send-Kathleen-Equipment.ps1"
pause
