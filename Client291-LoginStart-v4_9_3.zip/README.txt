V4.9.3 - CLOSE INITIATOR OBSERVER; THIS DOES NOT PREVENT CLOSING

Only F:\CABAL_291_TEST and test VM192.168.56.101. Existing V4.9.2 Login,
CH, CharacterList and World compatibility are retained byte-for-byte. The
optional unregistered3046 query stays omitted; its omission did not solve
self-close. Fresh server logs show no further unregistered command before
this run disconnects. The actual initiating client caller is still unknown.

Close CABAL, leave the test VM running. Run Palaist-291-v4_9_3.cmd as admin.
Login the existing fresh account, select the existing character and enter
World. Let the observed automatic close happen once. Return the generated
Downloads/Client291-LoginStart-v4_9_3-*.json shown by REPORT. If it stays open,
leave it open90seconds; ending observation leaves the client running.

Own leaf observers forward the Main PostMessageA and SendMessageA imports
through their exact saved USER32 targets. They record only the first WM_CLOSE
to the nonnull original Main HWND. There are no API calls, stack adjustments,
nonvolatile writes or original decision/result overrides in the leaf code.
RCX/RDX/R8/R9, natural return, original API result and Win32 last-error stay.
Two owned pages: RX code and RW context, retained for the owned client lifetime.
Main/SDK executable code is not changed by this new observer. The existing
compatibility edits and native SDK path remain as in V4.9.2.

At most16 stack words are privately sampled below the thread TIB StackBase.
The JSON exports only executable-address candidates and module basenames;
no raw stack, account data, request/reply frames or credential strings. Caller
candidates are not a guaranteed unwound call chain. A call through another
module's own API import is outside this Main-import observer's coverage; a
missing record does not prove that no WM_CLOSE happened. Cached observations
remain in the report after process exit. Observer polls every100ms.

Own Win64 observer3356 emulator checks pass, including both API targets,
unchanged arguments/result/nonvolatiles/stack/Win32 last-error/direction flag,
nonmatching calls, nullHWND, bounded-stack fallback and immutable first record.
The native APIs and TEB in these tests are synthetic. Full Windows observer
behavior and sustained gameplay remain unverified. Both World/CharacterList
compiled callbacks are unchanged; V4.9.1 stopped-process release fix retained.
No server install/restart, SQL edits or original client disk-file changes.
Only our sources, our compiled callbacks and nonsecret metadata are included.
