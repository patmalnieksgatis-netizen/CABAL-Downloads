"""Read game option definitions and the two requested characters; no writes.

Run via SSH stdin on the isolated VM. Returned definitions are private, never
bundled into the public collector. No inventory, account secret or session dump.
"""
import base64
import json
import os
from pathlib import Path
import subprocess

VM_UUID = '7632fb78-37a0-f645-97c0-dc322c50b002'
DATA_READER = r'''
import base64, hashlib, json, re, stat
from pathlib import Path
root=Path('/etc/cabal/Data').resolve()
keywords=re.compile(r'divine|extreme|enchant|avatar|avan|crest|option|force|bike|limitcore',re.I)
definitions=[]; listing=[];errors=[];scanned=0;exported=0
for p in sorted(root.glob('*.scp'),key=lambda p:(not bool(keywords.search(p.name)),p.name)):
    if p.resolve().parent!=root:continue
    size=p.stat().st_size; listing.append({'Name':p.name,'Bytes':size})
    if not p.is_file() or size>3*1024**2:continue
    if scanned+size>128*1024**2:errors.append('SCAN_BUDGET_REACHED');break
    b=p.read_bytes();scanned+=len(b)
    sections=[m.group(1).decode('ascii') for m in re.finditer(rb'(?m)^\[([A-Za-z][A-Za-z0-9_]{0,100})\]',b)]
    if p.name not in ('Item.scp','Item2.scp','Item3.scp','Item4.scp','Const.scp') and not keywords.search(p.name+' '+' '.join(sections)):continue
    if exported+len(b)>20*1024**2:errors.append('EXPORT_BUDGET_REACHED');continue
    exported+=len(b)
    definitions.append({'Name':p.name,'Bytes':len(b),'SHA256':hashlib.sha256(b).hexdigest(),
                        'Sections':sections,'Base64':base64.b64encode(b).decode('ascii')})
print(json.dumps({'Definitions':definitions,'Files':listing,'Errors':errors,'ScannedBytes':scanned}))
'''

SQL = r"""SET NOCOUNT ON;
SET LOCK_TIMEOUT 5000;
IF DB_NAME()<>N'Server01' THROW 51000,'WRONG_GAME_DATABASE',1;
IF (SELECT COUNT(*) FROM dbo.cabal_character_table
 WHERE Name COLLATE Latin1_General_100_BIN2=N'BumbleBee')<>1
 THROW 51000,'BUMBLEBEE_NOT_UNIQUE',1;
DECLARE @report nvarchar(max);
SET @report=(SELECT
 JSON_QUERY((SELECT Name,CharacterIdx,CharacterIdx/16 AS AccountNumber,LEV,Style,
 [STR],[DEX],[INT],[Login] FROM dbo.cabal_character_table
 WHERE Name COLLATE Latin1_General_100_BIN2 IN (N'BumbleBee',N'Kathleen')
 FOR JSON PATH)) AS Characters,
 JSON_QUERY((SELECT TOP(64) m.ItemKindIdx,m.ItemOption,COUNT_BIG(*) AS Examples
 FROM dbo.cabal_mail_received_table m
 WHERE m.ReceiverCharIdx IN (SELECT CharacterIdx FROM dbo.cabal_character_table
 WHERE Name COLLATE Latin1_General_100_BIN2 IN (N'BumbleBee',N'Kathleen'))
 AND (CONVERT(bigint,m.ItemKindIdx)&100667391) IN
 (33558050,33558051,33558052,33554729,33554730,33554731,33555377,33556579,67109275)
 GROUP BY m.ItemKindIdx,m.ItemOption ORDER BY m.ItemKindIdx,m.ItemOption FOR JSON PATH)) AS OwnMailOptionExamples,
 JSON_QUERY((SELECT o.name,o.type_desc FROM sys.objects o
 WHERE SCHEMA_NAME(o.schema_id)='dbo' AND
 (o.name LIKE '%itemoption%' OR o.name LIKE '%itemkind%' OR o.name LIKE '%divine%'
 OR o.name LIKE '%extreme%' OR o.name LIKE '%crest%') ORDER BY o.name FOR JSON PATH)) AS ItemHelperNames,
 JSON_QUERY((SELECT o.name,CONVERT(varchar(64),HASHBYTES('SHA2_256',CONVERT(varbinary(max),m.definition)),2) AS SHA256
 FROM sys.objects o JOIN sys.sql_modules m ON m.object_id=o.object_id
 WHERE SCHEMA_NAME(o.schema_id)='dbo' AND o.name IN ('cabal_tool_mail_send','Mail_GetGMType')
 FOR JSON PATH)) AS MailHelperHashes
 FOR JSON PATH,WITHOUT_ARRAY_WRAPPER);
SET @report=CONVERT(varchar(max),CONVERT(varbinary(max),@report),2);
DECLARE @at int=1;
WHILE @at<=LEN(@report)
BEGIN PRINT 'ITEM_OPTIONS_READ:'+SUBSTRING(@report,@at,2000); SET @at+=2000; END;
PRINT 'ITEM_OPTIONS_READ_COMPLETE';
"""

SQL_SHELL = '''set +x
export SQLCMDPASSWORD="${MSSQL_SA_PASSWORD:-${SA_PASSWORD:-}}"
[ -n "$SQLCMDPASSWORD" ] || exit 2
tool=/opt/mssql-tools18/bin/sqlcmd
[ -x "$tool" ] || tool=/opt/mssql-tools/bin/sqlcmd
exec "$tool" -S localhost -U sa -N -C -d Server01 -b -l 5 -t 30 -h -1 -W -w 65535 -i /dev/stdin
'''


def decode(raw):
    if raw.startswith((b'\xff\xfe',b'\xfe\xff')):
        return raw.decode('utf-16')
    if b'\x00' in raw[:100]:
        return raw.decode('utf-16-le')
    return raw.decode('utf-8-sig')


def main():
    if os.geteuid()!=0 or Path('/sys/class/dmi/id/product_uuid').read_text().strip().lower()!=VM_UUID:
        raise SystemExit('WRONG_TEST_VM_OR_ROOT_REQUIRED; NO_CHANGES')
    out=dict(Schema=1,Status='READ_ONLY_COMPLETE',Changes=False,TargetCharacter='BumbleBee',
             Requested=['3 filled Crests','Sage Belt +20','Carnelian +20','QW7 +20 3slots Extreme7 Divine20'],
             Snapshot=None,Definitions=[],Files=[],Errors=[])
    for stage,args,data in (
        ('GAME_DEFINITIONS',['docker','exec','cabal_main','python3','-c',DATA_READER],None),
        ('SQL_PROFILE',['docker','exec','-i','sql_main','sh','-ec',SQL_SHELL],SQL.encode('ascii'))):
        try:
            p=subprocess.run(args,input=data,capture_output=True,timeout=60)
            if p.returncode:
                raise RuntimeError('EXIT='+str(p.returncode)+'; '+decode(p.stdout+p.stderr)[-700:])
            text=decode(p.stdout)
            if stage=='GAME_DEFINITIONS':
                d=json.loads(text);out['Definitions']=d['Definitions'];out['Files']=d['Files']
                for e in d['Errors']:out['Errors'].append(dict(Stage=stage,Detail=e))
            else:
                lines=text.splitlines()
                if 'ITEM_OPTIONS_READ_COMPLETE' not in lines:raise RuntimeError('SQL_COMPLETION_MARKER_MISSING')
                encoded=''.join(l[len('ITEM_OPTIONS_READ:'):] for l in lines if l.startswith('ITEM_OPTIONS_READ:'))
                out['Snapshot']=json.loads(bytes.fromhex(encoded).decode('utf-16-le'))
        except (RuntimeError,OSError,ValueError,subprocess.SubprocessError) as e:
            out['Errors'].append(dict(Stage=stage,Detail=str(e)[:800]))
    if out['Errors']:out['Status']='READ_ONLY_PARTIAL'
    print(json.dumps(out))


if __name__=='__main__':
    main()
