$ErrorActionPreference='Stop'
Write-Host 'BUMBLEBEE: 3 PILNI CREST; SAGE BELT+20; CARNELIAN+20; QW7+20 3S EXTREME7 DIVINE20'
Write-Host 'TIKAI OPCIJU NOLASISANA; ITEMI VEL NETIEK SUTITI; TIKAI TESTA VM 192.168.56.101'
$code=Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'Read-BumbleBee-ItemOptions.py')
$rows=@($code | & ssh root@192.168.56.101 python3 -)
if($LASTEXITCODE -ne 0){throw 'NOLASISANA_NEIZDEVAS; ATSUTI_IZVADI'}
$text=$rows -join "`n"
$report=$text | ConvertFrom-Json
if($report.Schema -ne 1 -or $report.Changes -ne $false -or $report.TargetCharacter -cne 'BumbleBee'){throw 'NOLASISANAS_ATSKAITE_NAV_DERIGA'}
$folder=Join-Path $env:USERPROFILE ('Downloads\BumbleBee-ItemOptions-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $folder | Out-Null
[IO.File]::WriteAllText((Join-Path $folder 'report.json'),$text,[Text.UTF8Encoding]::new($false))
$zip=$folder+'.zip'
Compress-Archive -LiteralPath (Join-Path $folder 'report.json') -DestinationPath $zip
Write-Host ('STATUS='+$report.Status)
foreach($e in $report.Errors){Write-Host ('POSMS='+$e.Stage+'; '+$e.Detail)}
Write-Host ('ZIP='+$zip)
Write-Host 'ATSUTI_SO_ZIP; NAV_ITEMU_PIESKIRUMU_VAI_PARSTARTESANAS'
