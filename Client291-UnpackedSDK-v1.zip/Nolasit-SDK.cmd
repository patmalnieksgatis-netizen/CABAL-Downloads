@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Read-Client291-UnpackedSDK.ps1"
if errorlevel 1 echo NOLASISANA NEIZDEVAS. Saglaba konsoles tekstu.
pause
