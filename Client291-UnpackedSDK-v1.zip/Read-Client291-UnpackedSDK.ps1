# Copy selected SDK image sections for offline analysis. No Login is requested.
& {
    $ErrorActionPreference='Stop'
    if (![Environment]::Is64BitProcess -or $env:OS -ne 'Windows_NT') { throw 'USE_WINDOWS_X64_POWERSHELL' }
    $exe='F:\CABAL_291_TEST\Bin\x64\CabalMain.exe'
    $bin=Split-Path -Parent $exe
    $checks=[ordered]@{
        'CabalMain.exe'='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
        'libogg.dll'='ceafa8291dcf090856a215285114270fea1a8978bc2d2b26b33bcb7b3ac5c2a9'
        'd3d9.dll'='216058f9320d0667d551f4cea840ee539396449ef8c8e89fe481e4f0ddb628ae'
    }
    function Check-Originals {
        foreach ($name in $checks.Keys) {
            if ((Get-FileHash -LiteralPath (Join-Path $bin $name) -Algorithm SHA256).Hash -ne $checks[$name]) {
                throw ('ORIGINAL_FILE_DIFFERS='+$name)
            }
        }
    }
    Check-Originals
    if (!('Client291SDKImageRead' -as [type])) {
        Add-Type -Path (Join-Path $PSScriptRoot 'Client291-SDKImageRead.cs')
    }
    $game=$null
    if ($global:client291Game -is [Diagnostics.Process]) {
        try {
            if (!$global:client291Game.HasExited) {
                $candidate=$global:client291Game
                if (![String]::Equals([IO.Path]::GetFullPath($candidate.StartInfo.FileName),$exe,
                                     [StringComparison]::OrdinalIgnoreCase)) {
                    throw 'RETAINED_PROCESS_PATH_DIFFERS'
                }
                $handle=$candidate.Handle
                [void][Client291SDKImageRead]::MainEntry($handle,0x69afd8)
                $game=$candidate
            }
        } catch { $game=$null }
    }
    $startedHere=$false
    if ($null -eq $game) {
        if (Get-Process -Name CabalMain -ErrorAction SilentlyContinue) {
            throw 'Aizver speli un palaid so komandu velreiz; saglabats procesa izveides handle nav pieejams.'
        }
        $start=New-Object Diagnostics.ProcessStartInfo
        $start.FileName=$exe; $start.Arguments='breaklee'
        $start.WorkingDirectory=$bin; $start.UseShellExecute=$false
        $game=[Diagnostics.Process]::Start($start)
        $global:client291Game=$game
        $startedHere=$true
    }
    $handle=$game.Handle
    'TEST_PID='+$game.Id
    'ATSTAJ_SPELI_ATVERTU; LOGIN_NESPIED; GAIDI_KODA_NOLASISANU'
    $deadline=[DateTime]::UtcNow.AddSeconds(25)
    $sdk=$null; $lastFailure='SDK_NOT_READY'
    do {
        if ($game.HasExited) { throw ('ORIGINAL_CLIENT_EXITED='+$game.ExitCode) }
        try {
            $sdk=[Client291SDKImageRead]::SDKBase($handle)
            $anchorsBefore=@([Client291SDKImageRead]::Anchors($handle,$sdk))
            break
        } catch {
            $lastFailure=$_.Exception.GetBaseException().Message
            $sdk=$null
            Start-Sleep -Milliseconds 500
        }
    } while ([DateTime]::UtcNow -lt $deadline)
    if ($null -eq $sdk) { throw ('SDK_READ_NOT_READY='+$lastFailure) }
    $downloads=Join-Path $env:USERPROFILE 'Downloads'
    $stamp=(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)
    $payload=Join-Path $downloads ('Client291-UnpackedSDK-'+$stamp)
    New-Item -ItemType Directory -Path $payload | Out-Null
    $started=[DateTime]::UtcNow.ToString('o')
    $mainEntries=@()
    foreach ($rva in @(0x16d328,0x69afd8,0x6a49b8,0x6a3c6c,0x7f3208,0x2178e0)) {
        $bytes=[Client291SDKImageRead]::MainEntry($handle,$rva)
        $target=$null
        if ($rva -in @(0x16d328,0x69afd8)) {
            $target=([Client291SDKImageRead]::Resolve($handle,0x140000000L+$rva)).ToString('X')
        }
        $mainEntries += [ordered]@{RVAHex=$rva.ToString('X');BytesHex=[BitConverter]::ToString($bytes).Replace('-','');ResolvedHex=$target}
    }
    $sections=@([Client291SDKImageRead]::Capture($handle,$sdk,$payload))
    $anchorsAfter=@([Client291SDKImageRead]::Anchors($handle,$sdk))
    Check-Originals
    $stable=($anchorsBefore -join '|') -ceq ($anchorsAfter -join '|')
    $complete=@($sections | Where-Object { !$_.Complete }).Count -eq 0
    $report=[ordered]@{
        Schema=1; PID=$game.Id; StartedClientHere=$startedHere
        ProcessStartedUTC=$game.StartTime.ToUniversalTime().ToString('o')
        CaptureStartedUTC=$started; CaptureFinishedUTC=[DateTime]::UtcNow.ToString('o')
        SDKBaseHex=$sdk.ToString('X'); SDKImageSizeHex='1264000'
        OriginalFileSHA256=$checks; MainEntries=$mainEntries; Sections=$sections
        AnchorsBefore=$anchorsBefore; AnchorsAfter=$anchorsAfter; AnchorsStable=$stable
        AllSelectedSectionsComplete=$complete; MissingRangesAreZeroFilled=$true
        Scope='SDK .text .rdata .pdata .detourc .x30 only; excludes mutable sections, heap and other modules'
        SnapshotAtomic=$false; ClientWrites=$false; LoginRequested=$false; UploadedAutomatically=$false
    }
    $report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $payload 'SDKImage-Report.json') -Encoding UTF8
    foreach ($section in $sections) {
        if ((Get-FileHash -LiteralPath (Join-Path $payload $section.File) -Algorithm SHA256).Hash -ne $section.SHA256) {
            throw 'SAVED_SECTION_HASH_DIFFERS'
        }
    }
    $archive=$payload+'.zip'
    Compress-Archive -Path (Join-Path $payload '*') -DestinationPath $archive -CompressionLevel Optimal
    'UPLOAD='+$archive
    if (!$stable -or !$complete) { 'PARTIAL_OR_CHANGING_CAPTURE; SAGLABA_ZIP_ANALIZEI' }
    'READ_ONLY_CODE_CAPTURE_COMPLETE; ORIGINAL_FILES_VERIFIED; GAME_LEFT_OPEN; LOGIN_NOT_TESTED'
}
