// Read selected immutable image sections from the original v291 SDK.
// The caller supplies its own retained process-creation handle.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

public static class Client291SDKImageRead {
    [StructLayout(LayoutKind.Sequential)]
    struct Region {
        public IntPtr Base, AllocationBase;
        public uint AllocationProtect;
        public ushort Partition, Padding;
        public UIntPtr Size;
        public uint State, Protect, Type;
    }
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr h, IntPtr at, byte[] b, UIntPtr n, out UIntPtr got);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern UIntPtr VirtualQueryEx(IntPtr h, IntPtr at, out Region r, UIntPtr n);
    [DllImport("psapi.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern uint GetMappedFileNameW(IntPtr h, IntPtr at, StringBuilder name, uint n);

    public sealed class Hole {
        public int Offset, Bytes, Win32Error;
        public string Reason;
    }
    public sealed class Protection {
        public int Offset, Bytes;
        public uint State, Protect, Type;
    }
    public sealed class Section {
        public string Name, File, SHA256;
        public int RVA, Bytes, CapturedBytes;
        public uint DiskCharacteristics;
        public bool Complete;
        public List<Hole> Holes = new List<Hole>();
        public List<Protection> Regions = new List<Protection>();
    }
    public static string Hash(byte[] b) {
        using (SHA256 s=SHA256.Create())
            return BitConverter.ToString(s.ComputeHash(b)).Replace("-", "").ToLowerInvariant();
    }
    static Region Query(IntPtr h, long at) {
        Region r; int size=Marshal.SizeOf(typeof(Region));
        if (at<65536 || at>0x7fffffffffffL || size!=48)
            throw new Exception("ADDRESS_OR_X64_LAYOUT_DIFFERS");
        if (VirtualQueryEx(h,new IntPtr(at),out r,new UIntPtr((uint)size)).ToUInt64()!=(ulong)size)
            throw new Win32Exception(Marshal.GetLastWin32Error());
        long end=checked(r.Base.ToInt64()+(long)r.Size.ToUInt64());
        if (r.Base.ToInt64()>at || end<=at) throw new Exception("REGION_BOUNDS");
        return r;
    }
    static byte[] Raw(IntPtr h,long at,int count) {
        if (at<65536 || count<1 || count>65536 || checked(at+count)>0x7fffffffffffL)
            throw new Exception("READ_BOUNDS");
        byte[] b=new byte[count]; UIntPtr got;
        if (!ReadProcessMemory(h,new IntPtr(at),b,new UIntPtr((uint)count),out got))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        if (got.ToUInt64()!=(ulong)count) throw new Exception("PARTIAL_READ");
        return b;
    }
    public static byte[] MainEntry(IntPtr h,int rva) {
        int[] allowed={0x16d328,0x69afd8,0x6a49b8,0x6a3c6c,0x7f3208,0x2178e0};
        if (Array.IndexOf(allowed,rva)<0) throw new Exception("MAIN_RVA_NOT_SELECTED");
        Region r=Query(h,0x140000000L+rva);
        if (r.AllocationBase.ToInt64()!=0x140000000L || r.Type!=0x1000000 || r.State!=0x1000 ||
            (r.Protect&0x101)!=0) throw new Exception("MAIN_IMAGE_DIFFERS");
        return Raw(h,0x140000000L+rva,32);
    }
    public static long Resolve(IntPtr h,long at) {
        for (int hop=0;hop<4;hop++) {
            Region r=Query(h,at);
            if (r.State!=0x1000 || (r.Type!=0x1000000 && r.Type!=0x20000) ||
                (r.Protect&0x101)!=0 || (r.Protect&0xf0)==0)
                throw new Exception("JUMP_NOT_EXECUTABLE_IMAGE_OR_RELAY");
            byte[] b=Raw(h,at,6);
            if (b[0]==0xe9) { at=checked(at+5+BitConverter.ToInt32(b,1)); continue; }
            if (b[0]==0xff && b[1]==0x25) {
                long pointer=checked(at+6+BitConverter.ToInt32(b,2));
                Region p=Query(h,pointer);
                if (p.AllocationBase!=r.AllocationBase || p.State!=0x1000 || (p.Protect&0x101)!=0)
                    throw new Exception("JUMP_POINTER_OUTSIDE_RELAY_ALLOCATION");
                at=BitConverter.ToInt64(Raw(h,pointer,8),0); continue;
            }
            return at;
        }
        throw new Exception("JUMP_LIMIT");
    }
    public static long SDKBase(IntPtr h) {
        MainEntry(h,0x69afd8);
        long sdk=checked(Resolve(h,0x14069afd8L)-0x5e33d0);
        Region r=Query(h,sdk);
        if (r.AllocationBase.ToInt64()!=sdk || r.Type!=0x1000000 || r.State!=0x1000)
            throw new Exception("SDK_NOT_MAPPED_IMAGE");
        byte[] header=Raw(h,sdk,4096);
        int pe=BitConverter.ToInt32(header,60);
        if (header[0]!=77 || header[1]!=90 || pe<64 || pe>2048 ||
            BitConverter.ToUInt32(header,pe)!=0x4550 ||
            BitConverter.ToUInt16(header,pe+4)!=0x8664 ||
            BitConverter.ToUInt16(header,pe+6)!=12 ||
            BitConverter.ToUInt16(header,pe+24)!=0x20b ||
            BitConverter.ToUInt32(header,pe+80)!=0x1264000)
            throw new Exception("SDK_PE_LAYOUT_DIFFERS");
        StringBuilder path=new StringBuilder(32768);
        if (GetMappedFileNameW(h,new IntPtr(sdk),path,(uint)path.Capacity)==0 ||
            !path.ToString().EndsWith("\\libogg.dll",StringComparison.OrdinalIgnoreCase))
            throw new Exception("SDK_MAPPED_FILE_DIFFERS");
        return sdk;
    }
    // Nonwritable original sections only; mutable SDK data, IAT and process heap are excluded.
    static readonly string[] Names={".text",".rdata",".pdata",".detourc",".x30"};
    static readonly int[] RVAs={0x1000,0x6b1000,0xa0a000,0xa67000,0xa6b000};
    static readonly int[] Sizes={0x6afae7,0x3122c6,0x5b458,0x21c0,0x1d55d2};
    static readonly uint[] Flags={0x60000020,0x40000040,0x40000040,0x40000040,0x60000020};
    public static Section[] Capture(IntPtr h,long sdk,string directory) {
        if (!Directory.Exists(directory)) throw new Exception("OUTPUT_DIRECTORY_REQUIRED");
        byte[] header=Raw(h,sdk,4096);
        int pe=BitConverter.ToInt32(header,60);
        int table=checked(pe+24+BitConverter.ToUInt16(header,pe+20));
        if (table<64 || table+12*40>header.Length) throw new Exception("SECTION_TABLE_BOUNDS");
        List<Section> result=new List<Section>();
        for (int selected=0;selected<Names.Length;selected++) {
            int found=-1;
            for (int j=0;j<12;j++) {
                int at=table+j*40;
                string name=Encoding.ASCII.GetString(header,at,8).TrimEnd('\0');
                if (name!=Names[selected]) continue;
                if (found!=-1 || BitConverter.ToInt32(header,at+8)!=Sizes[selected] ||
                    BitConverter.ToInt32(header,at+12)!=RVAs[selected] ||
                    BitConverter.ToUInt32(header,at+36)!=Flags[selected])
                    throw new Exception("SELECTED_SECTION_LAYOUT_DIFFERS");
                found=at;
            }
            if (found<0) throw new Exception("SELECTED_SECTION_MISSING");
            Section section=new Section();
            section.Name=Names[selected]; section.RVA=RVAs[selected]; section.Bytes=Sizes[selected];
            section.DiskCharacteristics=Flags[selected];
            section.File="sdk-"+Names[selected].TrimStart('.')+".bin";
            byte[] data=new byte[section.Bytes];
            bool code=(Flags[selected]&0x20000000)!=0;
            for (int offset=0;offset<data.Length;) {
                long address=checked(sdk+section.RVA+offset);
                Region region=Query(h,address);
                long regionEnd=checked(region.Base.ToInt64()+(long)region.Size.ToUInt64());
                int count=(int)Math.Min(65536,Math.Min(data.Length-offset,regionEnd-address));
                uint protection=region.Protect&255;
                bool readable=protection==2 || protection==0x20 ||
                              (code && (protection==0x40 || protection==0x80));
                section.Regions.Add(new Protection {Offset=offset,Bytes=count,State=region.State,
                                                    Protect=region.Protect,Type=region.Type});
                if (region.AllocationBase.ToInt64()!=sdk || region.Type!=0x1000000 ||
                    region.State!=0x1000 || (region.Protect&0x101)!=0 || !readable) {
                    section.Holes.Add(new Hole {Offset=offset,Bytes=count,Reason="REGION_NOT_PERMITTED"});
                } else {
                    byte[] chunk=new byte[count]; UIntPtr got;
                    bool ok=ReadProcessMemory(h,new IntPtr(address),chunk,new UIntPtr((uint)count),out got);
                    int error=ok?0:Marshal.GetLastWin32Error();
                    if (ok && got.ToUInt64()==(ulong)count) {
                        Array.Copy(chunk,0,data,offset,count);section.CapturedBytes+=count;
                    } else {
                        section.Holes.Add(new Hole {Offset=offset,Bytes=count,Win32Error=error,Reason="READ_FAILED_OR_PARTIAL"});
                    }
                }
                offset+=count;
            }
            section.Complete=section.CapturedBytes==section.Bytes;
            section.SHA256=Hash(data);
            System.IO.File.WriteAllBytes(Path.Combine(directory,section.File),data);
            result.Add(section);
        }
        return result.ToArray();
    }
    public static string[] Anchors(IntPtr h,long sdk) {
        int[] rvas={0x5a57a0,0x5cda90,0x5d07a0,0x5e1170,0x5e33d0,0xacf83c,0xad18f5};
        List<string> hashes=new List<string>();
        foreach (int rva in rvas) {
            Region r=Query(h,sdk+rva);
            if (r.AllocationBase.ToInt64()!=sdk || r.Type!=0x1000000 || r.State!=0x1000 ||
                (r.Protect&0x101)!=0 || (r.Protect&0xf0)==0)
                throw new Exception("ANCHOR_NOT_EXECUTABLE_SDK_IMAGE");
            byte[] b=Raw(h,sdk+rva,32);bool nonzero=false;
            foreach (byte value in b) nonzero|=value!=0;
            if (!nonzero) throw new Exception("SDK_CODE_NOT_UNPACKED_AT_ANCHOR");
            hashes.Add(rva.ToString("X")+":"+Hash(b));
        }
        return hashes.ToArray();
    }
}
