EP36 / v282 - Red Monster Symbols Visual Fix

This client texture hides the red horned mask and triangle symbols.
It was confirmed working in the original EP36/v282 client installation.
It changes their appearance only; monster stats and effects remain unchanged.

INSTALLATION
1. Close CABAL completely.
2. Open your CABAL client folder (the folder containing Data).
3. Back up Data\UI\theme1\UI_Texture8.dds to a safe location outside the client.
4. Check that your original file matches the original SHA256 below. If it has
   a different hash, do not replace it: this texture is not a universal fix for
   other client versions or custom UI packs. If it already matches the patched
   hash, the fix is already installed.
5. Copy the Data folder from this archive into your CABAL client folder.
   Replace only Data\UI\theme1\UI_Texture8.dds when prompted.
6. Start CABAL again and check the monsters.

RESTORE
Close CABAL and copy your original backup file back to the same location.

SHA256
Original: 35fc63919ae47b3ab6a8be2c0325eb97a0378dd280f1c3bd1fd857a567569f64
Patched:  a2fa70349b3dd445b0762465902abf25faefdac3a128c0d0de0c66d977f524e7

To check the file in Windows PowerShell, replace CLIENT_FOLDER with your path:
Get-FileHash -LiteralPath 'CLIENT_FOLDER\Data\UI\theme1\UI_Texture8.dds' -Algorithm SHA256

This package contains one modified DDS texture and these instructions.
No server installation, SQL commands, executable edits or DLL changes are needed.
