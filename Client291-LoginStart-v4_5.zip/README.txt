Client291 LoginStart v4.5 - isolated CharacterList133 compatibility candidate.
Close CABAL. Keep test VM192.168.56.101 running. Extract ALL files to a NEW folder.
Run Palaist-291-v4_5.cmd as administrator. Only F:\CABAL_291_TEST and pinned originals.
Preserves V4.4 Login/3383/type17/public channel build profile.
Timestamp-correlated fault14072B754 is in original291 equipment list reading.
Own callback converts exact native47-slot character-list layouts to29151-slot layout.
Original reader remains unmodified; only its133 registration points to our callback.
Existing IDs/names/stats/items/options/appearance and six core outfit fields are copied.
New second-time/seventh-outfit fields and four additional slots are neutral zero.
Invalid frames/counts/slots/ownership refuse before original reader; no dummy characters.
Own freestanding callback runs on original game thread with native dynamic unwind metadata.
No injected thread/replacement DLL, game-file/server/SQL writes or installation.
No raw packet/account/password export. Close game to discard private RAM changes.
All5 real pre-edit digests and natural SDK integrity worker remain required.
Use your existing test account inside game; select CH, then character and world if available.
REPORT= shows Downloads\Client291-LoginStart-v4_5-*.json including bounded conversion counters.
Actual V4.5 Windows/character selection/world result remains pending.
