SET NOCOUNT ON;
SET XACT_ABORT ON;
SET LOCK_TIMEOUT 5000;
IF DB_NAME()<>N'Server01' THROW 51000,'WRONG_GAME_DATABASE; NOTHING_SENT',1;
DECLARE @items TABLE(N int PRIMARY KEY,Kind bigint,Opt bigint,Label varchar(40));
INSERT @items VALUES
__ITEM_VALUES__;
BEGIN TRY
 BEGIN TRANSACTION;
 DECLARE @lock int;
 EXEC @lock=sys.sp_getapplock @Resource='Client291_BumbleBeeFullItems_20261113:BumbleBee',
  @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=5000;
 IF @lock IS NULL OR @lock<0 THROW 51000,'BUMBLEBEE_MAIL_LOCK_FAILED',1;
 DECLARE @user int,@character int,@matches int;
 SELECT @character=MIN(CharacterIdx),@matches=COUNT(*) FROM dbo.cabal_character_table WITH(UPDLOCK,HOLDLOCK)
  WHERE Name COLLATE Latin1_General_100_BIN2='BumbleBee';
 IF @matches<>1 OR @character IS NULL THROW 51001,'BUMBLEBEE_CHARACTER_IDENTITY_MISMATCH; NOTHING_SENT',1;
 SET @user=@character/16;
 IF NOT EXISTS(SELECT 1 FROM Account.dbo.cabal_auth_table WHERE UserNum=@user)
  THROW 51001,'BUMBLEBEE_ACCOUNT_NOT_FOUND; NOTHING_SENT',1;
 IF NOT EXISTS(SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.cabal_tool_mail_send')
  AND name='@ItemKindIdx' AND TYPE_NAME(user_type_id)='bigint')
  THROW 51001,'NATIVE_MAIL_ITEM_KIND_NOT_BIGINT; NOTHING_SENT',1;
 IF HASHBYTES('SHA2_256',CONVERT(varbinary(max),OBJECT_DEFINITION(OBJECT_ID('dbo.cabal_tool_mail_send')))) IS NULL
  OR HASHBYTES('SHA2_256',CONVERT(varbinary(max),OBJECT_DEFINITION(OBJECT_ID('dbo.cabal_tool_mail_send'))))<>
  0xE1ACA240CF50C55C6847A38C202A79712DFC5E3EC31480FD67B479A99111E029
  OR HASHBYTES('SHA2_256',CONVERT(varbinary(max),OBJECT_DEFINITION(OBJECT_ID('dbo.Mail_GetGMType')))) IS NULL
  OR HASHBYTES('SHA2_256',CONVERT(varbinary(max),OBJECT_DEFINITION(OBJECT_ID('dbo.Mail_GetGMType'))))<>
  0xF11A7EF873E57ACC6FC9D5DDDBB7093E2E53745F35DA511659015837D0DCC4E1
  THROW 51002,'NATIVE_MAIL_HELPER_CHANGED; NOTHING_SENT',1;
 IF OBJECT_ID('dbo.Client291_BumbleBeeFullItems_20261113','U') IS NULL
  CREATE TABLE dbo.Client291_BumbleBeeFullItems_20261113(
   CharacterIdx int NOT NULL,N int NOT NULL,Kind bigint NOT NULL,Opt bigint NOT NULL,
   MailID int NOT NULL,SentAt datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),
   PRIMARY KEY(CharacterIdx,N));
 IF EXISTS(SELECT 1 FROM dbo.Client291_BumbleBeeFullItems_20261113 WITH(UPDLOCK,HOLDLOCK) WHERE CharacterIdx=@character)
 BEGIN
  IF (SELECT COUNT(*) FROM dbo.Client291_BumbleBeeFullItems_20261113 WHERE CharacterIdx=@character)<>6
   OR EXISTS(SELECT N,Kind,Opt FROM @items EXCEPT
   SELECT N,Kind,Opt FROM dbo.Client291_BumbleBeeFullItems_20261113 WHERE CharacterIdx=@character)
   THROW 51003,'MAIL_GRANT_JOURNAL_DIFFERS; NOTHING_SENT',1;
  COMMIT;
  PRINT 'BUMBLEBEE_FULL_ITEMS_ALREADY_SENT; NO_DUPLICATES';
  RETURN;
 END;
 DECLARE @n int=1,@kind bigint,@opt bigint,@label varchar(40),@body varchar(512),@id int;
 DECLARE @result TABLE(ID int);
 WHILE @n<=6
 BEGIN
  SELECT @kind=Kind,@opt=Opt,@label=Label FROM @items WHERE N=@n;
  SET @body='BumbleBee requested test equipment. Permanent attachment: '+@label;
  DELETE @result;
  INSERT @result EXEC dbo.cabal_tool_mail_send
   @SenderName='GM',@ReceiverCharIdx=@character,@Title=@label,@Content=@body,
   @Alz=0,@ItemKindIdx=@kind,@ItemOption=@opt,@ItemDurationIdx=0,@ExpirationTime=NULL;
  IF (SELECT COUNT(*) FROM @result)<>1 THROW 51004,'MAIL_RECEIPT_FAILED',1;
  SELECT @id=ID FROM @result;
  IF @id IS NULL OR @id<=0 OR NOT EXISTS(SELECT 1 FROM dbo.cabal_mail_received_table
   WHERE ReceiverCharIdx=@character AND ReceivedMailID=@id AND IsCommitted=1 AND Type=4
   AND ItemKindIdx=@kind AND ItemOption=@opt AND ItemDurationIdx=0
   AND ExpirationTime IS NULL AND SenderName='GM' AND Alz=0 AND IsReceivedItem=0)
   THROW 51005,'MAIL_ATTACHMENT_POSTCHECK_FAILED',1;
  INSERT dbo.Client291_BumbleBeeFullItems_20261113(CharacterIdx,N,Kind,Opt,MailID)
   VALUES(@character,@n,@kind,@opt,@id);
  SET @n+=1;
 END;
 COMMIT;
 PRINT 'BUMBLEBEE_FULL_ITEMS_SENT; MAILS6; OPEN_MAIL_AND_CLAIM_ATTACHMENTS';
 SELECT CONCAT('BUMBLEBEE_ITEM=',j.N,'; ',i.Label,'; MAIL_ID=',j.MailID) FROM dbo.Client291_BumbleBeeFullItems_20261113 j
 JOIN @items i ON i.N=j.N WHERE j.CharacterIdx=@character ORDER BY j.N;
END TRY
BEGIN CATCH
 IF @@TRANCOUNT>0 ROLLBACK;
 THROW;
END CATCH;
