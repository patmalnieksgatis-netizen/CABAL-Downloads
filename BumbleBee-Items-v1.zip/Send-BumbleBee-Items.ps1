$ErrorActionPreference='Stop'
Write-Host 'BUMBLEBEE: 3 CREST AR HP/DEF/CDI; SAGE BELT CHAOS+20; CARNELIAN CHAOS+20'
Write-Host 'QW7 +20; 3 SLOTI; EXTREME+7; DIVINE+15; TIKAI TESTA VM 192.168.56.101'
Write-Host 'PIRMS PASTA SKRIPTS PATS PARBAUDA PASREIZEJAS UZLABOJUMU TABULAS'
$code=Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'Send-BumbleBee-Items.py')
$rows=@($code | & ssh root@192.168.56.101 python3 - --apply)
$result=$LASTEXITCODE
$text=$rows -join "`r`n"
$text | Write-Host
$report=Join-Path $env:USERPROFILE ('Downloads\BumbleBee-Items-Receipt-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.txt')
[IO.File]::WriteAllText($report,$text,[Text.UTF8Encoding]::new($false))
Write-Host ('REPORT='+$report)
if($result -ne 0 -or $text -notmatch 'BUMBLEBEE_SIX_ITEMS_CONFIRMED'){throw 'PIESKIRUMS_NAV_APSTIPRINATS; ATSUTI_IZVADI'}
Write-Host 'VISI_6_ITEMI_PASTA; ATVER_PASTU_UN_PANEM_PIELIKUMUS'
