Client291 LoginStart v4 - prepared isolated runtime candidate, Windows/Login/world UNVERIFIED.
Close CABAL first. Extract ALL files into a NEW folder, run Palaist-291-v4.cmd as administrator.
Test VM192.168.56.101 must be running; Login port35003 is checked before client start.
Only F:\CABAL_291_TEST with pinned original Main/SDK/DXVK and existing clone Data/internal.txt.
No game-file replacement or installation. Uses only its own newly created child.
V1/V2/V3 are withdrawn. V4 does NOT write a gate in Main code.
It verifies initial RCX is the original Main entry and RIP maps to ntdll, then selects a private startup gate.
Normal loader/SDK initialization can run with original Main/SDK image bytes.
After a good stopped SDK baseline it restores12 native network prefixes, disables their reattach helpers,
skips SDK ExitLag startup paths, keeps native SECURITY/USE off and translates only2 wire-version calls to282.
Affected Main/SDK code digests are checked and recomputed while the owned child is stopped.
Version282 is a configured server profile, not a new live server readback.
Closing the game discards runtime changes. On startup failure only the owned new child is stopped.
No debugger, replacement DLL or injected thread. Initial start-register semantics remain Windows integration pending.
If Login appears, log in with your test account, select a character and try to enter the world.
Do not enter passwords into console. No credentials or packet contents collected/uploaded automatically.
Observes90seconds. REPORT= gives full Downloads\Client291-LoginStart-v4-*.json path.
No claim that APPLIED means authenticated or world entry achieved.
