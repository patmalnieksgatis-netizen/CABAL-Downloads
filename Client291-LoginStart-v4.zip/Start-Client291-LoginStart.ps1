param([ValidateSet('Inspect','Run')][string]$Action='Inspect')
$ErrorActionPreference='Stop'
if ($Action -eq 'Run') { Write-Host 'LOGIN_START_V4; PARBAUDU_KOMPILACIJU_UN_ORIGINALOS_FAILUS' }
if (![Environment]::Is64BitProcess) { throw 'USE_X64_POWERSHELL' }
$manifestPath=Join-Path $PSScriptRoot 'client291-login-start-v4.json'
if (!(Test-Path -LiteralPath $manifestPath)) {
    $manifestPath=Join-Path (Split-Path -Parent $PSScriptRoot) 'protocol/generated/client291-login-start-v4.json'
}
$manifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.Status -ne 'PREPARED_WINDOWS_UNVERIFIED') {
    if ($Action -eq 'Inspect') {
        [ordered]@{Status=$manifest.Status; Reason=$manifest.WithdrawalReason; ProcessStarted=$false; ClientFileChanges=$false} | ConvertTo-Json
        return
    }
    throw 'LOGIN_START_PROFILE_NOT_PREPARED; CLIENT_NOT_STARTED'
}
if (!('Client291LoginStart' -as [type])) {
    Add-Type -Path (Join-Path $PSScriptRoot 'Client291-LoginStart.cs')
}
$config=New-Object Client291LoginStart+Config
$config.Root=$manifest.TargetRoot
foreach ($name in @('MainSHA256','SDKSHA256','DXVKSHA256','MainEntryRVA','ServerVersion')) {
    $config.$name=$manifest.$name
}
$hooks=@()
foreach ($row in $manifest.MainHooks) {
    $hook=New-Object Client291LoginStart+Hook
    foreach ($name in @('Role','OriginalWindowSHA256','SDKWindowSHA256','RVA','RestoreBytes','ExpectedSDKRVA','RegistrarRVA','RegistrarBytes','RegistrarWindowSHA256','RegistrarSHA256')) {
        $hook.$name=$row.$name
    }
    $hooks+=$hook
}
$config.MainHooks=$hooks
$patches=@()
foreach ($row in $manifest.SDKPatches) {
    $patch=New-Object Client291LoginStart+SDKPatch
    foreach ($name in @('Role','ExpectedSHA256','ReplacementHex','RVA','Bytes')) { $patch.$name=$row.$name }
    $patches+=$patch
}
$config.SDKPatches=$patches
$versions=@()
foreach ($row in $manifest.VersionCalls) {
    $version=New-Object Client291LoginStart+VersionCall
    foreach ($name in @('Role','OriginalFunctionSHA256','RVA','FunctionRVA','FunctionBytes')) { $version.$name=$row.$name }
    $versions+=$version
}
$config.VersionCalls=$versions
if ($Action -eq 'Inspect') {
    [ordered]@{
        Status='CANDIDATE_PREPARED; WINDOWS_BOOTSTRAP_AND_LOGIN_UNVERIFIED'
        TargetRoot=$config.Root; ServerIP=$manifest.ServerIP; ServerLoginPort=$manifest.ServerLoginPort
        ServerVersionProfile=$config.ServerVersion; ProfileVersionIsLiveReadback=$false
        NativeEntries=$hooks.Count; PreventReattachRegistrars=$hooks.Count
        SDKChanges=$patches.Count; VersionChanges=$versions.Count
        ClientFileChanges=$false; ProcessStarted=$false
    } | ConvertTo-Json
    return
}
if ($env:OS -ne 'Windows_NT') { throw 'USE_WINDOWS_X64_POWERSHELL' }
if (Get-Process -Name CabalMain -ErrorAction SilentlyContinue) { throw 'Vispirms aizver CABAL klientu.' }
$downloads=Join-Path $env:USERPROFILE 'Downloads'
$stamp=(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)
$reportPath=Join-Path $downloads ('Client291-LoginStart-v4-'+$stamp+'.json')
$report=[ordered]@{
    Schema=4; ToolVersion='LoginStart-v4'; StartedUTC=[DateTime]::UtcNow.ToString('o'); Status='STARTING'
    ServerVersionProfile=$config.ServerVersion; ServerVersionLiveReadback=$false
    ClientDiskChanges=$false; CredentialsCollected=$false; Events=@(); Failure=$null
}
$session=$null
try {
    'LOGIN_START_V4; ORIGINAL_FAILI_TIKS_SAGLABATI; TIKAI_F_CABAL_291_TEST'
    $probe=New-Object Net.Sockets.TcpClient
    try {
        $connection=$probe.BeginConnect('192.168.56.101',35003,$null,$null)
        if (!$connection.AsyncWaitHandle.WaitOne(5000)) { throw 'CLONE_LOGIN_PORT_UNREACHABLE' }
        $probe.EndConnect($connection)
    } finally { $probe.Dispose() }
    $session=[Client291LoginStart]::Start($config)
    $report.PID=$session.PID; $report.SDKBaseHex=$session.SDKBaseHex
    $report.InitialRIPHex=$session.InitialRIPHex; $report.InitialStartRCXHex=$session.InitialStartRCXHex
    $report.PrivateGateHex=$session.GateBaseHex
    $report.CodeEdits=$session.CodeEditCount; $report.IntegrityRangesRebased=$session.IntegrityUpdates
    $report.Status=$session.Stage
    'TEST_PID='+$session.PID
    'GAIDI_LOGIN_LOGU; INSTALACIJA_NAV_VEIKTA'
    'KAD_LOGIN_PARADAS, IELOGOJIES_AR_SAVU_TESTA_KONTU; PAROLI_KONSOLE_NEIEVADI'
    'PEC_PIESLEGSANAS_IZVELIES_TELU_UN_MEGINI_IEIET_PASAULE'
    'ATSTAJ_SPELI_ATVERTU; NOVEROSANA_90_SEKUNDES'
    $deadline=[DateTime]::UtcNow.AddSeconds(90)
    $last=''
    while ([DateTime]::UtcNow -lt $deadline) {
        $state=$session.Snapshot()
        $event=[ordered]@{UTC=[DateTime]::UtcNow.ToString('o'); State=$state}
        if (!$state.Exited) { $event.CodeStillMatches=$session.VerifyCode() }
        $current=$state | ConvertTo-Json -Compress
        if ($current -cne $last -or $state.Exited -or $event.CodeStillMatches -eq $false) {
            $report.Events+=@($event); $current; $last=$current
        }
        if ($state.Exited) { $report.Status='CLIENT_EXITED'; break }
        if (!$event.CodeStillMatches) { $report.Status='PATCH_CHANGED_AFTER_BOOTSTRAP'; break }
        if (!$state.IntegrityGood) { $report.Status='INTEGRITY_STATUS_CHANGED'; break }
        Start-Sleep -Milliseconds 500
    }
    'SPELE_PALIEK_ATVERTA; LOGIN_REZULTATS_JAAPSTIPRINA_PASA_SPELE'
} catch {
    $report.Status='FAILED'
    $report.Failure=$_.Exception.GetBaseException().Message
    'KLUDA='+$report.Failure
} finally {
    $report.FinishedUTC=[DateTime]::UtcNow.ToString('o')
    $report | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath $reportPath -Encoding UTF8
    if ($null -ne $session) { $session.Dispose() }
    'REPORT='+$reportPath
}
