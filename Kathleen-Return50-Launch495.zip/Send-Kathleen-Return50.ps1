$ErrorActionPreference='Stop'
Write-Host 'KATHLEEN_RETURN_STONE_X50; SANEMSANA_PASTA'
$python=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Send-Kathleen-Return50.py'))
$rows=@($python | & ssh root@192.168.56.101 python3 - --apply-read-log)
$sshExit=$LASTEXITCODE
$visible=@($rows | Where-Object { -not $_.StartsWith('NPC_LOG_BASE64=') }); $visible | ForEach-Object { Write-Host $_ }
$report=Join-Path $env:USERPROFILE ('Downloads\Kathleen-Return50-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.txt')
[IO.File]::WriteAllLines($report,[string[]]$visible,[Text.UTF8Encoding]::new($false))
Write-Host ('REPORT='+$report)
if($sshExit -ne 0 -or -not ($rows | Where-Object { $_.StartsWith('KATHLEEN_RETURN50_TRANSACTION_CONFIRMED;') })){throw 'RETURN50_NAV_APSTIPRINATS; ATSUTI_IZVADI'}
Write-Host 'RETURN_STONE_X50_PASTA; ATKARTOTA_PALAISANA_NEDUBLE'
$folder=Join-Path $env:USERPROFILE ('Downloads\Kathleen-NPC-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $folder | Out-Null
Copy-Item -LiteralPath $report -Destination $folder
$logRows=@($rows | Where-Object { $_.StartsWith('NPC_LOG_BASE64=') })
if($logRows.Count -eq 1){[IO.File]::WriteAllBytes((Join-Path $folder 'WorldSvr-recent.log'),[Convert]::FromBase64String($logRows[0].Substring('NPC_LOG_BASE64='.Length)))}
$latest=Get-ChildItem -LiteralPath "$env:USERPROFILE\Downloads" -Filter 'Client291-LoginStart-v4_9_*.json' -File | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
if($latest){Copy-Item -LiteralPath $latest.FullName -Destination $folder}
Compress-Archive -LiteralPath $folder -DestinationPath ($folder+'.zip')
Write-Host ('NPC_ZIP='+$folder+'.zip')
Write-Host 'ATSUTI_NPC_ZIP_PIRKUMA_UN_TRESAS_ARCANA_ATTEIKUMA_ANALIZEI'
