@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Send-Kathleen-Return50.ps1"
pause
