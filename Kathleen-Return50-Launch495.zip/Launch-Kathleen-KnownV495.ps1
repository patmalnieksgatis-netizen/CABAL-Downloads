$ErrorActionPreference='Stop'
if(Get-Process -Name CabalMain -ErrorAction SilentlyContinue){throw 'VISPIRMS_AIZVER_SPELI_UN_PALAID_VELREIZ'}
$downloads=Join-Path $env:USERPROFILE 'Downloads'
$folder=Join-Path $downloads ('Client291-v4_9_5-'+[guid]::NewGuid().ToString('N'))
$zip=$folder+'.zip'
Write-Host 'LEJUPIELADEJU_PARBAUDITO_V4_9_5; JAUNA_MAPE'
Invoke-WebRequest -UseBasicParsing 'https://github.com/patmalnieksgatis-netizen/CABAL-Downloads/raw/e76536b/Client291-LoginStart-v4_9_5.zip' -OutFile $zip
if((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash -ine 'acffd2a7907b2fdb214ab29ec3afbf356fbd6251498e816835029638b22c9b18'){throw 'V495_ZIP_HASH_DIFFERS; NEPALAIJU'}
Expand-Archive -LiteralPath $zip -DestinationPath $folder
Write-Host ('PAKA=V4.9.5; MAPE='+$folder)
Start-Process -FilePath (Join-Path $folder 'Palaist-291-v4_9_5.cmd') -WorkingDirectory $folder -Verb RunAs
Write-Host 'PASTA_PIELIKUMUS_SANEM_KA_KATHLEEN; LAUNCHER_LOGU_TURI_ATVERTU'
