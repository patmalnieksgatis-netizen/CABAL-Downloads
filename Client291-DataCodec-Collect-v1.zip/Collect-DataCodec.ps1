# Read-only original profile plus1024 bytes at the known unpacked endpoint body. No hooks/writes.
& {
    $ErrorActionPreference = 'Stop'
    try {
    if (![Environment]::Is64BitProcess) { throw 'USE_X64_POWERSHELL' }
    if (Get-Process -Name CabalMain -ErrorAction SilentlyContinue) {
        throw 'Vispirms aizver Cabal speles logus.'
    }
    $exe = 'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe'
    $bin = Split-Path -Parent $exe
    $checks = @{
        'CabalMain.exe'='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
        'libogg.dll'='ceafa8291dcf090856a215285114270fea1a8978bc2d2b26b33bcb7b3ac5c2a9'
        'd3d9.dll'='216058f9320d0667d551f4cea840ee539396449ef8c8e89fe481e4f0ddb628ae'
    }
    foreach ($name in $checks.Keys) {
        if ((Get-FileHash -LiteralPath (Join-Path $bin $name) -Algorithm SHA256).Hash -ne $checks[$name]) {
            throw ('ORIGINAL_FILE_DIFFERS='+$name+'; RESTORE_ORIGINAL_SDK_FIRST')
        }
    }
    if (!('Client291DataCodecRead' -as [type])) {
        Add-Type @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class Client291DataCodecRead {
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr h, IntPtr a, byte[] b, UIntPtr n, out UIntPtr got);
    public static byte[] Read(IntPtr h, long a, int n) {
        if (a<65536 || a>0x7fffffffffffL || n<1 || n>256) throw new Exception("READ_BOUNDS");
        byte[] b=new byte[n]; UIntPtr got;
        if (!ReadProcessMemory(h,new IntPtr(a),b,new UIntPtr((uint)n),out got))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        if (got.ToUInt64()!=(ulong)n) throw new Exception("PARTIAL_READ");
        return b;
    }
    public static uint U32(IntPtr h,long a) { return BitConverter.ToUInt32(Read(h,a,4),0); }
    [StructLayout(LayoutKind.Sequential)]
    struct Region { public IntPtr Base, AllocationBase; public uint AllocationProtect;
        public ushort Partition, Padding; public UIntPtr Size;
        public uint State, Protect, Type; }
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern UIntPtr VirtualQueryEx(IntPtr h, IntPtr at, out Region r, UIntPtr size);
    public static string EndpointCode(IntPtr h) {
        long entry=0x14069afd8;
        for(int hop=0;hop<4;hop++){
            byte[] b=Read(h,entry,6);
            if(b[0]==0xe9) {entry=checked(entry+5+BitConverter.ToInt32(b,1));continue;}
            if(b[0]==0xff && b[1]==0x25){
                entry=BitConverter.ToInt64(Read(h,checked(entry+6+BitConverter.ToInt32(b,2)),8),0);continue;
            }
            break;
        }
        long sdk=checked(entry-0x5e33d0);
        byte[] head=Read(h,sdk,256);
        if(head[0]!=77 || head[1]!=90)throw new Exception("SDK_ENTRY_LAYOUT_DIFFERS");
        int pe=BitConverter.ToInt32(head,60);
        if(pe<64 || pe>2048)throw new Exception("SDK_PE_OFFSET_DIFFERS");
        byte[] header=Read(h,checked(sdk+pe),84);
        if(BitConverter.ToUInt32(header,0)!=0x4550 || BitConverter.ToUInt16(header,4)!=0x8664 ||
           BitConverter.ToUInt16(header,24)!=0x20b || BitConverter.ToUInt32(header,80)!=0x1264000)
            throw new Exception("SDK_IMAGE_LAYOUT_DIFFERS");
        long target=checked(sdk+0xacf83c); const int count=1024;
        Region r;int size=Marshal.SizeOf(typeof(Region));
        if(size!=48 || VirtualQueryEx(h,new IntPtr(target),out r,new UIntPtr((uint)size)).ToUInt64()!=(ulong)size)
            throw new Win32Exception(Marshal.GetLastWin32Error());
        ulong start=(ulong)target,end=(ulong)r.Base.ToInt64()+r.Size.ToUInt64();
        if(r.AllocationBase.ToInt64()!=sdk || r.Type!=0x1000000 || r.State!=0x1000 ||
           (r.Protect&0x101)!=0 || (r.Protect&0xf0)==0 || start<(ulong)r.Base.ToInt64() || end<start || end-start<count)
            throw new Exception("TARGET_NOT_EXPECTED_EXECUTABLE_IMAGE_REGION");
        byte[] code=new byte[count];
        for(int i=0;i<count;i+=256)Array.Copy(Read(h,target+i,256),0,code,i,256);
        return sdk.ToString("X")+"|"+entry.ToString("X")+"|"+target.ToString("X")+"|"+Convert.ToBase64String(code);
    }
    public static byte[] SDKHelperCode(IntPtr h,long sdk,long rva) {
        if(rva<0x1000 || rva>0x1264000-1024)
            throw new Exception("RVA_NOT_IN_FIXED_CAPTURE_LIST");
        long at=checked(sdk+rva);const int count=1024;
        Region r;int size=Marshal.SizeOf(typeof(Region));
        if(size!=48 || VirtualQueryEx(h,new IntPtr(at),out r,new UIntPtr((uint)size)).ToUInt64()!=(ulong)size)
            throw new Win32Exception(Marshal.GetLastWin32Error());
        ulong start=(ulong)at,end=(ulong)r.Base.ToInt64()+r.Size.ToUInt64();
        if(r.AllocationBase.ToInt64()!=sdk || r.Type!=0x1000000 || r.State!=0x1000 ||
           (r.Protect&0x101)!=0 || (r.Protect&0xf0)==0 || start<(ulong)r.Base.ToInt64() || end<start || end-start<count)
            throw new Exception("HELPER_NOT_EXPECTED_EXECUTABLE_IMAGE_REGION");
        byte[] code=new byte[count];
        for(int i=0;i<count;i+=256)Array.Copy(Read(h,at+i,256),0,code,i,256);
        return code;
    }
    public static byte[] ReadOnlyConstant(IntPtr h,long sdk,long at) {
        if(at<sdk+4096 || at>sdk+0x1264000-64)throw new Exception("CONST_BOUNDS");
        Region r;int size=Marshal.SizeOf(typeof(Region));
        if(VirtualQueryEx(h,new IntPtr(at),out r,new UIntPtr((uint)size)).ToUInt64()!=(ulong)size)
            throw new Win32Exception(Marshal.GetLastWin32Error());
        ulong start=(ulong)at,end=(ulong)r.Base.ToInt64()+r.Size.ToUInt64();uint kind=r.Protect&255;
        if(r.AllocationBase.ToInt64()!=sdk || r.Type!=0x1000000 || r.State!=0x1000 ||
           (r.Protect&0x101)!=0 || (kind!=2 && kind!=0x20) || start<(ulong)r.Base.ToInt64() || end<start || end-start<64)
            throw new Exception("CONST_NOT_READONLY_SDK_IMAGE");
        return Read(h,at,64);
    }
    public static long Jump(IntPtr h,long at) {
        byte[] b=Read(h,at,6);
        if(b[0]==0xe9)return checked(at+5+BitConverter.ToInt32(b,1));
        if(b[0]==0xff && b[1]==0x25)
            return BitConverter.ToInt64(Read(h,checked(at+6+BitConverter.ToInt32(b,2)),8),0);
        return 0;
    }
    public static string Mode(IntPtr h) {
        long p=BitConverter.ToInt64(Read(h,0x14120f7a0,8),0);
        if(p<65536 || p>0x7fffffffffffL) return "UNINITIALIZED";
        byte[] b=Read(h,p,12);uint sum=b[4],value=0;
        for(int i=0;i<4;i++){sum+=b[i];value|=(uint)(b[i]^b[4])<<(i*8);}
        return sum==BitConverter.ToUInt32(b,8)?value.ToString():"CHECKSUM_DIFFERS";
    }
    public static string Text(IntPtr h,long a) {
        byte[] b=Read(h,a,32); ulong n=BitConverter.ToUInt64(b,16),cap=BitConverter.ToUInt64(b,24);
        if(n==0) return "EMPTY";
        if(n>255 || cap<n || cap>4096) return "UNSUPPORTED_STRING";
        string s=System.Text.Encoding.ASCII.GetString(Read(h,cap<16?a:BitConverter.ToInt64(b,0),(int)n));
        return System.Text.RegularExpressions.Regex.IsMatch(s,@"^[A-Za-z0-9._:-]{1,255}$")?s:"UNEXPECTED_ENDPOINT_TEXT";
    }
}
'@
    }
    $stamp=(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)
    $payload=Join-Path $PSScriptRoot ('Payload-'+$stamp)
    New-Item -ItemType Directory -Path $payload | Out-Null
    $copied=@();$budget=0
    foreach($relative in @('Data\cabal.enc','Data\Language\English\cabal_msg.enc','Data\Language\Korean\cabal_msg.enc')){
        $source=Join-Path 'F:\CABAL_291_TEST' $relative
        if(!(Test-Path -LiteralPath $source -PathType Leaf)){continue}
        $info=Get-Item -LiteralPath $source
        $budget+=$info.Length
        if($info.Length -gt 8MB -or $budget -gt 16MB){throw 'SELECTED_DATA_SIZE_BOUND; NO_CLIENT_CHANGES'}
        $hash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
        $dest=Join-Path $payload $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $dest
        if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $hash -or
           (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash -ne $hash){throw 'DATA_COPY_CHANGED_DURING_READ'}
        $copied += [ordered]@{RelativePath=$relative;Bytes=$info.Length;SHA256=$hash}
    }
    if(!$copied.Count){throw 'SELECTED_DATA_FILES_NOT_FOUND; NO_CLIENT_CHANGES'}
    $priorLogs=@()
    $downloadRoot=Join-Path $env:USERPROFILE 'Downloads'
    $folders=@(Get-ChildItem -LiteralPath $downloadRoot -Directory -Filter 'Client291-Native-Skip-Test-v2*' -ErrorAction SilentlyContinue)
    $candidates=@($folders | ForEach-Object {
        Get-ChildItem -LiteralPath $_.FullName -File -Filter 'Client291-Native-Skip-Run-*.txt' -ErrorAction SilentlyContinue
    } | Sort-Object LastWriteTime -Descending | Select-Object -First 2)
    foreach($log in $candidates){
        if($log.Length -gt 128KB){continue}
        $name='Previous-V2-Run-'+($priorLogs.Count+1)+'.txt'
        Copy-Item -LiteralPath $log.FullName -Destination (Join-Path $payload $name)
        $priorLogs += $name
    }
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$exe;$start.Arguments='breaklee';$start.WorkingDirectory=$bin;$start.UseShellExecute=$false
    $game=[Diagnostics.Process]::Start($start)
    try {
        $h=$game.Handle
        'TEST_PID='+$game.Id
        'GAIDI_20_SEKUNDES; LOGIN_UN_ENTER_NAV_JASPIEZ'
        $until=[DateTime]::UtcNow.AddSeconds(20)
        while([DateTime]::UtcNow -lt $until){
            if($game.HasExited){throw ('ORIGINAL_CLIENT_EXITED='+$game.ExitCode)}
            Start-Sleep -Milliseconds 250
        }
        if([Text.Encoding]::ASCII.GetString([Client291DataCodecRead]::Read($h,0x140000000,2)) -cne 'MZ'){throw 'EXPECTED_IMAGE_BASE_DIFFERS'}
        $parts=[Client291DataCodecRead]::EndpointCode($h).Split('|')
        $sdk=[Convert]::ToInt64($parts[0],16)
        $procedures=@();$constants=@();$constantAttempts=0
        $seenConstants=New-Object 'System.Collections.Generic.HashSet[long]' 
        foreach($spec in @(
            @{Name='FileReader';Main=0x1402b5550;Expected=0x5cda90},
            @{Name='CheckValidData';Main=0x14040e184;Expected=0x5e1170}
        )){
            $entry=[long]$spec.Main
            try {
                for($hop=0;$hop -lt 4;$hop++){
                    if($entry -ge $sdk -and $entry -lt $sdk+0x1264000){break}
                    $next=[Client291DataCodecRead]::Jump($h,$entry)
                    if(!$next){break};$entry=$next
                }
                if($entry -lt $sdk+0x1000 -or $entry -ge $sdk+0x1264000){throw 'HOOK_TARGET_NOT_IN_VERIFIED_SDK'}
                $fragments=@();$at=$entry
                for($hop=0;$hop -lt 3;$hop++){
                    $code=[Client291DataCodecRead]::SDKHelperCode($h,$sdk,$at-$sdk)
                    $fragments += [ordered]@{RVAHex=($at-$sdk).ToString('X');Bytes=$code.Length;CodeBase64=[Convert]::ToBase64String($code)}
                    for($i=0;$i -lt $code.Length-7 -and $constants.Count -lt 32 -and $constantAttempts -lt 128;$i++){
                        $offset=-1;$length=0
                        if($code[$i] -ge 0x48 -and $code[$i] -le 0x4f -and
                           $code[$i+1] -in @(0x8d,0x8b,0x03,0x33) -and ($code[$i+2] -band 0xc7) -eq 5){$offset=$i+3;$length=7}
                        elseif($code[$i] -in @(0x8d,0x8b,0x03,0x33) -and ($code[$i+1] -band 0xc7) -eq 5){$offset=$i+2;$length=6}
                        if($offset -lt 0){continue}
                        $candidate=[long]$at+$i+$length+[BitConverter]::ToInt32($code,$offset)
                        if(!$seenConstants.Add($candidate)){continue};$constantAttempts++
                        try {
                            $bytes=[Client291DataCodecRead]::ReadOnlyConstant($h,$sdk,$candidate)
                            $constants += [ordered]@{RVAHex=($candidate-$sdk).ToString('X');Bytes=64;
                                ReadOnlySDKImageVerified=$true;CodeReferenceIsHeuristic=$true;
                                ReferencedFromHex=($at+$i).ToString('X');DataBase64=[Convert]::ToBase64String($bytes)}
                        } catch {}
                    }
                    $next=[Client291DataCodecRead]::Jump($h,$at)
                    if(!$next -or $next -eq $at -or $next -lt $sdk+0x1000 -or $next -gt $sdk+0x1264000-1024){break}
                    $at=$next
                }
                $procedures += [ordered]@{Name=$spec.Name;MainHex=([long]$spec.Main).ToString('X');EntryRVAHex=($entry-$sdk).ToString('X');ExpectedEntryMatch=($entry -eq $sdk+$spec.Expected);Fragments=$fragments}
            } catch {$procedures += [ordered]@{Name=$spec.Name;Error=$_.Exception.GetBaseException().Message}}
        }
        foreach($name in $checks.Keys){
            if((Get-FileHash -LiteralPath (Join-Path $bin $name) -Algorithm SHA256).Hash -ne $checks[$name]){throw ('DISK_FILE_CHANGED_DURING_READ='+$name)}
        }
        $report=Join-Path $payload 'DataCodec-Report.json'
        [ordered]@{Schema=1;PID=$game.Id;ReadUTC=[DateTime]::UtcNow.ToString('o');
            SDKBaseHex=$sdk.ToString('X');MainSHA256=$checks['CabalMain.exe'];OriginalOggSHA256=$checks['libogg.dll'];
            SelectedData=$copied;PreviousV2Logs=$priorLogs;Procedures=$procedures;ReadOnlyConstants=$constants;
            ConstantCandidateAttempts=$constantAttempts;PointerDataDereferenced=$false;
            LoginRequested=$false;ClientFilesModified=$false
        } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $report -Encoding UTF8
        $zip=Join-Path $PSScriptRoot ('Client291-DataCodec-'+$stamp+'.zip')
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [IO.Compression.ZipFile]::CreateFromDirectory($payload,$zip,[IO.Compression.CompressionLevel]::Optimal,$true)
        $check=[IO.Compression.ZipFile]::OpenRead($zip)
        try {
            foreach($file in $copied){
                $suffix='/'+$file.RelativePath.Replace([char]92,[char]47)
                $entries=@($check.Entries | Where-Object {$_.FullName.Replace([char]92,[char]47).EndsWith($suffix,[StringComparison]::OrdinalIgnoreCase)})
                if($entries.Count -ne 1 -or $entries[0].Length -ne $file.Bytes){throw 'BUNDLE_ENTRY_VERIFICATION_FAILED'}
            }
        } finally {$check.Dispose()}
        'UPLOAD='+$zip
        'READ_ONLY_COLLECTION_COMPLETE; ORIGINAL_FILES_VERIFIED; GAME_LEFT_OPEN; LOGIN_NOT_TESTED'
    } finally {$game.Dispose()}
    } catch {
        'TEST_ERROR='+$_.Exception.GetBaseException().Message
        'ERROR_LOCATION='+$_.InvocationInfo.PositionMessage
        'GAME_NOT_AUTOMATICALLY_STOPPED'
        throw
    }
} | Tee-Object -FilePath (Join-Path $PSScriptRoot ('Client291-DataCodec-Run-'+(Get-Date -Format yyyyMMdd-HHmmss)+'.txt'))
