@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-DataCodec.ps1"
echo.
pause
