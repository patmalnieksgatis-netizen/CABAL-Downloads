CLIENT291 V4.9.8: EMPTY EQUIPMENT ROW FIX
Close CABAL and the old Launcher. Extract the ZIP into a NEW directory.
Run Palaist-291-v4_9_8.cmd as administrator, leave Launcher open and join CH.
Send the visible result or the Downloads Client291-LoginStart-v4_9_8-*.json.

V497 identified: row1, equipment entry28, raw slot0, zero64-bit item kind,
refused as duplicate. V498 validates source bounds, then omits zero-kind
legacy equipment/appearance rows from our output and recomputes output counts.
Every real item row is preserved including serial/options/order. The input
packet is never changed. Nonzero duplicates, all out-of-range indices, account,
frame and count checks remain. Guardian12->50 mapping remains. Exact291 input
keeps previous strict validation. No item deletion, level reset, DB changes,
server installation/restart, original client disk writes or texture changes.

This addresses the observed refusal. Live channel/world result is pending.
CH_SLOT_FAILURE metadata stays available if another real invalid slot occurs.
