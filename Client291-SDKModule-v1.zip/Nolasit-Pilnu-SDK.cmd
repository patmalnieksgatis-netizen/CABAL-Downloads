@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Read-Client291-SDKModule.ps1" -Action Read
pause
