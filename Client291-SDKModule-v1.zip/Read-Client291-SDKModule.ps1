param([ValidateSet('Inspect','Read')][string]$Action='Inspect')
$ErrorActionPreference='Stop'
$manifestPath=Join-Path $PSScriptRoot 'client291-sdk-module-reader-v1.json'
if (!(Test-Path -LiteralPath $manifestPath)) {
    $manifestPath=Join-Path (Split-Path -Parent $PSScriptRoot) 'protocol/generated/client291-sdk-module-reader-v1.json'
}
$manifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.Status -ne 'READ_ONLY_DIAGNOSTIC_WINDOWS_PENDING') { throw 'UNREVIEWED_READER_MANIFEST' }
if ($Action -eq 'Inspect') {
    [ordered]@{
        Status=$manifest.Status; Scope='Full original SDK mapped image, including writable SDK image data'
        TargetRoot=$manifest.TargetRoot; ProcessStarted=$false; ClientMemoryWrites=$false
        ClientFileChanges=$false; HeapRead=$false; LoginRequested=$false
        BriefOwnChildPauseForSnapshot=$true; RunnableUnpackedDLLProved=$false
    } | ConvertTo-Json
    return
}
'SDK_MODULA_NOLASISANA; NAV_LOGIN_LABOJUMS; KLIENTA_KODS_NETIEK_MAINITS'
if (![Environment]::Is64BitProcess -or $env:OS -ne 'Windows_NT') { throw 'USE_WINDOWS_X64_POWERSHELL' }
if ($manifest.TargetRoot -cne 'F:\CABAL_291_TEST') { throw 'ISOLATED_TEST_ROOT_ONLY' }
if (Get-Process -Name CabalMain -ErrorAction SilentlyContinue) { throw 'VISPIRMS_AIZVER_CABAL_KLIENTU' }
$bin=Join-Path $manifest.TargetRoot 'Bin\x64'
$exe=Join-Path $bin 'CabalMain.exe'
function Check-Originals {
    foreach ($row in $manifest.OriginalFileSHA256.PSObject.Properties) {
        if ((Get-FileHash -LiteralPath (Join-Path $bin $row.Name) -Algorithm SHA256).Hash -ne $row.Value) {
            throw ('ORIGINAL_FILE_DIFFERS='+$row.Name)
        }
    }
}
Check-Originals
if (!('Client291SDKImageRead' -as [type])) {
    Add-Type -Path (Join-Path $PSScriptRoot 'Client291-SDKImageRead.cs')
}
if ($null -eq [Client291SDKImageRead].GetMethod('CaptureModule')) { throw 'USE_FRESH_POWERSHELL_SESSION' }
$downloads=Join-Path $env:USERPROFILE 'Downloads'
$stamp=(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)
$payload=Join-Path $downloads ('Client291-SDKModule-'+$stamp)
New-Item -ItemType Directory -Path $payload | Out-Null
$reportPath=Join-Path $payload 'SDKModule-Report.json'
$report=[ordered]@{
    Schema=1; Tool='SDKModule-reader-v1'; Status='STARTING'; StartedUTC=[DateTime]::UtcNow.ToString('o')
    OriginalFileSHA256=$manifest.OriginalFileSHA256; Snapshot=$null; Failure=$null
    SnapshotIncludesWritableSDKImage=$true; SnapshotIncludesHeap=$false; OtherModuleImagesExported=$false
    ClientMemoryWrites=$false; ClientFileChanges=$false; LoginRequested=$false
    OriginalFilesVerifiedAfter=$false; UploadedAutomatically=$false; RunnableUnpackedDLLProved=$false
}
$game=$null
try {
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$exe; $start.Arguments='breaklee'; $start.WorkingDirectory=$bin; $start.UseShellExecute=$false
    $game=[Diagnostics.Process]::Start($start)
    $report.PID=$game.Id
    $report.ProcessStartedUTC=$game.StartTime.ToUniversalTime().ToString('o')
    $handle=$game.Handle
    'TEST_PID='+$game.Id
    'LOGIN_NESPIED; GAIDI_SDK_NOLASISANU; SPELE_PALIKS_ATVERTA'
    $deadline=[DateTime]::UtcNow.AddSeconds(25); $sdk=$null; $lastFailure='SDK_NOT_READY'
    do {
        if ($game.HasExited) { throw ('ORIGINAL_CLIENT_EXITED='+$game.ExitCode) }
        try {
            $sdk=[Client291SDKImageRead]::SDKBase($handle)
            $anchors=@([Client291SDKImageRead]::Anchors($handle,$sdk))
            if (($anchors -join '|') -cne ($manifest.ExpectedAnchors -join '|')) { throw 'ORIGINAL_SDK_CODE_NOT_READY' }
            break
        } catch {
            $sdk=$null; $lastFailure=$_.Exception.GetBaseException().Message
            Start-Sleep -Milliseconds 100
        }
    } while ([DateTime]::UtcNow -lt $deadline)
    if ($null -eq $sdk) { throw ('SDK_READ_NOT_READY='+$lastFailure) }
    $report.SDKBaseHex=$sdk.ToString('X')
    'NOLASU_TIKAI_SDK_MODULI; ISLAICIGA_PROCESA_APTURESANA_UN_ATSAKSANA'
    $snapshot=[Client291SDKImageRead]::CaptureModule($handle,$sdk,$payload)
    $report.Snapshot=$snapshot
    Check-Originals
    $report.OriginalFilesVerifiedAfter=$true
    if ((Get-FileHash -LiteralPath (Join-Path $payload $snapshot.Image.File) -Algorithm SHA256).Hash -ne $snapshot.Image.SHA256) {
        throw 'SAVED_IMAGE_HASH_DIFFERS'
    }
    if (!$snapshot.AnchorsStable -or !$snapshot.Resumed) { throw 'SNAPSHOT_STABILITY_OR_RESUME_DIFFERS' }
    $report.Status=if ($snapshot.Image.Complete) {'SDK_MODULE_SNAPSHOT_COMPLETE'} else {'SDK_MODULE_SNAPSHOT_WITH_RECORDED_HOLES'}
} catch {
    $report.Status='FAILED'; $report.Failure=$_.Exception.GetBaseException().Message
    'KLUDA='+$report.Failure
} finally {
    $report.FinishedUTC=[DateTime]::UtcNow.ToString('o')
    $report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $reportPath -Encoding UTF8
    if ($null -ne $game) { $game.Dispose() }
    'REPORT='+$reportPath
}
if ($report.Status -ne 'FAILED') {
    $archive=$payload+'.zip'
    Compress-Archive -LiteralPath @((Join-Path $payload 'sdk-image.bin'),$reportPath) -DestinationPath $archive -CompressionLevel Optimal
    'UPLOAD='+$archive
    'READ_ONLY_MODULE_CAPTURE_COMPLETE; ORIGINAL_FILES_VERIFIED; GAME_LEFT_OPEN; LOGIN_NOT_TESTED'
}
