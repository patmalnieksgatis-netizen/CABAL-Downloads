$ErrorActionPreference = 'Stop'
Write-Host 'KATHLEEN: +1000000000000 ALZ; +20000 FORCE GEM; SPELEI JABUT AIZVERTAI'
Write-Host 'SETS UN ARCANA VEL NETIEK PIEVIENOTI; TO DATI TIKS NOLASITI'
$python = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Run-Client291-KathleenFundsAndRead.py'))
$rows = @($python | & ssh root@192.168.56.101 python3 - --apply)
$sshExit = $LASTEXITCODE
$records = @($rows | Where-Object { $_.StartsWith('GRANT_READ_JSON=') })
$rows | Where-Object { -not $_.StartsWith('GRANT_READ_JSON=') } | ForEach-Object { Write-Host $_ }
if ($sshExit -ne 0 -or $records.Count -ne 1) { throw 'IZPILDE_NAV_PILNIGI_APSTIPRINATA; ATSTITI_REDZAMO_IZVADI' }
$text = $records[0].Substring('GRANT_READ_JSON='.Length)
$report = $text | ConvertFrom-Json
$folder = Join-Path $env:USERPROFILE ('Downloads\Client291-Kathleen-Result-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $folder | Out-Null
[IO.File]::WriteAllText((Join-Path $folder 'Kathleen-Result.json'),$text,[Text.UTF8Encoding]::new($false))
$zip = $folder + '.zip'
Compress-Archive -LiteralPath (Join-Path $folder 'Kathleen-Result.json') -DestinationPath $zip
Write-Host ('ZIP=' + $zip)
if ($report.FundsTransactionConfirmed -eq $true) { Write-Host 'ALZ_UN_FORCEGEM_TRANSAKCIJA_APSTIPRINATA' } else { Write-Host 'ALZ_UN_FORCEGEM_NAV_APSTIPRINATI; ATSUTI_ZIP' }
Write-Host 'ATSUTI_SO_ZIP_SETA_UN_ARCANA_SAGATAVOSANAI'
