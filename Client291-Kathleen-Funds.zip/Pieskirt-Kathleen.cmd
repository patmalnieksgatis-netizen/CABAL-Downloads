@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-Client291-KathleenFunds.ps1"
pause
