V4.7 - CORE WORLD142 -> V291 CANDIDATE; WINDOWS WORLD ENTRY UNVERIFIED

Only F:\CABAL_291_TEST and test VM192.168.56.101. Original game files,
server files and SQL are unchanged. Uses the verified V4.5 Login/CH/character
adapter and a new RAM-only World field/stream conversion.

Close CABAL, leave test VM running. Run Palaist-291-v4_7.cmd as administrator.
Log in using the same test account, select CH and character, enter World once.
On success the game stays open. Tell us what appears in the game and return
Downloads/Client291-LoginStart-v4_7-*.json (exact path printed as REPORT).
A prepared World frame is recorded before it reaches the original reader.
Dispatch counters are NOT proof that World entry completed.
If the source fails a specific compatibility check, the tool records the
reason and closes only its own diagnostic client. Return that JSON.

New World source fixed tail2F9B -> target2FB1; accepted variable bytes stay
unchanged. New five setting records have valid keys0..4. Classic inventory,
equipment,skills,quickslots,crafting,merit,appearance and Costume fields are
retained by their measured offsets. Existing SDK hooks are retained, and the
World handoff preserves the original native caller return and RDX/R8/R9.
The old producer's forced high byte in the final15-byte-list count is corrected
only if the entire frame extent proves one count with the same low byte.

Nonempty old fixed pet state, active quest state requiring data-definition
reconciliation and legacy EventPass progress are explicitly refused in this
candidate. They are not silently cleared or migrated. This is not a full
port of all server systems. Source frames stay private in process RAM; no
packet/name/account/character/session/key data is exported.64 nonreused source+
target buffer pairs bound lifetime; restart the test client before a65th World.

Status1 prepared,2 dispatched;10 frame,11 name,12 count,13 slot,14 old pets,
15 quests,16 old EventPass,17 unwind,18 stream extent,19 unexplained tail,
20 buffer limit. BadOffset/BadCount/Group/Cursor identify a refusal.
ListDeclared/ListRestored show exact final-list count recovery.

Own-code Win64 ABI/guard-page tests and pinned registration guards pass locally.
The game/SDK boundary in that native test is a host stub; actual Windows World
entry remains to be verified. ZIP includes only own code and build metadata.
