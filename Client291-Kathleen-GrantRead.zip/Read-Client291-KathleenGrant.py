"""Read the requested test character and native item/grant contracts only.

Run through SSH stdin on the identified test VM. No game SQL procedure is
executed, no SQL row is changed, and no service is stopped or restarted.
The returned definitions are private evidence, not a public distribution.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess

VM_UUID = '7632fb78-37a0-f645-97c0-dc322c50b002'


def run(args, data=None):
    result = subprocess.run(args, input=data, capture_output=True, timeout=60)
    if result.returncode:
        raise RuntimeError('READ_FAILED_NO_CHANGES')
    return result.stdout


def main():
    if os.geteuid() != 0 or Path('/sys/class/dmi/id/product_uuid').read_text().strip().lower() != VM_UUID:
        raise SystemExit('WRONG_TEST_VM_OR_ROOT_REQUIRED_NO_ACTION')
    query = """SET NOCOUNT ON; SET LOCK_TIMEOUT 5000;
IF DB_NAME()<>N'Server01' THROW 51000,'WRONG_GAME_DATABASE',1;
DECLARE @user int,@character int;
IF (SELECT COUNT(*) FROM Account.dbo.cabal_auth_table
 WHERE ID COLLATE Latin1_General_100_BIN2='wolverine')<>1
 THROW 51000,'TEST_ACCOUNT_NOT_UNIQUE',1;
SELECT @user=UserNum FROM Account.dbo.cabal_auth_table
 WHERE ID COLLATE Latin1_General_100_BIN2='wolverine';
IF (SELECT COUNT(*) FROM dbo.cabal_character_table
 WHERE CharacterIdx/16=@user AND Name COLLATE Latin1_General_100_BIN2='Kathleen')<>1
 THROW 51000,'KATHLEEN_NOT_UNIQUE_ON_TEST_ACCOUNT',1;
SELECT @character=CharacterIdx FROM dbo.cabal_character_table
 WHERE CharacterIdx/16=@user AND Name COLLATE Latin1_General_100_BIN2='Kathleen';
DECLARE @report nvarchar(max);
SET @report=(SELECT
 JSON_QUERY((SELECT UserNum,ID,[Login] FROM Account.dbo.cabal_auth_table
  WHERE UserNum=@user FOR JSON PATH)) AS Account,
 JSON_QUERY((SELECT CharacterIdx,Name,LEV,Style,[STR],[DEX],[INT],Alz,[Login]
  FROM dbo.cabal_character_table WHERE CharacterIdx/16=@user FOR JSON PATH)) AS Characters,
 JSON_QUERY((SELECT CharacterIdx,DATALENGTH(Data) AS Bytes,
  CONVERT(varchar(64),HASHBYTES('SHA2_256',Data),2) AS SHA256
  FROM dbo.cabal_inventory_table WHERE CharacterIdx=@character FOR JSON PATH)) AS Inventory,
 JSON_QUERY((SELECT UserNum,ForcegemHave,Reserved1,DATALENGTH(AchievementRewardData) AS RewardBytes
  FROM dbo.cabal_forcegem_table WHERE UserNum=@user FOR JSON PATH)) AS ForceGem,
 JSON_QUERY((SELECT o.name,
  CONVERT(varchar(64),HASHBYTES('SHA2_256',CONVERT(varbinary(max),m.definition)),2) AS SHA256,
  m.definition FROM sys.objects o JOIN sys.sql_modules m ON m.object_id=o.object_id
  WHERE SCHEMA_NAME(o.schema_id)='dbo' AND o.name IN
  ('DoAlzXor','cabal_tool_forcegem_set','cabal_tool_inventory_set',
   'cabal_tool_Issue_serial','cabal_tool_mail_send','SplitStyle')
  ORDER BY o.name FOR JSON PATH)) AS Modules,
 JSON_QUERY((SELECT OBJECT_NAME(p.object_id) AS ProcedureName,p.parameter_id,p.name,
  TYPE_NAME(p.user_type_id) AS TypeName,p.max_length,p.is_output
  FROM sys.parameters p WHERE p.object_id IN
  (OBJECT_ID('dbo.DoAlzXor'),OBJECT_ID('dbo.cabal_tool_forcegem_set'),
   OBJECT_ID('dbo.cabal_tool_inventory_set'),OBJECT_ID('dbo.cabal_tool_Issue_serial'),
   OBJECT_ID('dbo.cabal_tool_mail_send'),OBJECT_ID('dbo.SplitStyle'))
  ORDER BY p.object_id,p.parameter_id FOR JSON PATH)) AS Parameters,
 JSON_QUERY((SELECT t.name AS TableName,c.name AS ColumnName,
  TYPE_NAME(c.user_type_id) AS TypeName,c.max_length,c.is_nullable
  FROM sys.tables t JOIN sys.columns c ON c.object_id=t.object_id
  WHERE t.name IN ('cabal_character_table','cabal_inventory_table',
   'cabal_forcegem_table','cabal_itemserial_table')
  ORDER BY t.name,c.column_id FOR JSON PATH)) AS Columns
 FOR JSON PATH,WITHOUT_ARRAY_WRAPPER);
-- Transport UTF16LE as hex, avoiding PRINT width, locale and whitespace loss.
SET @report=CONVERT(varchar(max),CONVERT(varbinary(max),@report),2);
DECLARE @at int=1;
WHILE @at<=LEN(@report)
BEGIN PRINT 'GRANT_READ:'+SUBSTRING(@report,@at,2000); SET @at+=2000; END;
PRINT 'GRANT_READ_COMPLETE_NO_CHANGES';
"""
    shell = '''set +x
export SQLCMDPASSWORD="${MSSQL_SA_PASSWORD:-${SA_PASSWORD:-}}"
[ -n "$SQLCMDPASSWORD" ] || exit 2
tool=/opt/mssql-tools18/bin/sqlcmd
[ -x "$tool" ] || tool=/opt/mssql-tools/bin/sqlcmd
exec "$tool" -S localhost -U sa -N -C -d Server01 -b -l 5 -t 30 -f 65001 -h -1 -W -w 65535 -i /dev/stdin
'''
    output = run(['docker','exec','-i','sql_main','sh','-ec',shell], query.encode('utf-8')).decode('utf-8-sig')
    if 'GRANT_READ_COMPLETE_NO_CHANGES' not in output.splitlines():
        raise RuntimeError('SQL_READ_NOT_CONFIRMED_NO_CHANGES')
    encoded = ''.join(line[len('GRANT_READ:'):] for line in output.splitlines()
                      if line.startswith('GRANT_READ:'))
    snapshot = json.loads(bytes.fromhex(encoded).decode('utf-16-le'))
    definitions = []
    for name in ('Item.scp','Item2.scp','Item3.scp','Item4.scp','Const.scp'):
        path = '/etc/cabal/Data/' + name
        size = int(run(['docker','exec','cabal_main','stat','-Lc','%s',path]))
        if not 0 < size <= 8 * 1024**2:
            raise RuntimeError('DEFINITION_SIZE_BOUND_NO_CHANGES')
        body = run(['docker','exec','cabal_main','cat',path])
        if len(body) != size:
            raise RuntimeError('DEFINITION_CHANGED_DURING_READ_NO_CHANGES')
        definitions.append(dict(Name=name, Bytes=len(body), SHA256=hashlib.sha256(body).hexdigest(),
                                Base64=base64.b64encode(body).decode('ascii')))
    print(json.dumps(dict(Schema=1,Status='READ_ONLY_COMPLETE',Changes=False,
                          TargetAccount='wolverine',TargetCharacter='Kathleen',
                          Snapshot=snapshot,Definitions=definitions),ensure_ascii=True))


if __name__ == '__main__':
    main()
