Client291 LoginStart v4.3 - isolated native EP36 CompletedStep1 type profile.
Close CABAL. Keep test VM192.168.56.101 running. Extract ALL files to a NEW folder.
Run Palaist-291-v4_3.cmd as administrator. Only F:\CABAL_291_TEST and pinned originals.
Preserves working V4.2 startup/native integrity/3383 Login opcode compatibility.
Adds one guarded comparison: completed auth subtype13 selection becomes native17.
Original common result handler consumes the REAL result and payload; no forced success.
Native server state, auth configuration and actual reply bytes are unchanged.
This is the native EP36 profile, not general simultaneous type13/type17 support.
Server snapshot2026-11-10T16:44:33Z: channel0/300, correct192.168.56.101:35011.
Current attempt16:27:45 logs CompletedStep1 VerifySuccess; native producer writes17.
No game-file/server/SQL changes or installation. Close game to discard RAM edits.
All5 real pre-edit integrity digests remain required; natural worker reaches GOOD.
When prompted use test account inside game; attempt channel, character, world entry.
No passwords in console. No account/password buffers or packet payload collection/upload.
REPORT= shows Downloads\Client291-LoginStart-v4_3-*.json. Leave game open.
Windows V4.3/Login/world result is pending; offline code checks are not gameplay proof.
