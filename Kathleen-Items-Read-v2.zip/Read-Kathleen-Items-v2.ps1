$ErrorActionPreference = 'Stop'
Write-Host 'KATHLEEN_ITEMU_DATI; TIKAI_NOLASISANA; ALZ_UN_FORCEGEM_NETIEK_MAINITI'
$python = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Read-Client291-KathleenGrant.py'))
$rows = @($python | & ssh root@192.168.56.101 python3 -)
if ($LASTEXITCODE -ne 0) { throw 'NOLASISANA_NAV_PABEIGTA; ATSUTI_IZVADI' }
$text = $rows -join "`n"
$report = $text | ConvertFrom-Json
if ($report.Schema -ne 2 -or $report.Changes -ne $false -or $report.TargetCharacter -ne 'Kathleen') { throw 'REPORT_INVALID' }
$folder = Join-Path $env:USERPROFILE ('Downloads\Kathleen-Items-v2-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $folder | Out-Null
[IO.File]::WriteAllText((Join-Path $folder 'Kathleen-Items.json'),$text,[Text.UTF8Encoding]::new($false))
$zip = $folder + '.zip'
Compress-Archive -LiteralPath (Join-Path $folder 'Kathleen-Items.json') -DestinationPath $zip
Write-Host ('STATUS=' + $report.Status + '; FAILI=' + @($report.Definitions).Count)
foreach ($issue in @($report.Errors)) { Write-Host ('NOLASISANAS_POSMS=' + $issue.Stage) }
Write-Host ('ZIP=' + $zip)
Write-Host 'ATSUTI_SO_ZIP; ALZ_UN_FORCEGEM_JAU_PIESKIRTI'
