@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Read-Kathleen-Items-v2.ps1"
pause
