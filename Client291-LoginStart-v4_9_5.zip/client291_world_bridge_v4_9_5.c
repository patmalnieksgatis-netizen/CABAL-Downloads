/* Own Core2F9B ->2912FB1 World142 adapter. No file/socket/game writes.
 * Retains every accepted source privately and leases immutable target buffers.
 * Tail entry preserves the natural Main caller for the original SDK wrapper. */
#include <stdint.h>
#include <stddef.h>
#define MSABI __attribute__((ms_abi))
#define HIDDEN __attribute__((visibility("hidden")))
#define INLINE static inline __attribute__((always_inline))
typedef void (MSABI *Reader)(const unsigned char *);
typedef void *(MSABI *GetModule)(const char *);
typedef void *(MSABI *GetProc)(void *,const char *);
typedef unsigned char (MSABI *AddTable)(void *,uint32_t,uint64_t);
enum { SOURCE_FIXED=0x2f9b,TARGET_FIXED=0x2fb1,MAX_SOURCE=65513,LEASES=64,PAIR=0x20000 };
enum { PREPARED=1,DISPATCHED=2,BAD_FRAME=10,BAD_NAME=11,BAD_COUNT=12,BAD_SLOT=13,
       PET_STATE=14,QUEST_STATE=15,LEGACY_PASS_STATE=16,BAD_UNWIND=17,
       STREAM_EXTENT=18,STREAM_TRAILING=19,NO_LEASE=20,QUEST_PROFILE=21,QUEST_PARTIAL=22 };
struct Context {
    Reader reader; GetModule get_module; GetProc get_proc;
    volatile uint64_t used;
    volatile uint32_t unwind,busy,seen,prepared,rejected,dispatches,status,source_bytes,target_bytes,
        group,cursor,bad_offset,bad_count,generation,hold,auto_release,list_declared,list_restored,
        pet_positive_mask,pet_negative_mask,quest_count,pass_nonzero_mask,
        quests_validated,quest_progress_added,quest_begin,quest_end;
};
extern struct Context bridge_context HIDDEN;
extern unsigned char bridge_buffers[LEASES][PAIR] HIDDEN;
extern unsigned char bridge_function_table[] HIDDEN;
extern uint32_t bridge_function_count HIDDEN;
_Static_assert(sizeof(struct Context)==136 && offsetof(struct Context,unwind)==32,"CONTEXT_LAYOUT");
_Static_assert(offsetof(struct Context,pet_positive_mask)==104,"STATE_METADATA_LAYOUT");
_Static_assert(offsetof(struct Context,hold)==88 && offsetof(struct Context,reader)==0,"TAIL_CONTROL");
INLINE uint16_t u16(const unsigned char *p){return (uint16_t)p[0]|(uint16_t)p[1]<<8;}
INLINE uint32_t u32(const unsigned char *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
INLINE void put32(unsigned char *p,uint32_t n){for(unsigned i=0;i<4;i++)p[i]=(unsigned char)(n>>(8*i));}
static void copy(unsigned char *d,const unsigned char *s,unsigned n){for(unsigned i=0;i<n;i++)d[i]=s[i];}
#include "generated_client291_quest_frame_profile.h"
INLINE const struct QuestFrameRow *quest_row(unsigned id){
    unsigned first=0,last=sizeof(quest_frame_rows)/sizeof(quest_frame_rows[0]);
    while(first<last){unsigned mid=first+(last-first)/2;
        if(quest_frame_rows[mid].id<id)first=mid+1;else last=mid;
    }
    return first<sizeof(quest_frame_rows)/sizeof(quest_frame_rows[0]) && quest_frame_rows[first].id==id?&quest_frame_rows[first]:0;
}
static unsigned scan_quests(const unsigned char *p,unsigned n,unsigned *cursor,struct Context *c){
    unsigned at=*cursor,slots=0;c->quest_begin=at;c->bad_offset=0x375;
    if(c->quest_count>20){c->bad_count=c->quest_count;return QUEST_STATE;}
    for(unsigned i=0;i<c->quest_count;i++){
        if(at>n || n-at<7)return STREAM_EXTENT;
        unsigned slot=p[at+6];
        if(slot>=20 || (slots&(1U<<slot))){c->bad_offset=at+6;c->bad_count=slot;return QUEST_STATE;}
        slots|=1U<<slot;
        const struct QuestFrameRow *q=quest_row(u16(p+at));
        if(!q)return QUEST_PROFILE;
        /* Matching identities/order/requirements are established offline.
         * Copy all existing progress unchanged. When native has NO objectives,
         * use neutral client progress; no progress value is guessed or dropped.
         * A partial nonempty objective subset is deliberately unsupported. */
        if(q->source_count && q->source_count!=q->target_count){
            c->bad_count=((unsigned)q->source_count<<16)|q->target_count;return QUEST_PARTIAL;
        }
        if(n-at<7U+q->source_count)return STREAM_EXTENT;
        at+=7+q->source_count;c->quest_progress_added+=q->target_count-q->source_count;c->quests_validated++;
    }
    c->quest_end=at;*cursor=at;return 0;
}
struct Span { uint16_t source,target,bytes; };
static const struct Span spans[]={
 {0,0,0x358},{0x358,0x35e,0x1880-0x358},{0x1979,0x1886,0x19ac-0x1979},
 {0x19ac,0x18c1,0x2217-0x19ac},{0x2217,0x214f,0x22ca-0x2217},
 {0x22df,0x2203,0x2345-0x22df},{0x2345,0x2271,4},
 {0x2349,0x227f,0x2f3d-0x2349},{0x2f3d,0x2e85,0x12},{0x2f87,0x2ea3,0x14}
};
/* Original v282 and291 consumers give the same classic stream order/widths.
 * Signed DWORD counters retain their original <=0 skip semantics. New291
 * groups are zero-count defaults and add no stream bytes. */
struct Group {uint16_t offset;uint8_t width,stride;uint16_t slot,capacity,maximum;uint8_t signed_count;};
#define NONE 0xffff
/* Achievement category totals are a fixed12->14 DWORD header array.
 * The separate19B4/18C9 DWORD counts variable8-byte achievement records.
 * Native291 category setter8A24F4 ignores index>13; record loop is WORD-indexed.
 * Bound records by65535 and the complete frame, not the category array length. */
static const struct Group groups[]={
 {0x356,1,30,24,47,47,0},{0x357,1,30,24,80,0,0},{0x358,1,2,0,47,47,0},
 {0x359,2,30,24,522,522,0},{0x35d,2,5,3,628,628,0},{0x35f,2,4,2,296,160,0},
 {0x36d,1,8,NONE,0,255,0},{0x36f,1,12,NONE,0,255,0},{0x371,1,6,NONE,0,255,0},
 {0x373,1,12,NONE,0,11,0},{0x374,1,30,NONE,0,255,0},
 {0x361,4,6,NONE,0,65535,1},{0x1878,4,2,NONE,0,65535,1},
 {0x1979,1,10,0,47,47,0},{0x197a,2,10,NONE,0,65535,0},
 {0x19b4,4,8,NONE,0,65535,0},{0x19b8,4,6,NONE,0,65535,0},{0x2217,4,7,NONE,0,65535,1},
 {0x19bc,4,2,NONE,0,65535,0},{0x19c0,1,6,0,30,30,0},{0x19d1,1,14,0,10,10,0},
 {0x21da,2,6,NONE,0,32767,0},{0x35b,2,30,24,80,80,0},{0x21ec,4,8,NONE,0,65535,1},
 {0x220e,2,5,NONE,0,65535,0},{0x2210,2,4,NONE,0,65535,0},{0x2212,2,9,NONE,0,65535,0},
 {0x2214,2,13,NONE,0,65535,0},{0x221f,4,12,NONE,0,65535,1},
 {0x2239,1,2,NONE,0,255,0},{0x2242,1,11,NONE,0,255,0},
 {0x226f,1,4,NONE,0,255,0},{0x2270,1,3,NONE,0,255,0},{0x22e1,1,22,NONE,0,255,0},
 {0x2306,2,17,NONE,0,65535,0},{0x2308,1,1,NONE,0,255,0},{0x2340,1,4,NONE,0,255,0},
 {0x2345,4,6,NONE,0,255,1},{0x2f12,1,16,NONE,0,255,0},{0x2f3c,1,16,NONE,0,255,0},
 {0x2f3d,2,15,NONE,0,65535,0},
 {0x2f87,4,8,NONE,0,65535,1},{0x2f8f,4,28,NONE,0,65535,1},{0x2f93,4,5,NONE,0,65535,1}
};
static unsigned translate(const unsigned char *p,unsigned n,unsigned char *out,struct Context *c){
    unsigned name=p[SOURCE_FIXED];
    if(name<2 || name>17 || name>n-SOURCE_FIXED)return BAD_NAME;
    for(unsigned i=1;i<name;i++)if(p[SOURCE_FIXED+i]<32 || p[SOURCE_FIXED+i]==127)return BAD_NAME;
    /* Exact v282 consumer31DA2C: three83-byte rows, signed DWORD<=0 skips
     * the ENTIRE row at31DA41/31DACF/31DB63. Inactive rows need not be zero.
     * Positive item kinds remain unsupported; no active state is discarded.
     * Record all unsupported-state flags before refusing, never item IDs. */
    for(unsigned i=0;i<3;i++){
        int32_t kind=(int32_t)u32(p+0x1880+i*83);
        if(kind>0)c->pet_positive_mask|=1U<<i;
        if(kind<0)c->pet_negative_mask|=1U<<i;
    }
    c->quest_count=p[0x375];
    static const uint16_t pass[]={0x2f4f,0x2f53,0x2f57,0x2f73,0x2f7f,0x2f83};
    for(unsigned i=0;i<sizeof(pass)/sizeof(pass[0]);i++)
        if(u32(p+pass[i]))c->pass_nonzero_mask|=1U<<i;
    if(c->pet_positive_mask){
        for(unsigned i=0;i<3;i++)if(c->pet_positive_mask&(1U<<i)){
            c->bad_offset=0x1880+i*83;break;
        }
        c->bad_count=c->pet_positive_mask;return PET_STATE;
    }
    if(c->pass_nonzero_mask){
        for(unsigned i=0;i<sizeof(pass)/sizeof(pass[0]);i++)if(c->pass_nonzero_mask&(1U<<i)){
            c->bad_offset=pass[i];break;
        }
        c->bad_count=c->pass_nonzero_mask;return LEGACY_PASS_STATE;
    }
    unsigned cursor=SOURCE_FIXED+name;
    for(unsigned k=0;k<sizeof(groups)/sizeof(groups[0]);k++){
        if(k==11){unsigned error=scan_quests(p,n,&cursor,c);if(error)return error;}
        const struct Group *g=&groups[k];
        unsigned count=g->width==1?p[g->offset]:g->width==2?u16(p+g->offset):u32(p+g->offset);
        c->group=k;c->cursor=cursor;c->bad_offset=g->offset;c->bad_count=count;
        if(g->signed_count && (int32_t)count<0)count=0;
        if(g->offset==0x2f3d){
            /* The pinned Core producer forcibly writes byte2F3E=1, which is
             * the high byte of the old15-byte-list count. Restore it only
             * when the complete frame and all known following streams give
             * one exact row count, retaining the producer's low byte. */
            uint32_t owned=u32(p+0x2f87),pages=u32(p+0x2f8f),aux=u32(p+0x2f93);
            if((int32_t)owned<0)owned=0;if((int32_t)pages<0)pages=0;if((int32_t)aux<0)aux=0;
            if(owned>n/8 || pages>n/28 || aux>n/5)return STREAM_EXTENT;
            unsigned trailing=owned*8+pages*28+aux*5;
            if(cursor>n || trailing>n-cursor || (n-cursor-trailing)%15)return STREAM_TRAILING;
            unsigned exact=(n-cursor-trailing)/15;
            c->list_declared=count;c->list_restored=exact;
            if(exact!=count && ((count>>8)!=1 || (count&255)!=(exact&255)))return STREAM_TRAILING;
            count=exact;
        }
        if(count>g->maximum)return BAD_COUNT;
        if(cursor>n || count>(n-cursor)/g->stride)return STREAM_EXTENT;
        if(g->capacity){
            unsigned char seen[80];for(unsigned i=0;i<80;i++)seen[i]=0;
            for(unsigned i=0;i<count;i++){
                const unsigned char *row=p+cursor+i*g->stride;
                unsigned slot=(g->offset==0x19c0 || g->offset==0x19d1)?row[g->slot]:u16(row+g->slot);
                if(slot>=g->capacity || (seen[slot/8]&(1U<<(slot%8))))return BAD_SLOT;
                seen[slot/8]|=(unsigned char)(1U<<(slot%8));
            }
        }
        cursor+=count*g->stride;
    }
    c->cursor=cursor;if(cursor!=n)return STREAM_TRAILING;
    unsigned result=n+TARGET_FIXED-SOURCE_FIXED+c->quest_progress_added;
    if(result>65535)return STREAM_EXTENT;
    for(unsigned i=0;i<result;i++)out[i]=0;
    for(unsigned i=0;i<sizeof(spans)/sizeof(spans[0]);i++)copy(out+spans[i].target,p+spans[i].source,spans[i].bytes);
    /* New setting rows have no v282 World counterpart: use proper slot keys,
     * empty names (native291 localization) and neutral setting bytes. */
    for(unsigned i=0;i<5;i++)out[0x2edc+i*41]=(unsigned char)i;
    out[0x2e85]=(unsigned char)c->list_restored;out[0x2e86]=(unsigned char)(c->list_restored>>8);
    unsigned prefix=c->quest_begin-SOURCE_FIXED,destination=TARGET_FIXED+prefix,source=c->quest_begin;
    copy(out+TARGET_FIXED,p+SOURCE_FIXED,prefix);
    for(unsigned i=0;i<c->quest_count;i++){
        const struct QuestFrameRow *q=quest_row(u16(p+source));
        copy(out+destination,p+source,7+q->source_count);
        /* The output was zero-initialized; only absent neutral bytes are new. */
        destination+=7+q->target_count;source+=7+q->source_count;
    }
    copy(out+destination,p+c->quest_end,n-c->quest_end);put32(out+2,result);
    c->target_bytes=result;c->bad_offset=0;c->bad_count=0;return PREPARED;
}
unsigned char *MSABI __attribute__((noinline)) client291_world_prepare(const unsigned char *packet){
    struct Context *c=&bridge_context;__atomic_fetch_add(&c->seen,1,__ATOMIC_RELAXED);
    unsigned expected=0;
    if(__atomic_compare_exchange_n(&c->unwind,&expected,1,0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE)){
        void *m=c->get_module("ntdll.dll");AddTable add=m?(AddTable)c->get_proc(m,"RtlAddFunctionTable"):(AddTable)0;
        unsigned good=add && add(bridge_function_table,bridge_function_count,(uint64_t)(uintptr_t)c-0x4000);
        __atomic_store_n(&c->unwind,good?2:3,__ATOMIC_RELEASE);
    }
    while(__atomic_load_n(&c->unwind,__ATOMIC_ACQUIRE)==1)__asm__ __volatile__("pause");
    if(__atomic_exchange_n(&c->busy,1,__ATOMIC_ACQ_REL))return (unsigned char*)0;
    __atomic_fetch_add(&c->generation,1,__ATOMIC_ACQ_REL);
    unsigned n=u32(packet+2),status=BAD_FRAME,lease=LEASES;
    c->list_declared=0;c->list_restored=0;c->source_bytes=n;c->target_bytes=0;c->bad_offset=0;c->bad_count=0;c->cursor=0;c->group=0;
    c->pet_positive_mask=0;c->pet_negative_mask=0;c->quest_count=0;c->pass_nonzero_mask=0;
    c->quests_validated=0;c->quest_progress_added=0;c->quest_begin=0;c->quest_end=0;
    if(c->unwind!=2)status=BAD_UNWIND;
    else if(u16(packet)==0xc8f3 && u16(packet+6)==142 && n>=SOURCE_FIXED+2 && n<=MAX_SOURCE){
        for(unsigned i=0;i<LEASES;i++)if(!(__atomic_fetch_or(&c->used,UINT64_C(1)<<i,__ATOMIC_ACQ_REL)&(UINT64_C(1)<<i))){lease=i;break;}
        if(lease==LEASES)status=NO_LEASE;
        else {
            copy(bridge_buffers[lease],packet,n);
            status=translate(bridge_buffers[lease],n,bridge_buffers[lease]+0x10000,c);
        }
    }
    c->status=status;
    if(status==PREPARED)__atomic_fetch_add(&c->prepared,1,__ATOMIC_RELAXED);
    else __atomic_fetch_add(&c->rejected,1,__ATOMIC_RELAXED);
    c->hold=(status!=PREPARED || !c->auto_release)?1:0;
    __atomic_fetch_add(&c->generation,1,__ATOMIC_RELEASE);__atomic_store_n(&c->busy,0,__ATOMIC_RELEASE);
    while(__atomic_load_n(&c->hold,__ATOMIC_ACQUIRE))__asm__ __volatile__("pause");
    if(status!=PREPARED)return (unsigned char*)0;
    __atomic_fetch_add(&c->generation,1,__ATOMIC_ACQ_REL);
    c->status=DISPATCHED;__atomic_fetch_add(&c->dispatches,1,__ATOMIC_RELAXED);
    __atomic_fetch_add(&c->generation,1,__ATOMIC_RELEASE);
    return bridge_buffers[lease]+0x10000;
}
/* The original return address and unused native arguments reach Main's SDK
 * wrapper unchanged. No call through its trampoline or security-check patch. */
__asm__(".text\n.p2align 4\n.global client291_world\n.type client291_world,@function\n"
"client291_world:\nsub $0x38,%rsp\nmov %rdx,0x20(%rsp)\nmov %r8,0x28(%rsp)\nmov %r9,0x30(%rsp)\n"
"call client291_world_prepare\nmov 0x20(%rsp),%rdx\nmov 0x28(%rsp),%r8\nmov 0x30(%rsp),%r9\n"
"add $0x38,%rsp\ntest %rax,%rax\njz 1f\nmov %rax,%rcx\njmp *bridge_context(%rip)\n1: ret\n"
".size client291_world,.-client291_world\n");
