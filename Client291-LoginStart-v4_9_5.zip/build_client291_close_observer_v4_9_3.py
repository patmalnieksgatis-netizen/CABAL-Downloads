"""Build only our position-independent Win64 leaf observers, no game bytes."""
from pathlib import Path
import hashlib,json,subprocess,tempfile
ROOT=Path(__file__).resolve().parent.parent
def run(args):return subprocess.check_output(args,text=True)
def main():
 src=ROOT/'tools/client291_close_observer_v4_9_3.S'
 with tempfile.TemporaryDirectory(prefix='client291-close-build-') as name:
  p=Path(name);obj=p/'observer.o';elf=p/'observer.elf';raw=p/'observer.bin';link=p/'observer.ld'
  link.write_text('ENTRY(close_post_entry)\nSECTIONS { . = 0; .text : { *(.text*) } /DISCARD/ : { *(.note*) *(.comment*) } ASSERT(. < 0x1000,"OBSERVER_TOO_LARGE") close_context = 0x1000; }\n')
  run(['gcc','-c','-m64',str(src),'-o',str(obj)]);run(['ld','-nostdlib','-T',str(link),str(obj),'-o',str(elf)])
  assert not run(['nm','-u',str(elf)]).strip()
  assert 'There are no relocations' in run(['readelf','-r',str(elf)])
  run(['objcopy','-O','binary','--only-section=.text',str(elf),str(raw)])
  b=raw.read_bytes();assert len(b)<0x1000
  symbols={f[2]:int(f[0],16) for line in run(['nm','-n',str(elf)]).splitlines() if len(f:=line.split())==3}
  assert symbols['close_post_entry']==0 and symbols['close_send_entry']==512
  out=ROOT/'protocol/generated/client291-close-observer-v4_9_3.bin';out.write_bytes(b)
  d=dict(status='OWN_LEAF_OBSERVER_WINDOWS_UNVERIFIED',source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),post_entry=0,send_entry=512,context_rva=4096,context_bytes=256,allocation_bytes=8192,leaf=True,stack_adjustments=False,api_calls=False,nonvolatile_register_writes=False,runtime_relocations=[],main_import_slots=dict(PostMessageA='0xB32C68',SendMessageA='0xB32C70'),scope='Only records first WM_CLOSE to the original main HWND and tail-forwards every call unchanged. Does not block close or alter authentication/protocol.')
  (ROOT/'protocol/generated/client291-close-observer-v4_9_3.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
if __name__=='__main__':main()
