V4.9.5 - ACHIEVEMENT RECORD COUNT FIX

Only F:\CABAL_291_TEST and the existing test VM192.168.56.101.
Extract into a NEW folder. Close the game. Run Palaist-291-v4_9_5.cmd
as administrator; keep its Launcher window open while playing.

Actual last V4.9.4 reports show WORLD_SOURCE_REFUSED/status12, source19B4
count23. Our controller then intentionally closes the held game. This is
not a new native crash: the achievement-record count was mistakenly capped
at12 (the source header's category count). Original291 loops process8-byte
records and separately bound category writes to14 slots. Native row loops
and setter were executed locally for0/1/12/13/14/23/64/1024/5000 records.
The corrected converter checks the WORD loop bound65535 plus exact frame
extents. It retains the complete count, every row, and all later streams.
Only TWO DATA BYTES in our compiled World blob change; machine code,
unwind tables, ABI, quest mapping and every other guard remain identical.

Original Main/SDK/World readers and all login, launch, close-observer and
protocol edits are unchanged from V4.9.4. Native launcher parent contract
is retained. A verified own build receipt reuses Launcher.exe on subsequent
CMD runs, avoiding recompilation of a still-running host. No server, SQL,
character level/progression or original game-file changes.

Local own-blob regression: old count23 rejection reproduced, new579
checks pass including all accepted data/suffix preservation and malformed
extent/count rejection. Actual native loop/decoder45 checks pass with
manager-finalize and achievement object lookup/update stubs. This is not
Windows gameplay verification. Return Downloads/Client291-LoginStart-
v4_9_5-*.json and whether Kathleen enters/stays in World. Do not delete
achievements, make another account, or reset progression for this fix.
