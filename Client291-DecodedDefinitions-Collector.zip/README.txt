V291 ORIGINAL DECODED DEFINITIONS: TWO READ-ONLY CACHE RECORDS

Close CABAL. Run Savakt-Atkodetas-Definicijas.cmd. Do not log in or select CH.
Starts original F:\CABAL_291_TEST\Bin\x64\CabalMain.exe breaklee.
Keeps original SDK/resources; no process writes, hooks, injected threads,
integrity changes, game-file changes, server/SSH/SQL operations or installation.
Original game/SDK can perform its normal startup behavior.

The original native loader caches resource pointer/byte-count records at
Main+DD6430,16-byte stride. Original filename switch binds quest.enc to29 and
AnimaMastery.enc to126. Only these two known game-resource records are read.
Checks exact native loader/filename code windows and current input hashes.
Requires expected decoded size, XML root/closing tag, original terminator,
two identical full reads and unchanged pointer/size record. Incomplete loading
waits up to90seconds. No resource decoder/security hook is changed or invoked
from our code. No packets, accounts, sessions, UserData or credentials collected.

Copies quest.xml and AnimaMastery.xml plus metadata to a fresh Downloads ZIP.
Upload Client291-DecodedDefinitions-<date>-<code>.zip printed as ZIP=.
Returned game definitions remain PRIVATE. You may close the client afterward.
This is a data export, not a World-entry fix; actual Windows run unverified.
