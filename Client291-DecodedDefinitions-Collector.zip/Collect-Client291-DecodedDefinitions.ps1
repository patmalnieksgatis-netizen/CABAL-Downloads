param([ValidateSet('Inspect','Collect')][string]$Action='Inspect')
$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'Client291-ResourceCacheRead.cs')
if($Action -eq 'Inspect') {
    [ordered]@{Scope='TWO_ORIGINAL_RESOURCE_CACHE_RECORDS';Root='F:\CABAL_291_TEST';Indices=@(29,126);DeclaredBytes=@(1670353,13499);ProcessWrites=$false;Hooks=$false;SDKChanges=$false;LoginRequested=$false;ServerContactByTool=$false;OriginalGameStartOnly=$true} | ConvertTo-Json
    return
}
if($env:OS -ne 'Windows_NT' -or ![Environment]::Is64BitProcess){throw 'USE_WINDOWS_X64_POWERSHELL'}
if(Get-Process -Name CabalMain -ErrorAction SilentlyContinue){throw 'VISPIRMS_AIZVER_CABAL'}
$root='F:\CABAL_291_TEST';$bin=Join-Path $root 'Bin\x64';$exe=Join-Path $bin 'CabalMain.exe'
$expected=[ordered]@{
    'Bin\x64\CabalMain.exe'='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
    'Bin\x64\libogg.dll'='ceafa8291dcf090856a215285114270fea1a8978bc2d2b26b33bcb7b3ac5c2a9'
    'Bin\x64\d3d9.dll'='216058f9320d0667d551f4cea840ee539396449ef8c8e89fe481e4f0ddb628ae'
    'Data\quest.enc'='c298999da93d3d1c3e415b1618efeda80362e7247945e26226090a29ee18ea3d'
    'Data\AnimaMastery.enc'='97c6b4877f060ac18da156acc08428c327d8c9bfc811011043fd38d8522d478d'
}
foreach($name in $expected.Keys){if((Get-FileHash -LiteralPath (Join-Path $root $name) -Algorithm SHA256).Hash -ne $expected[$name]){throw ('ORIGINAL_INPUT_DIFFERS='+$name)}}
$downloads=Join-Path $env:USERPROFILE 'Downloads'
$name='Client291-DecodedDefinitions-'+(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[guid]::NewGuid().ToString('N').Substring(0,6)
$folder=Join-Path $downloads $name;[void](New-Item -ItemType Directory -Path $folder)
$report=[ordered]@{Schema=1;Scope='ORIGINAL_CLIENT_RESOURCE_CACHE_READ';StartedUTC=[DateTime]::UtcNow.ToString('o');Status='STARTING';ProcessWrites=$false;Hooks=$false;SDKChanges=$false;LoginRequested=$false;ServerContactByTool=$false;InputFilesVerifiedAfter=$false;ClientDataModifiedByTool=$false;Resources=@();Failure=$null}
$client=$null
try {
    'TIKAI_ORIGINALO_DEFINICIJU_LASISANA; NEIELOGOJIES_UN_NESPIED_ENTER_SERVER'
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$exe;$start.Arguments='breaklee';$start.WorkingDirectory=$bin;$start.UseShellExecute=$false
    $client=[Diagnostics.Process]::Start($start);$handle=$client.Handle
    $report.PID=$client.Id;'TEST_PID='+$client.Id
    $deadline=[DateTime]::UtcNow.AddSeconds(90);$checked=$false;$done=@{}
    while([DateTime]::UtcNow -lt $deadline -and $done.Count -lt 2) {
        if($client.HasExited){throw ('ORIGINAL_CLIENT_EXITED='+$client.ExitCode)}
        if(!$checked){[Client291ResourceCacheRead]::CheckNativeCacheContract($handle);$checked=$true}
        foreach($index in @(29,126)){
            if($done.ContainsKey($index)){continue}
            $row=[Client291ResourceCacheRead]::ReadDefinition($handle,$index)
            if($row.Status -ne 'STABLE_ORIGINAL_SDK_DECODED_RESOURCE'){continue}
            [IO.File]::WriteAllBytes((Join-Path $folder ($row.Name+'.xml')),$row.Data)
            $report.Resources+=@([ordered]@{Name=$row.Name;Index=$row.Index;Status=$row.Status;Bytes=$row.Bytes;Root=$row.Root;SHA256=$row.SHA256})
            $done[$index]=$true;'DEFINICIJA_SAGLABATA='+$row.Name+'; BYTES='+$row.Bytes
        }
        if($done.Count -lt 2){Start-Sleep -Milliseconds 100}
    }
    if($done.Count -ne 2){throw 'RESOURCE_CACHE_NOT_READY_WITHIN_90_SECONDS'}
    foreach($file in $expected.Keys){if((Get-FileHash -LiteralPath (Join-Path $root $file) -Algorithm SHA256).Hash -ne $expected[$file]){throw ('INPUT_CHANGED_DURING_READ='+$file)}}
    $report.InputFilesVerifiedAfter=$true;$report.Status='TWO_DECODED_DEFINITIONS_COPIED'
} catch {
    $report.Status='FAILED';$report.Failure=$_.Exception.GetBaseException().Message
    'KLUDA='+$report.Failure
} finally {
    $report.FinishedUTC=[DateTime]::UtcNow.ToString('o')
    $report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $folder 'DecodedDefinitions-Report.json') -Encoding UTF8
    $zip=Join-Path $downloads ($name+'.zip')
    Compress-Archive -LiteralPath @(Get-ChildItem -LiteralPath $folder -File | Select-Object -ExpandProperty FullName) -DestinationPath $zip
    'ZIP='+$zip
    'KLIENTU_VARI_AIZVERT; KONTU_UN_PAROLI_IEVADIT_NEVAJAG'
    if($null -ne $client){$client.Dispose()}
}
