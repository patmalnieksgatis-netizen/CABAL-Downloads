@echo off
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-Original-v291-Mapinfo.ps1" -Action Collect -Mode Launch
pause
