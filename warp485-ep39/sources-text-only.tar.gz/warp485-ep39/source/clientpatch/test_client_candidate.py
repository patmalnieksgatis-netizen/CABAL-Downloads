from __future__ import annotations
import json, unittest
from pathlib import Path
from xml.etree import ElementTree as ET
from build_client_candidate import parse_and_patch
from triple_join_audit import server_registries

HERE = Path(__file__).parent
REF = HERE/'REFERENCE_UNVERIFIED_mapinfo.dec'
REG = HERE/'server_registry_evidence.zip'
D, W = server_registries(REG)

class TestClientCandidate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reference=REF.read_bytes()
        cls.patched, cls.meta=parse_and_patch(cls.reference,D,W)

    def test_actual_registry_anchor(self):
        self.assertEqual(W[675],8)
        self.assertEqual(D[4352]['world'],138)
        self.assertEqual(D[4378]['world'],172)
        self.assertNotIn(4380,D)

    def test_candidate_removes_only_mismatches(self):
        removed={x['dungeon_id'] for x in self.meta['removed']}
        self.assertEqual(removed,{4378,4379,4380,4381,4382,4383})
        self.assertEqual([x['dungeon_id'] for x in self.meta['retained']],[4352])

    def test_reference_xml_well_formed(self):
        self.assertEqual(ET.fromstring(self.patched).tag,'cabal')

    def test_preserves_all_outside_target_group(self):
        a=self.reference; b=self.patched
        start=b'<icon_value\ttype="3"\twarp_index="675"'
        i=a.index(start); j=a.index(b'</icon_value>',i)+len(b'</icon_value>')
        ii=b.index(start); jj=b.index(b'</icon_value>',ii)+len(b'</icon_value>')
        self.assertEqual(a[:i],b[:ii]);self.assertEqual(a[j:],b[jj:])

    def test_no_wrong_dungeon_ids_in_target(self):
        r=ET.fromstring(self.patched)
        found=[]
        for icon in r.findall('.//icon'):
            if icon.attrib.get('world_id')=='8':
                for group in icon.findall('icon_value'):
                    if group.attrib.get('warp_index')=='675':
                        found.append([int(w.attrib['dungeon_index']) for w in group.findall('warp')])
        self.assertEqual(found,[[4352]])

    def test_other_4384_reference_dungeon_untouched(self):
        self.assertIn(b'dungeon_index="4384"', self.patched)
        self.assertEqual(self.reference.count(b'dungeon_index="4384"'), self.patched.count(b'dungeon_index="4384"'))

    def test_after_patching_no_extra_work(self):
        with self.assertRaisesRegex(ValueError,'NO_CHANGE_REQUIRED'):
            parse_and_patch(self.patched,D,W,require_4380=False)

    def test_second_warp_group_is_ambiguous(self):
        # Duplicate the icon_value element; no guessing which one to fix.
        a=self.reference
        i=a.index(b'<icon_value\ttype="3"\twarp_index="675"')
        j=a.index(b'</icon_value>',i)+len(b'</icon_value>')
        altered=a[:j]+a[i:j]+a[j:]
        with self.assertRaisesRegex(ValueError,'TARGET_GROUP_NOT_UNIQUE:2'):
            parse_and_patch(altered,D,W)

    def test_no_4380_rejected(self):
        xml=self.reference.replace(b'dungeon_index="4380"',b'dungeon_index="4200"')
        with self.assertRaisesRegex(ValueError,'EXPECTED_4380_NOT_IN_TARGET_MENU'):
            parse_and_patch(xml,D,W)

    def test_dtd_rejected(self):
        with self.assertRaisesRegex(ValueError,'XML_DTD_OR_ENTITY_REFUSED'):
            parse_and_patch(b'<!DOCTYPE cabal>'+self.reference,D,W)

    def test_missing_warp_server_rejected(self):
        w=W.copy();del w[675]
        with self.assertRaisesRegex(ValueError,'SERVER_WARP_675_WORLD_8_NOT_FOUND'):
            parse_and_patch(self.reference,D,w)

    def test_bad_warp_world_rejected(self):
        w=W.copy();w[675]=9
        with self.assertRaisesRegex(ValueError,'SERVER_WARP_675_WORLD_8_NOT_FOUND'):
            parse_and_patch(self.reference,D,w)

    def test_missing_known_good_rejected(self):
        altered=self.reference.replace(b'dungeon_index="4352"',b'dungeon_index="4388"')
        with self.assertRaisesRegex(ValueError,'KNOWN_GOOD_4352_MISSING'):
            parse_and_patch(altered,D,W)

    def test_bad_xml_rejected(self):
        with self.assertRaisesRegex(ValueError,'INVALID_MAPINFO_XML'):
            parse_and_patch(self.reference[:-3],D,W)

    def test_non_target_byte_hashes(self):
        from hashlib import sha256
        self.assertNotEqual(sha256(self.reference).hexdigest(),sha256(self.patched).hexdigest())
        self.assertEqual(self.meta['candidate_sha256'],sha256(self.patched).hexdigest())

    def test_preserve_no_extra_ordinary_warp_changes(self):
        self.assertEqual(self.reference.count(b'dungeon_index="0"'),self.patched.count(b'dungeon_index="0"'))

if __name__=='__main__': unittest.main(verbosity=2)
