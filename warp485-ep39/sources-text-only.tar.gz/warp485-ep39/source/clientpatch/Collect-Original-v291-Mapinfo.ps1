param(
    [ValidateSet('Inspect','Collect')][string]$Action='Inspect',
    [ValidateSet('Attach','Launch')][string]$Mode='Attach',
    [ValidateRange(10,180)][int]$TimeoutSeconds=90
)
$ErrorActionPreference='Stop'
$root='F:\CABAL_291_TEST'
$exe=Join-Path $root 'Bin\x64\CabalMain.exe'
$enc=Join-Path $root 'Data\mapinfo.enc'
$exeSha='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
$encSha='88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc'
if($Action -eq 'Inspect') {
    [ordered]@{Purpose='Read only original v291 decoded mapinfo';Mode=$Mode;
        CacheIndexRange='0..136';ExpectedDecodedBytes=49101;ProcessWrites=$false;
        Hooks=$false;ServerWrites=$false;LoginRequested=$false;
        ExistingClientCanBeAttached=$true;OriginalClientLaunchOptional=$true;
        WindowsRuntimeVerified=$false} | ConvertTo-Json
    return
}
if($env:OS -ne 'Windows_NT' -or ![Environment]::Is64BitProcess) {throw 'WINDOWS_X64_POWERSHELL_REQUIRED'}
foreach($pair in @(@($exe,$exeSha),@($enc,$encSha))) {
    if(!(Test-Path -LiteralPath $pair[0] -PathType Leaf)) {throw ('INPUT_NOT_FOUND='+$pair[0])}
    $hash=(Get-FileHash -LiteralPath $pair[0] -Algorithm SHA256).Hash.ToLowerInvariant()
    if($hash -ne $pair[1]) {throw ('PINNED_INPUT_CHANGED='+$pair[0])}
}
$encBytes=[IO.File]::ReadAllBytes($enc)
if($encBytes.Length -ne 6808 -or [BitConverter]::ToUInt32($encBytes,0) -ne 49101) {throw 'ENCRYPTED_MAPINFO_FORMAT_CHANGED'}
Add-Type -Path (Join-Path $PSScriptRoot 'Mapinfo291CacheReader.cs')
$running=@(Get-Process -Name CabalMain -ErrorAction SilentlyContinue)
if($Mode -eq 'Attach' -and $running.Count -ne 1) {throw ('ATTACH_REQUIRES_EXACTLY_ONE_CLIENT;FOUND='+$running.Count)}
if($Mode -eq 'Launch' -and $running.Count -ne 0) {throw 'CLOSE_EXISTING_CLIENT_TO_USE_LAUNCH_MODE_OR_SELECT_ATTACH'}
$downloads=Join-Path $env:USERPROFILE 'Downloads'
$folder=Join-Path $downloads ('Original-v291-Mapinfo-'+(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[guid]::NewGuid().ToString('N').Substring(0,6))
[void](New-Item -Path $folder -ItemType Directory -ErrorAction Stop)
$report=[ordered]@{
    Status='STARTING';Mode=$Mode;OriginalClientSHA256=$exeSha;OriginalMapinfoSHA256=$encSha;
    ProcessWrites=$false;CodeHooks=$false;ServerWrites=$false;OriginalClientStarted=$false;
    ExistingClientAttached=$false;Index=$null;Bytes=0;DecodedSHA256=$null;
    ImageBase=$null;ClientPID=$null;CacheSizeMatchedSlots=0;XmlCandidates=0;
    StartedUTC=[DateTime]::UtcNow.ToString('o');FinishedUTC=$null;Failure=$null
}
$client=$null
try {
    if($Mode -eq 'Attach') {
        $client=$running[0]
        $report.ExistingClientAttached=$true
    } else {
        $start=New-Object Diagnostics.ProcessStartInfo
        $start.FileName=$exe;$start.Arguments='breaklee';$start.WorkingDirectory=(Split-Path -Parent $exe)
        $start.UseShellExecute=$false
        $client=[Diagnostics.Process]::Start($start)
        if($null -eq $client) {throw 'ORIGINAL_CLIENT_LAUNCH_FAILED'}
        $report.OriginalClientStarted=$true
    }
    $client.Refresh()
    $report.ClientPID=$client.Id
    $expectedPath=[IO.Path]::GetFullPath($exe)
    $handle=$client.Handle
    $last='MAPINFO_NOT_CACHED';$verified=$false
    $deadline=[DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    while([DateTime]::UtcNow -lt $deadline) {
        $client.Refresh()
        if($client.HasExited) {throw 'CLIENT_EXITED_BEFORE_RESOURCE_READY'}
        try {
            $actualPath=[IO.Path]::GetFullPath($client.MainModule.FileName)
            if(![string]::Equals($actualPath,$expectedPath,[StringComparison]::OrdinalIgnoreCase)) {
                throw 'PROCESS_IS_NOT_PINNED_ORIGINAL_V291_CLIENT'
            }
            $imageBase=[int64]$client.MainModule.BaseAddress.ToInt64()
            [Mapinfo291CacheReader]::VerifyOriginalClientCode($handle,$imageBase)
            $verified=$true
        } catch {
            $last=$_.Exception.GetBaseException().Message
            if($last -notin @('UNREADABLE_PAGE','PARTIAL_PROCESS_READ','NOT_ORIGINAL_PE_BASE') -and $Mode -eq 'Attach') {throw}
            if($last -eq 'PROCESS_IS_NOT_PINNED_ORIGINAL_V291_CLIENT') {throw}
            Start-Sleep -Milliseconds 200
            continue
        }
        $row=[Mapinfo291CacheReader]::FindOriginalDecodedMapinfo($handle,$imageBase)
        $report.CacheSizeMatchedSlots=$row.SizeMatchedSlots
        $report.XmlCandidates=$row.XmlCandidates
        if($row.Status -eq 'STABLE_ORIGINAL_V291_DECODED_MAPINFO') {
            [IO.File]::WriteAllBytes((Join-Path $folder 'mapinfo.xml'),$row.Data)
            $report.Status='ORIGINAL_V291_MAPINFO_CAPTURED'
            $report.Index=$row.Index;$report.Bytes=$row.ByteLength
            $report.ImageBase=('0x{0:X}' -f $imageBase)
            $report.DecodedSHA256=$row.Hash
            break
        }
        $last='MAPINFO_NOT_CACHED';Start-Sleep -Milliseconds 200
    }
    if(!$verified) {throw ('CLIENT_NATIVE_CONTRACT_NOT_READY='+$last)}
    if($report.Status -ne 'ORIGINAL_V291_MAPINFO_CAPTURED') {throw ('ORIGINAL_MAPINFO_NOT_AVAILABLE='+$last)}
    foreach($pair in @(@($exe,$exeSha),@($enc,$encSha))) {
        $hash=(Get-FileHash -LiteralPath $pair[0] -Algorithm SHA256).Hash.ToLowerInvariant()
        if($hash -ne $pair[1]) {throw ('ORIGINAL_INPUT_CHANGED_DURING_CAPTURE='+$pair[0])}
    }
} catch {
    $report.Status='FAILED';$report.Failure=$_.Exception.GetBaseException().Message
} finally {
    $report.FinishedUTC=[DateTime]::UtcNow.ToString('o')
    $report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $folder 'Report.json') -Encoding UTF8
    $zip=$folder+'.zip'
    Compress-Archive -LiteralPath @(Get-ChildItem -LiteralPath $folder -File | Select-Object -ExpandProperty FullName) -DestinationPath $zip
    'STATUS='+$report.Status
    if($report.Failure) {'REASON='+$report.Failure}
    'ZIP='+$zip
    if($null -ne $client) {$client.Dispose()}
}
