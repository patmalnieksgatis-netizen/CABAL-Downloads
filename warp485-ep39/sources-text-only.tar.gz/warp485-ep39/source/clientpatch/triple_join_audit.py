#!/usr/bin/env python3
"""Read-only reference-mapinfo versus v291-server triple-join audit.

No ENC decoder, no server writes, no patching. The decoded mapinfo shipped here is
from an UNVERIFIED alternate CABAL archive, not the original v291 client's file.
"""
from __future__ import annotations
from collections import Counter
from hashlib import sha256
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile
import argparse
import json

MISSING_DUNGEON = "missing_dungeon_id"
WORLD_MISMATCH = "target_world_mismatch"
MISSING_WARP = "missing_server_warp"
WARP_WORLD_MISMATCH = "warp_origin_world_mismatch"
OK = "triple_match"

def sha(data: bytes) -> str:
    return sha256(data).hexdigest()

def _table(z: ZipFile, name: str, section: str):
    lines = z.read(name).decode("utf-8-sig").splitlines()
    hdrs = [i for i, line in enumerate(lines) if line.startswith("[" + section + "]")]
    if len(hdrs) != 1:
        raise ValueError(f"SECTION_NOT_UNIQUE {name} {section}")
    start = hdrs[0]
    fields = lines[start].split()
    for row_index in range(start + 1, len(lines)):
        line = lines[row_index]
        if line.startswith("["):
            break
        cols = line.split()
        if not cols or cols[0].startswith("#"):
            continue
        yield fields, cols, row_index

def server_registries(archive: Path):
    dungeon = {}
    warp = {}
    with ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError("SERVER_CONFIG_ZIP_INVALID")
        for filename, section in [("QuestDungeon.scp", "QuestDungeon"),
                                  ("MissionDungeon.scp", "MD"),
                                  ("MissionDungeon2.scp", "MD")]:
            for fields, cols, _ in _table(z, filename, section):
                did = int(cols[fields.index("QDungeonIdx")])
                wid = int(cols[fields.index("WorldIdx")])
                if did in dungeon:
                    raise ValueError("DUPLICATE_DUNGEON_ID " + str(did))
                dungeon[did] = {"world": wid, "file": filename}
        for fields, cols, _ in _table(z, "Warp.scp", "Warp"):
            # [Warp] is the implicit index column; WorldIdx is the next column.
            warp_id = int(cols[0])
            world_value = cols[fields.index("WorldIdx")]
            if world_value == "<null>":
                continue
            if warp_id in warp:
                raise ValueError("DUPLICATE_WARP_ID " + str(warp_id))
            warp[warp_id] = int(world_value)
    return dungeon, warp

def audit(xml: bytes, dungeon: dict, warp: dict):
    if not xml.lstrip().startswith(b"<"):
        raise ValueError("ENC_OR_NON_XML_REFUSED")
    root = ET.fromstring(xml)
    groups = []
    entries = []
    seen = set()
    for icon in root.findall(".//icon"):
        origin = int(icon.attrib["world_id"])
        for grp in icon.findall("icon_value"):
            idx = int(grp.attrib["warp_index"])
            key = (origin, idx, grp.attrib.get("type"))
            # The reference source legitimately repeats (world, warp, type)
            # for separate GUI icon sections. Keep both; don't merge by key.
            seen.add(key)
            actual_origin = warp.get(idx)
            origin_state = ("warp_match" if actual_origin == origin else
                            MISSING_WARP if actual_origin is None else
                            WARP_WORLD_MISMATCH)
            group = {"origin_world": origin, "warp_id": idx,
                     "group_type": grp.attrib.get("type"),
                     "server_warp_world": actual_origin,
                     "warp_status": origin_state,
                     "dungeon_entry_count": 0}
            for w in grp.findall("warp"):
                did = int(w.attrib.get("dungeon_index", "0"))
                if did == 0:
                    continue  # ordinary warp, not a dungeon registration
                group["dungeon_entry_count"] += 1
                dest = int(w.attrib["target_world_index"])
                reg = dungeon.get(did)
                if origin_state != "warp_match":
                    status = origin_state
                elif reg is None:
                    status = MISSING_DUNGEON
                elif reg["world"] != dest:
                    status = WORLD_MISMATCH
                else:
                    status = OK
                entries.append({"origin_world": origin, "warp_id": idx,
                                "dungeon_id": did, "target_world": dest,
                                "server_dungeon_world": None if reg is None else reg["world"],
                                "status": status,
                                "other_problems": ([MISSING_DUNGEON] if reg is None else
                                                   [WORLD_MISMATCH] if reg["world"] != dest else [])
                                    if origin_state != "warp_match" else []})
            groups.append(group)
    return {"source": "UNVERIFIED_OTHER_CLIENT_DECODED_MAPINFO",
            "groups": groups, "entries": entries,
            "group_status_counts": dict(Counter(g["warp_status"] for g in groups)),
            "entry_status_counts": dict(Counter(e["status"] for e in entries))}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--xml", type=Path, required=True, help="decoded XML, never an ENC file")
    p.add_argument("--server-zip", type=Path, required=True)
    p.add_argument("--json", type=Path, help="local report output; never an input or game directory")
    args=p.parse_args()
    content=args.xml.read_bytes()
    dungeon, warp=server_registries(args.server_zip)
    result=audit(content,dungeon,warp)
    result["evidence"]={"decoded_reference_sha256":sha(content),
                        "server_zip_sha256":sha(args.server_zip.read_bytes()),
                        "server_dungeon_count":len(dungeon),"server_warp_count":len(warp)}
    if args.json:
        if args.json.resolve() in (args.xml.resolve(),args.server_zip.resolve()):
            raise ValueError("REFUSE_OVERWRITE_INPUT")
        args.json.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k in ("source", "group_status_counts", "entry_status_counts","evidence")},indent=2))

if __name__=="__main__":
    main()
