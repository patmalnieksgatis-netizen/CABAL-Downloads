#!/usr/bin/env python3
"""Create a byte-preserving candidate from authentic v291 decoded mapinfo.

No encoder, no client-file overwrite, no server writes. Requires an independently
verified in-memory mapinfo capture to operate on production client data.
"""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path
from xml.parsers import expat
from zipfile import ZipFile
from validate_capture_and_audit import checked_capture
from triple_join_audit import server_registries

# Allow only this precisely observed failure site. Do not mass-patch unrelated menus.
ORIGIN_WORLD=8
WARP_ID=675

def sha(v: bytes) -> str: return hashlib.sha256(v).hexdigest()

def parse_and_patch(original: bytes, dungeon: dict, warp: dict, *, require_4380=True):
    """No XML reserialization: all bytes outside targeted tags are unchanged."""
    if b'<!DOCTYPE' in original.upper() or b'<!ENTITY' in original.upper():
        raise ValueError('XML_DTD_OR_ENTITY_REFUSED')
    if warp.get(WARP_ID) != ORIGIN_WORLD:
        raise ValueError('SERVER_WARP_675_WORLD_8_NOT_FOUND')
    stack=[]; targets=[]; groups=[]; entries=[]
    parser=expat.ParserCreate()
    def tag_end(pos):
        # Find > outside quoted attributes; explicitly reject non-self-closing warp.
        quote=0
        for j in range(pos, min(len(original),pos+4096)):
            x=original[j]
            if quote:
                if x==quote: quote=0
            elif x in (34,39): quote=x
            elif x==62:
                if original[pos:j+1].rstrip()[-2:]!=b'/>':
                    raise ValueError('WARP_TAG_NOT_SELF_CLOSING')
                return j+1
        raise ValueError('WARP_TAG_INCOMPLETE')
    def on_start(name,attr):
        nonlocal targets,groups,entries
        stack.append((name,attr))
        if name=='icon_value' and len(stack)>=2:
            parent=stack[-2]
            if parent[0]=='icon' and parent[1].get('world_id')==str(ORIGIN_WORLD) and attr.get('warp_index')==str(WARP_ID):
                groups.append(len(stack))
        if name!='warp' or len(stack)<3: return
        group=stack[-2];icon=stack[-3]
        if (group[0],icon[0],group[1].get('warp_index'),icon[1].get('world_id')) != ('icon_value','icon',str(WARP_ID),str(ORIGIN_WORLD)):
            return
        pos=parser.CurrentByteIndex;end=tag_end(pos)
        if not original[pos:end].lstrip().startswith(b'<warp'):
            raise ValueError('WARP_SOURCE_OFFSET_INVALID')
        did=int(attr.get('dungeon_index','0'));world=int(attr['target_world_index'])
        entry={'dungeon_id':did,'world_id':world,'old_order':int(attr['order']),'start':pos,'end':end}
        entries.append(entry)
        if did==0:
            entry['status']='ordinary_warp'
        elif did not in dungeon:
            entry['status']='missing_dungeon'
            targets.append(entry)
        elif dungeon[did]['world']!=world:
            entry['status']='world_mismatch'
            targets.append(entry)
        else:
            entry['status']='compatible'
    def on_end(name):
        if not stack or stack[-1][0]!=name:raise ValueError('XML_STACK_MISMATCH')
        stack.pop()
    parser.StartElementHandler=on_start; parser.EndElementHandler=on_end
    try:parser.Parse(original,True)
    except expat.ExpatError as e:raise ValueError('INVALID_MAPINFO_XML') from e
    if len(groups)!=1:raise ValueError('TARGET_GROUP_NOT_UNIQUE:'+str(len(groups)))
    if not entries:raise ValueError('TARGET_GROUP_EMPTY')
    if require_4380 and not any(e['dungeon_id']==4380 for e in entries):
        raise ValueError('EXPECTED_4380_NOT_IN_TARGET_MENU')
    if not any(e['dungeon_id']==4352 and e['status']=='compatible' for e in entries):
        raise ValueError('KNOWN_GOOD_4352_MISSING')
    if not targets:raise ValueError('NO_CHANGE_REQUIRED')
    # Determine line-only tags: remove leading indent and end-of-line to avoid blank lines.
    removals=[]
    for e in targets:
        pos,end=e['start'],e['end']
        left=original.rfind(b'\n',0,pos)+1
        right=original.find(b'\n',end)
        if right==-1:right=len(original)
        if not original[left:pos].strip() and not original[end:right].strip():
            pos=left;end=min(len(original),right+1)
        removals.append((pos,end,e))
    removals.sort()
    for i in range(1,len(removals)):
        if removals[i-1][1]>removals[i][0]:raise ValueError('OVERLAPPING_PATCH_SPANS')
    kept=[e for e in entries if e not in targets]
    # Reindex only when needed; avoid modifying tags that already have correct order.
    replacements=[]
    for i,e in enumerate(kept):
        tag=original[e['start']:e['end']]
        new_tag,n=re.subn(rb'(\border\s*=\s*["\'])\d+(["\'])',lambda m:m.group(1)+str(i).encode()+m.group(2),tag,count=1)
        if n!=1:raise ValueError('ORDER_ATTRIBUTE_NOT_FOUND')
        if new_tag!=tag:replacements.append((e['start'],e['end'],new_tag))
    operations=[(l,r,b'') for l,r,_ in removals]+replacements
    operations.sort(key=lambda x:x[0])
    for i in range(1,len(operations)):
        if operations[i-1][1]>operations[i][0]:raise ValueError('PATCH_OPS_OVERLAP')
    dst=bytearray();pos=0
    for l,r,new in operations:dst+=original[pos:l];dst+=new;pos=r
    dst+=original[pos:]
    candidate=bytes(dst)
    # Fail closed if any removed dungeon remains in target group (the XML can
    # legitimately refer to the same ID elsewhere, so do not scan globally).
    result_meta={
        'source_sha256':sha(original),'candidate_sha256':sha(candidate),
        'original_bytes':len(original),'candidate_bytes':len(candidate),
        'removed':[{k:e[k] for k in ('dungeon_id','world_id','status')} for e in targets],
        'retained':[{k:e[k] for k in ('dungeon_id','world_id','status')} for e in kept],
        'source_kind':'AUTHENTIC_V291_CAPTURE_REQUIRED',
        'status':'DECODED_XML_CANDIDATE_ONLY',
        'encoded_client_file_created':False,'gameplay_verified':False
    }
    # Validate resulting XML and content; repeat parser in non-require mode with
    # expected no-change exception, ensuring the original conflict has gone.
    chk=[];P=expat.ParserCreate()
    P.StartElementHandler=lambda n,a:chk.append((n,a)) if n=='warp' and a.get('dungeon_index')=='4380' else None
    try:P.Parse(candidate,True)
    except expat.ExpatError as e:raise ValueError('CANDIDATE_XML_BROKEN') from e
    # Independent postcondition: target group no longer contains ANY invalid
    # dungeon for this server snapshot; other groups are intentionally untouched.
    from xml.etree import ElementTree as ET
    root=ET.fromstring(candidate)
    target_groups=[]
    for icon in root.findall('.//icon'):
        if icon.get('world_id') != str(ORIGIN_WORLD): continue
        for group in icon.findall('icon_value'):
            if group.get('warp_index') != str(WARP_ID): continue
            target_groups.append(group)
            for w in group.findall('warp'):
                did=int(w.get('dungeon_index','0'))
                if did and (did not in dungeon or dungeon[did]['world'] != int(w.attrib['target_world_index'])):
                    raise ValueError('CANDIDATE_STILL_CONTAINS_INVALID_DUNGEON')
    if len(target_groups) != 1:raise ValueError('CANDIDATE_TARGET_GROUP_COUNT_INVALID')
    if candidate==original:raise ValueError('CANDIDATE_UNCHANGED')
    return candidate,result_meta

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--capture',required=True,type=Path,help='J stage original v291 mapinfo ZIP')
    p.add_argument('--registry',default=Path(__file__).with_name('server_registry_evidence.zip'),type=Path)
    p.add_argument('--out',required=True,type=Path,help='Output decoded candidate .xml, NOT .enc')
    args=p.parse_args()
    if args.out.suffix.lower()=='.enc':raise SystemExit('REFUSE_WRITE_ENCRYPTED_CLIENT_FILE')
    if args.out.exists() or args.out.resolve() in (args.capture.resolve(),args.registry.resolve()):
        raise SystemExit('REFUSE_OVERWRITE_INPUT_OR_EXISTING_OUTPUT')
    xml,report=checked_capture(args.capture.read_bytes())
    dungeon,warp=server_registries(args.registry)
    result,meta=parse_and_patch(xml,dungeon,warp)
    meta['captured_cache_index']=report['Index']
    meta['capture_original_mapinfo_sha256']=report['OriginalMapinfoSHA256']
    args.out.write_bytes(result)
    args.out.with_suffix('.report.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(meta,indent=2))

if __name__=='__main__':main()
