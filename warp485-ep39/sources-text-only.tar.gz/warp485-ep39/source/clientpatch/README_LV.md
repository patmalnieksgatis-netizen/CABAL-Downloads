# CABAL v291 / EP39 — klienta Warp 485 labojuma sagatavošana

**Statuss:** pārbaudīts *dekodēta XML kandidāta ģenerators*, nevis uzstādāms `.enc` fails. Spēlē nav testēts. Aktīvajā `WorldSvr` nekas nav mainīts.

## Pierādījumi

- `WorldSvr` logā `MainCmd 485` saņem `qdIdx=4380` un atvieno klientu, nevis avarē.
- Vēsturiskajā v291 servera `MissionDungeon2.scp` nav `[MD] QDungeonIdx=4380` (servera reģistrētā sērija beidzas ar 4378).
- Tiešām izlasītais arhīvs `Dungeons from EP33 to EP35-[RaGEZONE].zip` no projekta GitHub satur tekstu `4380` **citās `MissionDungeon2.scp` sadaļās**, nevis kā pilnu `[MD] QDungeonIdx=4380` definīciju. Vienkārša arhīva pārkopēšana serverī nav pietiekama.
- `REFERENCE_UNVERIFIED_mapinfo.dec` ir **cita CABAL klienta** atkodēts fails. Tā `World 8 / Warp 675` izvēlnē ir `4352,4378,4379,4380,4381,4382,4383`.
- Salīdzinot ar vēsturisko v291 servera konfigurāciju, saderīgs ir `4352` (`World 138`), `4378` ir World nesakritība (`166` pret servera `172`), `4379–4383` trūkst.

## Kas ir gatavs

- `Collect-Original-v291-Mapinfo.ps1` un `Mapinfo291CacheReader.cs`: J posma tikai-lasīšanas v291 procesa kešatmiņas nolasītājs. Tas vēl **nav** pārbaudīts uz īsta Windows klienta. Režīms Attach darbojas ar vienu jau palaistu oriģinālo v291 klientu un neveic procesa atmiņas ierakstus.
- `validate_capture_and_audit.py`: pieņem tikai atbilstošu autentiskā klienta nolasīšanas arhīvu (pašdeklarēts izcelsmes apliecinājums, ne neatkarīga parakstīta attestation).
- `build_client_candidate.py`: izņem no `World 8 / Warp 675` grupas tikai tos ierakstus, kuri nav servera reģistrā vai kuru mērķa World ID nesakrīt. Citus Warp netiek skarts. Oriģinālā XML netiek pārrakstīts. Saglabā visus pārējos baitus ārpus mērķa tagiem; veic XML parsēšanu pirms un pēc labojuma.
- `REFERENCE_ONLY_mapinfo_675_candidate.xml`: **atsauces piemēra**, nevis v291 klienta labojums, kas saglabāts salīdzināšanai.
- `test_client_candidate.py`: 16 bezsaistes testi, PASS uz atsauces XML + vēsturiskā reģistra.

## Piemērošana autentiskam klienta XML (tikai vēlāk, ja ir oriģinālā nolasījuma ZIP)

```powershell
python build_client_candidate.py --capture "C:\\path\\Original-v291-Mapinfo-XXXXX.zip" --out "C:\\temp\\mapinfo.v291.candidate.xml"
```

Komanda izdod **tikai dekodētu kandidāta XML un atskaiti**. Tā NEĢENERĒ `.enc` un neaizvieto klienta failus. Bez apstiprinātas oriģinālā v291 datu kodēšanas vai cita pārbaudīta klienta runtime resursa aizvietošanas mehānisma dekodētais kandidāts NAV instalējams. Nav pieļaujams pārdēvēt `.xml` par `.enc` vai izmantot citas versijas kodētāju.

## Vēl nepieejamie nosacījumi reālam labojumam

1. Autentiskā v291 klienta `mapinfo` XML nolasījums. J posma nolasītāju šajā izolētajā vidē nevar palaist uz lietotāja Windows procesa.
2. Pierādīts v291 encoderis vai apstiprināts resursa aizvietošanas interfeiss, kas nepazaudē vajadzīgo klienta datu formātu.
3. Atkārtots klients → Warp testēšanas cikls; tikai tad drīkst paziņot, ka disconnect ir salabots.

Klienta failu aizvietošana ir atļauta, taču **netiek veikta bez derīga, pārbaudāma jauna `.enc` faila**, ar rezerves kopiju un rollback. Servera `WorldSvr` un pārējie paplašinājumi nav aiztikti.
