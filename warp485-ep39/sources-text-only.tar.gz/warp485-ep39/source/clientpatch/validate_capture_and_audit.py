#!/usr/bin/env python3
"""Read-only, fail-closed validation of a real H/I v291 cache capture ZIP.

Requires both mapinfo.xml and Report.json from the original v291 cache reader.
Never takes an alternate-client decoded mapinfo as authentic v291 evidence.
The server registry ZIP is a historical snapshot, not the running server.
"""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, BadZipFile
from xml.etree import ElementTree as ET
from triple_join_audit import server_registries, audit

CLIENT_SHA = '52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
MAPINFO_ENC_SHA = '88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc'
MAPINFO_PLAIN_BYTES = 49101

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def checked_capture(data: bytes):
    try:
        with ZipFile(__import__('io').BytesIO(data)) as z:
            if sorted(z.namelist()) != ['Report.json','mapinfo.xml']:
                raise ValueError('UNEXPECTED_CAPTURE_ZIP_MEMBERS')
            for zi in z.infolist():
                if zi.file_size > 256_000 or zi.filename.startswith(('/', '\\')) or '..' in Path(zi.filename).parts:
                    raise ValueError('UNSAFE_ZIP_MEMBER')
            if z.testzip() is not None:
                raise ValueError('CORRUPTED_CAPTURE_ZIP')
            report = json.loads(z.read('Report.json').decode('utf-8-sig'))
            content = z.read('mapinfo.xml')
    except (BadZipFile, UnicodeDecodeError, json.JSONDecodeError, KeyError) as exc:
        raise ValueError('INVALID_CAPTURE_ZIP') from exc
    needed = {
        'Status':'ORIGINAL_V291_MAPINFO_CAPTURED',
        'OriginalClientSHA256': CLIENT_SHA,
        'OriginalMapinfoSHA256': MAPINFO_ENC_SHA,
        'DecodedSHA256':sha(content),
        'Bytes':MAPINFO_PLAIN_BYTES,
        'ProcessWrites': False,
        'CodeHooks': False,
        'ServerWrites': False,
    }
    for name, expected in needed.items():
        if report.get(name) != expected:
            raise ValueError(f'REPORT_CONTRACT_MISMATCH:{name}')
    mode = report.get('Mode')
    if mode not in ('Attach', 'Launch'):
        raise ValueError('CAPTURE_MODE_INVALID')
    if report.get('OriginalClientStarted') is not (mode == 'Launch'):
        raise ValueError('MODE_LAUNCH_STATUS_MISMATCH')
    if report.get('ExistingClientAttached') is not (mode == 'Attach'):
        raise ValueError('MODE_ATTACH_STATUS_MISMATCH')
    pid = report.get('ClientPID')
    if type(pid) is not int or pid <= 0:
        raise ValueError('CLIENT_PID_INVALID')
    matches = report.get('CacheSizeMatchedSlots')
    candidates = report.get('XmlCandidates')
    if type(matches) is not int or type(candidates) is not int or not (1 <= candidates <= matches <= 137):
        raise ValueError('CACHE_MATCH_COUNTS_INVALID')
    if len(content) != MAPINFO_PLAIN_BYTES:
        raise ValueError('MAPINFO_DECODED_LENGTH_MISMATCH')
    index = report.get('Index')
    if not isinstance(index,int) or isinstance(index,bool) or not 0 <= index < 137:
        raise ValueError('MAPINFO_CACHE_INDEX_INVALID')
    base = report.get('ImageBase','')
    if not isinstance(base,str) or not base.startswith('0x'):
        raise ValueError('IMAGE_BASE_NOT_RECORDED')
    try:
        b = int(base,16)
    except ValueError:
        raise ValueError('IMAGE_BASE_INVALID')
    if b < 65536 or b % 4096 or b > 0x7fffffffffff - 0xdd6430 - 137*16:
        raise ValueError('IMAGE_BASE_INVALID')
    if b'<!DOCTYPE' in content.upper() or b'<!ENTITY' in content.upper():
        raise ValueError('XML_DTD_OR_ENTITY_REFUSED')
    try:
        root = ET.fromstring(content)
    except ET.ParseError as exc:
        raise ValueError('MAPINFO_XML_INVALID') from exc
    if root.tag != 'cabal' or not root.findall('.//icon/icon_value/warp'):
        raise ValueError('MAPINFO_XML_SCHEMA_INVALID')
    return content, report

def generate(capture_zip: Path, registry_zip: Path):
    content, rep = checked_capture(capture_zip.read_bytes())
    dungeon, warp = server_registries(registry_zip)
    result = audit(content, dungeon, warp)
    result['source'] = 'V291_CACHE_CAPTURE_SELF_REPORTED_WINDOWS_NOT_INDEPENDENTLY_VERIFIED'
    result['capture'] = {'index':rep['Index'], 'decoded_sha256':sha(content),
                         'image_base':rep['ImageBase'], 'input_pinned_sha256':rep['OriginalMapinfoSHA256'],
                         'mode':rep['Mode'], 'client_pid':rep['ClientPID'], 'cache_size_matched_slots':rep['CacheSizeMatchedSlots'],
                         'xml_candidates':rep['XmlCandidates']}
    target = [e for e in result['entries'] if e['origin_world']==8 and e['warp_id']==675]
    result['warp_8_675'] = {'entries':target,
                           'has_qdidx_4380':any(e['dungeon_id']==4380 for e in target),
                           'group_present':any(g['origin_world']==8 and g['warp_id']==675 for g in result['groups'])}
    result['registry_snapshot_sha256'] = sha(registry_zip.read_bytes())
    result['limitations'] = ['Not gameplay tested','Server configurations are historical snapshot',
                              'No patch generated, no client/server files modified']
    return result

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('capture_zip',type=Path,help='ZIP created by I/H mapinfo cache reader (I with ImageBase)')
    ap.add_argument('--server-zip',type=Path, default=Path(__file__).parent/'server_registry_evidence.zip')
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    if args.out.resolve() in (args.capture_zip.resolve(),args.server_zip.resolve()):
        raise SystemExit('OUTPUT_MUST_NOT_OVERWRITE_INPUT')
    data=generate(args.capture_zip,args.server_zip)
    args.out.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':'AUDITED_HISTORICAL_SERVER_SNAPSHOT',
                      'entry_status_counts':data['entry_status_counts'],
                      'warp_8_675':data['warp_8_675'],
                      'capture_sha256':data['capture']['decoded_sha256']},ensure_ascii=False))

if __name__=='__main__':
    main()
