@echo off
cd /d "%~dp0"
py -3 guard485.py --apply-lab "F:\CABAL_291_LAB"
echo.
echo Tikai LAB klienta kopija. Parbaudi statusu, netici spelei bez speletaja testa.
pause
