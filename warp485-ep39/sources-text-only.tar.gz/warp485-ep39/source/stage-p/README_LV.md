# CABAL v291 / EP39 — Stage P: mērķēts MainCmd 485 klienta aizsargs

**Statuss: IR IZVEIDOTS REĀLS EKSPERIMENTĀLS BINĀRS LABOJUMA KANDIDĀTS TIKAI LAB KOPIJAI.**
Tā nav spēlē pārbaudīta instalācija. Nav pamata teikt, ka 4380 dungeon tagad strādās.

## Kas tika atrasts **pilnajā, autentiskajā** `CabalMain.exe`

* EXE SHA256 `52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9`.
* `0x1406C9F30` — kods, kas veido **14 baitu** paketi (`E2 B7 0E 00 ... E5 01`), kopē 32 bitu dungeon ID no `0x14120CC68` uz paketes nobīdi `+0x0A`, un nodod to `0x1402B7A40`.
* `0x1406C7047` — atsevišķā klienta funkcijā statiski reģistrēta **tieša funkcijas adrese** `0x1406C9F30`. Tādējādi tā nav tikai nejauša koda baitu sakritība.
* WorldSvr atsauces bināra `OnCSCQDungeonLimitCheck` no paketes `+0x0A` nolasa `qdIdx`; vēsturiskajā v291 servera `[MD]` reģistrā pēdējais definētais ID ir `4378`, bet kļūdā tiek saņemts `4380`.

## Ko šis kandidāts tieši maina

Tikai šajā klienta funkcijā pievieno 32 bitu **`cmp eax,4380` / `je cleanup`** pārbaudi. Tā nepieļauj konkrētās 485 paketes nosūtīšanu **šajā ceļā**, ja atlasītais QD indeks ir precīzi 4380. Citu ID loģika, paketes formāts un esošie izsaukumu mērķi saglabāti; kods salikts vietā, izmantojot vienu sākotnējo `INT3` padding baitu. Nenotiek `4380 -> 4378/4352` pārvērtēšana un servera validācija netiek atslēgta.

**Ierobežojumi:** tas neizveido dungeon 4380, nenovērš citus nederīgus QD ID, negarantē, ka spēles izpilde tiešām izmanto šo konkrēto callback ceļu, un negarantē, ka klients atļaus mainīt savu EXE (oriģinālam ir PE certificate/security directory; pēc koda izmaiņas Authenticode paraksts vairs nebūs derīgs). Klientā var būt arī citi 485 izsūtīšanas ceļi.

## Izolētās kopijas izmantošana (NAV darba klientā)

Pakotne satur `guard485.py`, `Palaist-LAB-Uzlikt.cmd`, `Palaist-LAB-Atcelt.cmd` un 20 automātiskos testus. Priekšnosacījums: **jau izveidota atsevišķa, pilnīga spēles kopija** `F:\CABAL_291_LAB` ar `Bin\x64\CabalMain.exe`, kura SHA precīzi sakrīt ar iepriekš minēto. Nekopē tikai EXE kā pilnu klientu — datus un atkarības vajag spēles palaišanai.

1. Aizver visus `CabalMain.exe` procesus.
2. Izpako Stage P ZIP neatkarīgā mapē un, ja gribi veikt atsevišķu LAB eksperimentu, palaid `Palaist-LAB-Uzlikt.cmd`.
3. Rezultāts attiecas **tikai** uz `F:\CABAL_291_LAB\Bin\x64\CabalMain.exe`. Skripts pārbauda visu oriģinālo SHA, PE64 formātu, funkcijas koda rakstus un callback reģistrāciju, izveido `CabalMain.exe.stagep_original.bak`, pēc tam atomiski ievieto izmaiņu un pārbauda jauno SHA.
4. Atgriešana: `Palaist-LAB-Atcelt.cmd`; tas noraidīs citādi modificētu LAB EXE un neizmantos nepareizu backup.

Komandrindā:

```powershell
py -3 guard485.py --inspect-original "F:\CABAL_291_TEST\Bin\x64\CabalMain.exe"
py -3 guard485.py --apply-lab "F:\CABAL_291_LAB"
py -3 guard485.py --rollback-lab "F:\CABAL_291_LAB"
```

Rīks noraida ceļus bez `_LAB` vai `_ISOLATED` mapes nosaukuma, aktīvā projekta `F:\CABAL_291_TEST`, simboliskās saites un jau mainītus EXE; ja spēle darbojas, Windows vidē noraida izmaiņas. Nav servera, SQL vai tīkla rakstīšanas.

## Pārbaudes un pierādījumi

- `test_guard485.py`: **20/20 PASS** izolētā Linux vidē, arī uzlikšana un atjaunošana ar autentiskā EXE *kopiju*, oriģinālā EXE SHA, callback reģistrācijas adrese, branch mērķis un baitu izmaiņu robeža.
- `disassembly_after.txt`: neatkarīgs `objdump` x64 disassembly pēc binārā labojuma; `0x1406C9F5B je 0x1406C9F7A`, bet oriģinālā nākamā funkcija `0x1406C9F80` paliek neskarta.
- Oriģinālā EXE bloka file offset `0x6C9330`, garums **80** baiti; jauni baiti **tikai šajā blokā**.
- Mainītā pilnā LAB EXE sagaidāmais SHA256 `ef4fd980520d52d6ede0785d5de42d7ed90045acfe56c2f86be89c6e317869d1`.

**Neveiktas pārbaudes:** Windows loader/anti-cheat/digitālā paraksta pieņemšana, klienta reāla pievienošanās, konkrētā callback izsaukums spēles gaitā, atkārtots MainCmd485 tests. Līdz tam tas nav apstiprināts risinājums atvienošanās novēršanai.

## Ko šis aizstāj

Šai precīzajai kļūdai turpmāk nav nepieciešams akli minēt `mapinfo.enc` XOR atslēgu, lai iegūtu **izmēģināmu atvienošanās guard kandidātu**. Bet faktiskā `mapinfo` satura un derīgu 4379–4383 dungeon definīciju trūkums turpina bloķēt to patiesu spēlēšanu.
