#!/usr/bin/env python3
"""Offline tests only; no game process or server is launched."""
import hashlib
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
import guard485 as p

SRC=Path(os.environ.get('CABAL_V291_ORIGINAL_EXE', r'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe'))

class TestBinaryGuard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw=SRC.read_bytes()
        cls.old,cls.off=p.get_source_data(cls.raw)
        cls.new,cls.meta=p.make_block()
        cls.patched=p.build_patched(cls.raw)

    def test_01_original_sha_exact(self):
        self.assertEqual(p.sha(self.raw),p.EXE_SHA)
    def test_02_source_block_known_sha(self):
        self.assertEqual(p.sha(self.old),'b924030e097201a13504ac4f3c443527d47738e442bab09dc81563e042137a91')
    def test_03_asm_budget(self):
        self.assertEqual(len(self.new),80)
        self.assertEqual(self.meta['function_used_bytes'],79)
        self.assertEqual(self.new[-1],0xcc)
    def test_04_asm_opcode_485(self):
        self.assertIn(bytes.fromhex('66 C7 44 24 28 E5 01'),self.new)
    def test_05_asm_packet_size_14(self):
        self.assertIn(bytes.fromhex('6A 0E 41 58'),self.new)
    def test_06_asm_header(self):
        self.assertIn(bytes.fromhex('C7 44 24 20 E2 B7 0E 00'),self.new)
    def test_07_asm_qdidx_field(self):
        self.assertIn(bytes.fromhex('89 44 24 2A'),self.new)
    def test_08_exact_32bit_guard(self):
        self.assertIn(bytes.fromhex('3D 1C 11 00 00 74'),self.new)
    def test_09_branch_direct_to_epilogue(self):
        je=int(self.meta['je_at'],16)-p.BASE-p.PATCH_RVA
        offset=struct.unpack_from('b',self.new,je+1)[0]
        self.assertEqual(self.new[je],0x74)
        self.assertEqual(p.BASE+p.PATCH_RVA+je+2+offset,int(self.meta['je_target'],16))
        self.assertEqual(self.new[je+2+offset:je+2+offset+5],bytes.fromhex('48 83 C4 38 C3'))
    def test_10_send_and_flush_targets(self):
        for name,target in [('send',p.SEND_FN),('flush',p.FLUSH_FN),('selected_qdidx',p.QD_GLOBAL),('initial_connection',p.CONNECTION_GLOBAL),('flush_connection',p.CONNECTION_GLOBAL)]:
            ref=self.meta['references'][name]
            pos=int(ref['at'],16)-p.BASE-p.PATCH_RVA
            off=struct.unpack_from('<i',self.new,pos+ref['size']-4)[0]
            self.assertEqual(int(ref['at'],16)+ref['size']+off,target)
    def test_11_only_sender_region_changes(self):
        self.assertEqual(len(self.patched),len(self.raw))
        changed=[i for i,(a,b) in enumerate(zip(self.raw,self.patched)) if a!=b]
        self.assertTrue(changed)
        self.assertGreaterEqual(min(changed),self.off)
        self.assertLess(max(changed),self.off+80)
        self.assertEqual(self.patched[:self.off],self.raw[:self.off])
        self.assertEqual(self.patched[self.off+80:],self.raw[self.off+80:])
    def test_12_modified_exe_has_known_hash(self):
        self.assertEqual(p.sha(self.patched),'ef4fd980520d52d6ede0785d5de42d7ed90045acfe56c2f86be89c6e317869d1')
    def test_13_reject_wrong_source(self):
        b=bytearray(self.raw);b[100]^=1
        with self.assertRaisesRegex(ValueError,'SHA256'):p.build_patched(bytes(b))
    def test_14_refuse_active(self):
        with self.assertRaisesRegex(ValueError,'LAB'):
            p.verify_lab_root(Path('F:/CABAL_291_TEST'))
    def test_15_apply_rollback_lab(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'CABAL_291_LAB'
            exe=root/'Bin'/'x64'/'CabalMain.exe'
            exe.parent.mkdir(parents=True)
            exe.write_bytes(self.raw)
            self.assertEqual(p.run_lab(root,'apply')['status'],'LAB_EXPERIMENTAL_GUARD_APPLIED')
            self.assertEqual(exe.read_bytes(),self.patched)
            self.assertEqual(p.sha(exe.with_suffix('.exe.stagep_original.bak').read_bytes()),p.EXE_SHA)
            self.assertEqual(p.run_lab(root,'rollback')['status'],'LAB_ORIGINAL_RESTORED')
            self.assertEqual(exe.read_bytes(),self.raw)
    def test_16_apply_twice_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'CABAL_291_LAB';exe=root/'Bin'/'x64'/'CabalMain.exe';exe.parent.mkdir(parents=True);exe.write_bytes(self.raw)
            p.run_lab(root,'apply')
            with self.assertRaisesRegex(ValueError,'UNMODIFIED'):p.run_lab(root,'apply')
    def test_17_reject_tampered_backup(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'CABAL_291_LAB';exe=root/'Bin'/'x64'/'CabalMain.exe';exe.parent.mkdir(parents=True);exe.write_bytes(self.raw)
            p.run_lab(root,'apply')
            exe.with_suffix('.exe.stagep_original.bak').write_bytes(b'bad')
            with self.assertRaisesRegex(ValueError,'BACKUP'):p.run_lab(root,'rollback')
            self.assertEqual(exe.read_bytes(),self.patched)
    def test_18_callback_registration_target(self):
        addr=0x1406C7047
        offset=self.off+(0x6C7047-p.PATCH_RVA)
        self.assertEqual(self.raw[offset:offset+3],bytes.fromhex('48 8D 05'))
        rel=struct.unpack_from('<i',self.raw,offset+3)[0]
        self.assertEqual(addr+7+rel,p.BASE+p.PATCH_RVA)

    def test_19_native_event_registration(self):
        offset=self.off+(0x6C7030-p.PATCH_RVA)
        self.assertEqual(self.raw[offset:offset+7],bytes.fromhex('C7 45 10 BA 00 00 00'))

    def test_20_reject_symlink(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'CABAL_291_LAB'
            try:
                root.symlink_to(Path(t),target_is_directory=True)
            except (OSError,NotImplementedError): self.skipTest('symlinks unsupported')
            with self.assertRaisesRegex(ValueError,'SYMLINK'):p.verify_lab_root(root)

if __name__=='__main__':unittest.main(verbosity=2)
