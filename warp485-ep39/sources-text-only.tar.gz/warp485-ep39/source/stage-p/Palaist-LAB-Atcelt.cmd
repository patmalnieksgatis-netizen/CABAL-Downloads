@echo off
cd /d "%~dp0"
py -3 guard485.py --rollback-lab "F:\CABAL_291_LAB"
pause
