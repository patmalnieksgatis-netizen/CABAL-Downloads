#!/usr/bin/env python3
"""CABAL v291 MainCmd 485 exact-QDIdx-4380 send guard, for LAB clones only.

Offline experimental binary patch. Does NOT make dungeon 4380 valid or verify runtime call use.
No remote access, server code, database edits, or injections.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile

EXE_SHA = "52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9"
BASE = 0x140000000
PATCH_RVA = 0x6C9F30
BLOCK_CAP = 0x50
QDIDX = 4380
QD_GLOBAL = 0x14120CC68
CONNECTION_GLOBAL = 0x14126A9F8
SEND_FN = 0x1402B7A40
FLUSH_FN = 0x1402B7A38


def sha(buf: bytes) -> str:
    return hashlib.sha256(buf).hexdigest()


def assert_pe64(blob: bytes) -> int:
    if len(blob) < 0x300 or blob[:2] != b"MZ":
        raise ValueError("NOT_PE_MZ")
    pe, = struct.unpack_from('<I', blob, 0x3c)
    if pe + 0x100 >= len(blob) or blob[pe:pe+4] != b'PE\x00\x00':
        raise ValueError("NOT_PE")
    if struct.unpack_from('<H', blob, pe+24)[0] != 0x20b:
        raise ValueError("NOT_PE64")
    if struct.unpack_from('<Q', blob, pe+24+24)[0] != BASE:
        raise ValueError("IMAGE_BASE_MISMATCH")
    sections = struct.unpack_from('<H', blob, pe+6)[0]
    opt_size = struct.unpack_from('<H', blob, pe+20)[0]
    for i in range(sections):
        s = pe + 24 + opt_size + i*40
        name = blob[s:s+8].split(b'\0')[0]
        vs, rva, raw_size, raw_ptr = struct.unpack_from('<IIII', blob, s+8)
        if name == b'.text':
            if rva <= PATCH_RVA and PATCH_RVA + BLOCK_CAP <= rva + min(raw_size, vs):
                ofs = raw_ptr + PATCH_RVA - rva
                if ofs + BLOCK_CAP <= len(blob):
                    return ofs
    raise ValueError("PATCH_NOT_IN_FILE_BACKED_TEXT")


def make_block() -> tuple[bytes, dict]:
    out = bytearray()
    refs = {}
    def at() -> int:
        return BASE + PATCH_RVA + len(out)
    def add(raw: bytes):
        out.extend(raw)
    def rel32(op: bytes, target: int, label: str):
        start = at()
        offset = target - (start + len(op) + 4)
        if not -(1<<31) <= offset < (1<<31):
            raise ValueError("REL32_OUT_OF_RANGE")
        add(op + struct.pack('<i',offset))
        refs[label] = {'at': hex(start), 'target': hex(target), 'size':len(op)+4}
    add(bytes.fromhex('48 83 EC 38'))   # sub rsp,38h
    rel32(bytes.fromhex('48 8B 0D'), CONNECTION_GLOBAL, 'initial_connection')
    add(bytes.fromhex('48 8D 54 24 20')) # lea rdx,[rsp+20h]
    add(bytes.fromhex('83 64 24 24 00')) # and dword [rsp+24h],0
    add(bytes.fromhex('66 C7 44 24 28 E5 01')) # opcode 485
    add(bytes.fromhex('6A 0E 41 58')) # push 14; pop r8 (same semantics as mov r8d,14)
    rel32(bytes.fromhex('8B 05'), QD_GLOBAL, 'selected_qdidx')
    add(bytes.fromhex('3D 1C 11 00 00')) # cmp eax,4380 (EXACT dword)
    jcc_offset = len(out)
    add(bytes.fromhex('74 00')) # je to cleanup; filled below
    add(bytes.fromhex('89 44 24 2A')) # mov [rsp+2Ah],eax
    add(bytes.fromhex('C7 44 24 20 E2 B7 0E 00')) # protocol header, packet length 0xE
    rel32(bytes.fromhex('E8'), SEND_FN, 'send')
    rel32(bytes.fromhex('48 8B 0D'), CONNECTION_GLOBAL, 'flush_connection')
    rel32(bytes.fromhex('E8'), FLUSH_FN, 'flush')
    exit_at = len(out)
    add(bytes.fromhex('48 83 C4 38 C3')) # add rsp,38h; ret
    rel = exit_at - (jcc_offset + 2)
    if not 0 <= rel <= 127:
        raise AssertionError('GUARD_SHORT_BRANCH_OUT_OF_RANGE')
    out[jcc_offset+1] = rel
    unpadded_len = len(out)
    if unpadded_len > BLOCK_CAP:
        raise AssertionError('PATCH_TOO_LARGE')
    out += b'\xCC' * (BLOCK_CAP - len(out))
    assert len(out) == BLOCK_CAP
    return bytes(out), {'references':refs, 'je_at':hex(BASE+PATCH_RVA+jcc_offset),
                        'je_target':hex(BASE+PATCH_RVA+exit_at),
                        'function_used_bytes':unpadded_len,
                        'guard_qdidx':QDIDX, 'block_sha256':sha(out)}


def get_source_data(original: bytes) -> tuple[bytes, int]:
    if sha(original) != EXE_SHA:
        raise ValueError('ORIGINAL_EXE_SHA256_MISMATCH')
    offset = assert_pe64(original)
    # The native UI registration explicitly binds the callback pointer to this function.
    callback_ref = offset + (0x6C7047 - PATCH_RVA)
    event_registration = offset + (0x6C7030 - PATCH_RVA)
    if original[callback_ref:callback_ref+7] != bytes.fromhex('48 8D 05 E2 2E 00 00'):
        raise ValueError('CALLBACK_REGISTRATION_MISMATCH')
    if original[event_registration:event_registration+7] != bytes.fromhex('C7 45 10 BA 00 00 00'):
        raise ValueError('EVENT_REGISTRATION_MISMATCH')
    block = original[offset:offset+BLOCK_CAP]
    # Verify known original instruction anchors and that there is exactly one function
    if not block.startswith(bytes.fromhex('48 83 EC 38 48 8B 0D')):
        raise ValueError('SENDER_PROLOGUE_MISMATCH')
    for pat in (bytes.fromhex('B8 E5 01 00 00'), bytes.fromhex('41 B8 0E 00 00 00'),
                bytes.fromhex('89 44 24 2A'), bytes.fromhex('C7 44 24 20 E2 B7 0E 00'),
                bytes.fromhex('48 83 C4 38 C3')):
        if pat not in block:
            raise ValueError('SENDER_PATTERN_MISMATCH')
    if block[-3:] != b'\xCC'*3:
        raise ValueError('FUNCTION_PADDING_MISMATCH')
    return block, offset


def build_patched(original: bytes) -> bytes:
    before, offset = get_source_data(original)
    new, _ = make_block()
    if before == new:
        raise ValueError('ALREADY_PATCHED')
    return original[:offset] + new + original[offset+BLOCK_CAP:]


def no_running_game():
    if os.name != 'nt': return
    result = subprocess.run(['tasklist','/FI','IMAGENAME eq CabalMain.exe','/FO','CSV','/NH'],
                            capture_output=True,text=True,timeout=12)
    if result.returncode != 0:
        raise RuntimeError('CANNOT_CONFIRM_GAME_NOT_RUNNING')
    if 'cabalmain.exe' in result.stdout.lower():
        raise RuntimeError('CLOSE_ALL_CABALMAIN_PROCESSES')


def verify_lab_root(root: Path):
    name = root.name.upper()
    if not (name.endswith('_LAB') or name.endswith('_ISOLATED')):
        raise ValueError('ROOT_MUST_END_WITH_LAB_OR_ISOLATED')
    if name == 'CABAL_291_TEST' or 'CABAL_291_TEST' in str(root).upper():
        raise ValueError('ACTIVE_CLIENT_ROOT_FORBIDDEN')
    for p in [root,root/'Bin',root/'Bin'/'x64',root/'Bin'/'x64'/'CabalMain.exe']:
        if p.is_symlink(): raise ValueError('SYMLINK_REFUSED')
    if not root.is_dir() or not (root/'Bin'/'x64'/'CabalMain.exe').is_file():
        raise ValueError('LAB_CLIENT_EXE_NOT_FOUND')


def atomic_write(path: Path, data: bytes):
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(dir=str(path.parent),prefix='.stagep-',delete=False) as f:
            tmp = Path(f.name)
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
        tmp = None
    finally:
        if tmp is not None:tmp.unlink(missing_ok=True)


def run_lab(root: Path, action: str) -> dict:
    verify_lab_root(root)
    no_running_game()
    exe = root/'Bin'/'x64'/'CabalMain.exe'
    backup = exe.with_suffix('.exe.stagep_original.bak')
    orig = exe.read_bytes()
    if action == 'apply':
        if sha(orig) != EXE_SHA:
            raise ValueError('LAB_EXE_IS_NOT_UNMODIFIED_PINNED_ORIGINAL')
        if backup.exists():
            raise ValueError('BACKUP_EXISTS_REFUSING_OVERWRITE')
        new = build_patched(orig)
        # Save/verify backup before modifying the clone
        atomic_write(backup,orig)
        if sha(backup.read_bytes()) != EXE_SHA:
            raise ValueError('BACKUP_VERIFICATION_FAILED')
        atomic_write(exe,new)
        if sha(exe.read_bytes()) != sha(new):
            raise ValueError('PATCH_VERIFICATION_FAILED')
        return {'status':'LAB_EXPERIMENTAL_GUARD_APPLIED', 'old_sha256':EXE_SHA,
                'new_sha256':sha(new),'backup':str(backup)}
    if action == 'rollback':
        if not backup.is_file() or sha(backup.read_bytes()) != EXE_SHA:
            raise ValueError('VERIFIED_BACKUP_NOT_FOUND')
        exp = sha(build_patched(backup.read_bytes()))
        if sha(orig) != exp:
            raise ValueError('CURRENT_LAB_BINARY_DIFFERS_FROM_EXPECTED_PATCH')
        atomic_write(exe,backup.read_bytes())
        if sha(exe.read_bytes()) != EXE_SHA:
            raise ValueError('ROLLBACK_VERIFICATION_FAILED')
        return {'status':'LAB_ORIGINAL_RESTORED', 'sha256':EXE_SHA}
    raise ValueError('UNKNOWN_ACTION')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--inspect-original',type=Path)
    group.add_argument('--apply-lab',type=Path)
    group.add_argument('--rollback-lab',type=Path)
    a=p.parse_args()
    try:
        if a.inspect_original:
            b=a.inspect_original.read_bytes()
            old,ofs=get_source_data(b)
            new,meta=make_block()
            info={'status':'OFFLINE_ONLY_NOT_RUNTIME_VERIFIED',
                  'original_sha256':EXE_SHA,'original_sender_block_sha256':sha(old),
                  'patched_sender_block_sha256':sha(new),'sender_file_offset':hex(ofs),
                  'patched_full_exe_sha256':sha(build_patched(b)),**meta}
        else:
            root = a.apply_lab or a.rollback_lab
            info=run_lab(root, 'apply' if a.apply_lab else 'rollback')
        print(json.dumps(info,indent=2,ensure_ascii=False))
    except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired) as e:
        print('STOP:',str(e),file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':sys.exit(main())
