@echo off
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Parbaudit-LAB-Startu.ps1"
echo.
echo Atskaites fails: F:\CABAL_291_LAB\_STAGEQ_STARTUP_DIAG.json
pause
