CABAL v291 EP39 Stage Q - LAB klienta pazusanas parbaude

1. Aizver visus CabalMain.exe procesus.
2. Palaid Palaist-LAB-Starta-Parbaudi.cmd.
3. Skripts salidzina 2 SHA256, atjauno TIKAI LAB originalo EXE no
   CabalMain.exe.stagep_original.bak un atseviski saglaba neveiksmigo
   patch ka CabalMain.exe.stagep_failed_startup.bak.
4. Tas palaiž ORIĢINĀLO LAB klientu ar to pašu argumentu breaklee,
   parbauda, vai tas ir dzivs pec 12 sekundem, un mekle Windows
   Application Error / Windows Error Reporting ierakstus par CabalMain.
5. Atskaite: F:\CABAL_291_LAB\_STAGEQ_STARTUP_DIAG.json

Nemainaa F:\CABAL_291_TEST, mapinfo.enc, WorldSvr, SQL, Docker.
Ja veids / fails neatbilst sagaidamajai SHA256, skripts apstajas.
Ja oriģinālais LAB strādā, butu jagraiza Stage P patch vai klienta
integritates logika; tas vel nepierada tiesi kuru.
Ja arī oriģinālais LAB pazud, iespejama kopijas/argum./dependencu problema.
Windows reala izpilde vel nav apstiprinata.
