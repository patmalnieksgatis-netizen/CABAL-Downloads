# CABAL v291 / EP39 - Stage Q quick-exit isolation.
# Only restores F:\CABAL_291_LAB\Bin\x64\CabalMain.exe from its Stage Q verified backup.
# Does not touch F:\CABAL_291_TEST, server, SQL or other client files.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$lab = 'F:\CABAL_291_LAB'
$exe = Join-Path $lab 'Bin\x64\CabalMain.exe'
$originalBackup = $exe + '.stagep_original.bak'
$failedPatchedBackup = $exe + '.stagep_failed_startup.bak'
$originalHash = '52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
$patchedHash = 'ef4fd980520d52d6ede0785d5de42d7ed90045acfe56c2f86be89c6e317869d1'
$reportPath = Join-Path $lab '_STAGEQ_STARTUP_DIAG.json'
function Get-FileSha([string]$file) { (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() }
$report = [ordered]@{
    status = 'NOT_STARTED'; time = (Get-Date).ToString('o')
    lab_exe = $exe; work_client_unchanged = $true; server_unchanged = $true
    original_lab_exe_restored = $false; original_lab_exe_sha256 = $null
    launch_argument = 'breaklee'; launch_pid = $null; launch_status = $null
    exit_code_decimal = $null; exit_code_hex = $null; application_error_events = @()
}
try {
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'LAB_CLIENT_NOT_FOUND' }
    if (-not (Test-Path -LiteralPath $originalBackup -PathType Leaf)) { throw 'STAGEQ_ORIGINAL_BACKUP_NOT_FOUND' }
    if ((Get-FileSha $originalBackup) -ne $originalHash) { throw 'ORIGINAL_BACKUP_SHA256_MISMATCH_STOP' }
    if (@(Get-Process -Name CabalMain -ErrorAction SilentlyContinue).Count -gt 0) { throw 'CLOSE_ALL_CABALMAIN_FIRST' }
    $currentHash = Get-FileSha $exe
    if ($currentHash -eq $patchedHash) {
        if (Test-Path -LiteralPath $failedPatchedBackup) { throw 'PREVIOUS_FAILED_STARTUP_BACKUP_EXISTS_REFUSE_OVERWRITE' }
        $tmp = $exe + '.stageq_restore_tmp'
        if (Test-Path -LiteralPath $tmp) { throw 'RESTORE_TEMP_EXISTS_REFUSE_OVERWRITE' }
        try {
            [IO.File]::Copy($originalBackup,$tmp,$false)
            if ((Get-FileSha $tmp) -ne $originalHash) { throw 'RESTORE_TEMP_SHA256_MISMATCH' }
            [IO.File]::Replace($tmp,$exe,$failedPatchedBackup)
        } finally {
            if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force }
        }
        if ((Get-FileSha $failedPatchedBackup) -ne $patchedHash) { throw 'FAILED_PATCH_BACKUP_SHA256_MISMATCH' }
        Write-Host 'LAB_PATCH_ROLLED_BACK: patched exe saved for analysis.' -ForegroundColor Yellow
    } elseif ($currentHash -eq $originalHash) {
        Write-Host 'LAB_ALREADY_ORIGINAL: no binary change needed.' -ForegroundColor Yellow
    } else {
        throw ('UNRECOGNIZED_LAB_EXE_SHA256_STOP: ' + $currentHash)
    }
    if ((Get-FileSha $exe) -ne $originalHash) { throw 'ROLLBACK_VERIFICATION_FAILED' }
    $report.original_lab_exe_restored = $true
    $report.original_lab_exe_sha256 = $originalHash
    $start = Get-Date
    Write-Host 'LAUNCHING_ORIGINAL_LAB_CLIENT: wait up to 12 seconds...' -ForegroundColor Cyan
    $process = Start-Process -FilePath $exe -ArgumentList 'breaklee' -WorkingDirectory (Split-Path -Parent $exe) -PassThru
    $report.launch_pid = [int]$process.Id
    if ($process.WaitForExit(12000)) {
        $code = [int]$process.ExitCode
        $report.exit_code_decimal = $code
        $report.exit_code_hex = ('0x{0:X8}' -f ([uint32]([int64]$code -band 0xffffffffL)))
        $report.launch_status = 'ORIGINAL_LAB_PROCESS_EXITED_WITHIN_12S'
    } else {
        $report.launch_status = 'ORIGINAL_LAB_PROCESS_ALIVE_AFTER_12S'
    }
    $events = @(Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$start.AddSeconds(-5); Id=1000,1001} -MaxEvents 60 -ErrorAction SilentlyContinue | Where-Object { $_.Message -match 'CabalMain(?:\.exe)?' } | Select-Object -First 6)
    $report.application_error_events = @($events | ForEach-Object {
        [ordered]@{ time=$_.TimeCreated.ToString('o'); id=[int]$_.Id; source=$_.ProviderName; details=($_.Message.Substring(0,[Math]::Min(1200,$_.Message.Length))) }
    })
    $report.status = 'COMPLETE'
    Write-Host ('RESULT: ' + $report.launch_status + ' ' + $report.exit_code_hex) -ForegroundColor Green
    Write-Host 'If original LAB keeps running, patch or its integrity is the likely cause; this is not yet proved.'
    Write-Host 'If original LAB also closes, investigate launch path, dependencies and crash event.'
} catch {
    $report.status = 'STOPPED_SAFELY'
    $report.error = $_.Exception.Message
    Write-Host ('STOP: ' + $_.Exception.Message) -ForegroundColor Red
} finally {
    try {
        if (Test-Path -LiteralPath $lab -PathType Container) {
            $report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $reportPath -Encoding UTF8
            Write-Host ('REPORT: ' + $reportPath) -ForegroundColor Cyan
        }
    } catch { Write-Host ('REPORT_WRITE_FAILED: ' + $_.Exception.Message) -ForegroundColor Yellow }
}
if ($report.status -ne 'COMPLETE') { exit 2 }
