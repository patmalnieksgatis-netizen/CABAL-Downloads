# CABAL v291 / EP39 — Stage M: pilnā oriģinālā EXE analīze

**Šīs pakotnes statuss:** reproducējams **offline diagnostikas rezultāts** un izvēles **agrīnās, tikai-lasīšanas nolasīšanas rīks**. Šis **NAV uzstādāms Warp 485 labojums**. Reāls spēles tests nav noticis. Visi analizētie faili palikuši nemainīti.

## Ko atradām ar pilno `CabalMain.exe`

Saņemtais EXE ir autentiskais norādītais v291 x64 fails pēc SHA256:

`52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9`

Statiski pārbaudīta konkrēta resursu nolasīšanas ķēde:

`0x14021CDE6 -> 0x1402178E0 -> 0x140217A17 -> 0x1402B7FAC -> 0x1402B8B08 -> 0x1402B7A90`.

- `0x1402179C7` rāda, ka ieejas datu pointers tiek pārbīdīts par 4 baitiem (izlaižot izpakotā izmēra galveni).
- Pie `0x1402B7A90` pirmajiem **četriem saspiestā satura baitiem** tiek lietoti XOR baiti `92 65 67 57`. Atlikušos bitu straumes baitus šī funkcija atdod bez šī XOR.
- Šī komponente izsauc paša klienta **DEFLATE tipa** bitu straumes dekodētāju.
- Iepriekš pierādītais cache atbrīvošanas ceļš `0x14021BB38..BB5E` var nullēt pointeri, atstājot izmēru.

**Jauns un deterministisks konflikts:** četru oriģinālo, pēc SHA256 pārbaudīto `.enc` failu pirmais saspiestais baits pēc šīs konkrētās XOR transformācijas dod DEFLATE pirmā bloka tipu **3**. DEFLATE bloka tips `3` ir rezervēts/nederīgs, tātad **šie faili nav saderīgi ar šo tiešo nolasīšanas ceļu tādā veidā, kādā tie ir saglabāti**.

| Fails | Saspiestā satura pirmais baits | Pēc XOR 0x92 | DEFLATE BTYPE |
|---|---|---|---|
| `mapinfo.enc` | `0C` | `9E` | `3` — nederīgs |
| `Warp.enc` | `0C` | `9E` | `3` — nederīgs |
| `quest.enc` | `0D` | `9F` | `3` — nederīgs |
| `LegacyTicket.enc` | `54` | `C6` | `3` — nederīgs |

**Robeža:** no šīs pārbaudes **nedrīkst** secināt, ka klients kopumā neprot nolasīt failus. Var eksistēt **cits** resursu ceļš, pārveidojošs starpslānis vai šie faili nav tie, kurus reāli izmanto konkrētā spēles brīdī. Šādu alternatīvo ceļu vēl neesam pierādījuši. Pirmā bloka nesaderība nav pierādījums par alternatīva šifrēšanas algoritma identitāti.

## Kas ir gatavs

1. `tools/verify_loader_path.py`: no jauna validē pilnā EXE SHA256, PE x64 sadaļu, assemblera instrukciju baitus, trīs `call` mērķus un visu četru oriģinālo ENC SHA/galvenes. Tas **tikai lasa**, nesaudzēto kopiju vai patch nerada.
2. `evidence/direct_reader_audit.json`: faktiski ģenerēta strukturēta atskaite.
3. `evidence/native_call_chain.txt`: tiešs pilnā EXE disassembly izgriezums ar pierādījumu adresēm.
4. `tools/test_stage_m.py`: **15/15 PASS** Linux izolētajā vidē (statiska koda/artefaktu validācija un sintētiski datu testi).
5. `tools/capture_mapinfo_early.py`: **izvēles Windows x64** agrīnās nolasīšanas rīks. Pilnībā atsevišķs no spēles procesa, izmanto tikai Windows lasīšanas API, nepārraksta EXE/ENC, neveic injekciju, hook, servera izmaiņas vai spēles procesu nogalināšanu. Lasāma tikai `mapinfo` kešatmiņas vieta (indekss 28). Atlasa kandidātu tikai pēc precīza izmēra, stabilitātes un XML struktūras. Rāda piecu sekunžu progresu. Veiksmīgas nolasīšanas gadījumā saglabā `Report.json` un `mapinfo.xml` vienā ZIP formā, kas ir savietojama ar iepriekšējā `ClientPatch` ZIP auditēšanas ieejas kontraktu. Pašdeklarēta izcelsme nav kriptogrāfiska attestation.

**Windows rīks netika palaists** uz lietotāja Windows, un tam nav iespējams garantēt, ka īsā cache logā notvers pointeri. Tas nav uzskatāms par jau iegūtu autentisko XML.

## Ja nepieciešama viena Windows darbība (izvēles)

Pirms agrīnās nolasīšanas oriģinālais CABAL klients jāaizver pašam lietotājam. Rīks **neaptur un nenogalina** jau palaistu klientu. Kad klients ir aizvērts, ar dubultklikšķi palaist `Palaist-Mapinfo-Agrina-Nolasishana.cmd`. Nepieciešams x64 Python 3 ar `py -3`. Skripts pārbauda `F:\CABAL_291_TEST\Bin\x64\CabalMain.exe` un `F:\CABAL_291_TEST\Data\mapinfo.enc` SHA256; tad palaiž vienu oriģinālā klienta instanci `breaklee` un īsu laiku tikai nolasa kešatmiņu. Ziņo par statusu `Downloads\Original-v291-Mapinfo-Early-*.zip`.

Ja ziņo `MAPINFO_NOT_CAPTURED_DURING_WINDOW`, tas ir negatīvs mēģinājums — nav pamata uzskatīt klientu par sabojātu vai turpināt bezgalīgas vienas rindas pārbaudes. **Nav jāpalaiž šis rīks atkārtoti bez jaunas pieejas.**

## Ko **nedarījām**

- Neatkodējām oriģinālo v291 `mapinfo.enc`; **neizveidojām** derīgu jaunu `.enc` un neinstalējām patch.
- Neizmantojām citu klientu `REFERENCE_UNVERIFIED_mapinfo.dec` kā autentisku.
- Neatspējojām `MainCmd(485)`/dungeon limit servera pārbaudi.
- Neizmainījām `WorldSvr`, SQL, spēles klientu, VM vai aktīvu spēli.
- Neveicām reālu Warp 485 spēles testu.

## Tehniskā prioritāte pēc Stage M

**1.** Noteikt, vai oriģinālais v291 klienta resurss spēles startā izmanto šo tiešo loader ceļu vai citu. **2.** Iegūt autentisko `mapinfo` dekodējumu (viens agrīnās nolasīšanas mēģinājums, ja lietotājs to izvēlas). **3.** Tad izmantot jau esošo `build_client_candidate.py` un reālo servera reģistra salīdzinājumu. **4.** Tikai pēc verificēta v291 resursa kodētāja/aizvietotāja atrisināšanas var veidot rollback un instalējamu klienta failu. **5.** Spēlē atkārtot Warp 485 kļūdas ciklu, salīdzinot WorldSvr logus.

Šis ir pabeigts **pilnā EXE statiskās diagnostikas** posms, nevis Warp 485 problēmas atrisinājums.
