@echo off
setlocal
cd /d "%~dp0"
py -3 "%~dp0tools\capture_mapinfo_early.py" --seconds 90
set "ret=%ERRORLEVEL%"
echo.
echo Stage M read-only capture exit code: %ret%
echo Results are in Downloads as Original-v291-Mapinfo-Early-*.zip
pause
exit /b %ret%
