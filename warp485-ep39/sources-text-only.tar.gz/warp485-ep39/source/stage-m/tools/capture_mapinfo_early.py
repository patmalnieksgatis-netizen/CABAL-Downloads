#!/usr/bin/env python3
"""One-shot, read-only early CABAL v291 mapinfo cache capture (WINDOWS x64 only).

With no PID: launch the pinned client ONCE if no other CabalMain.exe is running,
then poll only cache slot #28 from outside the process. With --pid: attach only.
No remote writes, no DLL injection, no hooks, no server actions, no process termination.
Writes only result ZIP/diagnostics under Downloads, never into game files.

A CAPTURED result is self-reported read-only memory evidence, not independent
attestation of the game's resource provenance or proof of a working patch.
"""
import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

PIN_EXE='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
PIN_ENC='88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc'
RVA=0xdd6430+28*16
SIZE=49102
INDEX=28
READ_RIGHTS=0x0410


def hashfile(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def check_xml(blob):
    if len(blob)!=SIZE or blob[-1]!=0:return False
    x=blob[:-1]
    if b'<!DOCTYPE' in x.upper() or b'<!ENTITY' in x.upper():return False
    try:
        x.decode('utf-8-sig')
        r=ET.fromstring(x)
        return r.tag=='cabal' and bool(r.findall('.//icon/icon_value/warp'))
    except (UnicodeDecodeError, ET.ParseError):return False


def windows_api():
    if sys.platform!='win32' or ctypes.sizeof(ctypes.c_void_p)!=8:
        raise RuntimeError('WINDOWS_X64_PYTHON_REQUIRED')
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    p=ctypes.WinDLL('psapi',use_last_error=True)
    k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    k.OpenProcess.restype=wintypes.HANDLE
    k.CloseHandle.argtypes=[wintypes.HANDLE]
    k.CloseHandle.restype=wintypes.BOOL
    k.ReadProcessMemory.argtypes=[wintypes.HANDLE,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_size_t)]
    k.ReadProcessMemory.restype=wintypes.BOOL
    k.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
    k.QueryFullProcessImageNameW.restype=wintypes.BOOL
    p.EnumProcessModulesEx.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.HMODULE),wintypes.DWORD,ctypes.POINTER(wintypes.DWORD),wintypes.DWORD]
    p.EnumProcessModulesEx.restype=wintypes.BOOL
    return k,p


def image_base(psapi,handle):
    arr=(wintypes.HMODULE*32)()
    needed=wintypes.DWORD()
    if not psapi.EnumProcessModulesEx(handle,arr,ctypes.sizeof(arr),ctypes.byref(needed),3) or needed.value<ctypes.sizeof(wintypes.HMODULE):
        return None
    return int(arr[0])


def read_mem(k,handle,address,length):
    if not (0x10000 <= address <= 0x7fffffffffff-length):return None
    b=ctypes.create_string_buffer(length)
    got=ctypes.c_size_t()
    ok=k.ReadProcessMemory(handle,ctypes.c_void_p(address),b,length,ctypes.byref(got))
    return b.raw if ok and got.value==length else None


def current_image_path(k,handle):
    buf=ctypes.create_unicode_buffer(32768)
    size=wintypes.DWORD(len(buf))
    if not k.QueryFullProcessImageNameW(handle,0,buf,ctypes.byref(size)):
        raise RuntimeError('CANNOT_VERIFY_CLIENT_IMAGE_PATH')
    return Path(buf.value)


def is_running():
    try:
        rows=subprocess.check_output(['tasklist','/FI','IMAGENAME eq CabalMain.exe','/FO','CSV','/NH'],
                                     text=True,encoding='mbcs',errors='replace',timeout=10)
    except Exception as exc:raise RuntimeError('RUNNING_PROCESS_CHECK_FAILED') from exc
    return any(line.lstrip().lower().startswith('"cabalmain.exe"') for line in rows.splitlines())


def capture(exe,enc,pid,timeout,dest):
    exe=exe.resolve(strict=True);enc=enc.resolve(strict=True)
    if hashfile(exe)!=PIN_EXE:raise RuntimeError('EXE_SHA256_MISMATCH_REFUSE_LAUNCH')
    if hashfile(enc)!=PIN_ENC:raise RuntimeError('ENC_SHA256_MISMATCH_REFUSE_CAPTURE')
    if enc.stat().st_size!=6808 or int.from_bytes(enc.read_bytes()[:4],'little')!=49101:
        raise RuntimeError('ENC_SIZE_OR_HEADER_MISMATCH')
    k,psapi=windows_api()
    mode='Attach' if pid else 'Launch'; started=datetime.now(timezone.utc).isoformat()
    child=None
    if pid is None:
        if is_running():raise RuntimeError('CLIENT_ALREADY_RUNNING_USE_ATTACH_MODE_OR_CLOSE_CLIENT_MANUALLY')
        child=subprocess.Popen([str(exe),'breaklee'],cwd=str(exe.parent))
        pid=child.pid
    handle=k.OpenProcess(READ_RIGHTS,False,pid)
    if not handle:raise RuntimeError('OPEN_PROCESS_READ_ONLY_FAILED_WINERR_'+str(ctypes.get_last_error()))
    report=dict(Status='FAILED',Mode=mode,OriginalClientSHA256=PIN_EXE,
        OriginalMapinfoSHA256=PIN_ENC,ProcessWrites=False,CodeHooks=False,ServerWrites=False,
        OriginalClientStarted=(mode=='Launch'),ExistingClientAttached=(mode=='Attach'),
        Index=None,Bytes=0,DecodedSHA256=None,ImageBase=None,ClientPID=pid,
        CacheSizeMatchedSlots=0,XmlCandidates=0,StartedUTC=started,
        FinishedUTC=None,Failure=None,UniqueNonzeroPointers=0,SlotReadFailures=0,
        PollCount=0,ObservedSize49102WithNullPointer=0)
    value=None;base=None;ptrs=set();deadline=time.monotonic()+timeout
    last_message=time.monotonic()
    try:
        if current_image_path(k,handle).resolve()!=exe:
            raise RuntimeError('WRONG_CLIENT_PATH_REFUSE_PROCESS_READ')
        while time.monotonic()<deadline:
            if child is not None and child.poll() is not None:
                raise RuntimeError('CLIENT_EXITED_BEFORE_RESOURCE_CAPTURE')
            if base is None:
                base=image_base(psapi,handle)
                if base is None:
                    time.sleep(0.002);continue
                report['ImageBase']='0x%X'%base
            record=read_mem(k,handle,base+RVA,16)
            report['PollCount']+=1
            if record is None:
                report['SlotReadFailures']+=1
                time.sleep(0.002);continue
            ptr,size,flags=struct.unpack('<QII',record)
            if size==SIZE and ptr==0:report['ObservedSize49102WithNullPointer']+=1
            if size==SIZE and ptr:
                ptrs.add(ptr);report['UniqueNonzeroPointers']=len(ptrs)
                report['CacheSizeMatchedSlots']=1
                data=read_mem(k,handle,ptr,SIZE)
                if data is not None and check_xml(data):
                    followup=read_mem(k,handle,ptr,SIZE)
                    rerecord=read_mem(k,handle,base+RVA,16)
                    if followup==data and rerecord==record:
                        value=data[:-1]
                        report['XmlCandidates']=1
                        report.update(Status='ORIGINAL_V291_MAPINFO_CAPTURED',Index=INDEX,
                          Bytes=len(value),DecodedSHA256=hashlib.sha256(value).hexdigest())
                        break
            now=time.monotonic()
            if now-last_message>=5:
                print('DIAGNOSTIC: elapsed=%ds polls=%d ptrs=%d size49102_null=%d' %
                    (int(timeout-(deadline-now)),report['PollCount'],len(ptrs),report['ObservedSize49102WithNullPointer']),flush=True)
                last_message=now
            time.sleep(0.001)
        if value is None:raise RuntimeError('MAPINFO_NOT_CAPTURED_DURING_WINDOW')
        # Confirm immutable inputs did not change during sampling.
        if hashfile(exe)!=PIN_EXE or hashfile(enc)!=PIN_ENC:
            value=None
            raise RuntimeError('PINNED_INPUT_CHANGED_DURING_CAPTURE')
    except Exception as exc:
        report['Status']='FAILED';report['Failure']=str(exc)
    finally:
        k.CloseHandle(handle)
        report['FinishedUTC']=datetime.now(timezone.utc).isoformat()
    # No overwrites, only Downloads artifacts. On error Report.json only.
    dest.mkdir(parents=True,exist_ok=True)
    suffix=datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+str(os.getpid())
    outfile=dest/('Original-v291-Mapinfo-Early-'+suffix+'.zip')
    with zipfile.ZipFile(outfile,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('Report.json',json.dumps(report,indent=2)+'\n')
        if value is not None:z.writestr('mapinfo.xml',value)
    print('STATUS='+report['Status'])
    if report['Failure']:print('REASON='+report['Failure'])
    print('ZIP='+str(outfile))
    print('CLIENT_PROCESS_TERMINATED_BY_TOOL=NO')
    return report['Status']=='ORIGINAL_V291_MAPINFO_CAPTURED'


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--exe',type=Path,default=Path(r'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe'))
    ap.add_argument('--mapinfo',type=Path,default=Path(r'F:\CABAL_291_TEST\Data\mapinfo.enc'))
    ap.add_argument('--pid',type=int,help='Attach to an already running client; do not launch')
    ap.add_argument('--seconds',type=int,default=90)
    ap.add_argument('--out-dir',type=Path,default=Path.home()/'Downloads')
    args=ap.parse_args()
    if not 5<=args.seconds<=180:ap.error('timeout must be 5..180 seconds')
    try:return 0 if capture(args.exe,args.mapinfo,args.pid,args.seconds,args.out_dir) else 2
    except Exception as exc:
        print('STOP='+str(exc),file=sys.stderr);return 1

if __name__=='__main__':sys.exit(main())
