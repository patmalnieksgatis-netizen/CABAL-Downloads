#!/usr/bin/env python3
"""Regression tests for direct loader audit and Stage M capture validation."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
SRC=HERE/'verify_loader_path.py'
CAP=HERE/'capture_mapinfo_early.py'
INPUT_EXE=Path('/mnt/data/CabalMain(20261118-202936).exe')
INPUT_ENC=Path('/mnt/data/cabal_sources/v291_enc_authentic')

def module(path,name):
    s=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m
v=module(SRC,'stage_m_v')
c=module(CAP,'stage_m_c')

class TestStageM(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exe=INPUT_EXE
        cls.enc=INPUT_ENC
        cls.result=v.audit(cls.exe,cls.enc)

    def test_verified_pinned_exe(self):self.assertEqual(self.result['verified_original_client_sha256'],v.PIN_EXE)
    def test_x64_pe(self):self.assertEqual(v.PE(self.exe.read_bytes()).sections[0]['name'],'.text')
    def test_key_is_in_binary(self):self.assertEqual(bytes(v.KEY_BYTES),bytes.fromhex('92656757'))
    def test_reader_bypasses_four_byte_length_prefix(self):
        self.assertIn('mapped_input_skips_4_byte_header',{s['label'] for s in self.result['verified_code_sites']})
    def test_call_chain_resource_filename_to_io(self):
        self.assertEqual(v.PE(self.exe.read_bytes()).call(0x14021cde6),0x1402178e0)
    def test_call_chain_file_io_to_deflate(self):
        self.assertEqual(v.PE(self.exe.read_bytes()).call(0x140217a17),0x1402b7fac)
    def test_call_chain_deflate_to_stream_read(self):
        self.assertEqual(v.PE(self.exe.read_bytes()).call(0x1402b7fc7),0x1402b8b08)
    def test_all_four_pinned_encoded(self):self.assertEqual(len(self.result['resource_results']),4)
    def test_four_first_blocks_reserved(self):
        self.assertTrue(all(row['deflate_first_block_type']==3 for row in self.result['resource_results']))
    def test_mapinfo_size_header(self):
        e=next(x for x in self.result['resource_results'] if x['file']=='mapinfo.enc')
        self.assertEqual((e['total_bytes'],e['declared_decoded_bytes']),(6808,49101))
    def test_pinned_exe_rejects_tampering(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'bad.exe'; b=bytearray(self.exe.read_bytes()); b[0]=0;out.write_bytes(b)
            with self.assertRaisesRegex(ValueError,'WRONG_CLIENT_EXE_SHA256'):v.audit(out,self.enc)
    def test_pinned_enc_rejects_tampering(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)
            for file in self.enc.iterdir():shutil.copy2(file,folder/file.name)
            path=folder/'mapinfo.enc';b=bytearray(path.read_bytes());b[5]^=1;path.write_bytes(b)
            with self.assertRaisesRegex(ValueError,'ORIGINAL_ENC_MISMATCH'):v.audit(self.exe,folder)
    def test_synthetic_xml_validation(self):
        prefix=b'<cabal><icon><icon_value><warp dungeon_index="0" target_world_index="8"/></icon_value></icon></cabal>'
        blob=prefix+(b' '*(49101-len(prefix)))+b'\0'
        self.assertTrue(c.check_xml(blob))
    def test_synthetic_bad_xml_validation(self):
        self.assertFalse(c.check_xml(b'bad'+b' '*(49101-3)+b'\0'))
    def test_report_safety_claims(self):
        self.assertFalse(self.result['client_patch_installable'])
        self.assertFalse(self.result['gameplay_tested'])
        self.assertTrue(self.result['alternative_resource_decoder_not_established'])

if __name__=='__main__':unittest.main(verbosity=2)
