#!/usr/bin/env python3
"""CABAL v291 pinned PE loader and ENC compatibility audit (offline, read-only).

Supplied EXE is never executed, rewritten, patched, nor included in output.
The audit proves only compatibility with the *specified direct reader path*;
other resource loading mechanisms may exist and are not ruled out.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

PIN_EXE='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
PIN_ENC={
    'mapinfo.enc':'88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc',
    'Warp.enc':'40ffd038a5e61fca8d9f91b52843d4edf074f61484189bf3bcce53f2787b0f70',
    'quest.enc':'c298999da93d3d1c3e415b1618efeda80362e7247945e26226090a29ee18ea3d',
    'LegacyTicket.enc':'8da583b0edceae83fad0db40c7f652d6b952c5a966b8ee3458f3b0ddad4b4dc4',
}
BASE=0x140000000
KEY_BYTES=[0x92,0x65,0x67,0x57]
CODE_SITES=[
    # address, contiguous bytes, label
    (0x1402b7af5,'41 0f b6 00 35 92 00 00 00','read_first_byte_xor_92'),
    (0x1402b7ae5,'41 0f b6 40 01 83 f0 65','read_second_byte_xor_65'),
    (0x1402b7ad5,'41 0f b6 40 02 83 f0 67','read_third_byte_xor_67'),
    (0x1402b7ac5,'41 0f b6 40 03 83 f0 57','read_fourth_byte_xor_57'),
    (0x1402179c7,'48 8d 48 04','mapped_input_skips_4_byte_header'),
    (0x1402179dc,'49 89 06','output_buffer_stored_to_cache_slot'),
    (0x14021bb59,'48 83 24 df 00','free_path_clears_pointer'),
]
CALLS={
    0x14021cde6:0x1402178e0,
    0x140217a17:0x1402b7fac,
    0x1402b7fc7:0x1402b8b08,
}


def sha(data):return hashlib.sha256(data).hexdigest()

class PE:
    def __init__(self,blob):
        self.blob=blob
        if blob[:2]!=b'MZ':raise ValueError('NOT_MZ')
        pe=struct.unpack_from('<I',blob,0x3c)[0]
        if blob[pe:pe+4]!=b'PE\0\0':raise ValueError('NOT_PE')
        num=struct.unpack_from('<H',blob,pe+6)[0]
        optsz=struct.unpack_from('<H',blob,pe+20)[0]
        opt=pe+24
        if struct.unpack_from('<H',blob,opt)[0]!=0x20b:raise ValueError('NOT_X64_PE')
        if struct.unpack_from('<Q',blob,opt+24)[0]!=BASE:raise ValueError('IMAGE_BASE_CHANGED')
        off=opt+optsz
        self.sections=[]
        for i in range(num):
            row=off+i*40
            size,rva,rawsz,rawptr=struct.unpack_from('<IIII',blob,row+8)
            self.sections.append({'name':blob[row:row+8].split(b'\x00')[0].decode('ascii'),'rva':rva,'size':size,'rawsz':rawsz,'rawptr':rawptr})
    def read(self,addr,size):
        rva=addr-BASE
        for s in self.sections:
            if s['name']=='.text' and s['rva']<=rva and rva+size<=s['rva']+s['rawsz']:
                at=s['rawptr']+(rva-s['rva'])
                if at+size<=len(self.blob):return self.blob[at:at+size]
        raise ValueError('NOT_FILE_BACKED_TEXT_RVA_'+hex(rva))
    def call(self,at):
        raw=self.read(at,5)
        if raw[0]!=0xe8:raise ValueError('EXPECTED_RELATIVE_CALL_'+hex(at))
        return at+5+struct.unpack_from('<i',raw,1)[0]


def audit(exe:Path,enc_dir:Path):
    blob=exe.read_bytes()
    if sha(blob)!=PIN_EXE:raise ValueError('WRONG_CLIENT_EXE_SHA256_'+sha(blob))
    pe=PE(blob)
    checked=[]
    for at,pattern,label in CODE_SITES:
        expected=bytes.fromhex(pattern)
        got=pe.read(at,len(expected))
        if got!=expected:raise ValueError(f'CODE_SIGNATURE_MISMATCH_{label}: {got.hex()}')
        checked.append({'site':hex(at),'label':label,'bytes':got.hex()})
    for at,target in CALLS.items():
        got=pe.call(at)
        if got!=target:raise ValueError(f'CALL_TARGET_MISMATCH_{hex(at)}_actual_{hex(got)}')
        checked.append({'site':hex(at),'label':'call_to_'+hex(target),'bytes':pe.read(at,5).hex()})
    enc=[]
    for name,pin in PIN_ENC.items():
        raw=(enc_dir/name).read_bytes()
        if sha(raw)!=pin:raise ValueError('ORIGINAL_ENC_MISMATCH_'+name)
        payload=raw[4:]
        b0=payload[0]^KEY_BYTES[0]
        btype=(b0>>1)&3
        enc.append({'file':name,'sha256':sha(raw),'total_bytes':len(raw),
            'declared_decoded_bytes':int.from_bytes(raw[:4],'little'),
            'encrypted_first_byte_hex':f'{payload[0]:02x}',
            'decoded_first_byte_under_direct_reader_hex':f'{b0:02x}',
            'deflate_first_block_type':btype,
            'direct_reader_valid_first_block_type':btype!=3})
    all_bad=all(not e['direct_reader_valid_first_block_type'] for e in enc)
    return {'status':'CONFIRMED_DIRECT_READER_PATH_INCOMPATIBILITY' if all_bad else 'MIXED_RESULTS',
      'verified_original_client_sha256':sha(blob),
      'scope':'The specific EXE direct mapping + 4-byte XOR + raw-DEFLATE loader, not every possible resource load path',
      'verified_code_sites':checked,'xor_key_hex':bytes(KEY_BYTES).hex(),
      'raw_deflate_btype_3_is_reserved':True,'resource_results':enc,
      'all_four_direct_reader_block_types_invalid':all_bad,
      'specific_direct_reader_xor_recovered':True, 'alternative_resource_decoder_not_established':True,
      'authentic_mapinfo_xml_recovered':False,
      'client_patch_installable':False,'gameplay_tested':False,
      'non_modification_guarantee':'Input PE and ENC are read-only; output is JSON only'}


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--exe',required=True,type=Path)
    ap.add_argument('--enc-dir',required=True,type=Path)
    ap.add_argument('--out',required=True,type=Path)
    a=ap.parse_args(argv)
    if a.out.exists():raise ValueError('REFUSE_OVERWRITE_OUTPUT')
    r=audit(a.exe,a.enc_dir)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(json.dumps({'status':r['status'],'all_four_direct_reader_block_types_invalid':r['all_four_direct_reader_block_types_invalid'],'output':str(a.out)}))
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:
        print('STOP='+str(e),file=sys.stderr);sys.exit(1)
