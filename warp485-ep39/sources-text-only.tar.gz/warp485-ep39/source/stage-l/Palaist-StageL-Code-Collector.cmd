@echo off
cd /d "%~dp0"
py -3 "%~dp0tools\collect_missing_codec.py"
if errorlevel 1 (
    echo.
    echo Nav veikta neviena CABAL faila izmaina.
)
pause
