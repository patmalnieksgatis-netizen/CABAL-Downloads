# CABAL v291 / EP39 — Stage L: cache lifecycle un trūkstošā dekodētāja koda ceļš

**Statuss: offline izmeklēšana, NAV instalējams Warp 485 labojums.** Ne klienta spēles faili, ne serveris, ne datubāzes nav mainīti. Gameplay tests nav veikts.

## Jauns tiešs koda atradums (salīdzinot ar Stage K)

Paša oriģinālā klienta SHA256 sasaistītajā koda izgriezumā `CacheReader_14021CDDB.bin`:

1. `0x14021BAF4` sākas selektīvas kešatmiņas attīrīšanas funkcija.
2. `0x14021BB08`: `movabs rcx,0x20000001004`, `0x14021BB12`: `bt rcx,rbx`, `0x14021BB16`: pārlēciens pār atbrīvošanu, ja bits ir uzstādīts.
3. Maskas uzstādītie bitu indeksi: **2, 12, 41**. Visi pārējie indeksi 0–136 nonāk atbrīvošanas ceļā, **ja šī funkcija tiek izsaukta**.
4. `0x14021BB1D` izsauc `0x14021BB38`, kurš pārbauda norādi, izsauc `free` un `0x14021BB59` izpilda `and qword ptr [rdi+rbx*8],0`, nullējot ieraksta pointeri. Blakus esošā izmēra vērtība šajā atbrīvošanas funkcijā netiek nullēta.
5. `mapinfo` ir indekss **28** (iepriekšējais Stage J faktiskais Windows novērojums: `ptr=0`, `size=49102`), un tas **nav** starp 2, 12, 41.

**Precīzs secinājums:** oriģinālā klienta kodā ir konkrēts ceļš, kas var likumīgi atbrīvot `mapinfo` datu pointeri, atstājot izmēru. Tas atbilst novērojumam. Šie statiskie pierādījumi **nenosaka**, vai konkrētais attīrīšanas izsaukums pirms Stage J Attach patiešām notika.

## Negatīvie dekodēšanas eksperimenti — ierobežoti, bet reproducējami

- Stage K jau pierādīja, ka `libcozip` standarta `92 65 67 57` neatsaiņo četrus oriģinālos ENC.
- Papildu pārbaude `tools/codec_shared_header_probe.cpp`: visām četrām ENC pārbaudīti visi `2^24` varianti kopīgiem atslēgas **1.–3. baitiem** hipotēzei “tikai pirmie 4 saspiestie baiti tiek XOR-oti ar vienu nemainīgu 4 baitu atslēgu un turpinājums ir raw DEFLATE ar dinamisku Huffman pirmo bloku”. Neviena varianta Huffman kodu garuma koku struktūra nav derīga visiem četriem failiem (`78016 -> 384 -> 0`). Šis nav tests pilnam patvaļīgam ENC algoritmam.
- `tools/codec_mapinfo_header_probe.cpp`: mapinfo gadījumā pēc dinamiskā koda garuma struktūras atlases pārbaudīti visi 256 pirmās atslēgas baiti katram derīgajam 1.–3. baitu variantam; **neviens** nesniedza derīgu raw-DEFLATE progresu (`zret_ok=0`). Šis tests aprobežots ar **dinamisko Huffman pirmo bloku** un četru sākuma baitu XOR modeli, nevis ar citiem šifrēšanas/kompresijas ceļiem.
- Rezultāts: nav pamata pieņemt, ka aizvietojams `.enc` ir korekti ģenerēts. **Neveikt** aizvietošanu ar references `mapinfo` vai neatbilstošu EP45 codec.

C++ reproducēšanai vajadzīgs C++17 kompilators un `zlib` izstrādes bibliotēka, piemēram, Linux: `g++ -O3 -std=c++17 tools/codec_shared_header_probe.cpp -o shared_probe` un analogi `tools/codec_mapinfo_header_probe.cpp -lz -o mapinfo_probe`. Rīkiem kā argumenti secībā jāiedod oriģinālie `.enc` faili (tie atrodas `reference/v291_DungeonEntrance.zip`). Šī reproducēšana NAV nepieciešama, lai lietotu Stage L pārskatu.

## Svarīgais trūkstošais koda fragments

Esošajā v291 `CacheReader_14021CDDB.bin` redzams:

- `0x14021CDA4` veic resursa faila iegūšanas apstrādi.
- `0x14021CDE6` izsauc `0x1402178E0`.
- Pati `0x1402178E0` funkcija **nav** nevienā no pieejamajiem iepriekšējiem izgriezumiem; nav pilnā, ar SHA apstiprinātā `CabalMain.exe` attēla.

`tools/collect_missing_codec.py` ir sagatavots tā, lai, **ja tas tiek palaists lokālajā Windows datorā ar oriģinālo EXE**, vienā reizē iegūtu vajadzīgās **statiskās** `.text` sadaļas ap `0x1402178E0`, `0x1400289A8`, `0x1402B7A90` un `0x14040E184`. Rīks nestrādā ar procesu, nesūta datus tīklā, neveic kodu injekciju, nepatcho EXE/ENC un neietekmē serveri. Tam ir stingra oriģinālā EXE SHA256 pārbaude. Pārbaudītajā izolētajā vidē pilnā EXE nav; tāpēc **šīs jaunās funkcijas koda saturu nevarēja izanalizēt**.

Windows autonomās iegūšanas saīsne: `Palaist-StageL-Code-Collector.cmd` (nepieciešams `py -3`; avota skripts pieejams pārbaudei). ZIP tiek izveidots `Downloads` mapē, nepārrakstot esošos failus. To nevajag palaist vēlreiz uz tukšiem Stage J kešatmiņas ierakstiem.

## Pārbaudes un ierobežojumi

- `tools/audit_lifecycle.py`: **12/12 statiskas integritātes/instrukciju pārbaudes PASS**.
- Atkārtots C++ modelis: rezultāti `evidence/*.txt`; tie nav veiksmīgs dekodējums.
- Reālā klienta `mapinfo` XML: **nav iegūts**.
- Darbojošs v291 encoder: **nav apstiprināts**.
- Instalējams `.enc` patch un rollback: **nav izveidots, jo trūkst verificēta codec**.
- `MainCmd(485)` spēles testi: **nav veikti**; servera/klienta stāvoklis netika mainīts.

## Izejas artefakti

- `reference/v291_Codec_Code_Sections.zip` — oriģinālā klienta iepriekš fiksētie četri koda fragmenti.
- `reference/v291_DungeonEntrance.zip` — četri autentiski oriģinālā v291 ENC faili.
- `tools/audit_lifecycle.py` + `evidence/lifecycle_report.json` — instrukciju un maskas verificēšana.
- `tools/codec_*_probe.cpp` + `evidence/*_probe.txt` — testētās dekodēšanas hipotēzes, precīzi nošķirtas no faktiskā codec.
- `tools/collect_missing_codec.py` un Windows CMD saīsne — **vēl nepieciešamā trūkstošā EXE koda ieguve** turpmākai offline analīzei.
