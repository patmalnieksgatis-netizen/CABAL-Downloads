#!/usr/bin/env python3
"""Read-only Stage L audit of pinned v291 x64 code excerpts.

Runs without the game, a server, Windows privileges or network connections.
It does not decode or patch ENC data and does not assert runtime call ordering.
"""
import hashlib, json, pathlib, struct, zipfile, sys
HERE=pathlib.Path(__file__).resolve().parent.parent
PINNED_EXE='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
MAPINFO_SHA='88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc'

def analyze(stagek_zip=None):
    stagek_zip = stagek_zip or HERE/'reference/v291_Codec_Code_Sections.zip'
    with zipfile.ZipFile(stagek_zip) as z:
        manifest=json.loads(z.read('manifest.json'))
        entry=next(x for x in manifest['extracted'] if x['file']=='CacheReader_14021CDDB.bin')
        blob=z.read(entry['file'])
        start=int(entry['virtual_address_start'],16)
        at=lambda address,n: blob[address-start:address-start+n]
        sha=lambda b: hashlib.sha256(b).hexdigest()
        evidence={
          'pinned_exe_manifest':manifest['client_sha256']==PINNED_EXE,
          'code_excerpt_sha256':sha(blob)==entry['sha256'],
          'resource_slots_0_through_136':at(0x14021BB24,6)==bytes.fromhex('81fb89000000'),
          'selective_cleanup_mask_instruction':at(0x14021BB08,10)==bytes.fromhex('48b90410000000020000'),
          'selective_cleanup_bit_test':at(0x14021BB12,4)==bytes.fromhex('480fa3d9'),
          'skip_free_if_retained':at(0x14021BB16,2)==bytes.fromhex('720a'),
          'free_call':at(0x14021BB1D,5)==bytes.fromhex('e816000000'),
          'pointer_null_after_free':at(0x14021BB59,5)==bytes.fromhex('488324df00'),
          'slot_size_16_bytes':at(0x14021BB8D,4)==bytes.fromhex('48c1e004'),
          'mapinfo_index_28_not_retained':((0x20000001004>>28)&1)==0,
        }
        mask=int.from_bytes(at(0x14021BB0A,8),'little')
    with zipfile.ZipFile(HERE/'reference/v291_DungeonEntrance.zip') as z:
        mapinfo=z.read('mapinfo.enc')
    evidence['authentic_mapinfo_sha256']=hashlib.sha256(mapinfo).hexdigest()==MAPINFO_SHA
    evidence['authentic_mapinfo_size_header']=int.from_bytes(mapinfo[:4],'little')==49101
    report={
      'result':'READ_ONLY_STATIC_ANALYSIS' if all(evidence.values()) else 'EVIDENCE_FAILED',
      'checks':evidence,
      'verified_count':sum(evidence.values()),
      'total_checks':len(evidence),
      'cache_retention_mask_hex':hex(mask),
      'retained_indices':[i for i in range(137) if i<=41 and mask>>i&1],
      'selective_cleanup_would_release_index_28':28 not in [i for i in range(137) if i<=41 and mask>>i&1],
      'runtime_cleanup_trigger_verified':False,
      'genuine_v291_enc_codec_verified':False,
      'installable_client_patch':False,
      'gameplay_tested':False,
      'client_or_server_modified':False,
    }
    return report

if __name__=='__main__':
    r=analyze();print(json.dumps(r,indent=2))
    sys.exit(0 if r['result']=='READ_ONLY_STATIC_ANALYSIS' else 2)
