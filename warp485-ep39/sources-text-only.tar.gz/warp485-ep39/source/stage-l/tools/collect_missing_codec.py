#!/usr/bin/env python3
"""Opt-in read-only extraction of missing CABAL v291 x64 loader code excerpts.

Requires a LOCAL verified original EXE. It creates a ZIP in Downloads and never
modifies or executes the original game executable, any ENC, process or server.
This is not a codec, patcher or game fix. No bytes are downloaded or transmitted.
"""
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import zipfile
from datetime import datetime, timezone

PIN='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
IMAGEBASE=0x140000000
TARGETS={
    'ResourceFileIO_1400289A8':(0x00024000,0x00012000),
    'ResourceDecoderMissing_1402178E0':(0x00212000,0x0000D000),
    'ResourceCompression_1402B7A90':(0x002B4000,0x0000A000),
    'ResourceDispatcher_14040E184':(0x0040A000,0x0000A000),
}

def parse_pe(blob):
    if blob[:2]!=b'MZ':raise ValueError('NOT_MZ')
    e_lfanew=struct.unpack_from('<I',blob,0x3c)[0]
    if e_lfanew>=len(blob)-264 or blob[e_lfanew:e_lfanew+4]!=b'PE\x00\x00':raise ValueError('NOT_PE')
    num=struct.unpack_from('<H',blob,e_lfanew+6)[0]
    sz=struct.unpack_from('<H',blob,e_lfanew+20)[0]
    opt=e_lfanew+24
    if struct.unpack_from('<H',blob,opt)[0]!=0x20b:raise ValueError('NOT_PE32PLUS')
    ib=struct.unpack_from('<Q',blob,opt+24)[0]
    if ib!=IMAGEBASE:raise ValueError('IMAGEBASE_MISMATCH')
    sections=[]
    for i in range(num):
        o=opt+sz+i*40
        if o+40>len(blob):raise ValueError('INVALID_SECTION_TABLE')
        name=blob[o:o+8].split(b'\x00')[0].decode('ascii','replace')
        vsize,rva,rsize,offset=struct.unpack_from('<IIII',blob,o+8)
        sections.append((name,rva,vsize,rsize,offset))
    return sections

def read_rva(blob,sections,rva,n):
    for name,base,vsize,raw_size,raw_ptr in sections:
        if name != '.text':continue
        if base<=rva and n>0 and rva+n<=base+raw_size:
            at=raw_ptr+rva-base
            if at+n<=len(blob):return blob[at:at+n]
    raise ValueError('NOT_FULLY_FILE_BACKED_TEXT_RVA_0x%X'%rva)

def collect(exe,out):
    if not exe.is_file():raise ValueError('ORIGINAL_EXE_NOT_FOUND')
    blob=exe.read_bytes()
    digest=hashlib.sha256(blob).hexdigest()
    if digest!=PIN:raise ValueError('ORIGINAL_EXE_SHA256_MISMATCH_'+digest)
    sections=parse_pe(blob)
    if out.exists():raise ValueError('OUTPUT_EXISTS_NO_OVERWRITE')
    out.parent.mkdir(parents=True,exist_ok=True)
    parts={name:read_rva(blob,sections,*coords) for name,coords in TARGETS.items()}
    entries=[]
    for name,payload in parts.items():
        rva,size=TARGETS[name]
        entries.append(dict(name=name+'.bin',rva_start=hex(rva),virtual_address_start=hex(IMAGEBASE+rva),
                            bytes=size,sha256=hashlib.sha256(payload).hexdigest()))
    manifest=dict(status='STATIC_CODE_EXCERPTS_ONLY_NOT_A_PATCH',original_sha256=digest,
                  source_is_pinned_original=True,read_only_input=True,game_changed=False,
                  generated_utc=datetime.now(timezone.utc).isoformat(),
                  parts=entries,not_included='Original full executable')
    with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,payload in parts.items():z.writestr(name+'.bin',payload)
        z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    return out

if __name__=='__main__':
    # Only run on the user's own pinned local client in an isolated directory.
    default_exe=Path(r'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe')
    destination=Path.home()/'Downloads'/('CABAL_v291_MissingCodecSects_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
    try:
        dst=collect(Path(sys.argv[1]) if len(sys.argv)>1 else default_exe,
                    Path(sys.argv[2]) if len(sys.argv)>2 else destination)
        print('STATIC_CODE_EXCERPTS_EXTRACTED='+str(dst))
        print('ORIGINAL_FILES_CHANGED=NO')
    except Exception as exc:
        print('STOP='+str(exc),file=sys.stderr)
        sys.exit(1)
