#include <array>
#include <vector>
#include <cstdio>
#include <cstdint>
#include <fstream>
#include <string>
#include <chrono>
#include <zlib.h>
#include <cstring>
using namespace std;
static constexpr unsigned char order[19]={16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
static bool clen(uint32_t k,const unsigned char *data){
 int hclen=4+(((data[1]^((k)&255))>>5)&7) + (((data[2]^((k>>8)&255))&1)<<3);
 int counts[8]={};
 for(int j=0;j<hclen;j++) {
    int bit=17+3*j; int byte=bit>>3; int s=bit&7;
    int a=data[byte], b=data[byte+1];
    if(byte==1)a^=(k)&255; else if(byte==2)a^=(k>>8)&255; else if(byte==3)a^=(k>>16)&255;
    if(byte+1==2)b^=(k>>8)&255; else if(byte+1==3)b^=(k>>16)&255;
    int l=((a|(b<<8))>>s)&7;counts[l]++;
 }
 int left=1;
 for(int i=1;i<=7;i++){left=2*left-counts[i];if(left<0)return false;}
 return left==0;
}
int main(int argc,char**argv){if(argc<2)return 1;ifstream file(argv[1],ios::binary); vector<uint8_t> all((istreambuf_iterator<char>(file)),{});vector<uint8_t> payload(all.begin()+4,all.end());
 unsigned long long valid=0, zret_ok=0, xml_ok=0; auto t0=chrono::steady_clock::now();
 // k maps bytes 1 2 3; test all possible byte0 XOR producing dynamic deflate block
 for(uint32_t k=0;k<0x1000000;k++){
  if(!clen(k,payload.data()))continue;valid++;
  auto b0=payload[0];auto b1=payload[1];auto b2=payload[2];auto b3=payload[3];
  payload[1]^=k&255;payload[2]^=(k>>8)&255;payload[3]^=(k>>16)&255;
  for(int k0=0;k0<256;k0++){
   uint8_t first=b0^k0;
   if(((first>>1)&3)!=2)continue;
   payload[0]=first;
   unsigned char out[200]={}; z_stream z{};z.next_in=payload.data();z.avail_in=payload.size();z.next_out=out;z.avail_out=sizeof(out);
   if(inflateInit2(&z,-15)!=Z_OK) continue;
   int ret=inflate(&z,Z_NO_FLUSH);inflateEnd(&z);
   if(ret==Z_OK||ret==Z_STREAM_END){zret_ok++;
     if(z.total_out>=5 && (memcmp(out,"<?xml",5)==0||memcmp(out,"<caba",5)==0)){
      printf("FOUND key %02x%02x%02x%02x zret=%d out=%lu: %.100s\n",k0,k&255,(k>>8)&255,(k>>16)&255,ret,z.total_out,out);fflush(stdout);xml_ok++;
     }
   }
  }
  payload[0]=b0;payload[1]=b1;payload[2]=b2;payload[3]=b3;
 }
 printf("valid_clen=%llu zret_ok=%llu xml_ok=%llu seconds=%.2f\n",valid,zret_ok,xml_ok,chrono::duration<double>(chrono::steady_clock::now()-t0).count());
}
