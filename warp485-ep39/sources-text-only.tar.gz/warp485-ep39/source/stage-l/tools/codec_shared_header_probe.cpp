#include <array>
#include <vector>
#include <cstdio>
#include <cstdint>
#include <fstream>
#include <string>
#include <algorithm>
#include <chrono>
using namespace std;
static constexpr unsigned char order[19]={16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
static unsigned char files[4][12];
static bool check_clen(uint32_t k, int idx) {
  // The HCLEN field occupies bits 13..16, inside bytes 1 and 2.
  // Byte 0 is irrelevant for dynamic-Huffman header structure.
  unsigned b1=files[idx][1] ^ (k&255);
  unsigned b2=files[idx][2] ^ ((k>>8)&255);
  int hclen=4 + ((b1>>5)&7) + ((b2&1)<<3);
  // The code-length table extends past bit 64; read two bytes per field.
  int counts[8]={};
  for(int j=0;j<hclen;j++) {
    int bit=17+3*j; int byte=bit>>3; int s=bit&7;
    int val = files[idx][byte]; if(byte==1)val^=(k&255); else if(byte==2) val^=(k>>8)&255; else if(byte==3)val^=(k>>16)&255;
    int nx=files[idx][byte+1]; if(byte+1==2)nx^=(k>>8)&255; else if(byte+1==3)nx^=(k>>16)&255;
    int l=((val | (nx<<8)) >> s) & 7;
    counts[l]++;
  }
  int left=1;
  for(int i=1;i<=7;i++) {left=left*2-counts[i]; if(left<0) return false; }
  return left==0;
}
int main(int argc,char**argv){if(argc!=5) return 1;for(int i=0;i<4;i++){ifstream f(argv[i+1],ios::binary); f.seekg(4); f.read((char*)files[i],12);}
 auto t0=chrono::steady_clock::now(); unsigned long long passes[4]={};
 vector<uint32_t> matches;
 for(uint32_t k=0;k<0x1000000;k++){
  if(!check_clen(k,0))continue;passes[0]++;
  if(!check_clen(k,1))continue;passes[1]++;
  if(!check_clen(k,2))continue;passes[2]++;
  if(!check_clen(k,3))continue;passes[3]++;
  matches.push_back(k);
 }
 printf("pass counts: %llu %llu %llu %llu, found %zu, sec=%f\n",passes[0],passes[1],passes[2],passes[3],matches.size(),chrono::duration<double>(chrono::steady_clock::now()-t0).count());
 for(auto k:matches) printf("k[1..3]=%02X %02X %02X\n",k&255,(k>>8)&255,(k>>16)&255);
}
