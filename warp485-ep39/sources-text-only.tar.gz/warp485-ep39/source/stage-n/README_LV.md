# CABAL v291 / EP39 — Warp 485, Stage N

**Statuss: offline izpēte + pilnīga, droši norobežota kandidāta sagatavošanas plūsma. Tas nav apstiprināts spēles labojums.**

## Pieņēmumu pārbaude

- Oriģinālais v291 `CabalMain.exe` SHA256 ir `52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9`.
- Oriģinālais `mapinfo.enc` SHA256 ir `88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc`.
- EXE `0x1402178E0 -> 0x1402B7FAC` ceļš atpako četrbaitu izmēra galveni, pēc tam izmanto raw DEFLATE bitu lasītāju, kas pirmajos četros saspiestajos baitos pielieto XOR `92 65 67 57`. Tas ir **viens identificēts dekodēšanas ceļš**, nevis pierādījums par visu resursu iespējamo ielādes loģiku.
- Visi četri saglabātie oriģinālie ENC, šim konkrētajam tiešajam dekoderam pielietojot norādīto XOR, sākas ar rezervēto DEFLATE `BTYPE=3`. Nevienu no šiem failiem ar to droši atkodēt nevar.
- Pilna atkārtota četru baitu XOR pārbaude visā plūsmā (tikai **dinamiska Huffman pirmā bloka modelī**) izmēģināja 64 derīgas pirmā baita vērtības un `16 777 216` atlikušo trīs baitu variantus katrai (kopā 1 073 741 824 konfigurācijas). Pēc pirmo 128 saspiesto baitu atkodēšanas **nav novērots** `<?xml` vai `<caba` prefikss. Tā **nav matemātiska visu iespējamo ENC algoritmu izslēgšana** — testēta tikai konkrētā XOR/DEFLATE hipotēze.
- `mapinfo` kešatmiņas 28. ierakstā konstatētais `size=49102`, `ptr=0` saskan ar tādu klienta koda ceļu, kur atmiņa tiek atbrīvota, neizdzēšot izmēru. Tas neparāda, vai XML faktiski tika veiksmīgi ielādēts un apstrādāts.
- **Kritiskā nezināmā daļa:** `World 8 / Warp 675` un `4378–4383` vērtības ir iegūtas no **cita klienta** references XML; oriģinālajā v291 XML tas vēl nav apstiprināts. Bez autentiskiem datiem **nedrīkst** apgalvot, ka tieši šis saraksts izraisa `MainCmd(485) invalid qdIdx(4380)`.

## Kas jauns Stage N

1. `tools/codec_default.py` — precīzs identificētā **tiešā** 4 XOR baitu + raw DEFLATE modeļa kodētājs un atkodētājs. Sintētiski roundtrip testi ir sekmīgi. Oriģinālie ENC **nav** ar šo modeli saderīgi. Tas **nav** verificēts oriģinālā klienta jaunā resursa kodētājs.
2. `tools/stage_n_prepare.py` — vienā piegājienā verificē EXE/oriģinālā ENC SHA, Stage M agrīnās nolasīšanas autentisko (pašdeklarētu) ZIP, iepriekšējā ClientPatch drošo mērķa XML izmaiņu un vēsturisko servera reģistru. Veido **eksperimentālu**, nevienā klientā automātiski neuzstādāmu XML un `.enc` kandidātu; glabā oriģināla `.enc` rezerves kopiju un atskaiti.
3. `tools/stage_n_one_shot_windows.py` un `Palaist-StageN-Vienaa-Reize.cmd` — **vienas palaišanas** Windows darbplūsma: agrīna klienta atmiņas nolasīšana → ja izdodas, automātiska pārbaude → eksperimentāla kandidāta sagatavošana. Ja nolasīšana neizdodas, beidz darbu ar kļūdas arhīvu un **neveido** patch. Nemaina klientu, serveri vai procesu atmiņu.
4. `tools/stage_n_isolated_install.py` — tikai **jau esošai izolētai klienta kopijai**, ar manuālu `--apply`/`--rollback` izvēli, failu SHA pārbaudi, backup un izmaiņu atteikumu, ja CABAL process Windows ir palaists. Nekad nav paredzēts izmantot uz `F:\CABAL_291_TEST`. Izolētā instalācija **nav** pārbaudīta Windows un nesniedz spēles saderības garantiju.
5. `tools/verify_loader_path.py` — no Stage M atkārtota pirmavota EXE/ENC statiskā pārbaude.
6. `tools/test_stage_n.py` — **17/17 PASS** Linux offline vidē, ietverot sintētisku `mapinfo` nolasījumu, mērķa XML izmaiņu, default ENC roundtrip un izolētās kopijas uzlikšanas/rollback simulāciju.

## Ja vajag Windows vienā reizē (izvēles darbība)

Šī darbība nav nepieciešama, lai pārskatītu Stage N izmeklēšanas rezultātus. Ja vēlies pamēģināt **vienu** agrīno nolasīšanu reālajā v291 Windows vidē, vispirms aizver spēles klientu, tad no izpakotās pakotnes palaid `Palaist-StageN-Vienaa-Reize.cmd`. Nepieciešams `py -3` (64 bitu Python 3). 

Ja nolasīšana izdosies, `Downloads\StageN_v291_*\experimental_candidate` saturēs tikai **eksperimentālo** `.enc`, kandidāta XML, vecā `.enc` kopiju un atskaiti. Neviens fails netiek automātiski ievietots CABAL spēles direktorijā. **Nekopē eksperimentālo `.enc` uz darba klientu.**

Ja nolasīšana neizdosies, instruments izveidos kļūdas ziņojumu un apstāsies. Bez cita iegūšanas mehānisma atkārtoti to pašu testu nav jēgas skaitīt par progresu.

## Izolēta laboratorijas kopija (ne darba klients)

Eksperimentālajam klienta kandidātam ir pieejama brīvprātīga izolētas kopijas uzlikšanas/atcelšanas komandrindas saskarne:

```powershell
py -3 tools\stage_n_isolated_install.py --isolated-root "F:\CABAL_291_LAB" --candidate-dir "C:\<StageN_output>\experimental_candidate" --apply
py -3 tools\stage_n_isolated_install.py --isolated-root "F:\CABAL_291_LAB" --candidate-dir "C:\<StageN_output>\experimental_candidate" --rollback
```

Tās ir **parauga komandas**, nevis prasība pašreiz tās izpildīt. Skripts pārbauda oriģinālā `mapinfo.enc` kontrolsummu kopijā, izveido `mapinfo.enc.stage_n_backup` un pieļauj atjaunošanu. Darba spēli šis rīks nedrīkst modificēt. Windows pašu uzstādīšanu/atjaunošanu šajā sesijā neveicām.

## Neatrisinātais jautājums

**Trūkst autentiskā oriģinālā v291 `mapinfo` dekodējuma vai cita pierādīta aktīvā resursa izcelsmes mehānisma.** Līdz tam nevar droši apstiprināt, vai kliens tieši izmanto references `Warp 675` izvēlni, vai paredzētais XML labojums novērsīs atvienošanu, un vai eksperimentāli kodētais `.enc` būs lietojams reālajā spēlē.

**Spēles tests:** nav veikts. **Servera izmaiņas:** nav. **Darba klienta izmaiņas:** nav. **Instalējams, verificēts Warp 485 labojums:** vēl nav.
