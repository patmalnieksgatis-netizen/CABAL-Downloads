@echo off
cd /d "%~dp0"
py -3 "%~dp0tools\stage_n_one_shot_windows.py"
set "stage_n_result=%ERRORLEVEL%"
echo.
echo StageN status code: %stage_n_result%
echo Active game files and server files were not changed by this run.
pause
exit /b %stage_n_result%
