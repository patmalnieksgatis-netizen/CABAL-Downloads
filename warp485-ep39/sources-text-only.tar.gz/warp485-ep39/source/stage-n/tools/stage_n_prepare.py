#!/usr/bin/env python3
"""Stage N: one-shot build of EXPERIMENTAL v291 mapinfo candidate (OFFLINE).

No local game files are modified. Requires authentic in-memory capture ZIP;
uses historical server registry. Does NOT claim installed/gameplay compatibility.
"""
from __future__ import annotations
import argparse, hashlib, json, shutil, sys, zipfile
from pathlib import Path
from codec_default import encode,decode,sha
from build_client_candidate import parse_and_patch
from validate_capture_and_audit import checked_capture, CLIENT_SHA, MAPINFO_ENC_SHA
from triple_join_audit import server_registries

def calculate(path: Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def prepare(*, exe:Path, original_enc:Path, capture:Path, registry:Path, outdir:Path):
    for p in (exe,original_enc,capture,registry):
        if not p.is_file():raise ValueError('INPUT_FILE_NOT_FOUND:'+str(p))
    if calculate(exe)!=CLIENT_SHA:raise ValueError('WRONG_EXE_SHA256')
    if calculate(original_enc)!=MAPINFO_ENC_SHA:raise ValueError('WRONG_ORIGINAL_ENC_SHA256')
    xml,rep=checked_capture(capture.read_bytes())
    if rep['Index']!=28:raise ValueError('UNEXPECTED_MAPINFO_CACHE_INDEX')
    registry_d,registry_w=server_registries(registry)
    patched,meta=parse_and_patch(xml,registry_d,registry_w,require_4380=True)
    encoded=encode(patched)
    if decode(encoded)!=patched:raise ValueError('CANDIDATE_ROUNDTRIP_FAILED')
    if outdir.exists():raise ValueError('OUTPUT_ALREADY_EXISTS_REFUSE_OVERWRITE')
    if any(outdir.resolve()==p.resolve() for p in (exe,original_enc,capture,registry)):
        raise ValueError('OUTPUT_EQUALS_INPUT')
    # Output is deliberately named 'experimental', never an automatic install.
    outdir.mkdir(parents=True)
    try:
        files={
            'mapinfo.original.capture.xml':xml,
            'mapinfo.experimental.candidate.xml':patched,
            'mapinfo.experimental.candidate.enc':encoded,
            'mapinfo.original.backup.enc':original_enc.read_bytes(),
        }
        for name,content in files.items():(outdir/name).write_bytes(content)
        report={
          'status':'EXPERIMENTAL_DEFAULT_CODEC_CANDIDATE_NOT_GAMEPLAY_VERIFIED',
          'input_original_exe_sha256':CLIENT_SHA,
          'input_original_enc_sha256':MAPINFO_ENC_SHA,
          'capture_decoded_sha256':sha(xml),
          'historical_registry_sha256':calculate(registry),
          'patch_metadata':meta,
          'model':'four_byte_xor_92_65_67_57_then_raw_deflate',
          'critical_limitations':[
            'Original v291 mapinfo.enc does NOT decode with this native path',
            'The native path may not be the actual runtime resource path',
            'Capture provenance is self-declared, not independently attested',
            'No game client or server file has been changed',
            'No actual Windows/gameplay validation has been performed'
          ],
          'artifact_sha256':{name:sha(content) for name,content in files.items()},
        }
        (outdir/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    except Exception:
        shutil.rmtree(outdir,ignore_errors=True);raise
    return report

def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--exe',required=True,type=Path)
    a.add_argument('--original-enc',required=True,type=Path)
    a.add_argument('--capture',required=True,type=Path)
    a.add_argument('--registry',type=Path,default=Path(__file__).parent.parent/'reference/server_registry_evidence.zip')
    a.add_argument('--out-dir',required=True,type=Path)
    arg=a.parse_args()
    try:
        r=prepare(exe=arg.exe,original_enc=arg.original_enc,capture=arg.capture,registry=arg.registry,outdir=arg.out_dir)
        print(json.dumps({'status':r['status'],'out_dir':str(arg.out_dir),'removed':r['patch_metadata']['removed']},ensure_ascii=False))
        return 0
    except Exception as exc:
        print('STOP='+str(exc),file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
