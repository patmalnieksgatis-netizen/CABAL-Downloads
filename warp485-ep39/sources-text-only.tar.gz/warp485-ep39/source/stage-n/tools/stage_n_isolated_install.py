#!/usr/bin/env python3
"""Guarded opt-in staging for an ALREADY CREATED isolated Windows client COPY.

Never touches F:\\CABAL_291_TEST. --apply is required. Rollback is built-in.
No game launch or server actions. Use ONLY for testing experimental candidates.
"""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
from codec_default import decode,sha
from validate_capture_and_audit import MAPINFO_ENC_SHA

ORIGINAL_ROOT=Path(r'F:\CABAL_291_TEST')

def safe_client_path(root:Path)->Path:
    root=root.resolve(strict=True)
    if os.name == 'nt':
        try:
            if os.path.normcase(str(root))==os.path.normcase(str(ORIGINAL_ROOT.resolve(strict=True))):
                raise ValueError('ACTIVE_CLIENT_ROOT_PROHIBITED')
        except FileNotFoundError:pass
    target=root/'Data'/'mapinfo.enc'
    if not target.is_file():raise ValueError('ISOLATED_CLIENT_MISSING_MAPINFO_ENC')
    if target.is_symlink():raise ValueError('SYMLINK_TARGET_REFUSED')
    src=ORIGINAL_ROOT/'Data'/'mapinfo.enc'
    if src.exists() and os.path.samefile(src,target):raise ValueError('ACTIVE_CLIENT_SAMEFILE_REFUSED')
    return target

def run(root:Path,candidate_dir:Path,apply:bool,rollback:bool):
    if apply==rollback:raise ValueError('CHOOSE_EXACTLY_ONE_OF_APPLY_OR_ROLLBACK')
    if os.name == 'nt':
        try:
            rows=subprocess.check_output(['tasklist','/FI','IMAGENAME eq CabalMain.exe','/FO','CSV','/NH'],
                          text=True,encoding='mbcs',errors='replace',timeout=10)
        except Exception as exc:
            raise ValueError('CANNOT_VERIFY_GAME_IS_CLOSED') from exc
        if any(row.lstrip().lower().startswith('"cabalmain.exe"') for row in rows.splitlines()):
            raise ValueError('CLOSE_ALL_CABAL_CLIENTS_BEFORE_ISOLATED_COPY_CHANGE')
    target=safe_client_path(root)
    if target.stat().st_size>8<<20:raise ValueError('TARGET_SIZE_UNEXPECTED')
    dest_dir=candidate_dir.resolve(strict=True)
    source=dest_dir/'mapinfo.experimental.candidate.enc'
    report=json.loads((dest_dir/'report.json').read_text(encoding='utf8'))
    if report.get('status')!='EXPERIMENTAL_DEFAULT_CODEC_CANDIDATE_NOT_GAMEPLAY_VERIFIED':
        raise ValueError('CANDIDATE_REPORT_STATUS_INVALID')
    if not source.is_file():raise ValueError('CANDIDATE_MISSING')
    data=source.read_bytes()
    if sha(data)!=report['artifact_sha256']['mapinfo.experimental.candidate.enc']:
        raise ValueError('EXPERIMENTAL_ENC_SHA256_MISMATCH')
    if sha(decode(data))!=report['artifact_sha256']['mapinfo.experimental.candidate.xml']:
        raise ValueError('CANDIDATE_ENC_ROUNDTRIP_INVALID')
    backup=target.with_suffix('.enc.stage_n_backup')
    if apply:
        if sha(target.read_bytes())!=MAPINFO_ENC_SHA:raise ValueError('ISOLATED_ORIGINAL_ENC_MISMATCH')
        if backup.exists():raise ValueError('BACKUP_EXISTS_REFUSE_OVERWRITE')
        shutil.copy2(target,backup)
        if sha(backup.read_bytes())!=MAPINFO_ENC_SHA:raise ValueError('BACKUP_FAILED')
        temp=target.with_name('mapinfo.enc.stage_n_tmp')
        if temp.exists():raise ValueError('TEMP_EXISTS_REFUSE_OVERWRITE')
        try:
            with temp.open('xb') as f:
                f.write(data);f.flush();os.fsync(f.fileno())
            os.replace(temp,target)
            if sha(target.read_bytes())!=sha(data):raise ValueError('INSTALLED_CONTENT_MISMATCH')
        except Exception:
            if temp.exists():temp.unlink()
            if backup.exists():shutil.copy2(backup,target)
            raise
        return 'ISOLATED_COPY_UPDATED_EXPERIMENTAL_ONLY'
    else:
        if not backup.exists() or sha(backup.read_bytes())!=MAPINFO_ENC_SHA:
            raise ValueError('VERIFIED_BACKUP_NOT_FOUND')
        if sha(target.read_bytes())!=sha(data):raise ValueError('TARGET_CHANGED_REFUSE_ROLLBACK')
        shutil.copy2(backup,target)
        if sha(target.read_bytes())!=MAPINFO_ENC_SHA:raise ValueError('ROLLBACK_HASH_MISMATCH')
        return 'ISOLATED_COPY_ROLLED_BACK'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--isolated-root',required=True,type=Path)
    p.add_argument('--candidate-dir',required=True,type=Path)
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--apply',action='store_true')
    group.add_argument('--rollback',action='store_true')
    a=p.parse_args()
    try:
        print(run(a.isolated_root,a.candidate_dir,a.apply,a.rollback));return 0
    except Exception as exc:print('STOP='+str(exc),file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
