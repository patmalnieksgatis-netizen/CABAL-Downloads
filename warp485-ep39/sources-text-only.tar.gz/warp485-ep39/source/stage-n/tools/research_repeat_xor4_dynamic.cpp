#include <cstdio>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <vector>
#include <chrono>
#include <zlib.h>
using namespace std;
vector<uint8_t> input,trial;
const int payloadLen=6804;
inline bool test(uint32_t key){
  uint8_t k[4]={(uint8_t)key,(uint8_t)(key>>8),(uint8_t)(key>>16),(uint8_t)(key>>24)};
  auto d=input.data();uint8_t b0=d[0]^k[0],b1=d[1]^k[1],b2=d[2]^k[2];
  if(((b0>>1)&3)!=2)return false;
  int n=4+((b1>>5)&7)+((b2&1)<<3);
  int counts[8]={};
  for(int j=0;j<n;j++){
   int bit=17+3*j, by=bit>>3, sh=bit&7;
   unsigned v=(d[by]^k[by&3]) | ((unsigned)(d[by+1]^k[(by+1)&3])<<8);
   counts[(v>>sh)&7]++;
  }
  int left=1;for(int i=1;i<=7;i++){left=2*left-counts[i];if(left<0)return false;}return left==0;
}
int main(int argc,char**argv){
 if(argc!=3)return 1;
 ifstream f(argv[1],ios::binary);vector<uint8_t> all((istreambuf_iterator<char>(f)),{});input.assign(all.begin()+4,all.end()); trial=input;
 int k0=(int)strtol(argv[2],nullptr,16);
 auto start=chrono::steady_clock::now();uint32_t valid=0, zret_ok=0;
 for(uint32_t k123=0;k123<0x1000000;k123++){
  uint32_t key=k0|(k123<<8);if(!test(key))continue;valid++;
  uint8_t k[]={ (uint8_t)key,(uint8_t)(key>>8),(uint8_t)(key>>16),(uint8_t)(key>>24)};
  for(size_t i=0;i<min((size_t)128,trial.size());i++)trial[i]=input[i]^k[i%4];
  z_stream z{};unsigned char out[200]={};z.next_in=trial.data();z.avail_in=128;z.next_out=out;z.avail_out=sizeof(out);
  if(inflateInit2(&z,-15)!=Z_OK)continue;
  int ret=inflate(&z,Z_NO_FLUSH);inflateEnd(&z);
  if(ret==Z_OK || ret==Z_STREAM_END){zret_ok++;
   if(z.total_out>=5 && (memcmp(out,"<?xml",5)==0 || memcmp(out,"<caba",5)==0)) printf("POSSIBLE key=%08X  %.55s ret=%d total=%lu\n",key,out,ret,z.total_out);
  }
 }
 printf("first-key=%02X clen_valid=%u inflate_ok=%u elapsed=%.3f\n",k0,valid,zret_ok,chrono::duration<double>(chrono::steady_clock::now()-start).count());
}
