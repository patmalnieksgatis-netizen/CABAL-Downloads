#!/usr/bin/env python3
"""Offline deterministic tests, including synthetic capture/patch/rollback."""
from __future__ import annotations
import hashlib,io,json,os,sys,tempfile,unittest,zipfile
from pathlib import Path
from codec_default import encode,decode,sha
from stage_n_prepare import prepare
from stage_n_isolated_install import run
from validate_capture_and_audit import checked_capture,CLIENT_SHA,MAPINFO_ENC_SHA
from build_client_candidate import parse_and_patch
from triple_join_audit import server_registries

BASE=Path(__file__).resolve().parent.parent
REG=BASE/'reference/server_registry_evidence.zip'
ORIGINAL=Path('/mnt/data/cabal_sources/v291_enc_authentic/mapinfo.enc')
EXE=Path('/mnt/data/CabalMain(20261118-202936).exe')

def fixture():
    head=b'<?xml version="1.0" encoding="utf-8"?>\n<cabal>\n<icon world_id="8"><icon_value warp_index="675">\n'
    rows=(b'<warp order="0" dungeon_index="4352" target_world_index="138"/>\n'
          b'<warp order="1" dungeon_index="4378" target_world_index="166"/>\n'
          b'<warp order="2" dungeon_index="4380" target_world_index="174"/>\n'
          b'</icon_value></icon>\n')
    tail=b'</cabal>\n'
    pad=49101-len(head)-len(rows)-len(tail)
    assert pad>=0
    return head+rows+(b' '*pad)+tail

def capture_bytes(content):
    report={'Status':'ORIGINAL_V291_MAPINFO_CAPTURED','OriginalClientSHA256':CLIENT_SHA,
      'OriginalMapinfoSHA256':MAPINFO_ENC_SHA,'DecodedSHA256':sha(content),
      'Bytes':49101,'ProcessWrites':False,'CodeHooks':False,'ServerWrites':False,
      'Mode':'Attach','OriginalClientStarted':False,'ExistingClientAttached':True,
      'ClientPID':12345,'CacheSizeMatchedSlots':1,'XmlCandidates':1,'Index':28,
      'ImageBase':'0x140000000'}
    with io.BytesIO() as f:
        with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('Report.json',json.dumps(report))
            z.writestr('mapinfo.xml',content)
        return f.getvalue()

class StageNTests(unittest.TestCase):
    def test_01_native_codec_roundtrip(self):
        for data in (b'<cabal/>',b'<?xml version="1.0"?><cabal>hello</cabal>',bytes(range(256))*40):
            self.assertEqual(decode(encode(data)),data)
    def test_02_header_length(self):
        a=encode(b'<cabal/>');self.assertEqual(int.from_bytes(a[:4],'little'),8)
    def test_03_encoded_first_btype(self):
        a=encode(b'<cabal>test</cabal>'*400)
        self.assertNotEqual((a[4]>>1)&3, ( (a[4]^0x92)>>1 )&3)
    def test_04_reject_tampered_length(self):
        a=bytearray(encode(b'<cabal/>'));a[:4]=(99999).to_bytes(4,'little')
        with self.assertRaises(ValueError): decode(bytes(a))
    def test_05_reject_fake_enc(self):
        with self.assertRaises(ValueError):decode(b'deadbeef')
    def test_06_xml_length(self):self.assertEqual(len(fixture()),49101)
    def test_07_capture_contract(self):self.assertEqual(checked_capture(capture_bytes(fixture()))[0],fixture())
    def test_08_reject_failed_capture(self):
        z=capture_bytes(fixture())
        with zipfile.ZipFile(io.BytesIO(z)) as arc:
            report=json.loads(arc.read('Report.json'));content=arc.read('mapinfo.xml')
        report['Status']='FAILED'
        with io.BytesIO() as f:
            with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED) as zz:zz.writestr('Report.json',json.dumps(report));zz.writestr('mapinfo.xml',content)
            with self.assertRaises(ValueError):checked_capture(f.getvalue())
    def test_09_registry_contract(self):
        d,w=server_registries(REG)
        self.assertIn(4352,d);self.assertNotIn(4380,d);self.assertEqual(w[675],8)
    def test_10_patch_removes_invalid(self):
        d,w=server_registries(REG);out,meta=parse_and_patch(fixture(),d,w)
        self.assertIn(b'dungeon_index="4352"',out)
        self.assertNotIn(b'dungeon_index="4380"',out)
        self.assertNotIn(b'dungeon_index="4378"',out)
        self.assertEqual({x['dungeon_id'] for x in meta['removed']},{4380,4378})
    def test_11_patch_not_replacing_unrelated_bytes(self):
        d,w=server_registries(REG);out,_=parse_and_patch(fixture(),d,w)
        self.assertTrue(out.startswith(b'<?xml version="1.0"'))
        self.assertTrue(out.endswith(b'</cabal>\n'))
    def test_12_reject_missing_world(self):
        d,w=server_registries(REG)
        with self.assertRaises(ValueError):parse_and_patch(fixture(),d,{},require_4380=True)
    def test_13_unavailable_authentic_enc_not_default_compatible(self):
        if ORIGINAL.is_file():
            self.assertEqual(sha(ORIGINAL.read_bytes()),MAPINFO_ENC_SHA)
            with self.assertRaises(ValueError):decode(ORIGINAL.read_bytes())
    @unittest.skipUnless(EXE.is_file() and ORIGINAL.is_file(),'requires session originals')
    def test_14_prepare_on_synthetic_contract(self):
        with tempfile.TemporaryDirectory() as t:
            base=Path(t);cap=base/'fake.zip';cap.write_bytes(capture_bytes(fixture()))
            r=prepare(exe=EXE,original_enc=ORIGINAL,capture=cap,registry=REG,outdir=base/'out')
            self.assertEqual(r['status'],'EXPERIMENTAL_DEFAULT_CODEC_CANDIDATE_NOT_GAMEPLAY_VERIFIED')
            self.assertTrue((base/'out'/'mapinfo.experimental.candidate.enc').is_file())
    @unittest.skipUnless(EXE.is_file() and ORIGINAL.is_file(),'requires session originals')
    def test_15_reject_overwrite_output(self):
        with tempfile.TemporaryDirectory() as t:
            base=Path(t);cap=base/'cap.zip';cap.write_bytes(capture_bytes(fixture()))
            with self.assertRaises(ValueError):prepare(exe=EXE,original_enc=ORIGINAL,capture=cap,registry=REG,outdir=base)
    @unittest.skipUnless(EXE.is_file() and ORIGINAL.is_file(),'requires session originals')
    def test_16_guarded_isolated_apply_rollback(self):
        with tempfile.TemporaryDirectory() as t:
            b=Path(t);cap=b/'capture.zip';cap.write_bytes(capture_bytes(fixture()))
            prepare(exe=EXE,original_enc=ORIGINAL,capture=cap,registry=REG,outdir=b/'candidate')
            target=b/'cloned'/'Data'/'mapinfo.enc';target.parent.mkdir(parents=True);target.write_bytes(ORIGINAL.read_bytes())
            a=run(b/'cloned',b/'candidate',apply=True,rollback=False)
            self.assertIn('UPDATED',a);self.assertNotEqual(sha(target.read_bytes()),MAPINFO_ENC_SHA)
            self.assertTrue(target.with_suffix('.enc.stage_n_backup').is_file())
            a=run(b/'cloned',b/'candidate',apply=False,rollback=True)
            self.assertIn('ROLLED_BACK',a);self.assertEqual(sha(target.read_bytes()),MAPINFO_ENC_SHA)
    @unittest.skipUnless(EXE.is_file() and ORIGINAL.is_file(),'requires session originals')
    def test_17_reject_wrong_exe(self):
        with tempfile.TemporaryDirectory() as t:
            b=Path(t);bad=b/'wrong.exe';bad.write_bytes(b'not-v291')
            cap=b/'cap.zip';cap.write_bytes(capture_bytes(fixture()))
            with self.assertRaises(ValueError):prepare(exe=bad,original_enc=ORIGINAL,capture=cap,registry=REG,outdir=b/'out')

if __name__=='__main__': unittest.main(verbosity=2)
