#!/usr/bin/env python3
"""One Windows launch attempt, then automatically validate/patch/encode offline.

No user follow-up commands, no DLL injection, no active client/server edits.
Does NOT install resulting experimental ENC. Fails closed on capture failure.
"""
from __future__ import annotations
import argparse,datetime,json,sys
from pathlib import Path
from capture_mapinfo_early import capture
from stage_n_prepare import prepare
from validate_capture_and_audit import CLIENT_SHA,MAPINFO_ENC_SHA

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--exe',type=Path,default=Path(r'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe'))
    ap.add_argument('--mapinfo',type=Path,default=Path(r'F:\CABAL_291_TEST\Data\mapinfo.enc'))
    ap.add_argument('--capture-seconds',type=int,default=90)
    ap.add_argument('--out-root',type=Path,default=Path.home()/'Downloads')
    a=ap.parse_args()
    if not 5<=a.capture_seconds<=180:ap.error('capture-seconds must be 5..180')
    unique='StageN_v291_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    folder=a.out_root/unique
    if folder.exists():raise RuntimeError('OUTPUT_EXISTS')
    folder.mkdir(parents=True)
    ok=False
    try:
        print('STEP=EARLY_READ_ONLY_CAPTURE',flush=True)
        ok=capture(a.exe,a.mapinfo,None,a.capture_seconds,folder/'captures')
        archives=list((folder/'captures').glob('Original-v291-Mapinfo-Early-*.zip'))
        if len(archives)!=1:raise RuntimeError('CAPTURE_ARCHIVE_AMBIGUOUS')
        if not ok:
            print('STATUS=FAILED_CLOSED_NO_PATCH_PREPARED',flush=True)
            print('DETAIL=See '+str(archives[0]),flush=True)
            return 2
        print('STEP=VALIDATE_AND_BUILD_EXPERIMENTAL_CANDIDATE',flush=True)
        out=folder/'experimental_candidate'
        report=prepare(exe=a.exe,original_enc=a.mapinfo,capture=archives[0],
             registry=Path(__file__).parent.parent/'reference/server_registry_evidence.zip',outdir=out)
        print('STATUS='+report['status'])
        print('OUTPUT='+str(out))
        print('CLIENT_FILES_CHANGED=NO')
        print('SERVER_FILES_CHANGED=NO')
        return 0
    except Exception as exc:
        print('STOP='+str(exc),file=sys.stderr)
        print('CLIENT_FILES_CHANGED=NO',flush=True)
        return 2
if __name__=='__main__':sys.exit(main())
