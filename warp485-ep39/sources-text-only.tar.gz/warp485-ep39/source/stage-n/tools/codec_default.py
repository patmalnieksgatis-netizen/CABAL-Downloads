#!/usr/bin/env python3
"""CABAL x64 EXE's statically inspected four-byte XOR + raw DEFLATE path.

IMPORTANT: The *supplied original v291 ENC files do NOT decode with this path*.
This module only models that code path for synthetic roundtrips and produces
EXPERIMENTAL candidates, not a verified replacement for the running client.
"""
from __future__ import annotations
import hashlib, struct, zlib
KEY = bytes.fromhex('92 65 67 57')
MAX_XML = 4 * 1024 * 1024

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def decode(encoded: bytes) -> bytes:
    if len(encoded) < 10:
        raise ValueError('ENC_TOO_SHORT')
    expected, = struct.unpack_from('<I', encoded)
    if expected == 0 or expected > MAX_XML:
        raise ValueError('ENC_SIZE_OUT_OF_BOUNDS')
    payload = bytearray(encoded[4:])
    for i in range(min(4, len(payload))):
        payload[i] ^= KEY[i]
    unpacker = zlib.decompressobj(-15)
    try:
        decoded = unpacker.decompress(payload, MAX_XML+1)
        decoded += unpacker.flush()
    except zlib.error as exc:
        raise ValueError('ENC_NOT_VALID_FOR_DEFAULT_DECODER') from exc
    if not unpacker.eof or unpacker.unused_data or unpacker.unconsumed_tail:
        raise ValueError('ENC_DEFLATE_STREAM_INCOMPLETE_OR_TRAILING')
    if len(decoded) != expected:
        raise ValueError('ENC_UNPACKED_LENGTH_MISMATCH')
    return decoded

def encode(plain: bytes, *, level: int = 9) -> bytes:
    if not 0 < len(plain) <= MAX_XML:
        raise ValueError('XML_LENGTH_OUT_OF_BOUNDS')
    compressor = zlib.compressobj(level=level, wbits=-15)
    stream = bytearray(compressor.compress(plain) + compressor.flush())
    if len(stream) < 4:
        raise ValueError('COMPRESSED_STREAM_TOO_SHORT')
    for i in range(4):
        stream[i] ^= KEY[i]
    result = struct.pack('<I',len(plain)) + stream
    if decode(result) != plain:
        raise ValueError('CODEC_ROUNDTRIP_FAILED')
    return result
