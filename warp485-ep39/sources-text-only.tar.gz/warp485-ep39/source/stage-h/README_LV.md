# CABAL v291 / Warp485 — H posms: oriģinālā mapinfo kešatmiņas nolasītājs

## Kāpēc šī metode

Vecie XOR/DEFLATE minējumi neļāva atkodēt oriģinālo 6 808 baitu `mapinfo.enc`. Taču klienta oriģinālais ielādētājs **pats** atkodē spēles resursus. Iepriekš projekta GitHub sagatavots `Client291-DecodedDefinitions-Collector` to jau izmanto quest/AnimaMastery resursiem. H posms šo principu paplašina `mapinfo` gadījumam, **bez nepieejama resursa indeksa minēšanas**.

### Bināro instrukciju pierādījumi

- `CacheReader_14021CDDB.bin`, RVA bāze `0x21ADDB`; instrukcija pie `0x14021BB6C`: `cmp edx, 0x88` nosaka derīgos indeksus **0–136**.
- Kešatmiņas izkārtojums: `Main+0xDD6430 + index * 16`; iepriekšējā projekta resursu nolasītāja līgums.
- Oriģinālā `mapinfo.enc` pirmais DWORD: `49101` (atkodētais garums); fails 6 808 baiti, SHA256 `88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc`.
- V291 aktīvā klienta fiksētā faila SHA256: `52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9`.
- Četras kontrolsummas uz oriģināliem `CacheReader` un `CacheOwner` kodiem sakrīt ar iepriekš sagatavoto reāla klienta collector manifestu. Šeit nav patvaļīgu nopatch adresu.

### Rīks

`Mapinfo291CacheReader.cs` veic **tikai `ReadProcessMemory` un `VirtualQueryEx`**. Pēc oriģinālā klienta `breaklee` palaišanas tas pārbauda native koda parakstus, un **tikai zināmā kešatmiņas masīvā** skenē ierakstus ar garumu 49102. Reālam kandidātam papildus pārbauda `\0` terminatoru, XML sakni `<cabal>`, `</cabal>` noslēgumu, `warp_index` / `dungeon_index` pazīmes, identiskas atkārtotas atmiņas nolasīšanas un nemainīgu resursa ierakstu.

Ja ir vairāki kandidāti, kods apstājas, neizvēloties uz minējumu pamata. Ja `mapinfo` netiek ielādēts `breaklee` režīmā, atgriež neveiksmes statusu, **nevis viltotu XML**. Izvade `Downloads/Original-v291-Mapinfo-....zip`. Autentiski atkodētais fails būtu `mapinfo.xml`; to varētu izmantot jau izveidotajā G posma servera/triple-join auditā.

### Statuss un ierobežojumi

- Rīks ir **sagatavots bezsaistē**. **Windows darbība nav verificēta; īsts `mapinfo.xml` pagaidām nav iegūts.**
- Netiek izmantota SSH piekļuve vai pārveidoti servera procesi/SQL/dungeon faili.
- Netiek mainīti klienta faili, procesu atmiņa, iestatījumi, hooks vai vērtības; netiek prasīta konta parole.
- Palaišana pati var iedarbināt sākotnējā klienta dabisko startēšanās uzvedību. Skripts nedod login komandas.
- Rīks netiek izpildīts automātiski; tas ir tikai sagatavots kandidāts.
- C# kods un PowerShell darbs nav pārbaudāms šajā Linux vidē ar Windows API, tādēļ lietojams tikai kā izmeklēšanas kandidāts.

### Nākamais, ja oriģinālais XML tiek iegūts

1. Pārbaudīt oriģinālos `World 8 / Warp 675` dungeonu ID un vai tie patiešām satur `4380`.
2. Izmantot G posma trīskāršo sasaisti, nepārnesot atsauces `mapinfo` kā klienta labojumu.
3. Tikai tad izvēlēties klienta resource/bridge saderības labojumu (vai īstu servera dungeon reģistrācijas portu).

**Šī pakotne pati neatrisina atvienošanu.** Nav instalējamā patch, rollback nav nepieciešams, jo nekas nav uzstādīts.
