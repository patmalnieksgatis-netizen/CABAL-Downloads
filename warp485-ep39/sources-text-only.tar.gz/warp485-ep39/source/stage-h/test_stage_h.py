"""Offline evidence and contract tests, not native Windows execution tests."""
import hashlib
import re
import unittest
import zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent
DATA = Path('/mnt/data')
PLAIN = 49101


def sha(x): return hashlib.sha256(x).hexdigest()


def model_find(slots):
    """Mirror cache candidate filters (does not access a process)."""
    winner = None
    for i in range(137):
        pair = slots.get(i)
        if not pair: continue
        record, candidate, second, after = pair
        if record.get('length') != PLAIN + 1 or not record.get('pointer'): continue
        if len(candidate) != PLAIN + 1 or candidate[PLAIN] != 0: continue
        bom = 3 if candidate[:3] == b'\xef\xbb\xbf' else 0
        if not re.match(rb'^\s*(?:<\?xml[^>]*>\s*)?(?:<!--[\s\S]*?-->\s*)*<cabal(?:\s|>)',candidate[bom:bom+8192]):continue
        if not candidate[:PLAIN].rstrip(b'\0 \r\n\t').endswith(b'</cabal>'):continue
        if any(x not in candidate[:PLAIN] for x in [b'<warp',b'dungeon_index',b'warp_index']):continue
        if candidate!=second or record!=after:continue
        if winner is not None:raise ValueError('AMBIGUOUS_MAPINFO_MULTIPLE_CACHE_RECORDS')
        winner=i
    return winner


def fixture():
    head=b'<cabal><icon><icon_value warp_index="675"><warp dungeon_index="4380" /></icon_value></icon>'
    tail=b'</cabal>'
    middle=b' '*(PLAIN-len(head)-len(tail))
    return head+middle+tail+b'\0'


def slot(b=None,length=PLAIN+1,pointer=0x12345678,after=None,second=None):
    b=b if b is not None else fixture()
    record={'length':length,'pointer':pointer}
    return (record,b,b if second is None else second,record if after is None else after)


class StageHTests(unittest.TestCase):
    def test_native_cache_bound(self):
        z=zipfile.ZipFile(DATA/'v291_Codec_Code_Sections.zip')
        b=z.read('CacheReader_14021CDDB.bin')
        off=0x14021bb6c-0x14021addb
        self.assertEqual(b[off:off+6],bytes.fromhex('81 fa 88 00 00 00'))
    def test_four_pinned_code_signatures(self):
        z=zipfile.ZipFile(DATA/'v291_Codec_Code_Sections.zip')
        cache=z.read('CacheReader_14021CDDB.bin');owner=z.read('CacheOwner_14026927A.bin')
        e=[(cache,0x14021cddb-0x14021addb,17,'bfe3d4f0b0724a715057165f62afbd21d98489c3b40a69db4341bdeedfff3975'),
           (owner,0x2000,12,'c9b2b475fccc65d7143ce8cb3a096312c78d9a47db302de0880894119addfc04'),
           (cache,0x14021c18a-0x14021addb,34,'c9664dadf86f03431da8212867ba39938c37dcb453c3a33e92c0afd14d816101'),
           (cache,0x14021ca86-0x14021addb,14,'79080a5f6616f8579cc0254a52b886aef8d8b85537b7583c41a3e025ca630289')]
        for data,pos,size,expected in e:
            with self.subTest(pos=pos):self.assertEqual(sha(data[pos:pos+size]),expected)
    def test_original_encrypted_mapinfo(self):
        with zipfile.ZipFile(DATA/'CABAL_v291_Warp485_StageD_Offline/original_v291_enc.zip') as z:b=z.read('mapinfo.enc')
        self.assertEqual(len(b),6808)
        self.assertEqual(int.from_bytes(b[:4],'little'),PLAIN)
        self.assertEqual(sha(b),'88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc')
    def test_fixture_shape(self):self.assertEqual(len(fixture()),PLAIN+1)
    def test_detect_first(self):self.assertEqual(model_find({0:slot()}),0)
    def test_detect_last(self):self.assertEqual(model_find({136:slot()}),136)
    def test_outside_native_bound_not_scanned(self):self.assertIsNone(model_find({137:slot()}))
    def test_ambiguous_rejected(self):
        with self.assertRaisesRegex(ValueError,'AMBIGUOUS'):model_find({0:slot(),136:slot()})
    def test_plain_size_not_finished(self):self.assertIsNone(model_find({0:slot(length=PLAIN)}))
    def test_missing_pointer(self):self.assertIsNone(model_find({0:slot(pointer=0)}))
    def test_trailing_nonzero(self):
        b=fixture()[:-1]+b'!';self.assertIsNone(model_find({0:slot(b=b)}))
    def test_wrong_root(self):
        b=fixture().replace(b'<cabal>',b'<other>')
        self.assertIsNone(model_find({0:slot(b=b)}))
    def test_missing_warp_token(self):
        b=fixture().replace(b'warp_index',b'xxxx_index')
        self.assertIsNone(model_find({0:slot(b=b)}))
    def test_mutated_second_read(self):
        b=fixture();self.assertIsNone(model_find({0:slot(second=b[:-1]+b'!')}))
    def test_mutated_record(self):
        self.assertIsNone(model_find({0:slot(after={'length':PLAIN+1,'pointer':999})}))
    def test_no_process_write_apis(self):
        c=(ROOT/'Mapinfo291CacheReader.cs').read_text()
        ps=(ROOT/'Collect-Original-v291-Mapinfo.ps1').read_text()
        for bad in ('WriteProcessMemory','VirtualProtectEx','CreateRemoteThread','VirtualAllocEx','DllImport("ws2_32','SSH ', 'sqlcmd'):
            self.assertNotIn(bad,c)
        for bad in ('docker exec','ssh root','Set-ItemProperty','Start.bat'):
            self.assertNotIn(bad,ps)
        self.assertIn('ReadProcessMemory',c)
    def test_inspect_only_default(self):
        ps=(ROOT/'Collect-Original-v291-Mapinfo.ps1').read_text()
        self.assertIn("[string]$Action='Inspect'",ps)
        self.assertIn("if($Action -eq 'Inspect')",ps)

if __name__ == '__main__':unittest.main(verbosity=2)
