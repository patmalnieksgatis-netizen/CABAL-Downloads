// CABAL v291 original resource-cache reader. STRICTLY READ-ONLY process access.
// This library imports only the Windows process-read and virtual-query APIs.
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;

public static class Mapinfo291CacheReader {
    const long Main = 0x140000000L;
    const long CacheTable = Main + 0xDD6430L;
    const int CacheEntries = 137;  // native cmp edx,0x88 (indices 0 through 136)
    const int MapinfoBytes = 49101; // from original mapinfo.enc size header
    const int MapinfoAllocated = MapinfoBytes + 1;

    [StructLayout(LayoutKind.Sequential)] struct Region {
        public IntPtr Base, AllocationBase; public uint AllocationProtect;
        public ushort Partition, Padding; public UIntPtr Size; public uint State, Protect, Type;
    }
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr p, IntPtr at, [Out] byte[] data, UIntPtr n, out UIntPtr got);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern UIntPtr VirtualQueryEx(IntPtr p, IntPtr at, out Region r, UIntPtr n);
    static void Need(bool c, string why) { if(!c) throw new InvalidOperationException(why); }
    static string Hex(byte[] d) { using (var h=SHA256.Create()) return BitConverter.ToString(h.ComputeHash(d)).Replace("-","").ToLowerInvariant(); }
    static byte[] Read(IntPtr process,long address,int length) {
        Need(address>=65536L && address<=0x7fffffffffffL-length && length>0 && length<=MapinfoAllocated,
             "READ_OUTSIDE_BOUNDS");
        long end=address+length, pos=address;
        while(pos<end) {
            Region r;
            Need(VirtualQueryEx(process,new IntPtr(pos),out r,new UIntPtr(48)).ToUInt64()==48,
                "UNREADABLE_PAGE");
            long next=checked(r.Base.ToInt64()+(long)r.Size.ToUInt64());
            Need(r.State==0x1000 && (r.Protect&0x101)==0 && r.Base.ToInt64()<=pos && next>pos,
                "UNREADABLE_PAGE");
            pos=Math.Min(end,next);
        }
        byte[] result=new byte[length]; UIntPtr got;
        if(!ReadProcessMemory(process,new IntPtr(address),result,new UIntPtr((uint)length),out got))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        Need(got.ToUInt64()==(ulong)length,"PARTIAL_PROCESS_READ");
        return result;
    }
    static bool Equal(byte[] a, byte[] b) {
        if(a.Length!=b.Length) return false;
        for(int i=0;i<a.Length;i++) if(a[i]!=b[i]) return false;
        return true;
    }
    public static void VerifyOriginalClientCode(IntPtr handle) {
        Need(Read(handle,Main,2)[0]=='M' && Read(handle,Main,2)[1]=='Z',"NOT_ORIGINAL_PE_BASE");
        Need(Hex(Read(handle,Main+0x21CDDB,17))==
            "bfe3d4f0b0724a715057165f62afbd21d98489c3b40a69db4341bdeedfff3975", "CLIENT_LOADER_MISMATCH");
        Need(Hex(Read(handle,Main+0x26927A,12))==
            "c9b2b475fccc65d7143ce8cb3a096312c78d9a47db302de0880894119addfc04", "CACHE_OWNER_MISMATCH");
        Need(Hex(Read(handle,Main+0x21C18A,34))==
            "c9664dadf86f03431da8212867ba39938c37dcb453c3a33e92c0afd14d816101", "FILENAME_SWITCH_MISMATCH");
        Need(Hex(Read(handle,Main+0x21CA86,14))==
            "79080a5f6616f8579cc0254a52b886aef8d8b85537b7583c41a3e025ca630289", "FILENAME_SWITCH_MISMATCH");
        Need(Equal(Read(handle,Main+0x21BB6C,6),new byte[]{0x81,0xfa,0x88,0,0,0}),"RESOURCE_INDEX_BOUND_MISMATCH");
    }
    public sealed class Result {
        public string Status, Hash, Root;
        public int Index, ByteLength, SizeMatchedSlots, XmlCandidates;
        public byte[] Data;
    }
    public static Result FindOriginalDecodedMapinfo(IntPtr process) {
        var r=new Result {Status="NOT_LOADED",Index=-1,ByteLength=0};
        byte[] matched=null; int idx=-1;
        for(int i=0;i<CacheEntries;i++) {
            long slot=CacheTable+i*16L;
            byte[] record=Read(process,slot,16);
            long ptr=BitConverter.ToInt64(record,0);
            uint size=BitConverter.ToUInt32(record,8);
            if(size!=MapinfoAllocated || ptr==0) continue;
            r.SizeMatchedSlots++;
            byte[] candidate;
            try { candidate=Read(process,ptr,MapinfoAllocated); }
            catch(Win32Exception) { continue; }
            catch(InvalidOperationException) { continue; }
            if(candidate[MapinfoBytes]!=0) continue;
            int bom=candidate[0]==0xef && candidate[1]==0xbb && candidate[2]==0xbf?3:0;
            string prefix=Encoding.UTF8.GetString(candidate,bom,Math.Min(MapinfoBytes-bom,8192));
            if(!Regex.IsMatch(prefix,@"^\s*(?:<\?xml[^>]*>\s*)?(?:<!--[\s\S]*?-->\s*)*<cabal(?:\s|>)",RegexOptions.CultureInvariant)) continue;
            string end=Encoding.UTF8.GetString(candidate,Math.Max(0,MapinfoBytes-4096),Math.Min(4096,MapinfoBytes)).TrimEnd('\0',' ','\r','\n','\t');
            if(!end.EndsWith("</cabal>",StringComparison.Ordinal)) continue;
            string complete=Encoding.UTF8.GetString(candidate,0,MapinfoBytes);
            if(!complete.Contains("<warp") || !complete.Contains("dungeon_index") || !complete.Contains("warp_index")) continue;
            r.XmlCandidates++;
            byte[] second=Read(process,ptr,MapinfoAllocated),after=Read(process,slot,16);
            if(!Equal(candidate,second) || !Equal(record,after)) continue;
            if(idx>=0) throw new InvalidOperationException("AMBIGUOUS_MAPINFO_MULTIPLE_CACHE_RECORDS");
            idx=i; matched=candidate;
        }
        if(matched==null) return r;
        byte[] data=new byte[MapinfoBytes]; Array.Copy(matched,data,MapinfoBytes);
        r.Status="STABLE_ORIGINAL_V291_DECODED_MAPINFO";r.Index=idx;r.ByteLength=MapinfoBytes;
        r.Hash=Hex(data);r.Root="cabal";r.Data=data;
        return r;
    }
}
