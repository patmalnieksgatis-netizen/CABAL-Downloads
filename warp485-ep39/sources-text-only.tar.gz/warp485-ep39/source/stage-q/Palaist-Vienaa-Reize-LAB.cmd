@echo off
cd /d "%~dp0"
py -3 stageq_lab.py --prepare-launch
if errorlevel 1 (
  echo STAGE Q STOP. Klients un serveris nav mainiti; skaties kludas tekstu.
  pause
  exit /b 1
)
echo LAB klients ir palaists. Spele pasai ir japarbauda Warp komanda.
pause
