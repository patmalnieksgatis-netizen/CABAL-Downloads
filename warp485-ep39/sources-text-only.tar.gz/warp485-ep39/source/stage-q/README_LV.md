# CABAL v291 / EP39 — Stage Q: viena palaišana LAB pārbaudei

**Statuss: instalējams laboratorijas kandidāts, nevis spēlē pierādīts Warp 485 labojums.**

## Kas ir gatavs

- Pārbaudīts uz īstā `CabalMain.exe` SHA256 `52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9`.
- Stage P 80-baitu sūtītāja funkcijas izmaiņa tikai šajā klienta izsūtīšanas ceļā nepieļauj `qdIdx=4380` `MainCmd(485)` paketes izsūtīšanu. Tā nepadara dungeon 4380 derīgu.
- Sagatavots **Stage Q klonētājs** `stageq_lab.py`, kas izveido visu atsevišķo `F:\CABAL_291_LAB` no `F:\CABAL_291_TEST`, salīdzina klienta un oriģinālā `mapinfo.enc` SHA, pārbauda pieejamo diska vietu, tad instalē Stage P izmaiņu **tikai LAB** un atver LAB spēli ar `breaklee` argumentu.
- Tas atsakās pieskarties darba `F:\CABAL_291_TEST`, atsakās, ja LAB mape jau eksistē, ja klients ir palaists, ja source EXE neatbilst sākotnējam SHA, ja nav pietiekami daudz brīvas vietas vai ir simboliskās saites/junctions. Serveri, Docker un SQL neizmanto.
- Pirms EXE labošanas LAB tiek saglabāta `.stagep_original.bak` un pārbaudīta tās SHA. Rollback atjauno EXE tikai LAB kopijā; pārējā LAB kopija paliek.
- Izveido `F:\CABAL_291_LAB\_STAGEQ_LAB_REPORT.json` ar statusu, hash un informāciju. Reāla spēles pārbaude netiek automātiski uzskatīta par PASS.

## Lietošana

1. **Aizver CABAL klientu** (visus `CabalMain.exe` procesus). Serveri vari atstāt ieslēgtu.
2. Izpako šo ZIP `Downloads` mapē (jebkurā mapē ar rakstīšanas tiesībām), un **vienu reizi** palaid `Palaist-Vienaa-Reize-LAB.cmd`.
3. Skripts izveidos **pilnu kopiju**; lielam klientam tas prasa tikpat daudz papildu diska vietas, cik oriģinālā instalācija. Tas attiecas tikai uz laboratorijas klientu, nevis OVA/VM disku. Ja `F:\CABAL_291_LAB` jau eksistē, skripts **nepārrakstīs to**.
4. Ja instalēšana izdodas, atveras LAB `CabalMain.exe` un pārbaudei jāizmanto tieši tas pats Warp, kas iepriekš nosūtīja `qdIdx=4380`. Tas ir vienīgais tests, kas pierāda vai neapstiprina atvienošanās labojumu.
5. `Palaist-Parbaudit-LAB.cmd` pārbauda LAB patch un backup SHA. `Palaist-Atcelt-LAB.cmd` pēc klienta aizvēršanas atgriež oriģinālo LAB EXE. Nekādi citi klienta faili netiek aizvietoti.

### Svarīgas robežas

- Atkārtots mēģinājums uz jau eksistējošu LAB tiek noraidīts; tas **nav** automātisks turpinājums pēc nepabeigtas kopēšanas.
- Šo kandidātu nevar uzskatīt par derīgu citiem `qdIdx`, citiem 485 sūtītājiem vai dungeon izveidei. Vēsturiskā servera `[MD]` konfigurācijā nav pierādītas pilnas 4380 definīcijas.
- Modificētam EXE var nederēt digitālais paraksts, un klienta integritātes pārbaude var neļaut to startēt.
- Offline testu rezultāts **27/27 PASS**: Stage P 20 sākotnējie testi + Stage Q 7 pārbaudes ar īstā EXE izolētām kopijām. Windows/spēles/WorldSvr testu šajā vidē nav.

## Tiešā Python komandrinda

```
py -3 stageq_lab.py --prepare-launch
py -3 stageq_lab.py --verify
py -3 stageq_lab.py --rollback
```

**Atceries:** šajā ZIP **nav pilnā CABAL klienta**, bet gan skripti, kas izveido un aizsargā LAB kopiju uz tava datora. Neizpildi `guard485.py` ar aktīvā darba klienta ceļu.
