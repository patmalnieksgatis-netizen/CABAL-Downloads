#!/usr/bin/env python3
"""Safe laboratory copy + Stage P exact 4380 guard for original CABAL v291 client.

No server/SQL access; never modifies F:\\CABAL_291_TEST.
A complete LAB client is required to run the game. Refuses junctions/symlinks.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

import guard485 as guard

DEFAULT_SOURCE = Path(r'F:\CABAL_291_TEST')
DEFAULT_LAB = Path(r'F:\CABAL_291_LAB')
PATCHED_SHA = 'ef4fd980520d52d6ede0785d5de42d7ed90045acfe56c2f86be89c6e317869d1'
MAPINFO_SHA = '88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc'
REPORT_NAME = '_STAGEQ_LAB_REPORT.json'


def sha_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1024*1024),b''):
            h.update(part)
    return h.hexdigest()


def assert_normal(path: Path):
    if path.is_symlink():
        raise ValueError('SYMLINK_REFUSED: '+str(path))
    if os.name=='nt' and path.exists():
        st=path.stat(follow_symlinks=False)
        if getattr(st,'st_file_attributes',0) & 0x400:
            raise ValueError('REPARSE_POINT_REFUSED: '+str(path))


def scan_source(source: Path):
    file_count=0; byte_count=0
    for directory,dirs,files in os.walk(source, topdown=True, followlinks=False):
        assert_normal(Path(directory))
        for name in dirs:
            assert_normal(Path(directory)/name)
        for name in files:
            file=Path(directory)/name
            assert_normal(file)
            if not file.is_file():
                raise ValueError('UNSUPPORTED_SOURCE_ITEM: '+str(file))
            file_count+=1; byte_count+=file.stat().st_size
    if file_count < 2 or byte_count < 15_000_000:
        raise ValueError('SOURCE_CLIENT_TREE_INCOMPLETE')
    return file_count, byte_count


def validate_paths(source: Path, lab: Path, lab_may_exist: bool):
    if source.name.upper() != 'CABAL_291_TEST' or lab.name.upper() != 'CABAL_291_LAB':
        raise ValueError('EXPECTED_EXACT_TEST_AND_LAB_DIRECTORY_NAMES')
    if source.parent.resolve() != lab.parent.resolve():
        raise ValueError('SOURCE_LAB_DIFFERENT_PARENT_DRIVES')
    if not source.is_dir():
        raise ValueError('SOURCE_DIRECTORY_MISSING')
    for path in (source,source.parent,source/'Bin',source/'Bin'/'x64'):
        assert_normal(path)
    assert_normal(lab)
    if lab.exists() and not lab_may_exist:
        raise ValueError('LAB_ALREADY_EXISTS_REFUSE_OVERWRITE')
    src_exe=source/'Bin'/'x64'/'CabalMain.exe'
    if not src_exe.is_file() or sha_file(src_exe)!=guard.EXE_SHA:
        raise ValueError('SOURCE_EXE_PIN_MISMATCH')
    source_map=source/'Data'/'mapinfo.enc'
    if not source_map.is_file() or sha_file(source_map)!=MAPINFO_SHA:
        raise ValueError('SOURCE_MAPINFO_PIN_MISMATCH')
    return src_exe


def atomic_report(path: Path, obj: dict):
    path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf8',dir=str(path.parent),prefix='.stageq-',suffix='.json',delete=False) as f:
        tmp=Path(f.name)
        json.dump(obj,f,indent=2,ensure_ascii=False)
        f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)


def prepare(source: Path, lab: Path, launch: bool=False, min_headroom: int=512*1024*1024) -> dict:
    src_exe=validate_paths(source,lab,False)
    guard.no_running_game()
    files,total=scan_source(source)
    free=shutil.disk_usage(source.parent).free
    if free < total+min_headroom:
        raise ValueError('INSUFFICIENT_FREE_SPACE: need='+str(total+min_headroom)+' free='+str(free))
    # Confirm full source hash before any copy, then create a fresh-only clone.
    original_hash=sha_file(src_exe)
    print('LAB_CLONE_START: files=%d bytes=%d' % (files,total), flush=True)
    progress_files=0
    progress_bytes=0
    last_report=time.monotonic()
    def copy_with_progress(src, dst):
        nonlocal progress_files, progress_bytes, last_report
        result=shutil.copy2(src,dst)
        progress_files+=1
        progress_bytes+=os.stat(src,follow_symlinks=False).st_size
        if time.monotonic()-last_report > 7:
            print('LAB_CLONE_PROGRESS: files=%d/%d bytes=%d/%d' %
                  (progress_files,files,progress_bytes,total),flush=True)
            last_report=time.monotonic()
        return result
    shutil.copytree(source,lab,symlinks=False,copy_function=copy_with_progress)
    print('LAB_CLONE_COMPLETE: files=%d bytes=%d' % (progress_files,progress_bytes),flush=True)
    lab_exe=lab/'Bin'/'x64'/'CabalMain.exe'
    if sha_file(lab_exe)!=original_hash:
        raise ValueError('COPIED_EXE_SHA_MISMATCH')
    result=guard.run_lab(lab,'apply')
    if sha_file(lab_exe)!=PATCHED_SHA:
        raise ValueError('PATCHED_EXE_SHA_MISMATCH')
    if sha_file(src_exe)!=guard.EXE_SHA:
        raise ValueError('SOURCE_EXE_WAS_CHANGED')
    # This is a binary sender guard only; NEVER alter either client's mapinfo.enc.
    source_map=source/'Data'/'mapinfo.enc'
    lab_map=lab/'Data'/'mapinfo.enc'
    if source_map.is_file():
        if not lab_map.is_file() or sha_file(source_map)!=sha_file(lab_map):
            raise ValueError('ORIGINAL_MAPINFO_CHANGED_DURING_CLONE')
    report={
        'status':'LAB_GUARD_READY_NOT_GAMEPLAY_VERIFIED',
        'date_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'source_exe_sha256_unchanged':guard.EXE_SHA,
        'source_mapinfo_sha256_unchanged':MAPINFO_SHA,
        'lab_patched_exe_sha256':PATCHED_SHA,
        'copied_files':files,'copied_bytes':total,
        'worldsvr_modified':False,'databases_modified':False,
        'blocked_qdidx_in_one_client_callback_only':4380,
        'test_gameplay_completed':False,
        'rollback':'Palaist-Atcelt-LAB.cmd',
        'stagep':result
    }
    atomic_report(lab/REPORT_NAME,report)
    if launch:
        # The launch itself is not a gameplay verification. Standard v291 argument.
        game=subprocess.Popen([str(lab_exe),'breaklee'],cwd=str(lab_exe.parent),close_fds=True)
        report['lab_client_started_pid']=game.pid
        report['status']='LAB_CLIENT_LAUNCHED_NOT_GAMEPLAY_VERIFIED'
        atomic_report(lab/REPORT_NAME,report)
    return report


def verify(source: Path, lab: Path) -> dict:
    validate_paths(source,lab,True)
    guard.verify_lab_root(lab)
    lab_exe=lab/'Bin'/'x64'/'CabalMain.exe'
    got=sha_file(lab_exe)
    bak=lab_exe.with_suffix('.exe.stagep_original.bak')
    old=sha_file(bak) if bak.is_file() else 'MISSING'
    if got!=PATCHED_SHA or old!=guard.EXE_SHA:
        raise ValueError('LAB_PATCH_OR_BACKUP_SHA_MISMATCH: '+got+' '+old)
    return {'status':'LAB_FILE_HASHES_VERIFIED_NOT_GAMEPLAY_VERIFIED',
            'lab_exe_sha256':got,'rollback_backup_sha256':old,
            'source_exe_sha256':guard.EXE_SHA}


def rollback(source: Path, lab: Path)->dict:
    validate_paths(source,lab,True)
    result=guard.run_lab(lab,'rollback')
    if sha_file(source/'Bin'/'x64'/'CabalMain.exe') != guard.EXE_SHA:
        raise ValueError('SOURCE_CHANGED_AFTER_ROLLBACK')
    report={**result, 'status':'LAB_GUARD_ROLLED_BACK',
            'date_utc':dt.datetime.now(dt.timezone.utc).isoformat()}
    atomic_report(lab/REPORT_NAME,report)
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    g=parser.add_mutually_exclusive_group(required=True)
    g.add_argument('--prepare',action='store_true')
    g.add_argument('--prepare-launch',action='store_true')
    g.add_argument('--verify',action='store_true')
    g.add_argument('--rollback',action='store_true')
    parser.add_argument('--source',type=Path,default=DEFAULT_SOURCE)
    parser.add_argument('--lab',type=Path,default=DEFAULT_LAB)
    a=parser.parse_args()
    try:
        if a.prepare or a.prepare_launch:
            r=prepare(a.source,a.lab,launch=a.prepare_launch)
        elif a.verify:
            r=verify(a.source,a.lab)
        else:
            r=rollback(a.source,a.lab)
        print(json.dumps(r,indent=2,ensure_ascii=False));return 0
    except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired) as err:
        print('STAGE_Q_STOP:',str(err),file=sys.stderr)
        return 2


if __name__=='__main__':
    sys.exit(main())
