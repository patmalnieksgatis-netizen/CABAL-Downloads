@echo off
cd /d "%~dp0"
py -3 stageq_lab.py --rollback
pause
