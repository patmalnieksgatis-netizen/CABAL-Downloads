"""Offline-only test of LAB preparation. Source executable is read, never modified."""
import os
import tempfile
import unittest
from pathlib import Path
import stageq_lab as q
import guard485 as guard

ORIGINAL=Path(os.environ.get('CABAL_V291_ORIGINAL_EXE',r'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe'))
ORIGINAL_MAPINFO=Path(os.environ.get('CABAL_V291_ORIGINAL_MAPINFO',r'F:\CABAL_291_TEST\Data\mapinfo.enc'))


class StageQLab(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.source=Path(self.t.name)/'CABAL_291_TEST'
        self.lab=Path(self.t.name)/'CABAL_291_LAB'
        self.exe=self.source/'Bin'/'x64'/'CabalMain.exe'
        self.exe.parent.mkdir(parents=True)
        self.exe.write_bytes(ORIGINAL.read_bytes())
        (self.source/'Data').mkdir()
        (self.source/'Data'/'dummy_asset').write_bytes(b'CABAL data placeholder for lab-copy test')
        (self.source/'Data'/'mapinfo.enc').write_bytes(ORIGINAL_MAPINFO.read_bytes())
        self.src_hash=q.sha_file(self.exe)
    def test_01_original_source_preserved(self):
        rep=q.prepare(self.source,self.lab,min_headroom=0)
        self.assertEqual(rep['status'],'LAB_GUARD_READY_NOT_GAMEPLAY_VERIFIED')
        self.assertEqual(q.sha_file(self.exe),self.src_hash)
        self.assertEqual((self.lab/'Data'/'dummy_asset').read_bytes(),b'CABAL data placeholder for lab-copy test')
        self.assertEqual(q.sha_file(self.lab/'Bin'/'x64'/'CabalMain.exe'),q.PATCHED_SHA)
    def test_02_verify_rollback(self):
        q.prepare(self.source,self.lab,min_headroom=0)
        self.assertEqual(q.verify(self.source,self.lab)['status'],'LAB_FILE_HASHES_VERIFIED_NOT_GAMEPLAY_VERIFIED')
        self.assertEqual(q.rollback(self.source,self.lab)['status'],'LAB_GUARD_ROLLED_BACK')
        self.assertEqual(q.sha_file(self.lab/'Bin'/'x64'/'CabalMain.exe'),guard.EXE_SHA)
        self.assertEqual(q.sha_file(self.exe),guard.EXE_SHA)
    def test_03_refuse_existing_lab(self):
        self.lab.mkdir()
        with self.assertRaisesRegex(ValueError,'ALREADY_EXISTS'):
            q.prepare(self.source,self.lab,min_headroom=0)
        self.assertEqual(q.sha_file(self.exe),guard.EXE_SHA)
    def test_04_refuse_wrong_source_hash(self):
        with self.exe.open('r+b') as f:
            f.seek(100); f.write(b'X')
        with self.assertRaisesRegex(ValueError,'PIN_MISMATCH'):
            q.prepare(self.source,self.lab,min_headroom=0)
        self.assertFalse(self.lab.exists())
    def test_05_refuse_insufficient_space(self):
        with self.assertRaisesRegex(ValueError,'INSUFFICIENT_FREE_SPACE'):
            q.prepare(self.source,self.lab,min_headroom=2**63)
        self.assertFalse(self.lab.exists())
    def test_06_refuse_symlink_asset(self):
        link=self.source/'Data'/'link'
        try: link.symlink_to(self.exe)
        except OSError: self.skipTest('symlinks not supported')
        with self.assertRaisesRegex(ValueError,'SYMLINK_REFUSED'):
            q.prepare(self.source,self.lab,min_headroom=0)
    def test_07_detect_patch_tampering(self):
        q.prepare(self.source,self.lab,min_headroom=0)
        patched=self.lab/'Bin'/'x64'/'CabalMain.exe'
        with patched.open('r+b') as f:
            f.seek(120);f.write(b'X')
        with self.assertRaisesRegex(ValueError,'LAB_PATCH_OR_BACKUP_SHA_MISMATCH'):
            q.verify(self.source,self.lab)
        with self.assertRaisesRegex(ValueError,'CURRENT_LAB_BINARY_DIFFERS'):
            q.rollback(self.source,self.lab)
        self.assertEqual(q.sha_file(self.exe),guard.EXE_SHA)

if __name__=='__main__':unittest.main(verbosity=2)
