#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import tempfile
import unittest
import stager
import stagep_core

FILE=Path(os.environ.get('CABAL_V291_EXE','/mnt/data/CabalMain(20261118-202936).exe'))

class StageR(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.original=FILE.read_bytes()
  cls.patched,cls.info=stager.corrected_exe(cls.original)
 def test_01_original_digest(self):self.assertEqual(stager.sha(self.original),stager.ORIGINAL_SHA)
 def test_02_original_checksum(self):
  lay=stager.pe_layout(self.original)
  self.assertEqual(stager.pe_checksum(self.original,lay['checksum_off']),struct.unpack_from('<I',self.original,lay['checksum_off'])[0])
 def test_03_new_checksum(self):
  lay=stager.pe_layout(self.patched)
  self.assertEqual(stager.pe_checksum(self.patched,lay['checksum_off']),struct.unpack_from('<I',self.patched,lay['checksum_off'])[0])
 def test_04_function_pdata_end_fixed(self):
  lay=stager.pe_layout(self.patched)
  # independent entry scan
  es=[struct.unpack_from('<III',self.patched,i) for i in range(lay['exc_off'],lay['exc_off']+lay['exc_size'],12)]
  x=[(a,e,u) for a,e,u in es if a==stagep_core.PATCH_RVA]
  self.assertEqual(len(x),1)
  self.assertEqual(x[0][1],stagep_core.PATCH_RVA+0x4f)
 def test_05_ret_inside_registered_unwind_range(self):
  self.assertLess(int(self.info['patched_ret_rva'],16),int(self.info['pdata_new_end_rva'],16))
 def test_06_next_function_not_overlapped(self):
  self.assertLess(int(self.info['pdata_new_end_rva'],16),int(self.info['next_function_start_rva'],16))
 def test_07_security_cert_bytes_unchanged(self):
  l=stager.pe_layout(self.original);p=l['cert_off'];e=p+l['cert_size'];self.assertEqual(self.original[p:e],self.patched[p:e])
 def test_08_entire_file_length_same(self):self.assertEqual(len(self.original),len(self.patched))
 def test_09_original_sender_is_expected(self):
  blk,off=stagep_core.get_source_data(self.original)
  self.assertEqual(blk,self.original[off:off+0x50])
 def test_10_original_does_not_change(self):self.assertEqual(stager.sha(self.original),stager.ORIGINAL_SHA)
 def test_11_patch_matches_known_hash(self):self.assertEqual(self.info['new_sha256'],'02f51bb0051243b9da3b4730fc030f6dda491cb691551999e1df0df0ac123daf')
 def test_12_both_expected_changes(self):self.assertEqual(self.info['changed_bytes'],59)
 def test_13_patched_diff_whitelisted(self):
  l=stager.pe_layout(self.original);c=stagep_core.assert_pe64(self.original)
  p=next(i for i in range(l['exc_off'],l['exc_off']+l['exc_size'],12) if struct.unpack_from('<I',self.original,i)[0]==stagep_core.PATCH_RVA)
  allowed=set(range(c,c+80))|set(range(p+4,p+8))|set(range(l['checksum_off'],l['checksum_off']+4))
  self.assertTrue(all(i in allowed for i,(a,b) in enumerate(zip(self.original,self.patched)) if a!=b))
 def test_14_reject_nonoriginal_exe(self):
  bad=self.original[:-1]+bytes([self.original[-1]^1]);self.assertRaises(ValueError,stager.corrected_exe,bad)
 def test_15_lab_apply_rollback(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)/'CABAL_291_LAB';exe=root/'Bin'/'x64'/'CabalMain.exe';exe.parent.mkdir(parents=True)
   exe.write_bytes(self.original)
   r=stager.apply_lab(root)
   self.assertEqual(r['status'],'LAB_APPLIED_EXPERIMENTAL')
   self.assertEqual(exe.read_bytes(),self.patched)
   self.assertTrue((exe.parent/stager.STAGE_R_BACKUP).exists())
   r=stager.rollback_lab(root)
   self.assertEqual(r['status'],'LAB_ORIGINAL_RESTORED')
   self.assertEqual(exe.read_bytes(),self.original)
 def test_16_refuse_legacy_original_location(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)/'CABAL_291_TEST';exe=root/'Bin'/'x64'/'CabalMain.exe';exe.parent.mkdir(parents=True);exe.write_bytes(self.original)
   self.assertRaises(ValueError,stager.apply_lab,root)
 def test_17_existing_backup_refused(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)/'CABAL_291_LAB';exe=root/'Bin'/'x64'/'CabalMain.exe';exe.parent.mkdir(parents=True);exe.write_bytes(self.original)
   (exe.parent/stager.STAGE_R_BACKUP).write_bytes(b'bad')
   self.assertRaises(ValueError,stager.apply_lab,root)
   self.assertEqual(exe.read_bytes(),self.original)
 def test_18_rollback_tamper_refused(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)/'CABAL_291_LAB';exe=root/'Bin'/'x64'/'CabalMain.exe';exe.parent.mkdir(parents=True);exe.write_bytes(self.original)
   stager.apply_lab(root)
   raw=bytearray(exe.read_bytes());raw[100]^=1;exe.write_bytes(raw)
   self.assertRaises(ValueError,stager.rollback_lab,root)
 def test_19_wincert_still_invalid_annotated(self):self.assertTrue(self.info['signature_still_invalid'])
 def test_20_correct_guard_target(self):self.assertEqual(self.info['guard_exact_qdidx'],4380)
 def test_21_no_client_or_server_actions(self):
  import inspect
  script=inspect.getsource(stager)
  self.assertNotIn('ssh ',script)
  self.assertNotIn('docker exec',script)
  self.assertNotIn('requests.',script)

if __name__=='__main__':unittest.main(verbosity=2)
