# CABAL v291 / EP39 — Stage R: LAB strukturālais labojums

**Statuss:** reāls, izolētai LAB kopijai uzliekams kandidāts. **Nav Windows vai gameplay apstiprinājuma.**

## Kāpēc Stage Q klients pazuda?

No lietotāja diagnostikas:

- Stage Q modificētais `CabalMain.exe` SHA256 `ef4fd980520d52d6ede0785d5de42d7ed90045acfe56c2f86be89c6e317869d1` tika palaists, taču logs pazuda (Stage Q ziņoja tikai procesa palaišanu, nevis palikšanu dzīvu).
- Pēc Stage Q rollback oriģinālais LAB `CabalMain.exe` SHA256 `52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9` bija dzīvs pēc 12 sekundēm (PID 8796).
- Nav ziņotu `Application Error` notikumu. Precīzs modificētā procesa exit code nav iegūts. Tātad patch ir galvenais aizdomās turamais, bet tiešs avārijas mehānisms vēl nav identificēts.

## Statiskā izmeklēšana: DIVAS KONKRĒTAS Stage P/Q kļūdas

1. Oriģinālajā EXE PE kontrolsumma ir `0x00E70790`; neatkarīgais `CheckSumMappedFile` saderīgais algoritms dod **precīzi to pašu**. Stage P mainīja `.text` kodu, bet veco PE CheckSum neizmainīja. Stage R aprēķina jaunu: **`0x00E73456`**.
2. Oriģinālajā `.pdata` ir x64 funkcijas diapazons `[0x6C9F30, 0x6C9F7D)` (exclusive end). Stage P pārvietoja `ret` uz RVA **`0x6C9F7E`**, kas vairs **neietilpst** reģistrētajā funkcijā. Stage R pagarina `.pdata` end līdz **`0x6C9F7F`**, kas ietver `ret`, bet nepārklājas ar nākamo funkciju (`0x6C9F80`).

**Svarīga atruna:** šie ir reāli strukturāli defekti, bet nav pierādīts, ka tie ir konkrētās ātrās aizvēršanās cēlonis. `CabalMain.exe` ir `WIN_CERTIFICATE` un importē `SecureEngineSDK64.dll`. Pēc koda modifikācijas Authenticode paraksts paliek nederīgs. **Stage R neapiet un neizslēdz integritātes pārbaudi.** Ja tas netiek pieņemts, bināro patch ceļu neturpināt bez citām atļautām integrācijas iespējām.

## Kas izmainīts

Stage R saglabā Stage P guard loģiku: tikai šī `MainCmd(485)` izsūtīšanas callback ceļā bloķē `qdIdx = 4380`, nekonvertē uz citu dungeon ID. Papildus maina tikai:

- `.pdata` reģistra `EndAddress` precīzi šai funkcijai;
- PE `CheckSum` lauku;
- Stage P jau izmantoto 80 baitu funkcijas bloku.

Visas izmaiņas ir stingri ierobežotas ar šīm trim vietām. Netiek mainīts `mapinfo.enc`, oriģinālais darba klients, WorldSvr vai SQL. Nav lietojams kā universāls dungeon ID labojums.

## Viena palaišana

1. **Aizver visus CABAL klientus**. `F:\CABAL_291_LAB` jau eksistē un tajā pēc iepriekšējā rollback ir oriģinālais EXE; **nekopē visus 14,7 GB vēlreiz**.
2. Izpako šo ZIP jebkurā atsevišķā mapē.
3. Palaid `Palaist-StageR-LAB.cmd` (ne administratora režīmā, ja vien nav vajadzīgs failu atļaujām).
4. Skripts pārliecinās, ka LAB EXE ir autentisks, saglabā **atsevišķu** `CabalMain.exe.stager_original.bak`, uzliek koriģēto kandidātu, pārbauda SHA256 un palaiž LAB ar argumentu `breaklee`.
5. Ja process aizveras pirmajās 20 sekundēs, skripts **automātiski atgriež oriģinālo LAB EXE**. Ja process turpina darboties, LAB paliek eksperimentālais kandidāts spēles testam. **Neveic testus darba klientā.**
6. Rezultāta ziņojums: `F:\CABAL_291_LAB\_STAGER_LAB_STARTUP_REPORT.json`. Ja process ātri aizveras, atsūti šo JSON. Ja paliek spēlē, pārbaudi tieši Warp 485 un apraksti rezultātu.

Manuāla atjaunošana (aizver spēli): `Palaist-Atjaunot-Oriģinālo-LAB.cmd`.

**Priekšnosacījums:** Windows ir Python `py -3`, kā iepriekšējā Stage Q rīkā. Instalētājs noraida nepazīstamu EXE, nepareizu LAB mapi, jau pastāvošu Stage R backup un aktīvu CabalMain procesu. Stage Q vēsturiskie backup faili netiek pārrakstīti.

## Testi un ierobežojumi

- **21/21 Python offline testi PASS** uz reālā oriģinālā `CabalMain.exe`, ieskaitot faila SHA, PE checksum, `.pdata`, nākamās funkcijas robežu, WinCertificate baitu saglabāšanu, faila izmaiņu baltā saraksta pārbaudi, LAB kopijas apply/rollback un kļūmju atteikšanu.
- Sagaidāmais Stage R EXE SHA256: `02f51bb0051243b9da3b4730fc030f6dda491cb691551999e1df0df0ac123daf`.
- **Nav veikts** Windows loader, digitālā paraksta pieņemšanas, SecureEngineSDK, spēles pievienošanās vai Warp 485 tests. PS1 izpilde Windows nav pārbaudīta; šeit ir pārbaudīts Python pamatrīks.
- Pēc sekmīga starta tas tikai nepieļauj atvienošanos **no šī viena** nederīga ID nosūtīšanas. Dungeon 4380 netiks izveidots un nav pierādīta pilnīga Warp izvēlnes funkcionalitāte.
