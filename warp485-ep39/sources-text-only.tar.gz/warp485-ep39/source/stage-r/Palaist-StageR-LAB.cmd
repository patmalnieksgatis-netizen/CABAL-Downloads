@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Palaist-StageR-LAB.ps1"
echo.
pause
