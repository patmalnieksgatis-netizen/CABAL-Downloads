#!/usr/bin/env python3
"""CABAL v291 LAB-only Stage R: structural correction of the experimental Warp 485 guard.

Copies and corrects the previous Stage P guard by:
  1. Keeping the .pdata function EndAddress after the moved return instruction.
  2. Recalculating the PE32+ CheckSum after code and .pdata changes.

This does not repair the EXE's Authenticode signature and is not a gameplay fix.
No process injection, server access, or modification of CABAL_291_TEST.
"""
from __future__ import annotations
import argparse
from array import array
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import stagep_core as core

ORIGINAL_SHA=core.EXE_SHA
STAGE_R_BACKUP='CabalMain.exe.stager_original.bak'
RUNTIME_ORIGINAL_END=core.PATCH_RVA+0x4D  # Original .pdata entry end, exclusive.
RUNTIME_NEW_END=core.PATCH_RVA+0x4F       # New ret at RVA + 0x4E, inclusive.


def sha(b:bytes)->str: return hashlib.sha256(b).hexdigest()


def pe_layout(buf:bytes):
    pe,=struct.unpack_from('<I',buf,0x3C)
    if buf[:2]!=b'MZ' or buf[pe:pe+4]!=b'PE\0\0': raise ValueError('PE_INVALID')
    opt=pe+24
    if struct.unpack_from('<H',buf,opt)[0]!=0x20b: raise ValueError('NOT_PE32PLUS')
    opt_sz=struct.unpack_from('<H',buf,pe+20)[0]
    checksum_off=opt+64
    exc_rva,exc_sz=struct.unpack_from('<II',buf,opt+112+8*3)
    sec_off,sec_sz=struct.unpack_from('<II',buf,opt+112+8*4)
    if sec_off==0 or sec_sz==0 or sec_off+sec_sz>len(buf): raise ValueError('WIN_CERTIFICATE_MISSING')
    nsec,=struct.unpack_from('<H',buf,pe+6)
    sections=[]
    for i in range(nsec):
        pos=opt+opt_sz+i*40
        virt_sz,rva,raw_sz,raw_ptr=struct.unpack_from('<IIII',buf,pos+8)
        sections.append((rva,virt_sz,raw_sz,raw_ptr))
    def rva_offset(rva,size):
        for srva,vs,rs,rp in sections:
            if srva<=rva and rva+size<=srva+min(vs,rs):
                offset=rp+rva-srva
                if offset+size<=len(buf):return offset
        raise ValueError('NOT_FILE_BACKED_RVA')
    return {'checksum_off':checksum_off,'exc_off':rva_offset(exc_rva,exc_sz),
            'exc_size':exc_sz,'cert_off':sec_off,'cert_size':sec_sz}


def pe_checksum(buf:bytes, checksum_off:int)->int:
    # Native CheckSumMappedFile compatible fold over 16-bit little-endian words.
    body=bytearray(buf)
    body[checksum_off:checksum_off+4]=b'\0'*4
    if len(body)&1: body.append(0)
    words=array('H');words.frombytes(body)
    total=sum(words)
    while total>0xffff: total=(total&0xffff)+(total>>16)
    return (total+len(buf))&0xffffffff


def pdata_entry(buf:bytes,layout:dict):
    first,last=layout['exc_off'],layout['exc_off']+layout['exc_size']
    for off in range(first,last-11,12):
        begin,end,unwind=struct.unpack_from('<III',buf,off)
        if begin==core.PATCH_RVA:
            if end != RUNTIME_ORIGINAL_END: raise ValueError(f'UNEXPECTED_PDATA_END_0x{end:X}')
            next_off=off+12
            if next_off+8>last: raise ValueError('PDATA_NEXT_ENTRY_NOT_FOUND')
            next_begin,=struct.unpack_from('<I',buf,next_off)
            if RUNTIME_NEW_END>next_begin: raise ValueError('NEW_FUNCTION_OVERLAPS_NEXT')
            return off, next_begin, unwind
    raise ValueError('ORIGINAL_PDATA_ENTRY_NOT_FOUND')


def corrected_exe(original:bytes)->tuple[bytes,dict]:
    core.get_source_data(original)  # SHA, PE layout, callback + original code anchors
    lay=pe_layout(original)
    orig_sum,=struct.unpack_from('<I',original,lay['checksum_off'])
    if pe_checksum(original,lay['checksum_off'])!=orig_sum: raise ValueError('ORIGINAL_PE_CHECKSUM_INVALID')
    pdata, next_begin, unwind=pdata_entry(original,lay)
    patched=bytearray(core.build_patched(original))
    struct.pack_into('<I',patched,pdata+4,RUNTIME_NEW_END)
    new_sum=pe_checksum(patched,lay['checksum_off'])
    struct.pack_into('<I',patched,lay['checksum_off'],new_sum)
    patched=bytes(patched)
    if pe_checksum(patched,lay['checksum_off'])!=new_sum: raise AssertionError('NEW_CHECKSUM_FAILED')
    if patched[lay['cert_off']:lay['cert_off']+lay['cert_size']] != original[lay['cert_off']:lay['cert_off']+lay['cert_size']]:
        raise AssertionError('CERTIFICATE_BYTES_CHANGED')
    orig_off=core.assert_pe64(original)
    # make_block ends with 1-byte ret; ret RVA is last used byte - 1.
    newret=core.PATCH_RVA+core.make_block()[1]['function_used_bytes']-1
    if newret>=RUNTIME_NEW_END or newret<RUNTIME_ORIGINAL_END: raise AssertionError('RET_OUT_OF_PDATA')
    allowed=set(range(orig_off,orig_off+core.BLOCK_CAP))
    allowed.update(range(pdata+4,pdata+8))
    allowed.update(range(lay['checksum_off'],lay['checksum_off']+4))
    changed=[i for i,(a,b) in enumerate(zip(original,patched)) if a!=b]
    if not changed or not all(x in allowed for x in changed) or len(original)!=len(patched):
        raise AssertionError('WRITES_OUTSIDE_WHITELIST')
    return patched,{
      'status':'OFFLINE_ONLY_WINDOWS_STARTUP_NOT_VERIFIED','original_sha256':ORIGINAL_SHA,
      'new_sha256':sha(patched),'original_pe_checksum':hex(orig_sum),'corrected_pe_checksum':hex(new_sum),
      'pdata_function_begin_rva':hex(core.PATCH_RVA),'pdata_previous_end_rva':hex(RUNTIME_ORIGINAL_END),
      'pdata_new_end_rva':hex(RUNTIME_NEW_END),'patched_ret_rva':hex(newret),
      'next_function_start_rva':hex(next_begin),'unwind_rva':hex(unwind),
      'patch_file_offset':hex(orig_off),'pdata_file_offset':hex(pdata),
      'changed_bytes':len(changed),'signature_still_invalid':True,
      'guard_exact_qdidx':4380,'gameplay_verified':False}


def safe_lab(root:Path):
    if root.name.upper()!='CABAL_291_LAB': raise ValueError('LAB_ROOT_MUST_BE_CABAL_291_LAB')
    if not root.is_dir(): raise ValueError('LAB_DIR_MISSING')
    for q in [root,root/'Bin',root/'Bin'/'x64',root/'Bin'/'x64'/'CabalMain.exe']:
        if q.is_symlink():raise ValueError('SYMLINK_DISALLOWED')
    return root/'Bin'/'x64'/'CabalMain.exe'


def no_running_game():
    if os.name!='nt':return
    proc=subprocess.run(['tasklist','/FI','IMAGENAME eq CabalMain.exe','/FO','CSV','/NH'],capture_output=True,text=True,timeout=15)
    if proc.returncode!=0: raise RuntimeError('CANNOT_CHECK_GAME_PROCESSES')
    if 'cabalmain.exe' in proc.stdout.lower():raise RuntimeError('CLOSE_ALL_CABALMAIN_EXE_FIRST')


def atomic_new(path:Path,data:bytes):
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,prefix='.stager-',delete=False) as fh:
            temporary=Path(fh.name)
            fh.write(data);fh.flush();os.fsync(fh.fileno())
        os.replace(temporary,path)
        temporary=None
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)


def apply_lab(root:Path):
    exe=safe_lab(root)
    no_running_game()
    backup=exe.parent/STAGE_R_BACKUP
    raw=exe.read_bytes()
    if sha(raw)!=ORIGINAL_SHA:raise ValueError('LAB_NOT_ORIGINAL_OR_HAS_OTHER_PATCH')
    if backup.exists():raise ValueError('STAGER_BACKUP_ALREADY_EXISTS')
    patched,details=corrected_exe(raw)
    # Save original before changing working LAB clone.
    try:
        with open(backup,'xb') as fh:
            fh.write(raw);fh.flush();os.fsync(fh.fileno())
        if sha(backup.read_bytes())!=ORIGINAL_SHA:raise ValueError('BACKUP_SHA256_INVALID')
        atomic_new(exe,patched)
        if sha(exe.read_bytes())!=details['new_sha256']:raise ValueError('NEW_EXE_SHA256_INVALID')
    except Exception:
        if backup.exists() and sha(backup.read_bytes())==ORIGINAL_SHA and sha(exe.read_bytes())!=ORIGINAL_SHA:
            atomic_new(exe,raw)
        raise
    return {**details,'status':'LAB_APPLIED_EXPERIMENTAL','original_backup':str(backup)}


def rollback_lab(root:Path):
    exe=safe_lab(root);no_running_game()
    backup=exe.parent/STAGE_R_BACKUP
    if not backup.is_file():raise ValueError('STAGER_BACKUP_NOT_FOUND')
    original=backup.read_bytes()
    if sha(original)!=ORIGINAL_SHA:raise ValueError('BACKUP_SHA_MISMATCH')
    patched,details=corrected_exe(original)
    current=exe.read_bytes()
    if sha(current)==ORIGINAL_SHA:return {'status':'LAB_ALREADY_ORIGINAL','sha256':ORIGINAL_SHA}
    if sha(current)!=sha(patched):raise ValueError('LAB_EXE_CHANGED_BY_SOMETHING_ELSE')
    atomic_new(exe,original)
    if sha(exe.read_bytes())!=ORIGINAL_SHA:raise ValueError('RESTORE_FAILED')
    return {'status':'LAB_ORIGINAL_RESTORED','sha256':ORIGINAL_SHA,'failed_patch_still_available':False}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--inspect-original',type=Path)
    group.add_argument('--apply-lab',type=Path)
    group.add_argument('--rollback-lab',type=Path)
    a=ap.parse_args()
    try:
        if a.inspect_original:
            _,r=corrected_exe(a.inspect_original.read_bytes())
        elif a.apply_lab:r=apply_lab(a.apply_lab)
        else:r=rollback_lab(a.rollback_lab)
        print(json.dumps(r,indent=2,ensure_ascii=False))
    except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired,AssertionError) as e:
        print('STOP:',str(e),file=sys.stderr);return 2
    return 0

if __name__=='__main__':sys.exit(main())
