# CABAL v291 Stage R: one-click LAB patch with automatic rollback on quick exit.
# Never touches the real working client, WorldSvr or SQL.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root='F:\CABAL_291_LAB'
$exe=Join-Path $root 'Bin\x64\CabalMain.exe'
$reportPath=Join-Path $root '_STAGER_LAB_STARTUP_REPORT.json'
$script=Join-Path $PSScriptRoot 'stager.py'
$orig='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
$patched='02f51bb0051243b9da3b4730fc030f6dda491cb691551999e1df0df0ac123daf'
$applied=$false
$clientAlive=$false
$report=[ordered]@{
    status='NOT_STARTED'; time=(Get-Date).ToString('o')
    project='CABAL v291 EP39'; lab_client=$exe
    working_client_changed=$false; server_changed=$false; sql_changed=$false
    expected_original_sha256=$orig; expected_stage_r_sha256=$patched
    launch_argument='breaklee'; launch_pid=$null; launch_status=$null
    exit_code_decimal=$null; exit_code_hex=$null
    rollback_performed=$false; app_error_events=@(); warning='Runtime and gameplay validation not yet established'
}
try {
    if (!(Test-Path -LiteralPath $script -PathType Leaf)) {throw 'STAGER_PY_MISSING'}
    if (!(Test-Path -LiteralPath $exe -PathType Leaf)) {throw 'LAB_CLIENT_MISSING'}
    if (@(Get-Process -Name CabalMain -ErrorAction SilentlyContinue).Count -gt 0) {throw 'CLOSE_ALL_CABALMAIN_EXE_FIRST'}
    if ((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $orig) {throw 'LAB_NOT_UNMODIFIED_ORIGINAL_STOP'}
    Write-Host 'LAB: applying Stage R with corrected PE checksum and unwind range' -ForegroundColor Cyan
    & py -3 $script --apply-lab $root
    if ($LASTEXITCODE -ne 0) {throw 'STAGER_APPLY_FAILED'}
    if ((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $patched) {throw 'PATCH_SHA256_VERIFICATION_FAILED'}
    $applied=$true
    $started=Get-Date
    $p=Start-Process -FilePath $exe -ArgumentList 'breaklee' -WorkingDirectory (Split-Path -Parent $exe) -PassThru
    $report.launch_pid=[int]$p.Id
    if ($p.WaitForExit(20000)) {
        $code=[int]$p.ExitCode
        $report.launch_status='PATCHED_LAB_EXITED_WITHIN_20_SECONDS'
        $report.exit_code_decimal=$code
        $report.exit_code_hex=('0x{0:X8}' -f ([uint32]([int64]$code -band 0xffffffffL)))
        Write-Host 'LAB client exited quickly; restoring original LAB EXE automatically.' -ForegroundColor Yellow
        & py -3 $script --rollback-lab $root
        if ($LASTEXITCODE -ne 0) {throw 'AUTO_ROLLBACK_FAILED'}
        $report.rollback_performed=$true
        $report.status='PATCHED_STARTUP_FAILED_AND_ROLLED_BACK'
    } else {
        $clientAlive=$true
        $report.launch_status='PATCHED_LAB_ALIVE_AFTER_20_SECONDS'
        $report.status='LAB_CLIENT_STILL_RUNNING_GAMEPLAY_NOT_VERIFIED'
        Write-Host 'LAB client still running after 20s. Test Warp 485 inside LAB only.' -ForegroundColor Green
    }
    $events=@(Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$started.AddSeconds(-5); Id=1000,1001} -MaxEvents 50 -ErrorAction SilentlyContinue | Where-Object {$_.Message -match 'CabalMain(?:\.exe)?'} | Select-Object -First 5)
    $report.app_error_events=@($events | ForEach-Object { [ordered]@{time=$_.TimeCreated.ToString('o');id=[int]$_.Id;message=$_.Message.Substring(0,[Math]::Min(900,$_.Message.Length))} })
} catch {
    $report.error=$_.Exception.Message
    if ($applied -and !$clientAlive -and @(Get-Process -Name CabalMain -ErrorAction SilentlyContinue).Count -eq 0) {
        try {
            & py -3 $script --rollback-lab $root
            if ($LASTEXITCODE -eq 0) {$report.rollback_performed=$true}
        } catch {}
    }
    $report.status='STOPPED_SAFELY_CHECK_REPORT'
    Write-Host ('STOP: '+$report.error) -ForegroundColor Red
} finally {
    if (Test-Path -LiteralPath $root -PathType Container) {
        try {$report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $reportPath -Encoding UTF8
            Write-Host ('REPORT: '+$reportPath) -ForegroundColor Cyan} catch {Write-Host 'REPORT_WRITE_FAILED' -ForegroundColor Yellow}
    }
}
if ($report.status -eq 'STOPPED_SAFELY_CHECK_REPORT') {exit 2}
