@echo off
cd /d "%~dp0"
py -3 "%~dp0stager.py" --rollback-lab "F:\CABAL_291_LAB"
echo.
pause
