#!/usr/bin/env python3
"""Offline reference XML audit and conservative per-icon Warp candidate generator.
Never read or write *.enc, WorldSvr or a game install. Input MUST be decoded XML.
"""
import argparse
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from hashlib import sha256
import re, json

TARGET_WORLD='8'
TARGET_WARP='675'
TARGET_TYPE='3'
BLOCK_RE=re.compile(rb'(?P<open><icon_value\b[^>]*\bwarp_index="675"[^>]*>)(?P<body>.*?)(?P<close></icon_value>)',re.DOTALL)
LINE_RE=re.compile(rb'(?m)^[ \t]*<warp\b[^\r\n]*?/>[ \t]*(?:\r\n|\n|\r)')


def allowed_ids(server_zip:Path):
    allowed=set()
    with ZipFile(server_zip) as z:
        for filename,section in [('QuestDungeon.scp','QuestDungeon'),('MissionDungeon.scp','MD'),('MissionDungeon2.scp','MD')]:
            data=z.read(filename).decode('utf-8-sig').splitlines()
            head=next(i for i,line in enumerate(data) if line.startswith('['+section+']'))
            col=data[head].split('\t').index('QDungeonIdx')
            for row in data[head+1:]:
                if row.startswith('['):break
                cells=row.split()
                if cells:allowed.add(int(cells[col]))
    return allowed


def server_warp_location(server_zip:Path):
    with ZipFile(server_zip) as z:
        lines=z.read('Warp.scp').decode('utf-8-sig').splitlines()
        header=next(i for i,line in enumerate(lines) if line.startswith('[Warp]'))
        fields=lines[header].split('\t')
        x_col=fields.index('PosXPnt')
        y_col=fields.index('PosYPnt')
        world_col=fields.index('WorldIdx')
        for line in lines[header+1:]:
            if line.startswith('['):break
            values=line.split()
            if values and values[0]==TARGET_WARP:
                if values[world_col]!=TARGET_WORLD:
                    raise ValueError('SERVER_WARP_WORLD_MISMATCH')
                return {'warp_index':int(TARGET_WARP),'world_id':int(TARGET_WORLD),
                        'server_position':[int(values[x_col]),int(values[y_col])]}
    raise ValueError('SERVER_WARP_MISSING')


def target_nodes(xml_bytes:bytes):
    root=ET.fromstring(xml_bytes)
    matches=[]
    for icon in root.findall('.//icon'):
        if icon.get('world_id') != TARGET_WORLD:continue
        for group in icon.findall('icon_value'):
            if group.get('warp_index')==TARGET_WARP and group.get('type')==TARGET_TYPE:
                matches.append(group)
    if len(matches)!=1:raise ValueError(f'EXACT_ICON_NOT_FOUND_OR_DUPLICATE count={len(matches)}')
    return matches[0]


def stage(xml_bytes:bytes,server_zip:Path):
    if not xml_bytes.startswith(b'<'):
        raise ValueError('NOT_DECODED_XML_REFUSE_ENC')
    group=target_nodes(xml_bytes)
    valid=allowed_ids(server_zip)
    server_location=server_warp_location(server_zip)
    before=[dict(e.attrib) for e in group.findall('warp')]
    if len(before)<2:raise ValueError('WARP_ENTRIES_TOO_FEW')
    bad=[e for e in before if int(e['dungeon_index']) not in valid]
    good=[e for e in before if int(e['dungeon_index']) in valid]
    if not bad:raise ValueError('NO_INVALID_WARP_IN_TARGET')
    if [int(e['order']) for e in good]!=list(range(len(good))):
        raise ValueError('REMAINING_ORDER_NOT_CONTIGUOUS')
    blocks=list(BLOCK_RE.finditer(xml_bytes))
    if len(blocks)!=1:raise ValueError(f'WARP_INDEX_675_BLOCK_NOT_UNIQUE count={len(blocks)}')
    m=blocks[0]
    body=m.group('body')
    spans=list(LINE_RE.finditer(body))
    if len(spans)!=len(before):raise ValueError(f'SINGLE_LINE_WARP_COUNT_MISMATCH {len(spans)} vs {len(before)}')
    gone=[];retained=[]
    for span in spans:
        part=span.group()
        node=ET.fromstring(part.strip())
        attrs=dict(node.attrib)
        if attrs not in before:raise ValueError('ATTRIBUTES_NOT_IN_TARGET_XML')
        qd=int(attrs['dungeon_index'])
        if qd in valid:retained.append(part)
        else:gone.append(part)
    if sorted(int(ET.fromstring(v.strip()).get('dungeon_index')) for v in gone)!=sorted(int(x['dungeon_index']) for x in bad):
        raise ValueError('REMOVAL_SET_MISMATCH')
    # Delete only complete selected lines; all other source bytes remain unchanged.
    candidate_body=LINE_RE.sub(lambda o: b'' if int(ET.fromstring(o.group().strip()).get('dungeon_index')) not in valid else o.group(),body)
    candidate=xml_bytes[:m.start('body')]+candidate_body+xml_bytes[m.end('body'):]
    after=[dict(e.attrib) for e in target_nodes(candidate).findall('warp')]
    if after!=good:raise ValueError('POST_VERIFY_RETAINED_ENTRIES_MISMATCH')
    if len(candidate)!=len(xml_bytes)-sum(len(x) for x in gone):
        raise ValueError('BYTE_PRESERVATION_MISMATCH')
    return candidate,{'scope':{'world_id':TARGET_WORLD,'warp_index':TARGET_WARP,'type':TARGET_TYPE},'server_warp':server_location,
                      'original_sha256':sha256(xml_bytes).hexdigest(), 'candidate_sha256':sha256(candidate).hexdigest(),
                      'removed_dungeon_ids':[int(e['dungeon_index']) for e in bad],
                      'retained_dungeon_ids':[int(e['dungeon_index']) for e in good],
                      'removed_bytes':len(xml_bytes)-len(candidate),
                      'source': 'UNVERIFIED_DIFFERENT_ARCHIVE_REFERENCE_ONLY',
                      'compatible_with_v291_client':False,
                      'server_or_client_modified':False}


def main():
    p=argparse.ArgumentParser(description='Analyze decoded XML and optionally stage an offline candidate; never modifies .enc or live systems')
    p.add_argument('decoded_xml',type=Path);p.add_argument('--server-registry',type=Path,required=True)
    p.add_argument('--stage',action='store_true');p.add_argument('--out',type=Path)
    args=p.parse_args()
    raw=args.decoded_xml.read_bytes()
    candidate,report=stage(raw,args.server_registry)
    if args.stage:
        if not args.out:raise SystemExit('OUTPUT_PATH_REQUIRED')
        if args.out.resolve()==args.decoded_xml.resolve():raise SystemExit('OVERWRITE_ORIGINAL_REFUSED')
        if args.out.exists():raise SystemExit('OUTPUT_EXISTS_REFUSED')
        args.out.write_bytes(candidate);print('CANDIDATE_ONLY:',args.out)
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
