# CABAL v291 / EP39 — Warp 485 (offline, reference only)

## Pierādītā kļūda

`WorldSvr` žurnālā pēc Warp izvēlnes pieprasījuma ir `OnCSCQDungeonLimitCheck(): invalid qdIdx(4380)`, tad `UsrMap Fail : MainCmd(485)` un savienojuma aizvēršana. Pats `WorldSvr` process turpina darboties.

V291 servera `[QuestDungeon]` reģistrā ir ID 1–304, `[MissionDungeon.scp]` 4096–4341, `[MissionDungeon2.scp]` 4342–4378. 4379–4383 nav nevienā no šīm reģistra primārajām sadaļām.

## Jaunā neatkarīgā sasaite

No **cita, nesertificēta CABAL arhīva**, nevis v291 oriģinālā klienta, atkodēts `mapinfo.enc`. Tas ir reāls XML, kur World 8 / Warp 675 (`type=3`) satur septiņas rindas: 4352, 4378, 4379, 4380, 4381, 4382, 4383. Servera `Warp.scp` WarpIdx 675 pasaulē 8 ir pozīcijā 227,34. Tā nav garantija, ka v291 klienta izvēlne ir identiska.

## Izolētais kandidāts

`mapinfo_warp675_guard.py` ar **tikai atkodētu XML** un servera reģistra arhīvu izveido `REFERENCE_ONLY_Warp675_candidate.dec`. Tas izņem tikai piecas neatbalstītās rindas (4379–4383), saglabā 4352 un 4378 un pārējos XML baitus nemaina. `order` paliek 0 un 1. Neatlasa citu pasaules karšu izvēlnes rindas. Nav pārrakstīšanas vai dubultās piemērošanas iespējas.

Šī ir **atsauces kandidāta demonstrācija**, nevis instalējams v291 labojums. Tā nav `*.enc` datne, nav paredzēta ievietošanai spēlē un nav pārbaudīta v291 klientā. **NEDRĪKST aizvietot oriģinālo `mapinfo.enc` ar šo failu.**

## Pārbaudes

`python3 test_stage_e.py` — 8 automatizēti testi, 8 PASS (izpildīti šīs pakotnes ģenerēšanas laikā). Pārbauda tieši izņemtos ID, baitu saglabāšanu, pārējo neatbalstīto ID neaiztikšanu, kārtas indeksus, šifrētā v291 faila noraidīšanu, atkārtotas piemērošanas noraidīšanu, Warp 675 piesaisti un avota faila nemainību. `report.json` satur SHA256 un izmaiņas.

`unsupported_reference_menu_audit.json` rāda visus citā arhīvā atrastos 10 neatbalstītos *ne-nulles* dungeon ierakstus (`dungeon_index=0` ir parasts Warp un netiek uzskatīts par kļūdu); **automatizētā labojuma darbības lauks ir tikai World 8 / Warp 675**.

## Kas paliek neatrisināts

Oriģinālais v291 `mapinfo.enc` (`ORIGINAL_v291_ENCRYPTED_mapinfo.enc`) nav atkodēts. Standarta 4 baitu XOR+DEFLATE algoritms pieejamajiem v291 datiem nedarbojas; StageD pakotnē ir verificētie neveiksmīgie testi. Pirms jebkādas produkcijas izmaiņas nepieciešams iegūt patiesu v291 XML/resursu dekodējumu, saskaņot to ar šo kandidātu un pārbaudīt klienta spēles uzvedību.

**Nekādas izmaiņas aktīvajā VM, Docker, WorldSvr, klienta instalācijā vai SQL nav veiktas.**
