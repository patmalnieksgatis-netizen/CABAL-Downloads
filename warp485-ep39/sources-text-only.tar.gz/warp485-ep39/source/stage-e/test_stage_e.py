#!/usr/bin/env python3
"""Offline tests for a decoded-XML reference only; no game installation writes."""
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile
import hashlib, unittest
from mapinfo_warp675_guard import stage, server_warp_location, target_nodes

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'REFERENCE_UNVERIFIED_mapinfo.dec'
SERVER=ROOT/'server_registry_evidence.zip'
ENC=ROOT/'ORIGINAL_v291_ENCRYPTED_mapinfo.enc'

class ReferenceWarpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original=SOURCE.read_bytes()
        cls.candidate,cls.report=stage(cls.original,SERVER)

    def test_references_deleted_are_exact(self):
        self.assertEqual(self.report['removed_dungeon_ids'],[4379,4380,4381,4382,4383])
        self.assertEqual(self.report['retained_dungeon_ids'],[4352,4378])
        self.assertEqual(self.report['removed_bytes'],455)

    def test_bytes_untouched_other_than_removed_rows(self):
        original=self.original
        rebuilt=self.candidate
        for q in range(4379,4384):
            lines=[line for line in original.splitlines(keepends=True) if b'<warp' in line and (b'dungeon_index="'+str(q).encode()+b'"') in line]
            self.assertEqual(len(lines),1)
            original=original.replace(lines[0],b'',1)
        self.assertEqual(rebuilt,original)

    def test_neighboring_unsupported_entries_unchanged(self):
        for q in [4384,4385,4389,4390,4391]:
            marker=b'dungeon_index="'+str(q).encode()+b'"'
            self.assertEqual(self.original.count(marker),self.candidate.count(marker))

    def test_target_orders_contiguous(self):
        g=target_nodes(self.candidate)
        self.assertEqual([x.attrib['order'] for x in g.findall('warp')],['0','1'])

    def test_v291_actual_encoded_input_refused(self):
        with self.assertRaisesRegex(ValueError,'NOT_DECODED_XML_REFUSE_ENC'):
            stage(ENC.read_bytes(),SERVER)

    def test_no_double_apply(self):
        with self.assertRaisesRegex(ValueError,'NO_INVALID_WARP_IN_TARGET'):
            stage(self.candidate,SERVER)

    def test_server_warp_link(self):
        self.assertEqual(server_warp_location(SERVER),{'warp_index':675,'world_id':8,'server_position':[227,34]})

    def test_reference_file_unchanged(self):
        self.assertEqual(hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'83bec4c54dc68ea6ec4a6bf333cab1323092711a11546a9ad84c2a17d7540e86')

if __name__=='__main__':unittest.main(verbosity=2)
