import unittest, json, hashlib, io, zipfile, tempfile, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from validate_capture_and_audit import checked_capture,generate,CLIENT_SHA,MAPINFO_ENC_SHA
from triple_join_audit import server_registries
HERE=Path(__file__).resolve().parent

def specimen(with_4380=True, use_world=8, use_warp=675):
    did=4380 if with_4380 else 4352
    target=168 if with_4380 else 138
    s=(f'<cabal><guide><icon world_id="{use_world}"><icon_value warp_index="{use_warp}"><warp dungeon_index="{did}" target_world_index="{target}"/></icon_value></icon></guide></cabal>').encode()
    return s[:-8]+b' '*(49101-len(s))+s[-8:]

def make_zip(xml=None, overrides=None, extra=None):
    xml=xml if xml is not None else specimen()
    report={'Status':'ORIGINAL_V291_MAPINFO_CAPTURED','OriginalClientSHA256':CLIENT_SHA,
            'OriginalMapinfoSHA256':MAPINFO_ENC_SHA,'DecodedSHA256':hashlib.sha256(xml).hexdigest(),
            'Bytes':49101,'ProcessWrites':False,'CodeHooks':False,'ServerWrites':False,
            'OriginalClientStarted':True,'ImageBase':'0x140000000','Index':25}
    report.update(overrides or {})
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('Report.json',json.dumps(report));z.writestr('mapinfo.xml',xml)
        if extra:z.writestr(extra,'x')
    return out.getvalue()

class Integrity(unittest.TestCase):
    def test_authentic_shape(self):
        xml,rep=checked_capture(make_zip());self.assertEqual(len(xml),49101);self.assertEqual(rep['Index'],25)
    def test_missing_dungeon_captured(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'c.zip';p.write_bytes(make_zip())
            x=generate(p,HERE/'server_registry_evidence.zip')
            self.assertTrue(x['warp_8_675']['has_qdidx_4380'])
            self.assertEqual(x['warp_8_675']['entries'][0]['status'],'missing_dungeon_id')
    def test_valid_dungeon_not_mislabeled(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'c.zip';p.write_bytes(make_zip(specimen(False)))
            x=generate(p,HERE/'server_registry_evidence.zip')
            self.assertEqual(x['warp_8_675']['entries'][0]['status'],'triple_match')
            self.assertFalse(x['warp_8_675']['has_qdidx_4380'])
    def test_no_4380_elsewhere_not_accepted_as_warp675(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'c.zip';p.write_bytes(make_zip(specimen(True,use_world=9,use_warp=675)))
            x=generate(p,HERE/'server_registry_evidence.zip')
            self.assertFalse(x['warp_8_675']['has_qdidx_4380'])
    def test_changed_source_input_rejected(self):
        for field,value in [('OriginalClientSHA256','bad'),('OriginalMapinfoSHA256','bad'),('Status','FAILED')]:
            with self.subTest(field=field),self.assertRaisesRegex(ValueError,'REPORT_CONTRACT_MISMATCH'):
                checked_capture(make_zip(overrides={field:value}))
    def test_modified_decoded_sha_rejected(self):
        with self.assertRaisesRegex(ValueError,'DecodedSHA256'):checked_capture(make_zip(overrides={'DecodedSHA256':'bad'}))
    def test_wrong_decoded_length_rejected(self):
        with self.assertRaisesRegex(ValueError,'Bytes'):
            checked_capture(make_zip(overrides={'Bytes':5}))
    def test_corrupt_xml_rejected(self):
        b=specimen().replace(b'</cabal>',b'</zabal>')
        with self.assertRaisesRegex(ValueError,'MAPINFO_XML_INVALID'):checked_capture(make_zip(b))
    def test_bad_index_rejected(self):
        for index in [-1,137,False,1.2]:
            with self.subTest(index=index),self.assertRaisesRegex(ValueError,'MAPINFO_CACHE_INDEX_INVALID'):
                checked_capture(make_zip(overrides={'Index':index}))
    def test_bad_base_rejected(self):
        for base in ['', '0x0','0x123', 'JUNK']:
            with self.subTest(base=base),self.assertRaisesRegex(ValueError,'IMAGE_BASE'):
                checked_capture(make_zip(overrides={'ImageBase':base}))
    def test_malicious_zip_member_rejected(self):
        with self.assertRaisesRegex(ValueError,'UNEXPECTED_CAPTURE_ZIP_MEMBERS'):
            checked_capture(make_zip(extra='../../overwrite.txt'))
    def test_dtd_refused(self):
        b=specimen().replace(b'<cabal>',b'<!DOCTYPE cabal><cabal>')[:49101]
        with self.assertRaisesRegex(ValueError,'XML_DTD_OR_ENTITY_REFUSED'):
            checked_capture(make_zip(b))
    def test_game_writes_absent(self):
        source=(HERE/'Mapinfo291CacheReader.cs').read_text()
        p=(HERE/'Collect-Original-v291-Mapinfo.ps1').read_text()
        for banned in ('WriteProcessMemory','VirtualProtectEx','CreateRemoteThread','VirtualAllocEx'):
            self.assertNotIn(banned,source)
        for banned in ('docker exec','ssh root','Stop-Process','Start.bat'):
            self.assertNotIn(banned,p)
    def test_aslr_base_read(self):
        s=(HERE/'Mapinfo291CacheReader.cs').read_text()
        p=(HERE/'Collect-Original-v291-Mapinfo.ps1').read_text()
        self.assertIn('CheckBase(imageBase)',s)
        self.assertIn('long slot=imageBase+CacheTableRva+i*16L;',s)
        self.assertIn('MainModule.BaseAddress',p)
        self.assertNotIn('0x140000000L',s)
    def test_strict_xml_in_reader(self):
        s=(HERE/'Mapinfo291CacheReader.cs').read_text()
        self.assertIn('DtdProcessing.Prohibit',s)
        self.assertIn('SelectSingleNode(',s)
        self.assertIn('MaxCharactersInDocument',s)
    def test_registered_server_matches_snapshot(self):
        dungeon,warp=server_registries(HERE/'server_registry_evidence.zip')
        self.assertEqual(warp[675],8)
        self.assertNotIn(4380,dungeon)
        self.assertEqual(dungeon[4352]['world'],138)
    def test_registry_source_hash(self):
        self.assertEqual(hashlib.sha256((HERE/'server_registry_evidence.zip').read_bytes()).hexdigest(), 'caadebfa61ba3493c3447bf2d4e36aa3b59ca61e5470f9941f74d2d69b31dd37')

if __name__=='__main__':unittest.main(verbosity=2)
