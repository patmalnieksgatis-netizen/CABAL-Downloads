param([ValidateSet('Inspect','Collect')][string]$Action='Inspect')
$ErrorActionPreference='Stop'
if($Action -eq 'Inspect') {
    [ordered]@{Purpose='Read original v291 decoded mapinfo from native resource cache';
      Indices='0..136';ExpectedBytes=49101;ProcessWrites=$false;CodeHooks=$false;
      ServerWrites=$false;LoginRequested=$false;OriginalGameStart=$true;
      WindowsRuntimeVerified=$false} | ConvertTo-Json
    return
}
if($env:OS -ne 'Windows_NT' -or ![Environment]::Is64BitProcess) { throw 'WINDOWS_X64_POWERSHELL_REQUIRED' }
if(Get-Process -Name CabalMain -ErrorAction SilentlyContinue) { throw 'CLOSE_CABAL_FIRST' }
$root='F:\CABAL_291_TEST';$exe=Join-Path $root 'Bin\x64\CabalMain.exe'
$enc=Join-Path $root 'Data\mapinfo.enc'
$expected=@{
    $exe='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
    $enc='88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc'
}
foreach($path in $expected.Keys) {
    if(!(Test-Path -LiteralPath $path -PathType Leaf)) { throw ('MISSING_INPUT='+$path) }
    if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected[$path]) { throw ('PINNED_INPUT_CHANGED='+$path) }
}
$bytes=[IO.File]::ReadAllBytes($enc)
if($bytes.Length -ne 6808 -or [BitConverter]::ToUInt32($bytes,0) -ne 49101) {throw 'ENCRYPTED_MAPINFO_SIZE_CHANGED'}
Add-Type -Path (Join-Path $PSScriptRoot 'Mapinfo291CacheReader.cs')
$downloads=Join-Path $env:USERPROFILE 'Downloads'
$folder=Join-Path $downloads ('Original-v291-Mapinfo-'+(Get-Date -Format yyyyMMdd-HHmmss))
[void](New-Item -Path $folder -ItemType Directory -ErrorAction Stop)
$report=[ordered]@{Status='STARTING';OriginalClientSHA256=$expected[$exe];
    OriginalMapinfoSHA256=$expected[$enc];ProcessWrites=$false;CodeHooks=$false;ServerWrites=$false;
    OriginalClientStarted=$false;Index=$null;Bytes=0;DecodedSHA256=$null;Failure=$null}
$client=$null
try {
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$exe;$start.Arguments='breaklee';$start.WorkingDirectory=(Split-Path -Parent $exe)
    $start.UseShellExecute=$false
    $client=[Diagnostics.Process]::Start($start)
    if($null -eq $client) {throw 'CLIENT_DID_NOT_START'}
    $report.OriginalClientStarted=$true
    $handle=$client.Handle
    $imageBase=0L
    $deadline=[DateTime]::UtcNow.AddSeconds(90)
    $verified=$false;$last='CACHE_NOT_READY'
    while([DateTime]::UtcNow -lt $deadline) {
        if($client.HasExited) {throw 'CLIENT_EXITED_BEFORE_RESOURCE_READY'}
        try {
            $imageBase=[int64]$client.MainModule.BaseAddress.ToInt64()
            [Mapinfo291CacheReader]::VerifyOriginalClientCode($handle,$imageBase)
            $verified=$true
        } catch {
            $last=$_.Exception.GetBaseException().Message
            if($last -notin @('UNREADABLE_PAGE','PARTIAL_PROCESS_READ','NOT_ORIGINAL_PE_BASE')) {throw}
            Start-Sleep -Milliseconds 200
            continue
        }
        $row=[Mapinfo291CacheReader]::FindOriginalDecodedMapinfo($handle,$imageBase)
        if($row.Status -eq 'STABLE_ORIGINAL_V291_DECODED_MAPINFO') {
            [IO.File]::WriteAllBytes((Join-Path $folder 'mapinfo.xml'),$row.Data)
            $report.Status='ORIGINAL_V291_MAPINFO_CAPTURED';$report.Index=$row.Index
            $report.ImageBase=('0x{0:X}' -f $imageBase)
            $report.Bytes=$row.ByteLength;$report.DecodedSHA256=$row.Hash
            break
        }
        $last='MAPINFO_NOT_CACHED';Start-Sleep -Milliseconds 200
    }
    if(!$verified){throw ('CLIENT_NATIVE_CONTRACT_NOT_READY='+$last)}
    if($report.Status -ne 'ORIGINAL_V291_MAPINFO_CAPTURED'){throw ('ORIGINAL_MAPINFO_NOT_AVAILABLE='+$last)}
    foreach($path in $expected.Keys){
        if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected[$path]){
            throw ('ORIGINAL_INPUT_CHANGED_DURING_CAPTURE='+$path)
        }
    }
} catch {
    $report.Status='FAILED';$report.Failure=$_.Exception.GetBaseException().Message
} finally {
    $report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $folder 'Report.json') -Encoding UTF8
    $zip=$folder+'.zip'
    Compress-Archive -LiteralPath @(Get-ChildItem -LiteralPath $folder -File | Select-Object -ExpandProperty FullName) -DestinationPath $zip
    'STATUS='+$report.Status
    if($report.Failure){'REASON='+$report.Failure}
    'ZIP='+$zip
    if($null -ne $client){$client.Dispose()}
}
