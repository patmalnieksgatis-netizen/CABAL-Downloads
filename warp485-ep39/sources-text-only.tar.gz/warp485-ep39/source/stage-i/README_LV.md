# CABAL v291 — Warp485 / I posms: autentiskā klienta mapinfo savākšana + servera audits

## Statuss

**GATAVS BEZSAISTES DIAGNOSTIKAS KANDIDĀTS; NAV UZSTĀDĪTS UN NAV SPĒLĒ PĀRBAUDĪTS.**

Tika uzlabots H posmā izstrādātais tikai-lasīšanas `mapinfo` nolasītājs un sasaistīts ar G posma servera ID/World/Warp auditu. **Galīgā Warp atvienošanas kļūda pagaidām NAV izlabota.** Bez autentiska oriģinālā v291 `mapinfo.xml` nevar pamatot konkrēta klienta ieraksta izņemšanu vai atbildes protokola maiņu. Neviena klienta/servera/SQL/WorldSvr `.so` datne nav mainīta.

## Kas izdarīts jauns

1. **ASLR saderība.** H posma nolasītājā bija iešūta PE bāze `0x140000000`. Tagad faktiskā `CabalMain.exe` moduļa bāze tiek nolasīta no procesa `MainModule.BaseAddress`; instrukciju paraksti un kešatmiņas adrese tiek interpretēti kā relatīvas nobīdes no šīs bāzes. Tas novērš nepamatotu neveiksmi, ja Windows pārvieto moduli. Tas nenozīmē, ka klienta faktiskā ielādes adrese ir eksperimentāli noteikta.
2. **Stingrāka XML pārbaude.** Netiek vairs paļauts tikai uz teksta virkņu `dungeon_index` un `warp_index` klātbūtni. Nolasītājs pārbauda XML ar DTD aizliegumu un nepieciešamo `/cabal//icon/icon_value/warp` struktūru, saglabājot sākotnējo garuma, `NUL` terminatora, divu vienādu lasījumu un 137 kešatmiņas ierakstu ierobežojumu.
3. **Autentiska faila ieejas līgums.** `validate_capture_and_audit.py` pieņem tikai I posma `Original-v291-Mapinfo-*.zip`, kurā ir `Report.json` un `mapinfo.xml`, nepieciešamie oriģinālā klienta/šifrētā faila SHA-256, dekodētā faila 49101 baitu garums, procesa bāzes adrese, indekss un integritātes dati. Neuzticas vienkārši pārsauktam cita CABAL klienta `mapinfo.dec`.
4. **Automātisks trīskāršais audits.** Pēc ieejas pārbaudes salīdzina ierakstus ar iepriekš iegūto servera `QuestDungeon.scp`, `MissionDungeon*.scp` un `Warp.scp` ZIP. Izvadē īpaši izceļ `World 8 / Warp 675` un `qdIdx 4380`. Audits **neģenerē patch** un neko neraksta spēles/servera mapēs.

## Atsevišķi pierādīts esošajā servera snapshot

- `World 8 / Warp 675` reģistrēts.
- `qdIdx 4380` servera `[QuestDungeon]` / `[MD]` reģistros nav.
- `4352` ir reģistrēts un piesaistīts `WorldIdx 138`.
- Snapshot nav jauna tiešraides nolasīšana; kopš tā iegūšanas serveris teorētiski varēja mainīties.
- Atsauces ELF SHA-256: `caec7772acd22fd8918cfac386845c644451781e48c51975eaefed334c6705c3`, bet tā atbilstība pašlaik aktīvajam procesam šajā posmā nav atkārtoti pārbaudīta.

## Faili

- `Mapinfo291CacheReader.cs`, `Collect-Original-v291-Mapinfo.ps1`, `Palaist-Original-Mapinfo.cmd`: Windows, tikai-lasošs original v291 klienta dekodētā `mapinfo` savākšanas kandidāts. **Windows C#/PowerShell izpilde vēl nav pārbaudīta.** Palaistais sākotnējais klients var veikt savu parasto startēšanās darbību, bet pats rīks neveido login pieprasījumus.
- `validate_capture_and_audit.py`: neatkarīgs Python 3 autentiska ZIP līguma verificētājs, pēc tam audits pret snapshot.
- `triple_join_audit.py`: iepriekš G posmā izstrādātais tikai-lasīšanas servera konfigurāciju audits.
- `server_registry_evidence.zip`: vēsturiskais v291 servera konfigurāciju izvilkums.
- `test_stage_i.py`, `test_results.txt`: **17/17** testi. Testi ir sintētiski un bezsaistes; Windows procesi un spēle netika palaisti.
- `SHA256.json`: pakotnes komponentu SHA-256.

## Rīka darbības apraksts (nav aicinājums šobrīd veikt pārbaudi)

Windows savākšanai paredzēts `Palaist-Original-Mapinfo.cmd`; tas pārbauda oriģinālo `F:\CABAL_291_TEST\Bin\x64\CabalMain.exe` un `Data\mapinfo.enc` SHA-256 un palaiž spēli tikai ar `breaklee` argumentu. Ja `mapinfo` netiek ielādēts bez login, rezultāts ir `FAILED`, nevis viltots XML.

Tikai pēc reālas savākšanas tā arhīvu var pārbaudīt atsevišķā Python 3 vidē:

```
python validate_capture_and_audit.py Original-v291-Mapinfo-XXXX.zip --out audit.json
```

Faili nav jāievieto serverī vai CABAL spēles `Data` mapē. `README` neapgalvo, ka šī metode darbosies visās Windows konfigurācijās; integrācijas tests vēl ir nepieciešams.

## Drošības un funkcionalitātes ierobežojumi

- Nav SSH savienojuma ar `<PRIVATE_SERVER_LAN_IP>` no šīs darba vides. Aktīvais `WorldSvr` nav aiztikts.
- Nav autentiskā v291 `mapinfo.xml`, tādēļ **neviens īsts 4380 ieraksts vēl nav izņemts** un atvienošanās nav pārbaudīta kā novērsta.
- G/F posmos atkodētais `mapinfo` no cita CABAL arhīva ir **tikai atsauce**, nevis pierādījums par oriģinālo v291 izvēlni; tas šajā pakotnē nav izmantots kā autentiskā klienta ievade.
- Testi apliecina nolasītāja avota invariantu pārbaudes un Python validatora loģiku, nevis CABAL/Windows faktiskās izpildes rezultātu.
