# CABAL v291 / EP39 — Warp485, J posms: oriģinālā mapinfo iegūšanas uzlabošana

**Statuss: tikai lasīšanai paredzēts Windows nolasītāja kandidāts; NAV palaists Windows vidē, nav spēlē pārbaudīts, nav uzstādāms Warp labojums.**

## Kāpēc šī izmaiņa ir nepieciešama

I posma nolasītājs bija paredzēts palaist `CabalMain.exe breaklee` un nolasīt jau atkodēto `mapinfo` no procesa resursu kešatmiņas. Tomēr no pieejamajiem avotiem nav pierādīts, ka `mapinfo` tiek ielādēts **pirms ielogošanās**. Ja kešatmiņa šajā brīdī vēl ir tukša, I posma rīks atgrieztu neveiksmi, pat ja kešatmiņas nolasīšanas algoritms ir pareizs.

J posmā pievienoti divi stingri atšķirti režīmi:

- **Attach (jaunais noklusējums)**: izmanto tieši vienu jau darbojošos `CabalMain` procesu. Nekādu otru klientu nepalaiž, nekontrolē spēli un neveic login.
- **Launch (vēsturiskais)**: atteicas darboties, ja spēle jau palaista; tikai šajā režīmā startē oriģinālo `CabalMain.exe` ar `breaklee`.

Abi režīmi verificē sākotnējā `.exe` un šifrētā `mapinfo.enc` failu SHA256, faktisko procesa `.exe` ceļu, `CabalMain.exe` koda fragmentus un reālo ASLR bāzes adresi. Abos režīmos tiek tikai nolasītas atmiņas lapas, pārbaudītas XML struktūras un saglabāts atsevišķs rezultāta arhīvs. Kešatmiņas atlase joprojām ir **pēc izmēra + XML shēmas** (49101 baits, ar NUL + 1, 137 ieraksti), nevis pierādīta fiksēta `mapinfo` indeksa; vienlaicīgi piemēroti divi ieraksti izraisa kļūdu.

## Ko rīks nedara

- Nekādi `WriteProcessMemory`, injekcijas, binārā patch, servera/SQL/SSH vai esošo `Data` resursu labojumi.
- Neizmanto atsauces `mapinfo` no cita CABAL klienta par autentisku v291 failu.
- Neapgalvo, ka `qdIdx=4380` ir derīgs vai ka servera validāciju vajag atslēgt.
- Nepārbauda spēles tiešsaistes Warp darbību un nepierāda, ka šo kļūdu var labot tikai ar izvēlnes ieraksta izņemšanu.

## Faili

- `Collect-Original-v291-Mapinfo.ps1`: tikai-lasīšanas procesa nolasītājs ar Attach/Launch režīmiem.
- `Mapinfo291CacheReader.cs`: nemainīts I posma C# resursu kešatmiņas nolasīšanas kods.
- `Palaist-Pievienosanos.cmd`: Attach režīms (jau darbojošs oriģinālais v291 klients).
- `Palaist-Bez-Login.cmd`: alternatīvais Launch režīms (oriģinālā klienta startēšana).
- `validate_capture_and_audit.py` un `triple_join_audit.py`: ZIP integritātes un vēsturisko `Warp`/`Dungeon`/`World` definīciju audits.
- `server_registry_evidence.zip`: vēsturisks v291 servera konfigurāciju izvilkums; nevis dzīva servera nolasīšana.
- `test_stage_j.py`: J posma regresijas un līguma testi.
- `test_results.txt`: 8/8 jauno testu PASS; I posma 17/17 testi palaisti atsevišķi, PASS.

## Pēc autentiskā mapinfo iegūšanas

`validate_capture_and_audit.py` pārbaudīs faktisko klienta `mapinfo.xml` pret servera vēsturisko reģistru, īpaši `World 8 / Warp 675 / qdIdx 4380`. Ja savākšana neizdodas, tā atgriež `FAILED` — neģenerē izdomātu XML. Pēc autentiska XML saņemšanas joprojām būs jāizvērtē v291 kodēšanas/izmantošanas mehānisms, jāuztaisa minimālais labojums un jāveic reāls spēles tests, pirms var pasludināt Warp disconnect par salabotu.

## Tehniskie ierobežojumi

- Šajā izolētajā darba vidē nav piekļuves lietotāja `<PRIVATE_SERVER_LAN_IP>` privātajam VM vai viņa Windows `F:` diskam, tāpēc nevar patstāvīgi savākt dzīvu procesa atmiņu.
- Pieejamā autentiskā klienta `mapinfo.enc` SHA256: `88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc` (6808 baiti); dekompresētā garuma galvene norāda 49101 baitu.
- Aktīvā `WorldSvr` SHA256 šajā posmā nav no jauna nolasīts.
- **J posma C#/PowerShell izpilde Windows netika verificēta.** Python līguma testi ir bezsaistes.
