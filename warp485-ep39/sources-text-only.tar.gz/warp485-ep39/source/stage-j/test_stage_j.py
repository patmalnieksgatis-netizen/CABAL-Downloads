import io
import json
import hashlib
import os
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from validate_capture_and_audit import checked_capture,generate,CLIENT_SHA,MAPINFO_ENC_SHA

ROOT=Path(__file__).resolve().parent

def specimen():
    xml=b'<cabal><guide><icon world_id="8"><icon_value warp_index="675"><warp dungeon_index="4380" target_world_index="168"/></icon_value></icon></guide></cabal>'
    return xml[:-8]+b' '*(49101-len(xml))+xml[-8:]

def zip_capture(mode='Attach', overrides=None):
    xml=specimen()
    rep={'Status':'ORIGINAL_V291_MAPINFO_CAPTURED',
         'OriginalClientSHA256':CLIENT_SHA,'OriginalMapinfoSHA256':MAPINFO_ENC_SHA,
         'DecodedSHA256':hashlib.sha256(xml).hexdigest(),'Bytes':49101,
         'ProcessWrites':False,'CodeHooks':False,'ServerWrites':False,
         'Mode':mode,'ExistingClientAttached':mode=='Attach',
         'OriginalClientStarted':mode=='Launch','ImageBase':'0x140000000','Index':25,
         'ClientPID':1054,'CacheSizeMatchedSlots':1,'XmlCandidates':1}
    rep.update(overrides or {})
    out=io.BytesIO()
    with ZipFile(out,'w',ZIP_DEFLATED) as z:
        z.writestr('Report.json',json.dumps(rep))
        z.writestr('mapinfo.xml',xml)
    return out.getvalue()

class JTests(unittest.TestCase):
    def test_attach_and_launch_contracts(self):
        for mode in ('Attach','Launch'):
            with self.subTest(mode=mode):
                xml,meta=checked_capture(zip_capture(mode))
                self.assertEqual(meta['Mode'],mode)
                self.assertEqual(len(xml),49101)
    def test_mode_self_inconsistent_fails(self):
        tests=[('Attach',{'OriginalClientStarted':True}),
               ('Launch',{'ExistingClientAttached':True}),
               ('foo',{}),('Attach',{'ClientPID':0}),
               ('Attach',{'CacheSizeMatchedSlots':0}),
               ('Attach',{'XmlCandidates':0}),
               ('Attach',{'XmlCandidates':2})]
        for mode,update in tests:
            with self.subTest(mode=mode,update=update),self.assertRaises(ValueError):
                checked_capture(zip_capture(mode,update))
    def test_world_8_warp_675_4380_rejected_by_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'capture.zip';f.write_bytes(zip_capture())
            report=generate(f,ROOT/'server_registry_evidence.zip')
            self.assertTrue(report['warp_8_675']['has_qdidx_4380'])
            self.assertEqual(report['warp_8_675']['entries'][0]['status'],'missing_dungeon_id')
            self.assertEqual(report['capture']['mode'],'Attach')
    def test_reader_never_edits_game_process(self):
        s=(ROOT/'Mapinfo291CacheReader.cs').read_text()
        p=(ROOT/'Collect-Original-v291-Mapinfo.ps1').read_text()
        for dangerous in ('WriteProcessMemory','VirtualProtectEx','CreateRemoteThread','VirtualAllocEx','TerminateProcess'):
            self.assertNotIn(dangerous,s)
        for dangerous in ('Stop-Process','docker exec','ssh root','Start.bat','taskkill','WriteProcessMemory'):
            self.assertNotIn(dangerous,p)
        self.assertIn('ReadProcessMemory',s)
        self.assertIn('VirtualQueryEx',s)
    def test_attach_uses_exact_original_exe(self):
        p=(ROOT/'Collect-Original-v291-Mapinfo.ps1').read_text()
        self.assertIn('Get-Process -Name CabalMain',p)
        self.assertIn('MainModule.FileName',p)
        self.assertIn('OrdinalIgnoreCase',p)
        self.assertIn("$Mode -eq 'Attach'",p)
        self.assertIn("$Mode -eq 'Launch'",p)
        self.assertIn('MainModule.BaseAddress',p)
    def test_original_unmodified_server_snapshot(self):
        expected='caadebfa61ba3493c3447bf2d4e36aa3b59ca61e5470f9941f74d2d69b31dd37'
        data=(ROOT/'server_registry_evidence.zip').read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(),expected)
    def test_original_enc_hash_from_uploaded_bytes(self):
        import zipfile
        with ZipFile('/mnt/data/v291_DungeonEntrance.zip') as z:
            data=z.read('mapinfo.enc')
        self.assertEqual(len(data),6808)
        self.assertEqual(hashlib.sha256(data).hexdigest(),MAPINFO_ENC_SHA)
    def test_explicit_heuristic_cache_identity_and_error_handling(self):
        code=(ROOT/'Mapinfo291CacheReader.cs').read_text()
        self.assertIn('CacheEntries = 137',code)
        self.assertIn('AMBIGUOUS_MAPINFO_MULTIPLE_CACHE_RECORDS',code)
        self.assertIn('MapinfoBytes = 49101',code)
        self.assertIn('DtdProcessing.Prohibit',code)
        self.assertIn('CheckBase(imageBase)',code)

if __name__=='__main__':
    unittest.main(verbosity=2)
