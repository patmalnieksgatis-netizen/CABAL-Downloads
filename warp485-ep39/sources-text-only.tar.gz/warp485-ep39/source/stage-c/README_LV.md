# CABAL v291 / EP39 — Warp485 C posms (offline)

**STATUSS:** kļūdas izcelsme reproducēta līdz precīzam ELF kļūdas koda veidotājam. Sagatavots **tikai klienta Warp izvēlnes kandidāta rīks** pēc īstā dekodētā XML saņemšanas. Nav gatava izvietojama patch, un ne serverī, ne klientā nav veiktas izmaiņas.

## Pierādītais cēlonis

1. `WorldSvr` trīs reizes saņem `MainCmd(485)` ar `qdIdx(4380)`, noraida to un aizver klienta savienojumu. `WorldSvr` process pats neavarē.
2. Atsauces ELF ar SHA-256 `caec7772acd22fd8918cfac386845c644451781e48c51975eaefed334c6705c3` instrukcijās `0x9DD9AE`, `0x9DD9B8`, `0x9DD9CC`, `0x9DD9E0` redzams: ID no paketes `+0x0A`, Mission Dungeon indekss `qdIdx - 4096` un robežas pārbaude.
3. SCP: `[MD]` galvenie ieraksti ir `4096–4378`, bet `4379` un `4380` nav. Pieprasītais indekss ir `284`; pēdējais konfigurētā dungeon indekss `282`.
4. **Jauns C posma pierādījums**: kļūdas zars `0x9DDF8E` ielādē komponentu `0x35`, `0x9DDF93` ielādē rindas numuru `0x45F` (=1119), izsauc `0x527960`; palīgfunkcijas `0x5279B5`, `0x5279BB`, `0x5279BF` veido `(0x35 << 16) | 0x45F = 0x35045F`. Tā ir tieši logā redzamā `Ret(35045F:53:1119)` vērtība. Bez derīga dungeon ieraksta parastā **77 baitu S2C 485** atbilde netiek veidota.
5. Aktīvā `WorldSvr` pašreizējais SHA nav salīdzināts ar atsauces ELF. Šīs adreses automātiski nepārnest uz procesu.

## Kāpēc crash rodas, atverot Warp izvēlni

RaGEZONE kopienā ir precīzi tāds pats `MainCmd(485)` atvienošanas piemērs. Diskusijā izstrādātājs skaidro, ka viens neeksistējošs dungeon klienta kopīgajā Warp izvēlnē var izraisīt atvienošanu jau **uzklikšķinot uz Warp**, pirms izvēlēts konkrētais dungeon. Tas atbilst mūsu logam, taču **jāapstiprina ar reālo v291 `mapinfo` ierakstu**:

- https://forum.ragezone.com/threads/auto-disconnect-after-trying-to-enter-dungeon.1247710/
- https://forum.ragezone.com/threads/vm-ep33-ep35-extender-ghapi.1244954/page-10

## C posma kods

- `stage_c_audit.py` — pārbauda 15 oriģinālo instrukciju signatūras no diviem ELF koda fragmentiem, oriģinālos SCP ierakstus un visas 3 loga kļūdu ķēdes. Pēc izvēles var pārbaudīt pilnu ELF, ja ir lokāls oriģināls (`--elf path`). **Neko neraksta.**
- `mapinfo_485_stager.py` — no *jau dekodēta* klienta XML uzskaita visus `<warp dungeon_index="4380" ... />` un, tikai skaidri norādot `world_id` + `warp_index`, var izveidot atsevišķu `.candidate.dec` failu bez pārējo baitu pārserializācijas. Pārtrauc darbu pie 0 vai >1 mērķiem. Nekad nepārraksta oriģinālu.
- `Original_Mapinfo_Encrypted.enc` — **neizmainītais** v291 avota fails; šis rīks to neprot atkodēt un atsakās to rediģēt.
- `test_stage_c.py` — 13 automatizēti testi, visi PASS. Tie pārbauda C posma pierādījumus un XML kandidāta drošību, **nevis gameplay**.
- `report.json` — mašīnlasāms ziņojums. `WorldSvr_*_CodeSlice.bin` — koda fragmenti, **nevis binārie patch**.

Offline audit:

```
python stage_c_audit.py
python -m unittest -v test_stage_c
```

Piemērs nākotnes **kandidāta** sagatavošanai, ja precīzs dekodēts XML un pareizais Warp indekss ir jau identificēts:

```
python mapinfo_485_stager.py path/to/mapinfo.dec
python mapinfo_485_stager.py path/to/mapinfo.dec --stage --world-id 11 --warp-index 813 --out path/to/mapinfo.candidate.dec
```

**Piezīme:** `11`/`813` šeit ir *tikai sintētiska testa piemērs*, nevis konstatēti v291 patiesie indeksi. Tos nedrīkst automātiski lietot reālajam klientam.

## Nenovērstās atkarības

1. V291 `mapinfo.enc` (pieejams) pagaidām nav droši atkodēts, un nav pierādīta tieši kura `<warp>` elementa saite uz `4380`.
2. Drošam klienta labojumam vajag precīzu dekodēto `mapinfo` un tā oriģinālam atbilstošu ielādes/atjaunināšanas metodi; šie dati šeit nav pieejami.
3. Alternatīvi īstai dungeon ieejai nepieciešamas pilnas servera `[MD]` definīcijas un saistītās atkarības. Neizdomāt `4379/4380` rindas.
4. Korekta **negatīva S2C 485** atbilde klientam vēl nav pierādīta. **Neaizvietot `WorldSvr` kļūdas atgriešanas kodu ar 0 bez derīgas klienta atbildes.**

## Rollback

Nekas nav instalēts. Serveri, klientu, VM vai Costume/Mileage/CashShop/SkillBook/Guardian bibliotēkas neviens šīs pakotnes fails nemaina. Visi skripti ir offline; kandidāta failu var vienkārši izdzēst.
