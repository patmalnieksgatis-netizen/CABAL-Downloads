#!/usr/bin/env python3
"""Read-only audit & optional *offline* candidate creation for decoded mapinfo XML.

A staged candidate is never installed, and --stage requires a uniquely specified
world_id and warp_index. This script does not understand CABAL .enc encoding.
"""
from __future__ import annotations
import argparse
import difflib
import json
import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

ICON_RE = re.compile(r'<icon\b(?P<attrs>[^>]*)>(?P<body>.*?)</icon\s*>', re.S | re.I)
VALUE_RE = re.compile(r'<icon_value\b(?P<attrs>[^>]*)>(?P<body>.*?)</icon_value\s*>', re.S | re.I)
WARP_RE = re.compile(r'<warp\b(?P<attrs>[^>]*)/\s*>', re.S | re.I)
ATTR_RE = re.compile(r'\b([A-Za-z_][\w:-]*)\s*=\s*(["\'])(.*?)\2', re.S)

def attrs(s: str) -> dict[str,str]:
    return {m.group(1): m.group(3) for m in ATTR_RE.finditer(s)}

def scan(text: str) -> list[dict[str,str]]:
    out=[]
    for icon in ICON_RE.finditer(text):
        world=attrs(icon['attrs']).get('world_id')
        for val in VALUE_RE.finditer(icon['body']):
            wid=attrs(val['attrs']).get('warp_index')
            for w in WARP_RE.finditer(val['body']):
                w_attrs=attrs(w['attrs'])
                out.append({'world_id':world,'warp_index':wid,**w_attrs})
    return out

def stage_candidate(text: str, *, world_id: str, warp_index: str, qdid: str = '4380') -> tuple[str,int]:
    """Remove only exact self-closing <warp dungeon_index=.../> in selected icon_value.

    Never reserialize XML; all non-target bytes are preserved. Refuses 0/multi hits.
    """
    spans=[]
    for icon in ICON_RE.finditer(text):
        if attrs(icon['attrs']).get('world_id') != world_id: continue
        icon_body_offset=icon.start('body')
        for val in VALUE_RE.finditer(icon['body']):
            if attrs(val['attrs']).get('warp_index') != warp_index: continue
            value_offset=icon_body_offset + val.start('body')
            for w in WARP_RE.finditer(val['body']):
                if attrs(w['attrs']).get('dungeon_index') == qdid:
                    spans.append((value_offset+w.start(), value_offset+w.end()))
    if len(spans) != 1:
        raise ValueError(f'EXACTLY_ONE_TARGET_REQUIRED: matches={len(spans)}')
    start,end=spans[0]
    candidate=text[:start]+text[end:]
    if '<warp' in text and len(scan(candidate)) != len(scan(text))-1:
        raise AssertionError('XML_PARSE_SEMANTICS_CHANGED')
    return candidate, 1

def main(argv=None):
    p=argparse.ArgumentParser(description='Offline mapinfo 485 audit; source must be decoded XML')
    p.add_argument('decoded_mapinfo',type=Path)
    p.add_argument('--stage',action='store_true',help='create a separate candidate, never overwrite input')
    p.add_argument('--world-id',type=str)
    p.add_argument('--warp-index',type=str)
    p.add_argument('--out',type=Path)
    args=p.parse_args(argv)
    if args.decoded_mapinfo.suffix.lower()=='.enc':
        p.error('ENC_NOT_SUPPORTED: decoded mapinfo XML required, never edit encrypted source')
    raw=args.decoded_mapinfo.read_bytes(); text=raw.decode('utf-8-sig')
    # Parent XML could contain comments and proprietary wrappers; no schema invention.
    hit=[r for r in scan(text) if r.get('dungeon_index')=='4380']
    print(json.dumps({'4380_menu_entries':hit,'count':len(hit)},ensure_ascii=False,indent=2))
    if not args.stage:
        return 0
    if not args.world_id or not args.warp_index:
        p.error('--stage requires --world-id and --warp-index')
    candidate,_=stage_candidate(text,world_id=args.world_id,warp_index=args.warp_index)
    if candidate == text: raise AssertionError('NO_CHANGE')
    out=args.out or args.decoded_mapinfo.with_suffix('.candidate.dec')
    if out.resolve()==args.decoded_mapinfo.resolve():
        raise ValueError('OVERWRITE_ORIGINAL_REFUSED')
    if out.exists(): raise FileExistsError('CANDIDATE_EXISTS_REFUSED')
    out.write_bytes(candidate.encode('utf-8'))
    print('STAGED_ONLY:',out)
    print(''.join(list(difflib.unified_diff(text.splitlines(True),candidate.splitlines(True),fromfile='before',tofile='candidate'))[:80]))
    return 0

if __name__=='__main__':sys.exit(main())
