import hashlib
import os
import subprocess
import sys
import shutil
import tempfile
import unittest
from pathlib import Path
from stage_c_audit import REFERENCE_SHA, SIGS, verify_elf, verify_slices, analyze_registry, parse_error_events, result, ERR_COMPONENT, ERR_LINE
from mapinfo_485_stager import scan,stage_candidate

BASE=Path(__file__).resolve().parent
ELF=Path('/mnt/data/EP45_WorldSvr')

class TestNative485(unittest.TestCase):
    def test_actual_reference_integrity(self):
        r=verify_slices(BASE)
        self.assertTrue(r['slice_digests_verified'])
        self.assertEqual(r['failures'],[])
        self.assertEqual(r['instructions_checked'],len(SIGS))

    def test_reference_slice_tampering_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            for name in ('WorldSvr_485_CodeSlice.bin','WorldSvr_ErrorHelper_CodeSlice.bin'):
                shutil.copy(BASE/name, Path(tmp)/name)
            target=Path(tmp)/'WorldSvr_485_CodeSlice.bin'
            body=bytearray(target.read_bytes());body[3]^=1;target.write_bytes(body)
            self.assertFalse(verify_slices(tmp)['slice_digests_verified'])

    def test_structured_error_code(self):
        self.assertEqual((ERR_COMPONENT<<16)|ERR_LINE,0x35045F)
        self.assertEqual(ERR_LINE,1119)

    def test_missing_registry_entries(self):
        r=analyze_registry(BASE/'Config_Tables_Snapshot.zip')
        self.assertEqual(r['missing'],[4379,4380])
        self.assertFalse(r['configured'])
        self.assertEqual(r['last_md_index'],282)
        self.assertEqual(r['requested_md_index'],284)

    def test_actual_log_consistent(self):
        r=parse_error_events(BASE/'WorldSvr_Log_Full.txt')
        self.assertEqual(r['count'],3)
        for event in r['events']:
            self.assertTrue(event['native_error_code_present'])
            self.assertTrue(event['maincmd_485_present'])
            self.assertTrue(event['connection_closed'])

    def test_no_fake_negative_reply(self):
        r=result(None,BASE/'Config_Tables_Snapshot.zip', BASE/'WorldSvr_Log_Full.txt')
        self.assertFalse(r['native_invalid_branch_has_s2c_send'])
        self.assertTrue(r['valid_485_reply_is_not_proven_valid_as_negative_reply'])
        self.assertFalse(r['deployable_patch'])

XML='''<?xml version="1.0"?>
<mapinfo><icon world_id="11"><icon_value warp_index="813" type="1">
 <warp order="0" target_world_index="172" dungeon_index="4378" />
 <warp order="1" target_world_index="174" dungeon_index="4380" />
 <warp order="2" target_world_index="173" dungeon_index="4377" />
 </icon_value></icon><icon world_id="12"><icon_value warp_index="821">
 <warp order="0" dungeon_index="4380"/>
 </icon_value></icon></mapinfo>'''

class TestCandidateStaging(unittest.TestCase):
    def test_scan_structure(self):
        x=scan(XML);self.assertEqual(len(x),4)
        self.assertEqual([(t['world_id'],t['warp_index']) for t in x if t.get('dungeon_index')=='4380'], [('11','813'),('12','821')])

    def test_exact_removal_and_all_other_bytes_preserved(self):
        got,n=stage_candidate(XML, world_id='11',warp_index='813')
        self.assertEqual(n,1)
        self.assertNotIn('target_world_index="174"',got)
        self.assertIn('dungeon_index="4378"',got)
        self.assertIn('dungeon_index="4377"',got)
        self.assertIn('<warp order="0" dungeon_index="4380"/>',got)
        self.assertEqual(len(scan(got)),3)

    def test_no_change_if_scope_wrong(self):
        with self.assertRaisesRegex(ValueError, 'EXACTLY_ONE_TARGET_REQUIRED'):
            stage_candidate(XML,world_id='9',warp_index='813')

    def test_ambiguous_scope_fails_closed(self):
        doubled=XML.replace('<warp order="1" target_world_index="174" dungeon_index="4380" />',
             '<warp order="1" target_world_index="174" dungeon_index="4380" /><warp order="3" dungeon_index="4380" />')
        with self.assertRaisesRegex(ValueError, 'matches=2'):
            stage_candidate(doubled,world_id='11',warp_index='813')

    def test_cli_rejects_encrypted_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            filename=Path(tmp)/'mapinfo.enc';filename.write_bytes(b'NOT_XML')
            cmd=[sys.executable,str(BASE/'mapinfo_485_stager.py'),str(filename),'--stage','--world-id','11','--warp-index','813']
            p=subprocess.run(cmd,text=True,capture_output=True)
            self.assertNotEqual(p.returncode,0)
            self.assertIn('ENC_NOT_SUPPORTED',p.stderr)
            self.assertEqual(filename.read_bytes(),b'NOT_XML')

    def test_cli_stages_only_separate_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            orig=Path(tmp)/'mapinfo.dec';orig.write_text(XML)
            candidate=Path(tmp)/'candidate.dec'
            cmd=[sys.executable,str(BASE/'mapinfo_485_stager.py'),str(orig),'--stage','--world-id','11','--warp-index','813','--out',str(candidate)]
            p=subprocess.run(cmd,text=True,capture_output=True)
            self.assertEqual(p.returncode,0,p.stderr)
            self.assertTrue(candidate.exists())
            self.assertEqual(orig.read_text(),XML)
            self.assertEqual(len(scan(candidate.read_text())),3)
            again=subprocess.run(cmd,text=True,capture_output=True)
            self.assertNotEqual(again.returncode,0)
            self.assertIn('CANDIDATE_EXISTS_REFUSED',again.stderr)

    def test_does_not_write_files_while_staging_model(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'mapinfo.dec';path.write_text(XML)
            before=hashlib.sha256(path.read_bytes()).hexdigest()
            candidate,_=stage_candidate(path.read_text(),world_id='11',warp_index='813')
            out=Path(t)/'candidate.xml';out.write_text(candidate)
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),before)
            self.assertNotEqual(path.read_bytes(),out.read_bytes())

if __name__=='__main__': unittest.main()
