#!/usr/bin/env python3
"""Read-only forensic analysis of native WorldSvr opcode 485 error path.

NO server access, NO executable patching, NO wire-reply fabrication.
"""
import argparse
import hashlib
import json
import re
import struct
import zipfile
from pathlib import Path

REFERENCE_SHA = 'caec7772acd22fd8918cfac386845c644451781e48c51975eaefed334c6705c3'
OPCODE = 485
FAILED_QD = 4380
ERR_LINE = 1119
ERR_COMPONENT = 0x35
MD_BASE = 0x1000

# Exact instruction bytes from the independently obtained ELF, checked by file hash.
SIGS = {
    0x9DD9AE: '8b580a',               # mov ebx, [rax+0xa]
    0x9DD9B8: '81fbff0f0000',         # cmp ebx, 0xfff
    0x9DD9CC: '448db300f0ffff',       # lea r14d, [rbx - 0x1000]
    0x9DD9E0: '0f8f5a050000',         # jg invalid label
    0x9DDA3A: 'b9e5010000',           # reply opcode 485 (only valid path)
    0x9DDA49: 'c74580e2b74d00',       # reply header/length 0x4d
    0x9DDEF5: 'ba4d000000',           # send length 77
    0x9DDF01: 'ff9068010000',         # send via vtable (normal path)
    0x9DDF07: '31c0',                 # normal return 0
    0x9DDF8E: 'b935000000',           # error component 0x35
    0x9DDF93: 'ba5f040000',           # error line 0x45f = 1119
    0x9DDFA2: 'e8b999b4ff',           # call error helper
    0x5279B5: '89d8',                 # helper: mov eax, ebx (component)
    0x5279BB: 'c1e010',               # helper: shl eax, 16
    0x5279BF: '4409e0',               # helper: or eax,r12d (line)
}

def vaddr_offset(data, vaddr):
    assert data[:5] == b'\x7fELF\x02', 'ELF64 required'
    assert data[5] == 1, 'little-endian required'
    phoff = struct.unpack_from('<Q',data,0x20)[0]
    entsize, n = struct.unpack_from('<HH',data,0x36)
    for i in range(n):
        entry = phoff + entsize*i
        if struct.unpack_from('<I', data, entry)[0] != 1: continue
        off, va, _, size = struct.unpack_from('<QQQQ',data, entry+8)
        if va <= vaddr < va + size: return off + vaddr - va
    raise ValueError('Address is not file backed')

SLICE_BASES = {0x9dd960:'WorldSvr_485_CodeSlice.bin', 0x527960:'WorldSvr_ErrorHelper_CodeSlice.bin'}
SLICE_SHA256 = {
    'WorldSvr_485_CodeSlice.bin': '0c9ea62b90a344b7d7528b84bca6986f2797eb037ec8de8d46bace85c9071494',
    'WorldSvr_ErrorHelper_CodeSlice.bin': '715372211cc00500945f036a22fafbe5c10f43a86a1990629fe9e1319e69a47d',
}

def verify_slices(directory):
    directory=Path(directory)
    failures=[]
    source={}
    for base,name in SLICE_BASES.items():
        data=(directory/name).read_bytes()
        digest=hashlib.sha256(data).hexdigest()
        if digest!=SLICE_SHA256[name]:failures.append(f'{name}:hash')
        source[base]=data
    for address,hexbytes in SIGS.items():
        base=max(b for b in source if b<=address)
        data=source[base]; offset=address-base
        if data[offset:offset+len(bytes.fromhex(hexbytes))]!=bytes.fromhex(hexbytes):
            failures.append(f'{hex(address)}:instruction')
    return {'slice_digests_verified':len(failures)==0, 'instructions_checked':len(SIGS),'failures':failures,
            'reference_elf_sha256':REFERENCE_SHA, 'full_elf_sha256_verified_here':False}

def verify_elf(path):
    data=Path(path).read_bytes(); sha=hashlib.sha256(data).hexdigest()
    if sha != REFERENCE_SHA:
        return {'sha256':sha,'matches_reference':False,'instruction_verification':'SKIPPED_HASH_MISMATCH'}
    failed=[]
    for addr,hexbytes in SIGS.items():
        b=bytes.fromhex(hexbytes); off=vaddr_offset(data,addr)
        if data[off:off+len(b)]!=b: failed.append(hex(addr))
    return {'sha256':sha,'matches_reference':True,'verified_instructions':len(SIGS),'mismatches':failed}

def md_main_records(data):
    text=data.decode('utf-8-sig',errors='replace')
    found={}; active=False
    for line in text.splitlines():
        columns=line.strip().split()
        if not columns: continue
        if columns[0].startswith('['):
            active = columns[0] == '[MD]'
            continue
        if not active or len(columns)<2: continue
        try: row_index=int(columns[0]); qdid=int(columns[1])
        except ValueError: continue
        found[qdid] = {'row_index': row_index,'line':line}
    return found

def analyze_registry(snapshot):
    with zipfile.ZipFile(snapshot) as z:
        files=['MissionDungeon.scp','MissionDungeon2.scp']
        d={n:md_main_records(z.read(n)) for n in files}
    combined={}
    for mapping in d.values():combined.update(mapping)
    candidates=sorted(combined)
    return {
        'source_tables': {n:len(x) for n,x in d.items()},
        'first_qdid':candidates[0], 'last_qdid':candidates[-1],
        'last_md_index':candidates[-1]-MD_BASE,
        'requested_qdid':FAILED_QD, 'requested_md_index':FAILED_QD-MD_BASE,
        'missing': [x for x in range(candidates[-1]+1, FAILED_QD+1) if x not in combined],
        'configured':FAILED_QD in combined,
        'main_header_4379':4379 in combined,
    }

def parse_error_events(path):
    lines=Path(path).read_text(encoding='utf-8-sig',errors='replace').splitlines()
    events=[]
    for i,line in enumerate(lines):
        if 'OnCSCQDungeonLimitCheck(): invalid qdIdx(4380)' in line:
            following='\n'.join(lines[i+1:i+5]);
            events.append({'invalid_qdid':4380,
                           'native_error_code_present':'35045F:53:1119' in following,
                           'maincmd_485_present':'MainCmd(485)' in following,
                           'connection_closed':'close(): closing' in following})
    return {'events':events, 'count':len(events)}

def result(elf,snapshot,log):
    code=(ERR_COMPONENT<<16)|ERR_LINE
    output={'error_code':f'0x{code:06X}', 'error_number_decimal':code,
       'error_builder':'(0x35 << 16) | 0x45F',
       'log_expected':'Ret(35045F:53:1119)',
       'native_invalid_branch_has_s2c_send':False,
       'native_valid_branch_reply_length':77,
       'native_valid_branch_reply_opcode':485,
       'valid_485_reply_is_not_proven_valid_as_negative_reply':True,
       'native_reference':verify_elf(elf) if elf is not None else verify_slices(Path(__file__).resolve().parent),
       'registry':analyze_registry(snapshot),
       'log':parse_error_events(log),
       'deployable_patch':False}
    return output

def main():
    p=argparse.ArgumentParser()
    base=Path(__file__).resolve().parent
    p.add_argument('--elf',type=Path,help='Optional 11 MB reference ELF; otherwise verify packaged code slices')
    p.add_argument('--snapshot',default=str(base/'Config_Tables_Snapshot.zip'))
    p.add_argument('--log',default=str(base/'WorldSvr_Log_Full.txt'))
    a=p.parse_args()
    print(json.dumps(result(a.elf,a.snapshot,a.log),indent=2,ensure_ascii=False))

if __name__=='__main__': main()
