import io
import json
import unittest
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from xml.etree import ElementTree as ET
import warp_registry_world_audit as m

ROOT=Path(__file__).parent
REF=ROOT/'REFERENCE_UNVERIFIED_mapinfo.dec'
REG=ROOT/'server_registry_evidence.zip'
RAW=REF.read_bytes()
REGDATA=REG.read_bytes()

class AuditStageF(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.registry=m.registry_from_zip(REG)
  cls.candidate,cls.report=m.full_audit(RAW,REG)
 def test_reference_sha(self):
  self.assertEqual(m.digest(RAW),'83bec4c54dc68ea6ec4a6bf333cab1323092711a11546a9ad84c2a17d7540e86')
 def test_registry_world_and_absence(self):
  self.assertEqual(self.registry[4378]['world'],172)
  self.assertEqual(self.registry[4352]['world'],138)
  for d in range(4379,4384):self.assertNotIn(d,self.registry)
 def test_global_consistency_counts(self):
  self.assertEqual(self.report['total_dungeon_entries'],81)
  self.assertEqual(self.report['counts'],{'id_and_world_match':70,'missing_dungeon_id':10,'world_mismatch':1})
 def test_world_mismatch_unique(self):
  mm=[r for r in self.report['discrepancies'] if r['status']=='world_mismatch']
  self.assertEqual(len(mm),1)
  self.assertEqual((mm[0]['dungeon_id'],mm[0]['target_world'],mm[0]['server_world'],mm[0]['warp_index']), (4378,166,172,'675'))
 def test_target_candidate_valid_only(self):
  result=m.target_group(self.candidate)
  self.assertEqual([x.get('dungeon_index') for x in result.findall('warp')],['4352'])
  self.assertEqual([x.get('order') for x in result.findall('warp')],['0'])
 def test_only_six_rows_removed(self):
  removed=self.report['target_group_change']['removed']
  self.assertEqual([int(x['dungeon_index']) for x in removed],list(range(4378,4384)))
  self.assertEqual([x['reason'] for x in removed],['world_mismatch']+['missing_id']*5)
  self.assertEqual(len(RAW)-len(self.candidate),sum(len(line) for line in RAW.splitlines(keepends=True)
      if b'dungeon_index="4378"' in line or any(f'dungeon_index="{x}"'.encode() in line for x in range(4379,4384))))
 def test_outside_target_group_unmodified(self):
  import re
  a=m.BLOCK_RE.search(RAW);b=m.BLOCK_RE.search(self.candidate)
  self.assertIsNotNone(a);self.assertIsNotNone(b)
  self.assertEqual(RAW[:a.start('body')],self.candidate[:b.start('body')])
  self.assertEqual(RAW[a.end('body'):],self.candidate[b.end('body'):])
 def test_original_server_snapshot_unchanged(self):
  self.assertEqual(REG.read_bytes(),REGDATA)
  self.assertEqual(REF.read_bytes(),RAW)
 def test_bogus_encrypted_binary_refused(self):
  with self.assertRaises(ValueError):m.entries_in_xml(b'\xcd\xbf\x00\x00garbage')
  with self.assertRaises(ValueError):m.reference_candidate(b'\xcd\xbf\x00\x00garbage',self.registry)
 def test_duplicate_group_refused(self):
  import re
  x=m.BLOCK_RE.search(RAW)
  self.assertIsNotNone(x)
  duplicate=RAW.replace(x.group(),x.group()+x.group(),1)
  with self.assertRaises(ValueError):m.target_group(duplicate)
 def test_restage_refused(self):
  with self.assertRaises(ValueError):m.reference_candidate(self.candidate,self.registry)
 def test_row_zero_is_not_dungeon(self):
  entries=m.entries_in_xml(RAW)
  self.assertTrue(all(x['dungeon_id']>0 for x in entries))
  self.assertIn(b'dungeon_index="0"', RAW)
 def test_world_consistency_is_real_guard(self):
  changed=RAW.replace(b'target_world_index="166"',b'target_world_index="172"',1)
  c,rep=m.reference_candidate(changed,self.registry)
  self.assertEqual(rep['retained_ids'],[4352,4378])
  self.assertEqual([int(x['dungeon_index']) for x in rep['removed']],list(range(4379,4384)))
 def test_target_scope_world_specific(self):
  entries=m.entries_in_xml(RAW)
  mismatched=[e for e in entries if e['icon_world']=='8' and e['warp_index']=='675']
  self.assertEqual([e['dungeon_id'] for e in mismatched],[4352,4378,4379,4380,4381,4382,4383])
 def test_candidate_is_not_game_enc(self):
  self.assertTrue(self.candidate.startswith(b'<cabal>'))
  self.assertFalse(self.report['target_group_change']['installable_enc'])
  self.assertFalse(self.report['production_change'])

if __name__=='__main__':unittest.main(verbosity=2)
