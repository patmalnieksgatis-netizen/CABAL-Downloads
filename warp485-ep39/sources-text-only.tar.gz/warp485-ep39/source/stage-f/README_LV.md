# CABAL v291 Warp485 — F posms (tikai atsauces XML)

## Jauns atradums

Iepriekšējais E posma kandidāts pārbaudīja tikai to, vai `dungeon_index` pastāv serverī, un **nepārbaudīja atbilstošo `WorldIdx`**. Tas bija nepietiekami.

Salīdzinot 81 dungeon ierakstu no atkodēta cita CABAL arhīva `mapinfo` ar iesūtīto v291 servera konfigurāciju:

- 70 ierakstos sakrīt gan dungeon ID, gan `target_world_index` ar servera `WorldIdx`.
- 10 ierakstos dungeon ID v291 serverī nav.
- 1 ierakstā **ID eksistē, taču World ID nesakrīt**: `dungeon_index=4378`, reference World 166, serveris World 172.

Šī vienīgā pasaules neatbilstība ir tieši World 8 / Warp 675 izvēlnē, kur parādās arī `qdIdx=4380`. `4352` ir vienīgais šīs konkrētās atsauces izvēlnes ieraksts, kuram sakrīt gan ID, gan World ID (`138`).

## Kāpēc tas ir svarīgi

Bez papildu pārbaudes `4378` varētu tikt pieņemts kā derīgs dungeon, lai gan šajā atsauces izvēlnē tas norāda uz citu pasauli. Tādēļ **E posma kandidātu nedrīkst izmantot kā pilnīgu saderības filtru**.

F posma demonstrācijā **tikai uz alternatīva, neapstiprināta avota XML** izņem `4378–4383`, atstāj `4352`. Maina tikai sešas pilnas `<warp .../>` rindas; neskar izvēlni un XML ārpus World 8 / Warp 675 grupas. Saglabātā ieraksta `order` ir `0`.

## Faili

- `warp_registry_world_audit.py` — neatkarīgs servera `[QuestDungeon]` un `[MD]` reģistru parsētājs; salīdzina ID **un** WorldIdx; pieņem tikai dekodētu XML.
- `test_stage_f.py` — vienības/regresijas testi, ieskaitot gadījumu, kad 4378 pasaules ID tiek tīši izlabots, lai pārbaudītu precīzu filtra uzvedību.
- `report.json` — visu 81 atsauces izvēlnes ierakstu salīdzinājuma neatbilstības.
- `REFERENCE_UNVERIFIED_mapinfo.dec` — no *cita* CABAL arhīva dekodēts resursa piemērs, NAV v291 klienta fails.
- `REFERENCE_ONLY_Warp675_world_checked.dec` — demonstrācijas kandidāts, **nav instalējama .enc datne**.
- `server_registry_evidence.zip` — iesūtītās servera konfigurācijas izvilkums.

Pārbaude: `python3 -m unittest -v test_stage_f.py` no pakotnes mapes. Kods ir lokāls un tikai lasa failus; pārbaudes neraksta spēles failus.

## Stingrs ierobežojums

Sākotnējais `mapinfo.enc` no faktiskā v291 klienta joprojām nav atkodēts un spēlē kandidāts nav testēts. Netiek aizvietots v291 klients, `WorldSvr`, `.so` faili, SQL vai servera konfigurācijas. F posms nepretendē uz uzstādāmu labojumu vai uz pierādījumu, ka tieši šādas ir v291 klienta izvēlnes rindas. Tas izlabo **analīzes kļūdu**, nevis uzstāda produkcijas labojumu.
