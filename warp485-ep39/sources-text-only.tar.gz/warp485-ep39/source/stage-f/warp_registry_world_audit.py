#!/usr/bin/env python3
"""Read-only cross-check of decoded CABAL mapinfo XML and server dungeon registry.

* No ENC decoder; never modifies the encrypted client input.
* References in this package belong to an unverified different CABAL archive.
* A candidate XML output, when requested, is unencoded REFERENCE ONLY.
"""
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from hashlib import sha256
import argparse
import json
import re

TARGET_WORLD = "8"
TARGET_WARP = "675"
TARGET_TYPE = "3"
BLOCK_RE = re.compile(rb'(?P<open><icon_value\b[^>]*\bwarp_index="675"[^>]*>)(?P<body>.*?)(?P<close></icon_value>)', re.DOTALL)
LINE_RE = re.compile(rb'(?m)^[ \t]*<warp\b[^\r\n]*?/>[ \t]*(?:\r\n|\n|\r)')


def digest(content: bytes) -> str:
    return sha256(content).hexdigest()


def registry_from_zip(archive: Path) -> dict[int, dict]:
    rows: dict[int, dict] = {}
    with ZipFile(archive) as z:
        for filename, section in [
            ("QuestDungeon.scp", "QuestDungeon"),
            ("MissionDungeon.scp", "MD"),
            ("MissionDungeon2.scp", "MD"),
        ]:
            data = z.read(filename).decode("utf-8-sig").splitlines()
            hidx = next(i for i, r in enumerate(data) if r.startswith("[" + section + "]"))
            header = data[hidx].split()
            idcol = header.index("QDungeonIdx")
            worldcol = header.index("WorldIdx")
            for line in data[hidx + 1 :]:
                if line.startswith("["):
                    break
                cells = line.split()
                if not cells:
                    continue
                assert len(cells) >= len(header), (filename, line)
                dungeon_id = int(cells[idcol])
                world = int(cells[worldcol])
                if dungeon_id in rows:
                    raise ValueError(f"DUPLICATE_DUNGEON_ID {dungeon_id}")
                rows[dungeon_id] = {"id": dungeon_id, "world": world, "file": filename}
    return rows


def entries_in_xml(raw: bytes):
    if not raw.lstrip().startswith(b"<"):
        raise ValueError("REFUSE_NON_XML_INPUT_NOT_DECODED")
    root = ET.fromstring(raw)
    result = []
    for icon in root.findall(".//icon"):
        world = icon.get("world_id")
        for group in icon.findall("icon_value"):
            for item in group.findall("warp"):
                dungeon_id = int(item.get("dungeon_index", "0"))
                if dungeon_id == 0:
                    continue  # ordinary warp, not a dungeon
                result.append({
                    "icon_world": world,
                    "warp_index": group.get("warp_index"),
                    "group_type": group.get("type"),
                    "dungeon_id": dungeon_id,
                    "target_world": int(item.attrib["target_world_index"]),
                    "order": int(item.attrib["order"]),
                })
    return result


def classify(raw: bytes, registry: dict[int, dict]):
    checked = entries_in_xml(raw)
    results = []
    for item in checked:
        row = registry.get(item["dungeon_id"])
        result = dict(item)
        result["server_world"] = row["world"] if row else None
        result["status"] = (
            "missing_dungeon_id" if not row else
            "world_mismatch" if row["world"] != item["target_world"] else
            "id_and_world_match"
        )
        results.append(result)
    return results


def target_group(raw: bytes):
    root = ET.fromstring(raw)
    groups = [v for icon in root.findall(".//icon") if icon.get("world_id") == TARGET_WORLD
              for v in icon.findall("icon_value")
              if v.get("warp_index") == TARGET_WARP and v.get("type") == TARGET_TYPE]
    if len(groups) != 1:
        raise ValueError(f"TARGET_GROUP_COUNT_{len(groups)}")
    return groups[0]


def reference_candidate(raw: bytes, reg: dict[int, dict]):
    """Safely removes unsupported rows only in an explicit decoded XML reference."""
    if not raw.startswith(b"<"):
        raise ValueError("REFUSE_ENCRYPTED_BINARY")
    group = target_group(raw)
    original = [dict(x.attrib) for x in group.findall("warp")]
    matches = list(BLOCK_RE.finditer(raw))
    if len(matches) != 1:
        raise ValueError("TARGET_WARP_BLOCK_NOT_UNIQUE")
    match = matches[0]
    spans = list(LINE_RE.finditer(match.group("body")))
    if len(spans) != len(original):
        raise ValueError("XML_WARP_LINE_COUNT_MISMATCH")
    kept: list[dict] = []
    dropped: list[dict] = []
    chunks = []
    body = match.group("body")
    pos = 0
    for span in spans:
        original_item = ET.fromstring(span.group().strip()).attrib
        d = int(original_item["dungeon_index"])
        w = int(original_item["target_world_index"])
        row = reg.get(d)
        valid = d == 0 or (row is not None and row["world"] == w)
        chunks.append(body[pos:span.start()])
        if valid:
            chunks.append(span.group())
            kept.append(dict(original_item))
        else:
            dropped.append({**original_item, "server_world": None if row is None else row["world"],
                            "reason": "missing_id" if row is None else "world_mismatch"})
        pos = span.end()
    chunks.append(body[pos:])
    if not dropped:
        raise ValueError("NO_UNSUPPORTED_ENTRIES_IN_TARGET")
    if [int(x["order"]) for x in kept] != list(range(len(kept))):
        raise ValueError("ORDER_HAS_GAPS_AFTER_REMOVAL_REFUSE_TO_RENUMBER")
    candidate = raw[:match.start("body")] + b"".join(chunks) + raw[match.end("body"):]
    after = [dict(x.attrib) for x in target_group(candidate).findall("warp")]
    if after != kept:
        raise ValueError("POST_WRITE_CHECK_FAILED")
    if len(candidate) != len(raw) - sum(len(sp.group()) for sp in spans
                                      if int(ET.fromstring(sp.group().strip()).get("dungeon_index"))
                                      in {int(x["dungeon_index"]) for x in dropped}):
        raise ValueError("UNEXPECTED_BYTE_CHANGE")
    return candidate, {"before_ids": [int(x["dungeon_index"]) for x in original],
                       "retained_ids": [int(x["dungeon_index"]) for x in kept],
                       "removed": dropped,
                       "decoded_reference_sha256": digest(raw),
                       "reference_candidate_sha256": digest(candidate),
                       "source_verified_v291": False,
                       "installable_enc": False}


def full_audit(raw: bytes, server: Path):
    reg = registry_from_zip(server)
    rows = classify(raw, reg)
    statuses = ("id_and_world_match", "missing_dungeon_id", "world_mismatch")
    candidate, diff = reference_candidate(raw, reg)
    return candidate, {"source": "UNVERIFIED_ALTERNATE_CLIENT_REFERENCE",
                       "total_dungeon_entries": len(rows),
                       "counts": {key: sum(x["status"] == key for x in rows) for key in statuses},
                       "discrepancies": [x for x in rows if x["status"] != "id_and_world_match"],
                       "target_world": int(TARGET_WORLD), "target_warp": int(TARGET_WARP),
                       "target_group_change": diff, "production_change": False}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("decoded_reference", type=Path)
    p.add_argument("server_registry_zip", type=Path)
    p.add_argument("--candidate-out", type=Path)
    p.add_argument("--report-out", type=Path)
    args = p.parse_args()
    raw = args.decoded_reference.read_bytes()
    candidate, report = full_audit(raw, args.server_registry_zip)
    for output, data in [(args.candidate_out, candidate),
                         (args.report_out, json.dumps(report, indent=2, ensure_ascii=False).encode())]:
        if output is not None:
            if output.exists() or output.resolve() in (args.decoded_reference.resolve(), args.server_registry_zip.resolve()):
                raise ValueError("REFUSE_EXISTING_OR_ORIGINAL_OUTPUT_PATH")
            output.write_bytes(data)
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
