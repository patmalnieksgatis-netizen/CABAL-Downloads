@echo off
cd /d "%~dp0"
py -3 tools\test_stagek.py
if errorlevel 1 (
  echo STAGE_K_TESTS_FAILED
  pause
  exit /b 1
)
py -3 tools\stagek_audit.py > stagek_runtime_report.json
if errorlevel 1 (
  echo STAGE_K_AUDIT_FAILED
  pause
  exit /b 1
)
echo OFFLINE_AUDIT_COMPLETE - see stagek_runtime_report.json
pause
