import hashlib
import json
import sys
from pathlib import Path
import unittest
import zlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
import stagek_audit as s

class Tests(unittest.TestCase):
    def test_archived_inputs(self):
        status=s.audit()
        self.assertTrue(all(v['pinned'] for v in status['inputs'].values()))
    def test_mapinfo_sha(self):
        self.assertEqual(s.audit()['inputs']['mapinfo.enc']['sha256'],s.PINNED['mapinfo.enc'][0])
    def test_mapinfo_header(self):
        self.assertEqual(s.audit()['inputs']['mapinfo.enc']['declared_unpacked_bytes'],49101)
    def test_cache_layout(self):
        self.assertTrue(s.audit()['static']['cache_record_layout_verified'])
    def test_pointer_release(self):
        self.assertTrue(s.audit()['static']['cache_pointer_clear_verified'])
    def test_code_integrity(self):
        self.assertTrue(s.audit()['static']['section_sha256_verified'])
    def test_default_key_unverified(self):
        self.assertFalse(s.audit()['codec']['default_cabal']['validated_all_four'])
    def test_non_installable(self):
        self.assertIn(s.audit()['status'], ('OFFLINE_EVIDENCE_VERIFIED_NO_INSTALLABLE_PATCH','CODEC_KEY_VALIDATED_OFFLINE_NO_GAME_TEST'))
    def test_roundtrip_synthetic(self):
        original=b'<cabal>' + b'<warp id="675"/>'*777 + b'</cabal>'
        enc=s.pack_enc(original,s.DEFAULT_XOR)
        self.assertEqual(s.unpack_enc(enc,s.DEFAULT_XOR),original)
    def test_corruption_detected(self):
        original=b'<cabal>test</cabal>'*17
        raw=s.pack_enc(original,s.DEFAULT_XOR)
        with self.assertRaises(ValueError):s.unpack_enc(raw[:8],s.DEFAULT_XOR)
    def test_codec_wrong_key(self):
        original=b'<cabal>test</cabal>'*17
        raw=s.pack_enc(original,s.DEFAULT_XOR)
        with self.assertRaises(ValueError):s.unpack_enc(raw,bytes.fromhex('12345678'))
    def test_no_process_or_server_action(self):
        self.assertTrue(s.audit()['read_only'])
        self.assertFalse(s.audit()['server_changed'])

if __name__=='__main__':unittest.main(verbosity=2)
