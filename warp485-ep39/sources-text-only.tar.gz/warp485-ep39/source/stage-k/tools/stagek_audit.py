#!/usr/bin/env python3
"""Independent offline CABAL v291 evidence and codec compatibility audit.

Reads packaged snapshots only. Never connects to a game/server, changes an ENC,
patches a binary, or writes to a client directory. Fails closed on any mismatch.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
import xml.etree.ElementTree as ET
from zipfile import ZipFile
import zlib

ROOT = Path(__file__).resolve().parent.parent
PINNED = {
    'mapinfo.enc': ('88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc', 6808, 49101),
    'Warp.enc': ('40ffd038a5e61fca8d9f91b52843d4edf074f61484189bf3bcce53f2787b0f70', 15698, 146278),
    'quest.enc': ('c298999da93d3d1c3e415b1618efeda80362e7247945e26226090a29ee18ea3d', 113689, 1670353),
    'LegacyTicket.enc': ('8da583b0edceae83fad0db40c7f652d6b952c5a966b8ee3458f3b0ddad4b4dc4', 3364, 44324),
}
PINNED_EXE = '52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
DEFAULT_XOR = bytes.fromhex('92656757')
MAX_SIZE = 4 * 1024 * 1024


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def unpack_enc(data: bytes, key: bytes) -> bytes:
    if len(key) != 4 or len(data) < 8:
        raise ValueError('INVALID_KEY_OR_ENC_LENGTH')
    length = int.from_bytes(data[:4], 'little')
    if not 0 < length <= MAX_SIZE:
        raise ValueError('IMPLAUSIBLE_UNPACKED_SIZE')
    payload = bytearray(data[4:])
    for i in range(4):
        payload[i] ^= key[i]
    dec = zlib.decompressobj(wbits=-15)
    try:
        output = dec.decompress(payload, MAX_SIZE + 1)
        output += dec.flush()
    except zlib.error as exc:
        raise ValueError('RAW_DEFLATE_FAILED') from exc
    if not dec.eof or dec.unused_data or len(output) != length:
        raise ValueError('DEFLATE_INCOMPLETE_OR_SIZE_MISMATCH')
    return output


def pack_enc(original: bytes, key: bytes, level: int = 9) -> bytes:
    if len(key) != 4 or not original or len(original) > MAX_SIZE:
        raise ValueError('INVALID_KEY_OR_DATA')
    obj = zlib.compressobj(level, zlib.DEFLATED, wbits=-15)
    payload = bytearray(obj.compress(original) + obj.flush())
    if len(payload) < 4:
        raise ValueError('TOO_SMALL')
    for i in range(4):
        payload[i] ^= key[i]
    return struct.pack('<I', len(original)) + payload


def inspect_static_code(data: bytes) -> dict:
    out = {'section_sha256_verified': False, 'cache_record_layout_verified': False,
           'cache_pointer_clear_verified': False, 'source_codec_key_verified_for_v291': False}
    with ZipFile(ROOT / 'data/v291_Codec_Code_Sections.zip') as z:
        manifest = json.loads(z.read('manifest.json'))
        out['section_sha256_verified'] = manifest['client_sha256'] == PINNED_EXE and all(
            sha(z.read(item['file'])) == item['sha256'] for item in manifest['extracted'])
        by_name = {item['file']: item for item in manifest['extracted']}
        cache = z.read('CacheReader_14021CDDB.bin')
        base = int(by_name['CacheReader_14021CDDB.bin']['virtual_address_start'], 16)
        off = lambda a: a - base
        # 0x14021BB6C: cmp edx, 0x88, and 0x14021BB8D: shl rax, 4
        out['cache_record_layout_verified'] = (
            cache[off(0x14021BB6C):off(0x14021BB72)] == bytes.fromhex('81fa88000000')
            and cache[off(0x14021BB8D):off(0x14021BB91)] == bytes.fromhex('48c1e004'))
        # 0x14021BB54 call to free (target 0x1409F8F1C),
        # 0x14021BB59 and qword ptr [rdi+rbx*8], 0.
        out['cache_pointer_clear_verified'] = (
            cache[off(0x14021BB54):off(0x14021BB59)] == bytes.fromhex('e8c3d37d00')
            and cache[off(0x14021BB59):off(0x14021BB5E)] == bytes.fromhex('488324df00'))
        # The included inflate snippet at 0x1402B7A90 has DEFAULT CABAL XOR.
        # This is not proof that this path decodes these four v291 resources.
        inflate = z.read('ResourceLoader_1402B5550.bin')
        start = int(by_name['ResourceLoader_1402B5550.bin']['virtual_address_start'],16)
        f=0x1402B7A90-start
        out['standard_xor_function_present'] = (inflate[f:f+4] == bytes.fromhex('4c634914')
                 and bytes.fromhex('83f057') in inflate[f:f+130]
                 and bytes.fromhex('83f065') in inflate[f:f+130]
                 and bytes.fromhex('83f067') in inflate[f:f+130])
    return out


def audit(root: Path = ROOT, extra_key: bytes | None = None) -> dict:
    status = {'status':'OFFLINE_EVIDENCE_VERIFIED_NO_INSTALLABLE_PATCH',
              'scope':'isolated snapshot, not active v291 client/server',
              'read_only':True, 'client_files_changed':False, 'server_changed':False,
              'inputs':{}, 'codec':{}, 'static':{}}
    with ZipFile(root / 'data/v291_DungeonEntrance.zip') as z:
        all_data = {n:z.read(n) for n in PINNED}
    for n, (pin, size, decoded_len) in PINNED.items():
        blob = all_data[n]
        info = {'bytes':len(blob),'sha256':sha(blob),
                'declared_unpacked_bytes':int.from_bytes(blob[:4],'little'),
                'pinned':len(blob)==size and sha(blob)==pin and int.from_bytes(blob[:4],'little')==decoded_len}
        status['inputs'][n] = info
    if not all(v['pinned'] for v in status['inputs'].values()):
        status['status']='INPUT_PIN_MISMATCH'; return status
    status['static'] = inspect_static_code(b'')
    if not all(status['static'].get(x) for x in ('section_sha256_verified','cache_record_layout_verified','cache_pointer_clear_verified')):
        status['status']='STATIC_EVIDENCE_MISMATCH'; return status
    def check_codec(key: bytes) -> dict:
        items={}
        for name, blob in all_data.items():
            try:
                output=unpack_enc(blob,key)
                ET.fromstring(output)
                repacked=pack_enc(output,key)
                repeated=unpack_enc(repacked,key)
                if repeated!=output: raise ValueError('ROUNDTRIP_FAILED')
                items[name]={'success':True,'unpacked_sha256':sha(output),
                             'roundtrip_success':True}
            except (ValueError,ET.ParseError) as exc:
                items[name]={'success':False,'reason':type(exc).__name__}
        return {'key_hex':key.hex(), 'results':items, 'validated_all_four':all(i['success'] for i in items.values())}
    status['codec']['default_cabal'] = check_codec(DEFAULT_XOR)
    if extra_key is not None:
        status['codec']['candidate_key'] = check_codec(extra_key)
    verified = status['codec'].get('candidate_key',status['codec']['default_cabal'])['validated_all_four']
    if verified:
        status['status']='CODEC_KEY_VALIDATED_OFFLINE_NO_GAME_TEST'
        status['static']['source_codec_key_verified_for_v291']=True
    status['blocked_steps'] = [] if verified else ['authentic_mapinfo_decode','trusted_v291_encoder','installable_client_enc']
    status['gameplay_tested']=False
    return status


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--key',help='Optional candidate XOR key as exactly 8 hex chars (no key guessing)')
    ap.add_argument('--out',type=Path,help='Optional output report JSON, not a client file')
    args=ap.parse_args()
    key=None
    if args.key:
        try:key=bytes.fromhex(args.key)
        except ValueError:ap.error('key must be 8 hex chars')
        if len(key)!=4:ap.error('key must be 8 hex chars')
    result=audit(extra_key=key)
    out=json.dumps(result,ensure_ascii=False,indent=2)
    print(out)
    if args.out:
        if args.out.suffix.lower()!='.json' or args.out.exists():ap.error('output must be a NEW .json report')
        args.out.write_text(out+'\n',encoding='utf-8')
    return 1 if result['status'].endswith('MISMATCH') else 0

if __name__=='__main__':sys.exit(main())
