# CABAL v291 / EP39 — Stage K, neatkarīgs offline izmeklējums

**Datums:** 2026-11-18.  **Reālas spēles labojuma statuss:** NAV APSTIPRINĀTS.

## Kas izdarīts

- Šajā pakotnē ir precīzs oriģinālā v291 `v291_DungeonEntrance.zip` kopējums ar četriem `.enc` resursiem un `v291_Codec_Code_Sections.zip`, nevis neatbilstoša EP45 klienta faili.
- `data/v291_DungeonEntrance.zip` esošais `mapinfo.enc` (6808 B) ir autentisks pēc iepriekš fiksētā SHA256 `88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc`. Tā sākuma garuma lauks = 49101 B.
- Statiskā x64 koda izpēte apstiprināja, ka `0x14021BB6C` pieļauj indeksus līdz 136, `0x14021BB8D` veido 16 baitu ieraksta nobīdi, un `0x14021BB38..BB5E` satur resursa pointera atbrīvošanas/attīrīšanas ceļu. Šis ir tiešs izskaidrojums, kā var palikt saglabāts *izmērs* un būt nulles *pointeris*, taču **nav dinamiski pierādīts**, ka tieši `mapinfo` tā tiek atbrīvots.
- Lietotāja reālajā Windows atmiņas diagnostikā `index 28: ptr=0x0 size=49102`. No šī vien paša nedrīkst secināt, ka `mapinfo` nav ielādēts vai ka adreses ir nepareizas.
- Publiska `libcozip` implementācija izmanto 4 sākuma saspiesto baitu XOR ar raw DEFLATE. Piedāvātais noklusējuma XOR `92 65 67 57` **neatkodē nevienu no četriem autentiskajiem v291 resursiem** mūsu stingrajā offline validācijā. Vairāki deflate veidi ar šo atslēgu tika pārbaudīti, bet neviens nebija validēts. Tas neapstiprina citu konkrētu atslēgu, un pieejamais koda fragments ar noklusējuma atslēgu nepierāda, ka tieši šis ceļš atkodē v291 failus.
- Esmu neatkarīgi palaidis iepriekšējā `ClientPatch` XML kandidāta testus — **16/16 PASS**. Tie ir *references XML* testi, nevis autentiska `.enc` instalācijas vai spēles tests.
- Jaunā `tools/stagek_audit.py` + `tools/test_stagek.py`: **12/12 PASS**. Autentisko failu SHA, galvenes, statiskā koda norādes un failu integritātes kontroles tiek pārbaudītas automātiski.
- Papildu regresijas pārbaudes: Stage G 21/21 PASS, Stage J 8/8 PASS. Stage J testi ir **koda līguma testi**, nevis Windows runtime.

## Galvenais ierobežojums

Pieejami **četri oriģināli `.enc`** un tikai **mērķēti** EXE koda izgriezumi; šajā izpildvidē nav oriģinālā `CabalMain.exe` pilnā PE faila, Windows CABAL procesa vai piekļuves aktīvajam WorldSvr. Ar šo kopu **nav verificēts** v291 atkodētājs/kodētājs. Nevar droši saražot klientam instalējamu `mapinfo.enc` un nav pamata apgalvot, ka Warp 485 spēlē salabots.

## Nākamais pamatotais reverse-engineering ceļš

1. Atjaunot izpildes ķēdi **`0x14021CDA4` → `0x1402178E0`** (resursa faila nolasīšana/ievietošana) un faktisko `mapinfo.enc` atkodēšanas kodu, sekojot norādēm no `0x14021CE38`. Pašlaik *visa* funkcija `0x1402178E0` NAV ietverta izgriezumos, un `ResourceLoader_1402B5550` var būt cita koda ceļš.
2. Kad pilnajā v291 EXE iegūta iespējamā XOR atslēga / kompresijas ķēde, **pārbaudīt uz visiem četriem autentiskajiem ENC**; pieprasīt derīgu XML, precīzu garumu un sekmīgu round-trip. Sintētiska testu iziešana nav pietiekama.
3. Tikai pēc autentiskā `mapinfo` iegūšanas izmantot `build_client_candidate.py` no iekļautā `ClientPatch` arhīva. Tas darbojas tikai ar pārbaudītu Stage J capture, izveido vienīgi `.xml` un neizmaina klientu.
4. Pirms jebkādas uzstādīšanas — izolēta klienta kopija, oriģinālā `mapinfo.enc` SHA, reversīva `.bak` kopija, instalējamā kandidāta dekodēšanas validācija. Pēc tam īsta Warp 485 spēles pārbaude un logu salīdzinājums.

## Kā palaist šīs pakotnes offline testus

Windows: `Palaist-StageK-Offline.cmd`. Tam nepieciešams tikai Python 3; CABAL vai VM nav jāpalaiž. Pakotne **nekad** nepatcho klientu vai WorldSvr. Alternatīvi `python tools/test_stagek.py` un `python tools/stagek_audit.py`.

## Faili

- `data/v291_DungeonEntrance.zip` — SHA pārbaudīti oriģinālie ENC.
- `data/v291_Codec_Code_Sections.zip` — iepriekšējos posmos verificēti v291 koda izgriezumi, ar oriģinālā klienta SHA pierakstu manifestā.
- `reference/CABAL_v291_Warp485_ClientPatch_Offline_20261118.zip` — iepriekšējā kandidāta ģenerators, 16 testu skripts, vēsturiskais servera reģistrs; *nav instalējams patch*.
- `reference/CABAL_v291_Warp485_StageG_TripleJoin_20261118.zip` — reference/triple-join dati, kuru XML nav v291 oriģinālais.
- `tools/stagek_audit.py` — no ārējiem resursiem neatkarīga offline pārbaude, ar izvēles `--key` kandidātu. Neverificētu key nedrīkst pasludināt par derīgu.
- `tools/test_stagek.py` — regresija, sintētiski codec round-trip + autentisko datu riska kontroles.
- `stagek_report.json` — faktiski palaistas pārbaudes rezultāts.

## Atsauces

- `libcozip`: https://github.com/Michael-K-GH/libcozip (public MIT, kodētāja ideja, **ne v291 saderības garantija**)
- Problēmas servera logs no iepriekšējām pārbaudēm: `OnCSCQDungeonLimitCheck(): invalid qdIdx(4380)` / `MainCmd(485)`.

**Drošība:** Nav injekcijas, nav rakstīšanas CABAL procesā, nav datubāzes/VM/Docker darbību, nav `.enc` aizvietošanas, nav servera validācijas atslēgšanas, nav EP45 koda pārnešanas.
