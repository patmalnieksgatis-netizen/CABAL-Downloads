import struct
import unittest
from pathlib import Path
from warp485_gate import read_registry, classify_packet, verify_binary, REF_SHA256, SIGNATURES

HERE = Path(__file__).parent
REG = read_registry(HERE / 'Config_Tables_Snapshot.zip')
IDS = set(REG['QuestDungeon.scp'] + REG['MissionDungeon.scp'] + REG['MissionDungeon2.scp'])

def packet(cmd=485, qdid=4380, n=14):
    b = bytearray(n)
    b[0:2] = b'\xe2\xb7'
    struct.pack_into('<H', b, 2, n)
    struct.pack_into('<H', b, 4, cmd)
    struct.pack_into('<I', b, 10, qdid)
    return bytes(b)

class Warp485Test(unittest.TestCase):
    def test_quest_count(self): self.assertEqual(len(REG['QuestDungeon.scp']), 304)
    def test_md_counts(self):
        self.assertEqual(len(REG['MissionDungeon.scp']), 246)
        self.assertEqual(len(REG['MissionDungeon2.scp']), 37)
    def test_md_contiguity(self):
        md = REG['MissionDungeon.scp']+REG['MissionDungeon2.scp']
        self.assertEqual(md, list(range(4096, 4379)))
    def test_4378_is_registered(self): self.assertIn(4378, IDS)
    def test_4379_unregistered(self): self.assertNotIn(4379, IDS)
    def test_4380_unregistered(self): self.assertNotIn(4380, IDS)
    def test_4380_decoded(self):
        self.assertEqual(classify_packet(packet(), IDS), {'decision':'UNREGISTERED_NEEDS_PROTOCOL_REPLY','qdid':4380,'namespace':'MissionDungeon'})
    def test_valid_4378_allowed(self): self.assertEqual(classify_packet(packet(qdid=4378), IDS)['decision'],'PASS_TO_NATIVE')
    def test_normal_quest_allowed(self): self.assertEqual(classify_packet(packet(qdid=304), IDS)['decision'],'PASS_TO_NATIVE')
    def test_other_opcode_ignored(self): self.assertEqual(classify_packet(packet(cmd=486), IDS)['decision'],'OTHER_OPCODE')
    def test_truncated_packet_rejected(self): self.assertEqual(classify_packet(b'\xe2\xb7', IDS)['decision'],'MALFORMED')
    def test_length_mismatch_rejected(self): self.assertEqual(classify_packet(packet() + b'\x00', IDS)['decision'],'MALFORMED')
    def test_bad_magic_not_assumed(self): self.assertEqual(classify_packet(b'\x00'+packet()[1:], IDS)['decision'],'UNKNOWN_HEADER')
    def test_unsupported_does_not_redirect(self):
        r=classify_packet(packet(), IDS)
        self.assertNotIn('remap', r)
        self.assertNotIn('reply_bytes', r)
    def test_reference_code_slice(self):
        fragment=(HERE/'Reference_WorldSvr_485_CodeSlice.bin').read_bytes()
        self.assertEqual(len(fragment), 1616)
        for addr, expected in SIGNATURES.items():
            off=addr-0x9DD960
            self.assertEqual(fragment[off:off+len(expected)], expected, hex(addr))

    def test_known_elf_signatures(self):
        e=HERE/'reference_elf.bin'
        if not e.exists(): self.skipTest('Reference ELF not bundled (intentionally)')
        v=verify_binary(e)
        self.assertEqual(v['sha256'],REF_SHA256)
        self.assertTrue(v['all_reference_signatures_match'])

if __name__=='__main__': unittest.main()
