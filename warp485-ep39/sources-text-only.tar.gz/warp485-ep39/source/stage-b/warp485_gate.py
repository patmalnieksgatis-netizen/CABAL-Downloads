#!/usr/bin/env python3
"""Offline-only pre-dispatch guard model for CABAL opcode 485.

This is not a runtime hook and intentionally does not emit replies, modify
server files, alter dungeon IDs or disable native validation.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import zipfile

OPCODE = 485
HEADER = b'\xe2\xb7'
REF_SHA256 = 'caec7772acd22fd8918cfac386845c644451781e48c51975eaefed334c6705c3'
SIGNATURES = {
    0x9DD9AE: bytes.fromhex('8b 58 0a'),  # mov ebx, [rax+0x0a]
    0x9DD9B8: bytes.fromhex('81 fb ff 0f 00 00'),  # cmp ebx, 4095
    0x9DD9CC: bytes.fromhex('44 8d b3 00 f0 ff ff'),  # id minus 4096
    0x9DD9DD: bytes.fromhex('41 39 c6'),
    0x9DD9E0: bytes.fromhex('0f 8f 5a 05 00 00'),
    0x9DDA3A: bytes.fromhex('b9 e5 01 00 00'),  # reply opcode 485
    0x9DDA49: bytes.fromhex('c7 45 80 e2 b7 4d 00'),  # normal reply header, size=77
    0x9DDA8E: bytes.fromhex('89 5d 86'),  # reply +6 = qdIdx
    0x9DDF01: bytes.fromhex('ff 90 68 01 00 00'),  # reply send call
    0x9DDF07: bytes.fromhex('31 c0'),  # explicit zero return on normal reply
    0x9DDFA7: bytes.fromhex('eb 80'),  # error path -> epilogue, no reply
}


def read_registry(snapshot_zip):
    result = {}
    with zipfile.ZipFile(snapshot_zip) as archive:
        for filename in ('QuestDungeon.scp', 'MissionDungeon.scp', 'MissionDungeon2.scp'):
            records = []
            in_table = False
            for line in archive.read(filename).decode('utf-8-sig').splitlines():
                cols = line.strip().split()
                if not cols:
                    continue
                if cols[0].startswith('['):
                    in_table = cols[0] in ('[MD]', '[QuestDungeon]')
                    continue
                if not in_table:
                    continue
                try:
                    # Mission main tables: positional row index then QDungeonIdx.
                    # Quest main table: position index then QDungeonIdx at col 12.
                    qdid = int(cols[1] if filename.startswith('Mission') else cols[12])
                    records.append(qdid)
                except (ValueError, IndexError):
                    continue
            result[filename] = records
    return result


def classify_packet(raw, known_ids):
    """Structural *hypothesis* for normal B7E2 C2S packet; not wire-verified.

    Returns a decision, never an executable hook action. The +0x0A field is
    verified by reference WorldSvr disassembly, not by captured client traffic.
    """
    if len(raw) < 14:
        return {'decision': 'MALFORMED', 'reason': 'short packet'}
    if raw[:2] != HEADER:
        return {'decision': 'UNKNOWN_HEADER', 'reason': 'only normal B7E2 modelled'}
    advertised_length = struct.unpack_from('<H', raw, 2)[0]
    if advertised_length != len(raw):
        return {'decision': 'MALFORMED', 'reason': 'length mismatch'}
    cmd = struct.unpack_from('<H', raw, 4)[0]
    if cmd != OPCODE:
        return {'decision': 'OTHER_OPCODE', 'opcode': cmd}
    qdid = struct.unpack_from('<I', raw, 10)[0]
    decision = 'PASS_TO_NATIVE' if qdid in known_ids else 'UNREGISTERED_NEEDS_PROTOCOL_REPLY'
    return {'decision': decision, 'qdid': qdid, 'namespace': 'MissionDungeon' if qdid >= 4096 else 'QuestDungeon'}


def vaddr_to_offset(elf_data, vaddr):
    if elf_data[:4] != b'\x7fELF' or elf_data[4] != 2 or elf_data[5] != 1:
        raise ValueError('Expected ELF64 little-endian')
    phoff, = struct.unpack_from('<Q', elf_data, 0x20)
    entsize, phnum = struct.unpack_from('<HH', elf_data, 0x36)
    for i in range(phnum):
        p = phoff + i * entsize
        ptype, = struct.unpack_from('<I', elf_data, p)
        if ptype != 1:
            continue
        poff, va, _, filesz = struct.unpack_from('<QQQQ', elf_data, p + 8)
        if va <= vaddr < va + filesz:
            return poff + vaddr - va
    raise ValueError(f'Virtual address 0x{vaddr:X} not backed by file')


def verify_binary(elf_path):
    data = Path(elf_path).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    return {
        'sha256': digest,
        'reference_sha_match': digest == REF_SHA256,
        'all_reference_signatures_match': all(
            data[vaddr_to_offset(data, a):vaddr_to_offset(data, a)+len(sig)] == sig
            for a, sig in SIGNATURES.items()
        ) if digest == REF_SHA256 else None,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--snapshot', default=str(Path(__file__).with_name('Config_Tables_Snapshot.zip')))
    p.add_argument('--elf', help='Optional reference ELF file for exact hash + xref verification')
    p.add_argument('--hex', help='Optional captured opcode packet in hex (not required)')
    args = p.parse_args()
    reg = read_registry(args.snapshot)
    quests = reg['QuestDungeon.scp']
    missions = reg['MissionDungeon.scp'] + reg['MissionDungeon2.scp']
    result = {
        'quest_count': len(quests), 'quest_id_range': [min(quests), max(quests)],
        'mission_count': len(missions), 'mission_id_range': [min(missions), max(missions)],
        'mission_contiguous': missions == list(range(4096, max(missions) + 1)),
        'requested_qdid': 4380, 'mission_index': 4380 - 4096,
        'registered': 4380 in missions or 4380 in quests,
        'missing_ids_between_max_and_4380': [i for i in range(max(missions)+1, 4381) if i not in missions],
        'deployable_fix': False,
    }
    if args.elf:
        result['reference_elf'] = verify_binary(args.elf)
    if args.hex:
        result['packet'] = classify_packet(bytes.fromhex(args.hex), set(quests) | set(missions))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
