# CABAL v291 / EP39 — Warp485 analīzes B posms (tikai offline)

## Jauni apstiprināti binārā koda fakti

Pieejamajā **atsauces** `WorldSvr` ELF (SHA-256 `caec7772...`) `0x9DD960` sākas funkcija, kura tiek identificēta ar kļūdas virkni `OnCSCQDungeonLimitCheck` un C2S opcode `485`.

- `0x9DD9AE`: nolasa 32 bitu `qdIdx` no pieprasījuma bufera **+0x0A**.
- `0x9DD9B8`, `0x9DD9CC`: ja ID ir >4095, izmanto **Mission Dungeon** indeksu `qdIdx-4096`.
- `0x9DD9E0`: ja indekss pārsniedz ielādēto MD robežu, lec uz `0x9DDF40`.
- `0x9DDA49`: **derīga ieraksta** gadījumā tiek sagatavots S2C atbildes buferis ar garumu `0x4D` (77 baiti), `0x9DDA3A`: opcode `0x1E5` (485), `0x9DDA8E`: atbildē ierakstīts `qdIdx` sākot ar +6.
- `0x9DDF01`: normālā zara atbildes nosūtīšana; `0x9DDF07`: explicit `xor eax,eax` pirms atgriešanās.
- `0x9DDF40`/`0x9DDFA7`: kļūdas zars veic logošanu un atgriežas **bez atbildes izveides / nosūtīšanas**, kas atbilst atkārtoti redzētajam `UsrMap Fail` un `close()`.

Tieši šis **priekš-Warp validācijas pieprasījums** atvieno lietotāju; tas nav pierādījums kļūdai pašā pārvietošanas mehānismā.

## Reģistra fakti

- `[QuestDungeon]`: ID 1..304.
- `MissionDungeon.scp [MD]`: ID 4096..4341.
- `MissionDungeon2.scp [MD]`: ID 4342..4378.
- Trūkst 4379 un 4380. Pieprasījums 4380 nozīmē MD indeksu 284, kas pārsniedz 282.

## Kāpēc šeit nav automātiska binārā patch

**Nevar droši izdomāt servera atbildes 77 baitu saturu** un to, kuru statusa lauku klients interpretē kā atteikumu. Kļūdas zara pārslēgšana uz `return 0` neizveidos atbildi un nevarēs ielaist nederīgu dungeon. Arī `jg` pārslēgšana uz success zaru novestu pie ārpus reģistra atmiņas nolasīšanas. Tāpēc šeit apzināti nav pat izmēģinājuma runtime patch.

Lai izveidotu instalējamu **fail-closed, non-disconnecting** saderības slāni, jāpierāda viena no divām lietām:
1. Šim klientam pareizs **negatīvs S2C 485** atbildes formāts, ko var noformēt bez neesoša dungeon ieraksta; **vai**
2. Korespondējošas 4379/4380 MD definīcijas ar pilnām servera datu atkarībām, lai native apstrādātājs tās varētu pārbaudīt.

Atsauces ELF SHA **nav salīdzināts** ar aktīvā `WorldSvr_01_01` procesa failu. Netiek apgalvots, ka adreses noteikti atbilst pašreizējam procesam.

## Pakotnes saturs un testi

`Config_Tables_Snapshot.zip` — oriģinālie v291 reģistra izvilkumi, `warp485_gate.py` — atsevišķs **modelis**, kas klasificē paredzamos pieprasījumus, nelabo serveri un nesūta paketes, `test_gate.py` — unit testi, `binary_xrefs.txt` — atsauces koda fragmenti, `Reference_WorldSvr_485_CodeSlice.bin` — 1616 baitu oriģinālā koda fragments (nevis patch). Neviens fails nav paredzēts automātiskai instalācijai.

```
python warp485_gate.py
python -m unittest -v test_gate
```

## Rollback

Nav veikta neviena izmaiņa ne aktīvajā serverī, ne VM. Rollback nav vajadzīgs.
