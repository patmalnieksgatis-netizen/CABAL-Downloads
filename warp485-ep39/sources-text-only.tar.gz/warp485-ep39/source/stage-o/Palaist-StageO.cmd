@echo off
cd /d "%~dp0"
py -3 -u "%~dp0tools\runtime_key_audit.py"
pause
