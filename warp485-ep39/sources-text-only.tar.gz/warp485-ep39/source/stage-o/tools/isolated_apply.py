#!/usr/bin/env python3
"""Guarded Stage O apply/rollback in a PRE-EXISTING ISOLATED CLIENT COPY ONLY.

Never modifies the F:\\CABAL_291_TEST working client; no auto-apply, no server
calls. Experimental only; game-side compatibility is not established.
"""
import argparse,csv,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
from runtime_key_audit import PIN_MAP, decode,sha

PRODUCTION=Path(r'F:\CABAL_291_TEST')
BACKUP='mapinfo.enc.stage_o_backup'

def game_not_running():
 if os.name!='nt':return
 result=subprocess.check_output(['tasklist','/FI','IMAGENAME eq CabalMain.exe','/FO','CSV','/NH'],
    text=True,encoding='mbcs',errors='replace',timeout=10)
 for row in csv.reader(result.splitlines()):
  if row and row[0].casefold()=='cabalmain.exe':raise ValueError('CLOSE_CLIENT_BEFORE_ISOLATED_APPLY')

def check_client_target(root):
 root=root.resolve(strict=True)
 if os.name=='nt' and root==PRODUCTION.resolve():raise ValueError('PRODUCTION_ROOT_REFUSED')
 target=root/'Data'/'mapinfo.enc'
 if not target.is_file() or target.is_symlink():raise ValueError('ISOLATED_TARGET_MISSING_OR_SYMLINK')
 prod=PRODUCTION/'Data'/'mapinfo.enc'
 if prod.is_file() and os.path.samefile(target,prod):raise ValueError('ISOLATED_TARGET_IS_PRODUCTION_FILE')
 return target

def run(root,candidate_dir,apply=False,rollback=False):
 if apply==rollback:raise ValueError('EXPLICIT_APPLY_OR_ROLLBACK_REQUIRED')
 game_not_running()
 target=check_client_target(root)
 candidate_dir=candidate_dir.resolve(strict=True)
 encoded=candidate_dir/'mapinfo.v291.candidate.enc'
 xml=candidate_dir/'mapinfo.v291.candidate.xml'
 reportpath=candidate_dir/'candidate_report.json'
 if not all(x.is_file() and not x.is_symlink() for x in [encoded,xml,reportpath]):
  raise ValueError('CANDIDATE_FILE_MISSING_OR_SYMLINK')
 report=json.loads(reportpath.read_text(encoding='utf-8'))
 if report.get('source_original_enc_sha256')!=PIN_MAP:
  raise ValueError('CANDIDATE_ORIGINAL_PIN_MISMATCH')
 key=bytes.fromhex(report['candidate_codec_key_hex'])
 if len(key)!=4:raise ValueError('CANDIDATE_KEY_LENGTH_INVALID')
 data=encoded.read_bytes();plaintext=xml.read_bytes()
 if sha(data)!=report.get('encoded_candidate_sha256') or sha(plaintext)!=report.get('candidate_sha256'):
  raise ValueError('CANDIDATE_HASH_MISMATCH')
 if decode(data,key)!=plaintext:raise ValueError('CANDIDATE_CODEC_ROUNDTRIP_FAILED')
 source=target.read_bytes()
 backup=target.with_name(BACKUP)
 if apply:
  if sha(source)!=PIN_MAP:raise ValueError('ISOLATED_INPUT_NOT_ORIGINAL_ENC')
  if backup.exists():raise ValueError('BACKUP_ALREADY_EXISTS')
  # Never touch a non-original unverified client. The candidate source XML
  # must decode from this exact original ENC using this exact observed key.
  if sha(decode(source,key))!=report.get('source_sha256'):
   raise ValueError('SOURCE_XML_NOT_AUTHENTIC_FOR_CODEC_KEY')
  shutil.copy2(target,backup)
  if sha(backup.read_bytes())!=PIN_MAP:raise ValueError('BACKUP_VERIFICATION_FAILED')
  tmp=target.with_name(target.name+'.stage_o_tmp')
  if tmp.exists():raise ValueError('OLD_TEMP_FILE_PRESENT')
  try:
   with tmp.open('xb') as w:w.write(data);w.flush();os.fsync(w.fileno())
   os.replace(tmp,target)
   if sha(target.read_bytes())!=sha(data):raise ValueError('STAGED_INSTALL_VERIFY_FAILED')
  except Exception:
   if tmp.exists():tmp.unlink()
   if backup.exists():shutil.copy2(backup,target)
   raise
  return 'EXPERIMENTAL_ISOLATED_COPY_APPLIED_NOT_GAMEPLAY_VERIFIED'
 if not backup.is_file() or sha(backup.read_bytes())!=PIN_MAP:
  raise ValueError('VERIFIED_BACKUP_NOT_AVAILABLE')
 if sha(source)!=sha(data):raise ValueError('COPY_CHANGED_REFUSE_ROLLBACK')
 shutil.copy2(backup,target)
 if sha(target.read_bytes())!=PIN_MAP:raise ValueError('ROLLBACK_HASH_VERIFY_FAILED')
 return 'ISOLATED_COPY_ORIGINAL_RESTORED'

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--isolated-root',required=True,type=Path)
 ap.add_argument('--candidate-dir',required=True,type=Path)
 g=ap.add_mutually_exclusive_group(required=True)
 g.add_argument('--apply',action='store_true')
 g.add_argument('--rollback',action='store_true')
 a=ap.parse_args()
 try:print(run(a.isolated_root,a.candidate_dir,a.apply,a.rollback))
 except Exception as e:print('STOP='+str(e),file=sys.stderr);return 2
 return 0
if __name__=='__main__':sys.exit(main())
