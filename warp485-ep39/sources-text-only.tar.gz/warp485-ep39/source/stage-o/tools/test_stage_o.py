#!/usr/bin/env python3
import hashlib
import os
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_key_audit as m
import isolated_apply as ia
from unittest.mock import patch

EXE=Path(os.environ.get('CABAL_EXE',r'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe' if os.name=='nt' else '/mnt/data/CabalMain(20261118-202936).exe'))
ENC=Path(os.environ.get('CABAL_MAPINFO',r'F:\CABAL_291_TEST\Data\mapinfo.enc' if os.name=='nt' else '/mnt/data/cabal_sources/v291_enc_authentic/mapinfo.enc'))
REF=Path(__file__).resolve().parent.parent/'reference'/'REFERENCE_UNVERIFIED_mapinfo.xml'
REG=Path(__file__).resolve().parent.parent/'reference'/'server_registry_evidence.zip'

class Test(unittest.TestCase):
 def test_pins(self):
  self.assertEqual(m.sha(EXE.read_bytes()),m.PIN_EXE)
  self.assertEqual(m.sha(ENC.read_bytes()),m.PIN_MAP)
 def test_disk_decoder_key(self):
  key=m.read_key(lambda a,n:m.pe_rva_to_file(EXE.read_bytes(),a,n))
  self.assertEqual(key,m.DEFAULT_KEY)
 def test_disk_key_invalid_input(self):
  with self.assertRaisesRegex(ValueError,'DEFLATE_RESERVED_BLOCK_TYPE'):
   m.decode(ENC.read_bytes(),m.DEFAULT_KEY)
 def test_pe_bogus(self):
  with self.assertRaises(ValueError):m.pe_rva_to_file(b'NOTPE',0x2000,1)
 def test_pattern_scanner(self):
  matches=m.find_decoder_patterns(EXE.read_bytes())
  self.assertTrue(any(x["key_hex"]=="92656757" for x in matches))
 def test_signatures_reject_wrong(self):
  with self.assertRaises(ValueError):m.read_key(lambda a,n:b'\x90'*n)
 def test_runtime_key_mutation(self):
  exe=EXE.read_bytes()
  from unittest.mock import MagicMock
  changed=bytearray(exe)
  # Substitute four native immediates by emulating read-only runtime memory.
  target=b'\x11\x22\x33\x44'
  def mem(a,n):
   raw=bytearray(m.pe_rva_to_file(exe,a,n))
   for i,(r,op,ext) in enumerate(m.XOR_INSTRUCTIONS):
    if a==r:raw[len(op)]=target[i]
   return bytes(raw)
  self.assertEqual(m.read_key(mem),target)
 def test_codec_synthetic_roundtrip(self):
  x=b'<cabal><icon><icon_value><warp dungeon_index="1" target_world_index="138"/></icon_value></icon></cabal>'
  m.confirm_xml(x,True)
  for k in [m.DEFAULT_KEY,bytes.fromhex('11223344'),bytes.fromhex('00000000')]:
   self.assertEqual(m.decode(m.encode(x,k),k),x)
 def test_codec_wrong_key(self):
  x=b'<cabal><icon><icon_value><warp dungeon_index="1" target_world_index="138"/></icon_value></icon></cabal>'
  enc=m.encode(x,b'\x11\x22\x33\x44')
  with self.assertRaises(ValueError):m.decode(enc,m.DEFAULT_KEY)
 def test_xml_dtd(self):
  with self.assertRaises(ValueError):m.confirm_xml(b'<!DOCTYPE xx><cabal/>')
 def test_actual_static_report(self):
  info=m.static_analysis(EXE.read_bytes(),ENC.read_bytes())
  self.assertEqual(info['disk_native_xor_key_hex'],'92656757')
  self.assertIn('DEFLATE_RESERVED_BLOCK_TYPE',info['disk_key_mapinfo_result'])
 def test_actual_xml_ref_not_v291(self):
  self.assertNotEqual(hashlib.sha256(REF.read_bytes()).hexdigest(),m.PIN_MAP)
 def test_prepare_candidate_reference_only(self):
  # This is explicitly a NOT-V291 reference XML used to test machinery only.
  content=REF.read_bytes()
  m.confirm_xml(content,True)
  encoded=m.encode(content,b'\x11\x22\x33\x44')
  with tempfile.TemporaryDirectory() as d:
   meta=m.prepare_candidate(content,encoded,b'\x11\x22\x33\x44',REG,Path(d)/'c')
   p=Path(d)/'c'/'mapinfo.v291.candidate.enc'
   decoded=m.decode(p.read_bytes(),bytes.fromhex('11223344'))
   self.assertNotEqual(decoded,content)
   self.assertEqual(meta['verification'],'OFFLINE_ONLY_NOT_GAMEPLAY_TESTED')
   self.assertTrue(any(x['dungeon_id']==4380 for x in meta['removed']))
 def test_isolated_apply_rollback_synthetic(self):
  orig=b'<cabal><icon><icon_value><warp dungeon_index="1" target_world_index="138"/></icon_value></icon></cabal>'
  patched=orig.replace(b'dungeon_index="1"',b'dungeon_index="2"')
  key=bytes.fromhex('11223344')
  source=m.encode(orig,key);enc=m.encode(patched,key)
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);root=td/'lab';(root/'Data').mkdir(parents=True)
   target=root/'Data'/'mapinfo.enc';target.write_bytes(source)
   cand=td/'cand';cand.mkdir()
   (cand/'mapinfo.v291.candidate.enc').write_bytes(enc)
   (cand/'mapinfo.v291.candidate.xml').write_bytes(patched)
   rep={'source_original_enc_sha256':m.sha(source),'source_sha256':m.sha(orig),
        'candidate_codec_key_hex':key.hex(),'encoded_candidate_sha256':m.sha(enc),
        'candidate_sha256':m.sha(patched)}
   (cand/'candidate_report.json').write_text(__import__('json').dumps(rep))
   with patch.object(ia,'PIN_MAP',m.sha(source)),patch.object(ia,'PRODUCTION',td/'notreal'):
    self.assertIn('APPLIED',ia.run(root,cand,apply=True))
    self.assertEqual(target.read_bytes(),enc)
    self.assertIn('RESTORED',ia.run(root,cand,rollback=True))
    self.assertEqual(target.read_bytes(),source)
 def test_isolated_refuses_production_samefile(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);p=td/'production';(p/'Data').mkdir(parents=True)
   (p/'Data'/'mapinfo.enc').write_bytes(b'fake')
   with patch.object(ia,'PRODUCTION',p):
    with self.assertRaisesRegex(ValueError,'PRODUCTION'):
     ia.check_client_target(p)
 def test_isolated_refuses_unverified_codec(self):
  self.assertRaises(ValueError,m.decode,ENC.read_bytes(),bytes.fromhex('92656757'))
 def test_mismatched_exe_refused(self):
  with self.assertRaises(ValueError):m.static_analysis(b'MZxxxx',ENC.read_bytes())
 def test_mismatched_enc_refused(self):
  with self.assertRaises(ValueError):m.static_analysis(EXE.read_bytes(),b'xxxx')

if __name__=='__main__':unittest.main(verbosity=2)
