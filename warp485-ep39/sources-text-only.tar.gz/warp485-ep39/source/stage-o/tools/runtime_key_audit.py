#!/usr/bin/env python3
"""CABAL v291 isolated runtime-key audit / conditional candidate builder.

Only reads the pinned EXE, original ENC and (on Windows, when running) small
process memory ranges; NEVER writes a CABAL client file, injects code or kills a
process. Writes evidence under Downloads/StageO_*. Uses a historical server
registry only to propose a candidate, never to assert current configuration.
"""
from __future__ import annotations
import argparse
import ctypes
from ctypes import wintypes
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
import re
from pathlib import Path
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
import zlib

PIN_EXE='52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9'
PIN_MAP='88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc'
MAX_XML=4_000_000
# Native decoder reading order (first input byte -> last). Each immediate offset
# has a machine-code signature; refuse to extract a key from arbitrary bytes.
XOR_INSTRUCTIONS=(
    (0x2B7AF9, b'\x35',3),    # xor eax, imm32; only low byte may be nonzero
    (0x2B7AEA, b'\x83\xF0',0),
    (0x2B7ADA, b'\x83\xF0',0),
    (0x2B7ACA, b'\x83\xF0',0),
)
ENTRY_RVAS=(0x2178E0,0x2B7A90,0x2B7FAC,0x21CDA4)
DEFAULT_KEY=bytes.fromhex('92656757')

def sha(b):return hashlib.sha256(b).hexdigest()

def pe_rva_to_file(blob,rva,count):
    if blob[:2]!=b'MZ':raise ValueError('NOT_MZ')
    pe=struct.unpack_from('<I',blob,0x3c)[0]
    if blob[pe:pe+4]!=b'PE\0\0':raise ValueError('NOT_PE')
    nsec=struct.unpack_from('<H',blob,pe+6)[0]
    optsz=struct.unpack_from('<H',blob,pe+20)[0]
    opt=pe+24
    if struct.unpack_from('<H',blob,opt)[0]!=0x20b:raise ValueError('NOT_X64_PE')
    hdr=struct.unpack_from('<I',blob,opt+60)[0]
    if rva+count<=hdr:return blob[rva:rva+count]
    for i in range(nsec):
        pos=opt+optsz+i*40
        vs,va,raw,off=struct.unpack_from('<IIII',blob,pos+8)
        if va<=rva and rva+count<=va+raw and off+rva-va+count<=len(blob):
            return blob[off+rva-va:off+rva-va+count]
    raise ValueError('RVA_NOT_MAPPED_0x%X'%rva)

def read_key(read_rva):
    key=[]
    for rva,opcode,extra in XOR_INSTRUCTIONS:
        raw=read_rva(rva,len(opcode)+1+extra)
        if len(raw)!=len(opcode)+1+extra or raw[:len(opcode)]!=opcode:
            raise ValueError('NATIVE_KEY_OPCODE_MISMATCH_RVA_0x%X'%rva)
        if extra and any(raw[-extra:]):
            raise ValueError('NATIVE_KEY_NOT_BYTE_IMMEDIATE_RVA_0x%X'%rva)
        key.append(raw[len(opcode)])
    return bytes(key)

def decode(enc,key):
    if len(enc)<10 or len(key)!=4:raise ValueError('ENC_HEADER_OR_KEY_INVALID')
    expected=int.from_bytes(enc[:4],'little')
    if expected<=0 or expected>MAX_XML:raise ValueError('ENC_DECLARED_LENGTH_INVALID')
    packed=bytearray(enc[4:])
    for i in range(4):packed[i]^=key[i]
    if ((packed[0]>>1)&3)==3:raise ValueError('DEFLATE_RESERVED_BLOCK_TYPE')
    d=zlib.decompressobj(-15)
    try:out=d.decompress(packed,MAX_XML+1)+d.flush()
    except zlib.error as ex:raise ValueError('DEFLATE_ERROR:'+str(ex)) from ex
    if not d.eof or d.unused_data or len(out)!=expected or len(out)>MAX_XML:
        raise ValueError('DEFLATE_SIZE_OR_EOF_MISMATCH')
    return out

def encode(xml,key):
    if not (0<len(xml)<=MAX_XML and len(key)==4):raise ValueError('INVALID_INPUT_XML_OR_KEY')
    c=zlib.compressobj(level=9,wbits=-15)
    p=bytearray(c.compress(xml)+c.flush())
    for i in range(4):p[i]^=key[i]
    return struct.pack('<I',len(xml))+p

def confirm_xml(raw,need_mapinfo=False):
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise ValueError('XML_DTD_REJECTED')
    root=ET.fromstring(raw)
    if root.tag!='cabal':raise ValueError('XML_ROOT_NOT_CABAL')
    if need_mapinfo and not root.findall('.//icon/icon_value/warp'):
        raise ValueError('MAPINFO_WARPS_MISSING')
    return root

def static_analysis(exe,enc):
    if sha(exe)!=PIN_EXE:raise ValueError('WRONG_EXE_SHA256')
    if sha(enc)!=PIN_MAP:raise ValueError('WRONG_MAPINFO_SHA256')
    exkey=read_key(lambda r,n:pe_rva_to_file(exe,r,n))
    info={'exe_sha256':PIN_EXE,'mapinfo_sha256':PIN_MAP,'mapinfo_encoded_bytes':len(enc),
          'mapinfo_decoded_length_declared':int.from_bytes(enc[:4],'little'),
          'disk_native_xor_key_hex':exkey.hex(),'default_key_matches':exkey==DEFAULT_KEY}
    try:
        xml=decode(enc,exkey);confirm_xml(xml,True)
        info['disk_key_mapinfo_result']='VALID_XML';info['decoded_sha256']=sha(xml)
    except (ValueError,ET.ParseError) as e:info['disk_key_mapinfo_result']=type(e).__name__+':'+str(e)
    return info

def find_decoder_patterns(binary):
    """Recognize the complete native four-XOR-byte reader signature in a module.

    Scanner hits are candidate constants, NOT proof the game executes that DLL.
    """
    if len(binary)>96*1024*1024:return []
    patterns=[bytes.fromhex('410fb6400383f0'),bytes.fromhex('410fb6400283f0'),
              bytes.fromhex('410fb6400183f0'),bytes.fromhex('410fb60035')]
    found=[];start=0
    while True:
        pos=binary.find(patterns[-1],start)
        if pos<0:break
        start=pos+len(patterns[-1]);key0end=pos+len(patterns[-1])+4
        if key0end>len(binary) or any(binary[pos+5:pos+9][1:]):continue
        segment=binary[max(0,pos-128):pos]
        locations=[];cursor=0
        for prefix in patterns[:3]:
            at=segment.find(prefix,cursor)
            if at<0:break
            locations.append((at,segment[at+len(prefix)]))
            cursor=at+len(prefix)+1
        if len(locations)!=3:continue
        key=bytes([binary[pos+5],locations[2][1],locations[1][1],locations[0][1]])
        found.append({'file_offset':'0x%X'%pos,'key_hex':key.hex()})
        if len(found)>=16:break
    return found

def find_game_pid():
    res=subprocess.check_output(['tasklist','/FI','IMAGENAME eq CabalMain.exe','/FO','CSV','/NH'],
        text=True,encoding='mbcs',errors='replace',timeout=12)
    pids=[]
    for line in csv.reader(res.splitlines()):
        if len(line)>1 and line[0].lower()=='cabalmain.exe':
            try:pids.append(int(line[1]))
            except ValueError:continue
    if len(pids)>1:raise ValueError('MULTIPLE_CABAL_CLIENTS_RUNNING')
    return pids[0] if pids else None

def windows_memory_reader(pid,exe_path):
    if sys.platform!='win32' or ctypes.sizeof(ctypes.c_void_p)!=8:
        raise ValueError('WINDOWS_X64_PYTHON_REQUIRED')
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    p=ctypes.WinDLL('psapi',use_last_error=True)
    k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    k.OpenProcess.restype=wintypes.HANDLE
    k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
    k.ReadProcessMemory.argtypes=[wintypes.HANDLE,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_size_t)]
    k.ReadProcessMemory.restype=wintypes.BOOL
    k.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
    k.QueryFullProcessImageNameW.restype=wintypes.BOOL
    p.EnumProcessModulesEx.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.HMODULE),wintypes.DWORD,ctypes.POINTER(wintypes.DWORD),wintypes.DWORD]
    p.EnumProcessModulesEx.restype=wintypes.BOOL
    p.GetModuleFileNameExW.argtypes=[wintypes.HANDLE,wintypes.HMODULE,wintypes.LPWSTR,wintypes.DWORD]
    p.GetModuleFileNameExW.restype=wintypes.DWORD
    handle=k.OpenProcess(0x0410,False,pid) # VM_READ | QUERY_INFORMATION ONLY
    if not handle:raise ValueError('READ_ONLY_OPENPROCESS_FAILED')
    try:
        chars=ctypes.create_unicode_buffer(32768);l=wintypes.DWORD(len(chars))
        if not k.QueryFullProcessImageNameW(handle,0,chars,ctypes.byref(l)):
            raise ValueError('CANNOT_VERIFY_PROCESS_PATH')
        if Path(chars.value).resolve()!=exe_path.resolve():
            raise ValueError('RUNNING_EXE_PATH_NOT_PINNED')
        module_count=1024;arr=(wintypes.HMODULE*module_count)();needed=wintypes.DWORD()
        if not p.EnumProcessModulesEx(handle,arr,ctypes.sizeof(arr),ctypes.byref(needed),3):
            raise ValueError('ENUM_MODULES_FAILED')
        n=min(module_count,needed.value//ctypes.sizeof(wintypes.HMODULE))
        if not n:raise ValueError('NO_BASE_MODULE')
        base=int(arr[0]);mods=[];game_root=exe_path.parents[2];dll_keys=[]
        for module in arr[:n]:
            tmp=ctypes.create_unicode_buffer(8192)
            if p.GetModuleFileNameExW(handle,module,tmp,len(tmp)):
                path=Path(tmp.value)
                try:
                    relative=path.resolve().relative_to(game_root.resolve()).as_posix()
                    category='GAME'
                except ValueError:
                    category='EXTERNAL';relative=path.name
                mods.append({'category':category,'name':relative,'image_base':'0x%X'%int(module)})
                if category=='GAME' and path.suffix.lower()=='.dll':
                    try:
                        if path.stat().st_size<=96*1024*1024:
                            patterns=find_decoder_patterns(path.read_bytes())
                            if patterns:dll_keys.append({'module':relative,'candidate_patterns':patterns})
                    except OSError:pass
        def read(rva,nbytes):
            addr=base+rva
            if not (0x10000<=addr<=0x7fffffffffff-nbytes):raise ValueError('MEMORY_RANGE_INVALID')
            out=ctypes.create_string_buffer(nbytes);got=ctypes.c_size_t()
            ok=k.ReadProcessMemory(handle,ctypes.c_void_p(addr),out,nbytes,ctypes.byref(got))
            if not ok or got.value!=nbytes:raise ValueError('MEMORY_READ_FAILED_RVA_0x%X'%rva)
            return out.raw
        result={'pid':pid,'base':'0x%X'%base,'modules':mods,'game_dll_key_patterns_unverified':dll_keys,'runtime_xor_key_hex':None,
                'code_entry_provenance':[]}
        for rva in ENTRY_RVAS:
            dis=pe_rva_to_file(exe_path.read_bytes(),rva,16);mem=read(rva,16)
            result['code_entry_provenance'].append({'rva':'0x%X'%rva,
                'matches_disk':dis==mem,'disk':dis.hex(),'runtime':mem.hex()})
        # Read only native bit-reader opcode bytes, no whole-memory scanning.
        result['runtime_xor_key_hex']=read_key(read).hex()
        return result
    finally:k.CloseHandle(handle)

def prepare_candidate(mapinfo,enc,key,registry_zip,out_dir,key_origin="RUNTIME_VERIFIED_CLIENT_OPCODE"):
    # Import trusted existing byte-preserving, server-registry-aware algorithm.
    from build_client_candidate import parse_and_patch
    from triple_join_audit import server_registries
    dungeon,warp=server_registries(registry_zip)
    patched,meta=parse_and_patch(mapinfo,dungeon,warp,require_4380=True)
    candidate_enc=encode(patched,key)
    if decode(candidate_enc,key)!=patched:raise ValueError('ENC_ROUNDTRIP_FAILURE')
    confirm_xml(patched,True)
    out_dir.mkdir(exist_ok=False)
    (out_dir/'mapinfo.v291.candidate.xml').write_bytes(patched)
    (out_dir/'mapinfo.v291.candidate.enc').write_bytes(candidate_enc)
    (out_dir/'ORIGINAL_mapinfo.enc.backup').write_bytes(enc)
    meta.update({'candidate_codec_key_hex':key.hex(),'candidate_key_origin':key_origin,'encoded_candidate_sha256':sha(candidate_enc),
      'source_original_enc_sha256':sha(enc),'verification':'OFFLINE_ONLY_NOT_GAMEPLAY_TESTED',
      'client_files_modified':False,'server_modified':False,'registry_snapshot':'HISTORICAL'})
    (out_dir/'candidate_report.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    return meta

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--exe',type=Path,default=Path(r'F:\CABAL_291_TEST\Bin\x64\CabalMain.exe'))
    ap.add_argument('--mapinfo',type=Path,default=Path(r'F:\CABAL_291_TEST\Data\mapinfo.enc'))
    ap.add_argument('--registry',type=Path,default=Path(__file__).resolve().parent.parent/'reference'/'server_registry_evidence.zip')
    ap.add_argument('--out-dir',type=Path,default=Path.home()/'Downloads')
    ap.add_argument('--pid',type=int,default=None)
    ap.add_argument('--static-only',action='store_true',help='Perform static check without a running client.')
    a=ap.parse_args(argv)
    stamp=datetime.now().strftime('%Y%m%d-%H%M%S')
    dest=a.out_dir/('StageO_v291_'+stamp+'_'+str(os.getpid()))
    dest.mkdir(parents=True,exist_ok=False)
    status='FAILED';rep={'kind':'STAGE_O_READ_ONLY_AUDIT','started_utc':datetime.now(timezone.utc).isoformat(),
        'client_modified':False,'server_modified':False,'process_modified':False}
    try:
        exe=a.exe.read_bytes();enc=a.mapinfo.read_bytes()
        rep['static']=static_analysis(exe,enc)
        status='STATIC_ONLY'
        if not a.static_only:
            pid=a.pid if a.pid else find_game_pid()
            if pid is None:
                status='CLIENT_NOT_RUNNING';rep['runtime']='No running client; no process launched.'
            else:
                runtime=windows_memory_reader(pid,a.exe)
                rep['runtime']=runtime
                key=bytes.fromhex(runtime['runtime_xor_key_hex'])
                try:
                    xml=decode(enc,key);confirm_xml(xml,True)
                    rep['runtime']['mapinfo_decode']='SUCCESS_NATIVE_RUNTIME_KEY';
                    rep['runtime']['decoded_sha256']=sha(xml)
                    if len(xml)!=49101:raise ValueError('MAPINFO_49101_LENGTH_MISMATCH')
                    (dest/'ORIGINAL_v291_mapinfo.xml').write_bytes(xml)
                    status='ORIGINAL_MAPINFO_DECODED'
                    try:
                        meta=prepare_candidate(xml,enc,key,a.registry,dest/'EXPERIMENTAL_OFFLINE_CANDIDATE',key_origin="RUNTIME_VERIFIED_CLIENT_OPCODE")
                        rep['candidate']=meta;status='CANDIDATE_OFFLINE_PREPARED'
                    except Exception as exc:
                        rep['candidate_blocked']=str(exc)
                except (ValueError,zlib.error,ET.ParseError) as e:
                    status='RUNTIME_KEY_DECODE_INCOMPATIBLE'
                    rep['runtime']['mapinfo_decode']='FAILED: '+str(e)
                    # Recognized DLL signatures are NOT proof of loaded execution
                    # at the decoder site. Treat decoded results as candidates.
                    hits=[]
                    for item in runtime['game_dll_key_patterns_unverified']:
                        for pattern in item['candidate_patterns']:
                            try:
                                dllkey=bytes.fromhex(pattern['key_hex'])
                                dllxml=decode(enc,dllkey)
                                confirm_xml(dllxml,True)
                                if len(dllxml)!=49101:continue
                                hits.append({'module':item['module'],'key_hex':dllkey.hex(),
                                    'decoded_sha256':sha(dllxml),'status':'CANDIDATE_KEY_NOT_RUNTIME_VERIFIED'})
                                (dest/'CANDIDATE_mapinfo_from_DLL_pattern.xml').write_bytes(dllxml)
                            except (ValueError,zlib.error,ET.ParseError):pass
                    if hits:
                        status='DLL_KEY_CANDIDATE_XML_RECOVERED'
                        rep['dll_candidates']=hits
                        validkeys={x['key_hex'] for x in hits}
                        if len(validkeys)==1:
                            dllkey=bytes.fromhex(next(iter(validkeys)))
                            try:
                                xml=decode(enc,dllkey)
                                meta=prepare_candidate(xml,enc,dllkey,a.registry,
                                    dest/'EXPERIMENTAL_OFFLINE_CANDIDATE',
                                    key_origin='UNVERIFIED_LOADED_DLL_ON_DISK_PATTERN')
                                rep['candidate']=meta
                                status='DLL_KEY_OFFLINE_CANDIDATE_PREPARED'
                            except Exception as ex:
                                rep['candidate_blocked']='UNVERIFIED_DLL_KEY:'+str(ex)
                        else:rep['candidate_blocked']='AMBIGUOUS_MULTIPLE_DLL_KEYS'
    except Exception as e:
        status='FAILED';rep['failure']=str(e)
    rep['status']=status;rep['finished_utc']=datetime.now(timezone.utc).isoformat()
    (dest/'Report.json').write_text(json.dumps(rep,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    archive=dest.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for f in dest.rglob('*'):
            if f.is_file():z.write(f,f.relative_to(dest))
    print('STATUS='+status,flush=True);print('REPORT='+str(archive),flush=True)
    if status in ('CANDIDATE_OFFLINE_PREPARED','DLL_KEY_OFFLINE_CANDIDATE_PREPARED'):print('INSTALLATION=NOT_PERFORMED; GAMEPLAY_TEST=NOT_PERFORMED')
    return 0 if status not in ('FAILED','RUNTIME_KEY_DECODE_INCOMPATIBLE') else 2

if __name__=='__main__':sys.exit(main())
