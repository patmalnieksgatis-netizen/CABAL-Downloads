# CABAL v291 / EP39 — Stage O (reālās ENC atslēgas izcelsmes pārbaude)

## Statuss

**Nav apstiprināts spēles labojums.** Šajā izolētajā Linux vidē atkal pārbaudīts pilnais oriģinālais `CabalMain.exe` un autentiskais 6808 B `mapinfo.enc`. EXE SHA256 `52e7956d4781fea1f0369cac8ab1eac4c3ddec2d1977c6557be53ec2b79885d9`; mapinfo SHA256 `88f7694e476e1ebe5cf55014657194fcc2a4b61c2d83d8c908bf823e538b63fc`.

Koda diska versijas bitu lasītāja XOR ir `92 65 67 57`; tā dod **nederīgu DEFLATE BTYPE=3** no oriģinālā `mapinfo.enc`. Šo pretrunu iepriekšējie posmi bija identificējuši, bet neatrisināja, vai dzīvajā spēlē ir cita atslēga. Stage O tagad pārbauda **instrukcijas atmiņā**, nevis atkārtoti skenē atbrīvotu mapinfo kešu.

## Kas ir jauns

* `tools/runtime_key_audit.py`: salīdzina procesa koda ieejas ar diska EXE, nolasa četrus konkrētos XOR immediate baitus no **darbojošā** v291 klienta, uzskaita no spēles mapes ielādētos DLL (un anonimizētus ārējo moduļu nosaukumus), meklē spēles DLL pēc tās pašas native četrbaitu dekodētāja instrukciju signatūras. Izmanto tikai procesa lasīšanas tiesības. Ja reālās instrukcijas atšķiras, mēģina ar atrasto atslēgu dekodēt autentisko `mapinfo.enc`; pieņem tikai korektu XML ar `cabal` un warp struktūru un tieši 49101 baitiem.
* Ja **reālā procesa instrukciju atslēga** der un autentiskajā XML tiešām ir `World 8 / Warp 675 / QDIdx 4380`, izmanto esošo, pārbaudīto Stage N XML labotāju un vēsturisko servera reģistru, lai izveidotu **tikai eksperimentālu** `.enc` kandidātu kopā ar avota rezerves kopiju. Neko neinstalē.
* Ja atrastā **DLL diska signatūras** atslēga dod derīgu autentisko XML, to atzīmē kā **neapstiprinātu reālo kodu**. Kandidāts tiek izolēti sagatavots tikai tad, ja visi XML un reģistra nosacījumi izpildās. DLL klātbūtne pati par sevi nenozīmē, ka tā kods spēlē tiek izsaukts.
* `tools/isolated_apply.py`: **brīvprātīga**, ar explicit `--apply` vai `--rollback`, izolētas klienta kopijas uzlikšana/atjaunošana ar EXE nemainīšanu, oriģinālā ENC SHA un jaunā kodētā kandidāta roundtrip pārbaudi. Neļauj mainīt `F:\CABAL_291_TEST`, liek aizvērt klientus un atsakās izmantot symlink / citas izcelsmes failu.
* `tools/test_stage_o.py`: 18/18 offline testi Linux vidē, ieskaitot reālo EXE/ENC nesaderību un sintētisku izolētas kopijas uzlikšanu/rollback. **Windows atmiņas nolasīšana un spēles tests šajā vidē nav iespējami un netika veikti.**

## Viena Windows palaišana — nav manuālu mikrodiagnostiku

Kad oriģinālais `F:\CABAL_291_TEST\Bin\x64\CabalMain.exe` ir palaists, **izpako šo ZIP** un palaid `Palaist-StageO.cmd` (vajadzīgs 64-bit Python ar `py -3`). Skripts nepalaiž spēli pats un neveic injekcijas, procesu atmiņas ierakstus, klienta/servera failu labojumus vai restartus. Rezultāta `Report.json` un ZIP tiek radīts **Downloads\StageO_v291_***, pēc tam tiek parādīts STATUS/REPORT. Ja atslēga nav atgūta, skripts neko nelabo.

Statiskai Windows pārbaudei bez spēles: `py -3 tools\runtime_key_audit.py --static-only`.

### Potenciālo statusu nozīme

- `STATIC_ONLY` — tikai diska datu pārbaude.
- `CLIENT_NOT_RUNNING` — process nav palaists, nekas netika skenēts.
- `RUNTIME_KEY_DECODE_INCOMPATIBLE` — spēles procesa nolasītās atslēgas kodēšanas modelis nav savietojams ar oriģinālo ENC.
- `DLL_KEY_CANDIDATE_XML_RECOVERED` — atrasts ar DLL faila signatūras kandidātu atkodēts oriģinālais XML, bet **nav pierādīts**, ka šo DLL funkciju spēle tiešām izmanto.
- `ORIGINAL_MAPINFO_DECODED` — ar spēles procesa koda atslēgu atgūts un verificēts oriģinālais XML, bet nevar droši ģenerēt konkrēto Warp 675 labojumu.
- `CANDIDATE_OFFLINE_PREPARED` vai `DLL_KEY_OFFLINE_CANDIDATE_PREPARED` — izveidots **tikai laboratorijas** `.enc` kandidāts. **Nav spēles tests vai instalācijas atļauja darba klientā.**
- `FAILED` — nav izpildījies kāds priekšnosacījums vai notikusi piekļuves kļūda, neko nepārveido.

## Izolētas kopijas piemērošana — tikai pēc kandidāta iegūšanas

Ja ir izveidots `EXPERIMENTAL_OFFLINE_CANDIDATE`, un **jau eksistē** neatkarīga spēles kopija `F:\CABAL_291_LAB`, kurā ir oriģinālais mapinfo, laboratorijas pielietošana ir atsevišķa, skaidri izvēlēta darbība:

```powershell
py -3 tools\isolated_apply.py --isolated-root "F:\CABAL_291_LAB" --candidate-dir "C:\...\StageO_v291_...\EXPERIMENTAL_OFFLINE_CANDIDATE" --apply
py -3 tools\isolated_apply.py --isolated-root "F:\CABAL_291_LAB" --candidate-dir "C:\...\StageO_v291_...\EXPERIMENTAL_OFFLINE_CANDIDATE" --rollback
```

**Nekādā gadījumā neizmanto šo kandidātu aktīvajā klientā bez atsevišķa Windows/spēles testa.** Projekta aktīvo serveri, `WorldSvr`, SQL, Costume, Mileage un citus addonus šis rīks nemaina.

## Bez apstiprinājuma paliek

Oriģinālais v291 mapinfo nav atkodēts ar pašreiz pieejamajiem diska failiem; nav pierādīts, ka oriģinālais klients izmanto references `World 8 / Warp 675 / 4380` izvēlni. Nevar apgalvot, ka `MainCmd(485)` atvienošanās ir salabota. Reālā Windows atmiņas stāvokļa un aktīvo DLL datu pieejamība ir neatrisinātais posms. 

### Sabiedriskās references

CABAL ENC standarta algoritms (ne obligāti šī klienta faktiskā atslēga): https://github.com/Michael-K-GH/libcozip
Par iespēju, ka atslēga ir klienta DLL, diskutēts: https://forum.ragezone.com/threads/main-program-key-viewing-issue-and-client-crashes-after-cabal-enc-encryption.1238202/ (diskusijas pieņēmums, ne pierādījums šim konkrētajam klientam).
