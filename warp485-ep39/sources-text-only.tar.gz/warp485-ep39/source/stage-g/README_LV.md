# CABAL v291 — Warp485 G posms: pilnais trīskāršais reģistra audits

**Statuss:** bezsaistes, tikai lasīšanas analīze. **NAV instalējams Warp labojums.** Atsauces `mapinfo.dec` ir no **cita CABAL klienta arhīva**, nevis apstiprināti oriģinālā v291 klienta resursi. Tāpēc visi klienta izvēlnes secinājumi ir hipotēzes par v291, nevis pierādīta faktiskā klienta konfigurācija.

## Jaunais pret F posmu

F posms salīdzināja dungeon ID un mērķa World ID. G posmā tiek papildus pārbaudīta izvēlnes `icon_value warp_index` saite pret servera `Warp.scp` indeksu **un sākuma World ID**.

Atsauces XML ir **50** Warp grupas. Servera `Warp.scp`:

- **47** grupām Warp ID un izcelsmes World ID sakrīt.
- **3** grupām Warp ID serverī neeksistē: **876, 877, 879**.
- `World 8 / Warp 675` ir **reģistrēts un tā World ID sakrīt**.

Atsauces XML ir **81** dungeon (`dungeon_index != 0`) izvēlnes ieraksts. Pēc trīs komponentu salīdzināšanas:

| Statuss | Skaits |
|---|---:|
| Derīgs Warp ID + sākuma World ID + dungeon ID + mērķa World ID | 65 |
| Trūkst dungeon ID | 10 |
| Trūkst servera Warp ID | 5 |
| Dungeon ID ir, bet mērķa World ID atšķiras | 1 |
| **Kopā** | **81** |

Piecas trūkstošā Warp ID `877` dungeon saites ir **218, 253, 302, 303, 304**. Šie dungeon ID un mērķa World ID sakrīt ar serveri, bet *izvēlnes izcelsmes Warp 877* servera failā nav. Parastā Warp `dungeon_index=0` nav dungeon reģistrācijas kļūda; `876` un `879` ir divas šādas atsevišķas Warp grupas.

### Tieši mūsu kļūdas vieta

- `World 8 / Warp 675`: servera Warp ieraksts ir klāt ar `WorldIdx=8`.
- `qdIdx=4380`: servera dungeon reģistrā nav. Pieprasījumu serveris noraida; tas ir saskaņā ar `OnCSCQDungeonLimitCheck` žurnālu.
- Atsauces XML paredz `4380 -> World 168`, taču tas **nav v291 oriģinālā klienta pierādījums**.
- Tajā pašā atsauces izvēlnē `4352` ir saderīgs, bet `4378` mērķa pasaule 166 neatbilst servera `WorldIdx=172`.

Šī trīskāršā salīdzināšana parāda, kāpēc problēmu nevar droši risināt ar patvaļīgu 4380 pārsaukšanu, ieraksta izveidi vai pārbaudes atslēgšanu. Ja pievieno faktiskas dungeon konfigurācijas, jāpārbauda arī mērķa pasaule, Warp ieeja un visi saistītie servera resursi.

## Pārbaudāmie artefakti

- `triple_join_audit.py` — tikai lasīšanas audits, var strādāt ar **jebkuru jau dekodētu** `mapinfo` XML un šādas struktūras servera `.scp` ZIP.
- `test_stage_g.py`, `test_results.txt` — **21/21** bezsaistes regresijas un negatīvie testi.
- `report.json` — rezultāts ar precīziem katra ieraksta statusiem.
- `REFERENCE_UNVERIFIED_mapinfo.dec` — cita klienta XML references fails, **NAV uzstādāms** v291 faila aizvietotājs.
- `server_registry_evidence.zip` — iepriekš iegūtais servera konfigurāciju snapshot, nevis jauna informācija no šobrīd aktīvā VM.

Lai pārbaudītu bezsaistē:

```bash
python3 -m unittest -v test_stage_g.py
python3 triple_join_audit.py --xml REFERENCE_UNVERIFIED_mapinfo.dec --server-zip server_registry_evidence.zip --json report.json
```

**Nekad nepalaist `mapinfo.enc` kā dekodētu XML**. Rīks noraida šifrētu/ne-XML ievadi. Nav šifrēšanas, spēles palaišanas, SSH, DB, kopiju aizstāšanas vai klienta/servera patch funkciju.

## Kas vēl vajadzīgs galīgajam labojumam

1. Autentiski dekodēts v291 klienta `mapinfo` vai ekvivalents tā pašas versijas *faktiski izmantoto* Warp izvēlnes ierakstu apliecinājums. Pieejamie v291 `.enc` līdz šim nav veiksmīgi atkodēti; vecās XOR/DEFLATE hipotēzes ir pārbaudītas un neder.
2. Tikai tad jāizvēlas minimālā taktika: nepieprasīt neesošu dungeon no klienta izvēlnes **vai** iegūt īstos servera dungeon resursus un loģiku. Nav pierādījuma, ka vienkāršs XML ierakstu dzēšanas kandidāts ir drošs un instalējams šajā klientā.
3. Gameplay tests nav veikts. Aktīvā WorldSvr hash sakritība ar analīzes kopiju vēl nav verificēta.

Netiek atslēgta servera validācija un nekas nav mainīts aktīvajā serverī, klientā vai SQL.
