#!/usr/bin/env python3
"""Reference-only, read-only audits. No game resources are modified."""
import unittest
from pathlib import Path
from triple_join_audit import *

HERE=Path(__file__).resolve().parent
DATA=(HERE/'REFERENCE_UNVERIFIED_mapinfo.dec').read_bytes()
ZIP=HERE/'server_registry_evidence.zip'

class TripleJoinTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dungeon,cls.warp=server_registries(ZIP)
        cls.result=audit(DATA,cls.dungeon,cls.warp)

    def test_dungeon_registry_count(self):
        self.assertEqual(len(self.dungeon),587)
    def test_warp_registry_count(self):
        self.assertEqual(len(self.warp),856)
    def test_675_exists_at_world_8(self):
        self.assertEqual(self.warp[675],8)
    def test_877_not_in_warp_registry(self):
        self.assertNotIn(877,self.warp)
    def test_4380_missing_from_dungeon_registry(self):
        self.assertNotIn(4380,self.dungeon)
    def test_total_reference_groups(self):
        self.assertEqual(len(self.result['groups']),50)
    def test_total_reference_entries(self):
        self.assertEqual(len(self.result['entries']),81)
    def test_group_distribution(self):
        self.assertEqual(self.result['group_status_counts'],{'warp_match':47,'missing_server_warp':3})
    def test_entry_distribution(self):
        self.assertEqual(self.result['entry_status_counts'],{'triple_match':65,'missing_dungeon_id':10,'missing_server_warp':5,'target_world_mismatch':1})
    def test_675_4380_missing(self):
        rows=[x for x in self.result['entries'] if x['origin_world']==8 and x['warp_id']==675 and x['dungeon_id']==4380]
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['status'],MISSING_DUNGEON)
    def test_675_4352_valid(self):
        rows=[x for x in self.result['entries'] if x['origin_world']==8 and x['warp_id']==675 and x['dungeon_id']==4352]
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['status'],OK)
    def test_675_4378_world_mismatch(self):
        rows=[x for x in self.result['entries'] if x['origin_world']==8 and x['warp_id']==675 and x['dungeon_id']==4378]
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['status'],WORLD_MISMATCH)
        self.assertEqual(rows[0]['target_world'],166)
        self.assertEqual(rows[0]['server_dungeon_world'],172)
    def test_877_group_missing_even_with_valid_dungeons(self):
        rows=[x for x in self.result['entries'] if x['origin_world']==1 and x['warp_id']==877]
        self.assertEqual(sorted(x['dungeon_id'] for x in rows),[218,253,302,303,304])
        self.assertTrue(all(x['status']==MISSING_WARP and x['server_dungeon_world']==x['target_world'] for x in rows))
    def test_missing_regular_warps_not_dungeon_entries(self):
        self.assertFalse(any(x['warp_id'] in (876,879) for x in self.result['entries']))
        self.assertTrue(all(any(g['warp_id']==wid and g['warp_status']==MISSING_WARP for g in self.result['groups']) for wid in (876,879)))
    def test_changed_warp_877_becomes_valid(self):
        changed=dict(self.warp);changed[877]=1
        res=audit(DATA,self.dungeon,changed)
        rows=[x for x in res['entries'] if x['warp_id']==877]
        self.assertEqual(len(rows),5)
        self.assertTrue(all(x['status']==OK for x in rows))
    def test_changed_dungeon_4380_becomes_valid(self):
        changed=dict(self.dungeon);changed[4380]={'world':168,'file':'synthetic'}
        res=audit(DATA,changed,self.warp)
        rows=[x for x in res['entries'] if x['dungeon_id']==4380 and x['warp_id']==675]
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['status'],OK)
    def test_wrong_origin_world_detected(self):
        changed=dict(self.warp);changed[675]=2
        res=audit(DATA,self.dungeon,changed)
        rows=[x for x in res['entries'] if x['warp_id']==675]
        self.assertEqual(len(rows),7)
        self.assertTrue(all(x['status']==WARP_WORLD_MISMATCH for x in rows))
    def test_enc_rejected(self):
        with self.assertRaisesRegex(ValueError,'ENC_OR_NON_XML_REFUSED'):
            audit((HERE/'REFERENCE_UNVERIFIED_mapinfo.dec').read_bytes()[:0]+b'\xcd\xbf\x00\x00',self.dungeon,self.warp)
    def test_malformed_xml_rejected(self):
        with self.assertRaises(ET.ParseError):
            audit(b'<cabal><bad></cabal>',self.dungeon,self.warp)
    def test_duplicate_reference_groups_kept(self):
        groups=[x for x in self.result['groups'] if x['origin_world']==22 and x['warp_id']==612]
        self.assertEqual(len(groups),2)
    def test_source_not_mutated(self):
        self.assertEqual(sha(DATA),'83bec4c54dc68ea6ec4a6bf333cab1323092711a11546a9ad84c2a17d7540e86')

if __name__=='__main__':
    unittest.main(verbosity=2)
