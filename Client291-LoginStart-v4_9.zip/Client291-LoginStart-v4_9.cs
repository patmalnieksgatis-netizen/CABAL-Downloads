// Isolated v291 start adapter. A private initial-thread gate preserves all
// Main/SDK image bytes during Windows loader and SDK initialization.
// No client file writes, proxy DLL, injected thread or debugger.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

public sealed class Client291LoginStartV49 : IDisposable {
    const bool RuntimeEnabled=true; // V4.5 character adapter plus guarded Core World142 translation candidate.
    public sealed class Hook {
        public string Role, OriginalWindowSHA256, SDKWindowSHA256, RegistrarWindowSHA256, RegistrarSHA256;
        public int RVA, RestoreBytes, ExpectedSDKRVA, RegistrarRVA, RegistrarBytes;
    }
    public sealed class SDKPatch {
        public string Role, ExpectedSHA256, ReplacementHex;
        public int RVA, Bytes;
    }
    public sealed class VersionCall {
        public string Role, OriginalFunctionSHA256;
        public int RVA, FunctionRVA, FunctionBytes;
    }
    public sealed class Config {
        public string Root, MainSHA256, SDKSHA256, DXVKSHA256;
        public int MainEntryRVA, ServerVersion;
        public byte[] CharacterListCode, WorldBridgeCode;
        public Hook[] MainHooks;
        public SDKPatch[] SDKPatches;
        public VersionCall[] VersionCalls;
    }
    public sealed class State {
        public WorldProfile World;
        public int PID, LastDispatchTable, LastDispatchKey;
        public bool Exited;
        public uint ExitCode, NativeSourcePort;
        public string Mode, NativeSourceIP, NativeEndpointIP;
        public uint NativeEndpointPort;
        public byte NativeConnected;
        public bool IntegrityGood;
        public string IntegrityState;
        public byte NativeSecurityUse;
        public uint CharacterListUnwind,CharacterListBusy,CharacterListSeen,CharacterListsConverted,
            CharacterListsAlready291,CharacterListsRejected,CharacterListStatus,CharacterListBytes,
            CharacterListCharacters,CharacterListReaderReturned;
    }
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    struct Startup {
        public uint Size; public string Reserved, Desktop, Title;
        public uint X,Y,XSize,YSize,XCount,YCount,Fill,Flags;
        public ushort Show,ReservedSize; public IntPtr ReservedPointer,Input,Output,Error;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct ProcessInfo { public IntPtr Process, Thread; public uint PID, TID; }
    [StructLayout(LayoutKind.Sequential)]
    struct Region {
        public IntPtr Base,AllocationBase;public uint AllocationProtect;
        public ushort Partition,Padding;public UIntPtr Size;public uint State,Protect,Type;
    }
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
    static extern bool CreateProcessW(string file,StringBuilder command,IntPtr pa,IntPtr ta,
        bool inherit,uint flags,IntPtr environment,string directory,ref Startup startup,out ProcessInfo info);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr p,IntPtr at,byte[] data,UIntPtr n,out UIntPtr got);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool WriteProcessMemory(IntPtr p,IntPtr at,byte[] data,UIntPtr n,out UIntPtr got);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool VirtualProtectEx(IntPtr p,IntPtr at,UIntPtr n,uint protection,out uint old);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern IntPtr VirtualAllocEx(IntPtr p,IntPtr address,UIntPtr bytes,uint allocation,uint protection);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern UIntPtr VirtualQueryEx(IntPtr p,IntPtr at,out Region region,UIntPtr size);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool FlushInstructionCache(IntPtr p,IntPtr at,UIntPtr size);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint ResumeThread(IntPtr thread);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetThreadContext(IntPtr thread,IntPtr context);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetThreadContext(IntPtr thread,IntPtr context);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr p,out uint code);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(IntPtr p,uint code);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    [DllImport("psapi.dll",CharSet=CharSet.Unicode,ExactSpelling=true,SetLastError=true)]
    static extern uint GetMappedFileNameW(IntPtr process,IntPtr address,StringBuilder path,uint count);
    [DllImport("ntdll.dll")] static extern int NtSuspendProcess(IntPtr process);
    [DllImport("ntdll.dll")] static extern int NtResumeProcess(IntPtr process);
    [DllImport("ntdll.dll")] static extern int NtQueryInformationProcess(IntPtr process,int kind,
        byte[] information,int bytes,out int returned);

    const long Main=0x140000000L;
    const int MainSize=0x131c000, SDKSize=0x1264000;
    readonly List<Edit> edits=new List<Edit>();
    sealed class Edit { public string Name;public long At;public byte[] Before,After; }
    sealed class IntegrityRange { public long At,HashAt;public int Bytes;public ulong BeforeHash,AfterHash;public bool Affected; }
    ProcessInfo child;
    bool frozen,completed,entryReleased;
    long sdk,gate,characterListBase,worldBridgeBase;
    public string WorldBridgeBaseHex { get { return worldBridgeBase.ToString("X"); } }
    public string CharacterListBaseHex { get { return characterListBase.ToString("X"); } }
    public string InitialRIPHex { get; private set; }
    public string InitialStartRCXHex { get; private set; }
    public string GateBaseHex { get { return gate.ToString("X"); } }
    byte[] original;
    Config config;
    public int PID { get { return (int)child.PID; } }
    public string Stage { get; private set; }
    public int CodeEditCount { get; private set; }
    public int IntegrityUpdates { get; private set; }
    public int IntegrityRangesVerified { get; private set; }
    public string InitialIntegrityState { get; private set; }
    public string IntegrityAudit { get; private set; }
    public string SDKBaseHex { get { return sdk.ToString("X"); } }

    static void Need(bool yes,string error) { if (!yes) throw new Exception(error); }
    static void Win(bool yes) { if (!yes) throw new Win32Exception(Marshal.GetLastWin32Error()); }
    public static string ClassifyIntegrity(uint good,uint bad,uint current) {
        if(good==bad)return "NOT_INITIALIZED";
        return current==good?"GOOD":current==bad?"BAD":"PENDING";
    }
    string IntegrityStateNow() {return ClassifyIntegrity(U32(sdk+0x9cc320),U32(sdk+0x9cc324),U32(sdk+0x9cc328));}
    void RequireInitialIntegrityPhase() {
        string state=IntegrityStateNow();
        InitialIntegrityState=state;
        Need(state!="NOT_INITIALIZED" && state!="BAD","SDK_INTEGRITY_STATE="+state);
        if(state=="PENDING"){
            long rip=ThreadControl(false,0);
            Need(!entryReleased && gate!=0 && (rip==gate || rip==gate+2),"PENDING_ONLY_BEFORE_ORIGINAL_MAIN_ENTRY");
        }
    }
    public static string Hash(byte[] b) {
        using(SHA256 s=SHA256.Create())return BitConverter.ToString(s.ComputeHash(b)).Replace("-", "").ToLowerInvariant();
    }
    public static byte[] Unhex(string text) {
        Need(text!=null && text.Length%2==0,"HEX_LENGTH");byte[] b=new byte[text.Length/2];
        for(int i=0;i<b.Length;i++)b[i]=Convert.ToByte(text.Substring(i*2,2),16);return b;
    }
    static bool Equal(byte[] a,byte[] b) {
        if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;
    }
    public static void ValidateTail(byte[] file,byte[] live,int rva,int prefix,Hook[] selected) {
        Need(file.Length==32 && live.Length==32 && prefix>=5 && prefix<=16,"TAIL_WINDOW_SHAPE");
        for(int i=prefix;i<32;i++){
            int at=rva+i;bool covered=false;
            foreach(Hook other in selected)if(other.RVA!=rva && other.RVA<=at && at<other.RVA+other.RestoreBytes)covered=true;
            if(!covered)Need(live[i]==file[i],"HOOK_TAIL_DIFFERS_AT="+at.ToString("X"));
        }
    }
    byte[] Read(long at,int n) {
        Need(at>=65536 && n>0 && n<=32*1024*1024 && checked(at+n)<0x7fffffffffffL,"READ_BOUNDS");
        byte[] b=new byte[n];UIntPtr got;
        Win(ReadProcessMemory(child.Process,new IntPtr(at),b,new UIntPtr((uint)n),out got));
        Need(got.ToUInt64()==(ulong)n,"PARTIAL_READ");return b;
    }
    uint U32(long at) { return BitConverter.ToUInt32(Read(at,4),0); }
    ulong U64(long at) { return BitConverter.ToUInt64(Read(at,8),0); }
    Region Query(long at) {
        Region r;int n=Marshal.SizeOf(typeof(Region));Need(n==48,"X64_REGION_LAYOUT");
        Win(VirtualQueryEx(child.Process,new IntPtr(at),out r,new UIntPtr((uint)n)).ToUInt64()==(ulong)n);return r;
    }
    void Image(long at,int n,long allocation) {
        long end=checked(at+n);
        while(at<end){Region r=Query(at);long stop=checked(r.Base.ToInt64()+(long)r.Size.ToUInt64());
            Need(r.State==0x1000 && r.Type==0x1000000 && r.AllocationBase.ToInt64()==allocation &&
                 (r.Protect&0x101)==0 && stop>at,"IMAGE_REGION_DIFFERS");at=Math.Min(stop,end);}
    }
    long Resolve(long at) {
        for(int hop=0;hop<4;hop++){
            Region region=Query(at);Need(region.State==0x1000 && (region.Protect&0x101)==0 &&
                (region.Protect&0xf0)!=0 && (region.Type==0x1000000 || region.Type==0x20000),"HOOK_NOT_EXECUTABLE_IMAGE_OR_RELAY");
            byte[] b=Read(at,6);
            if(b[0]==0xe9){at=checked(at+5+BitConverter.ToInt32(b,1));continue;}
            if(b[0]==0xff && b[1]==0x25){long slot=checked(at+6+BitConverter.ToInt32(b,2));
                Region pointer=Query(slot);Need(pointer.AllocationBase==region.AllocationBase && pointer.State==0x1000 &&
                    (pointer.Protect&0x101)==0,"RELAY_POINTER_ALLOCATION_DIFFERS");at=(long)U64(slot);continue;}
            return at;
        }
        throw new Exception("HOOK_JUMP_LIMIT");
    }
    long FindSDK() {
        // A native endpoint is not evidence that libogg is absent. Query the
        // loader's module list instead of subtracting an assumed hook target.
        byte[] info=new byte[48];int returned;
        int status=NtQueryInformationProcess(child.Process,0,info,info.Length,out returned);
        Need(status>=0 && returned==info.Length && BitConverter.ToUInt64(info,32)==child.PID,"OWN_PROCESS_BASIC_INFO");
        long peb=(long)BitConverter.ToUInt64(info,8),ldr=(long)U64(peb+0x18);
        Need(ldr>=65536,"LOADER_NOT_INITIALIZED");
        long head=checked(ldr+0x10),entry=(long)U64(head),address=0;
        var seen=new HashSet<long>();
        for(int i=0;entry!=head;i++){
            Need(i<512 && entry>=65536 && seen.Add(entry),"LOADER_LIST_INVALID");
            byte[] row=Read(entry,0x68);int length=BitConverter.ToUInt16(row,0x58),capacity=BitConverter.ToUInt16(row,0x5a);
            Need(length%2==0 && length<=512 && capacity>=length,"LOADER_MODULE_NAME_SHAPE");
            string name=length==0?"":Encoding.Unicode.GetString(Read((long)BitConverter.ToUInt64(row,0x60),length));
            if(name.Equals("libogg.dll",StringComparison.OrdinalIgnoreCase)){
                Need(address==0,"DUPLICATE_SDK_MODULE");address=(long)BitConverter.ToUInt64(row,0x30);
                Need(BitConverter.ToUInt32(row,0x40)==SDKSize,"SDK_LOADER_SIZE_DIFFERS");
            }
            entry=(long)BitConverter.ToUInt64(row,0);
        }
        Need(address>=65536 && (address&0xffff)==0,"SDK_NOT_IN_LOADER_LIST");
        Image(address,4096,address);
        byte[] b=Read(address,4096);int pe=BitConverter.ToInt32(b,60);
        Need(b[0]==77 && b[1]==90 && pe>=64 && pe<=2048 && BitConverter.ToUInt32(b,pe)==0x4550 &&
            BitConverter.ToUInt16(b,pe+4)==0x8664 && BitConverter.ToUInt16(b,pe+24)==0x20b &&
            BitConverter.ToUInt32(b,pe+80)==SDKSize,"SDK_PE_DIFFERS");
        var path=new StringBuilder(32768);
        Need(GetMappedFileNameW(child.Process,new IntPtr(address),path,(uint)path.Capacity)!=0 &&
            path.ToString().EndsWith("\\libogg.dll",StringComparison.OrdinalIgnoreCase),"SDK_MAPPED_FILE_DIFFERS");
        return address;
    }
    void SDKReady() {
        Image(sdk+0x9cc320,0x80,sdk);Image(sdk+0x9cd328,4,sdk);
        Need(U32(sdk+0x9cd328)==0,"SDK_HOOK_TRANSACTION_PENDING");
        // These bodies must have been unpacked before examining mutable state.
        foreach(Hook h in config.MainHooks){
            Need(h.RegistrarBytes==0x7f,"REGISTRAR_EXTENT_DIFFERS");
            Image(sdk+h.RegistrarRVA,h.RegistrarBytes,sdk);Image(sdk+h.ExpectedSDKRVA,32,sdk);
            Need(Hash(Read(sdk+h.RegistrarRVA,h.RegistrarBytes))==h.RegistrarSHA256,"SDK_REGISTRAR_NOT_READY="+h.Role);
            Need(Hash(Read(sdk+h.ExpectedSDKRVA,32))==h.SDKWindowSHA256,"SDK_HANDLER_NOT_READY="+h.Role);
        }
        Need(Read(sdk+0x9cc394,1)[0]==0,"SDK_INTEGRITY_WORKER_BUSY");
        // The normal checker is started by the application constructor. A
        // pending marker before Main is expected to remain pending at this gate.
        // Commit must still verify ALL five real input digests before any edits.
        RequireInitialIntegrityPhase();
        Need(Resolve(Main+0x27b384)==sdk+0x5e2bb0 && Resolve(Main+0x2820f8)==sdk+0x5e2bf0 &&
             Resolve(Main+0x269174)==sdk+0x5e2bd0,"SDK_APPLICATION_HOOKS_NOT_READY");
    }
    string RouteState(int mainRVA,int sdkRVA) {
        try {
            if(Equal(Read(Main+mainRVA,32),FileRVA(original,mainRVA,32)))return "NATIVE";
            return sdk!=0 && Resolve(Main+mainRVA)==sdk+sdkRVA?"SDK":"OTHER";
        } catch {return "UNREADABLE";}
    }
    void Write(long at,byte[] bytes) {
        Need(frozen,"WRITE_REQUIRES_STOPPED_OWN_PROCESS");uint old,discard;UIntPtr got;
        Win(VirtualProtectEx(child.Process,new IntPtr(at),new UIntPtr((uint)bytes.Length),0x40,out old));
        try {
            Win(WriteProcessMemory(child.Process,new IntPtr(at),bytes,new UIntPtr((uint)bytes.Length),out got));
            Need(got.ToUInt64()==(ulong)bytes.Length,"PARTIAL_WRITE");
            Win(FlushInstructionCache(child.Process,new IntPtr(at),new UIntPtr((uint)bytes.Length)));
        } finally { Win(VirtualProtectEx(child.Process,new IntPtr(at),new UIntPtr((uint)bytes.Length),old,out discard)); }
        Need(Equal(Read(at,bytes.Length),bytes),"WRITE_READBACK_DIFFERS");
    }
    public static byte[] FileRVA(byte[] file,int rva,int n) {
        Need(file.Length>256 && file[0]==77 && file[1]==90,"MAIN_NOT_PE");int pe=BitConverter.ToInt32(file,60);
        Need(pe>=64 && pe<=2048 && pe+24<file.Length,"PE_OFFSET");
        int count=BitConverter.ToUInt16(file,pe+6),table=pe+24+BitConverter.ToUInt16(file,pe+20);
        Need(count>0 && count<96 && table+count*40<=file.Length,"SECTION_TABLE");
        for(int i=0;i<count;i++){
            int at=table+i*40,virtualRVA=BitConverter.ToInt32(file,at+12),raw=BitConverter.ToInt32(file,at+16),off=BitConverter.ToInt32(file,at+20);
            if(rva>=virtualRVA && (long)rva+n<=virtualRVA+(long)raw){
                int source=checked(off+rva-virtualRVA);Need(source>=0 && (long)source+n<=file.Length,"FILE_RVA_BOUNDS");
                byte[] b=new byte[n];Array.Copy(file,source,b,0,n);return b;}
        }
        throw new Exception("FILE_RVA_NOT_PRESENT");
    }
    void Profile() {
        string path=Path.Combine(config.Root,@"Data\internal.txt");
        Need(System.IO.File.Exists(path),"LOCAL_INTERNAL_PROFILE_MISSING");
        string section="";var values=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        foreach(string raw in System.IO.File.ReadAllLines(path)) {
            string line=raw.Trim();if(line.Length==0 || line[0]==';' || line[0]=='#')continue;
            if(line[0]=='[' && line.EndsWith("]")){section=line.Substring(1,line.Length-2).Trim();continue;}
            int equals=line.IndexOf('=');if(equals<1)continue;
            string key=section+"/"+line.Substring(0,equals).Trim();
            if(key.Equals("SERVER/IP",StringComparison.OrdinalIgnoreCase) ||
               key.Equals("SERVER/PORT",StringComparison.OrdinalIgnoreCase)) {
                Need(!values.ContainsKey(key),"DUPLICATE_LOCAL_ENDPOINT_SETTING");values.Add(key,line.Substring(equals+1).Trim());
            }
        }
        Need(values.ContainsKey("SERVER/IP") && values["SERVER/IP"]=="192.168.56.101" &&
             values.ContainsKey("SERVER/PORT") && values["SERVER/PORT"]=="35003","LOCAL_ENDPOINT_PROFILE_DIFFERS");
    }
    void Freeze() { int code=NtSuspendProcess(child.Process);Need(code>=0,"NT_SUSPEND="+code.ToString("X8"));frozen=true; }
    void Thaw() { if(!frozen)return;int code=NtResumeProcess(child.Process);Need(code>=0,"NT_RESUME="+code.ToString("X8"));frozen=false; }
    long ThreadControl(bool replace,long instruction) {return ThreadContext(replace?1:0,instruction);}
    long ThreadContext(int action,long value) {
        IntPtr memory=Marshal.AllocHGlobal(1280);
        try {long aligned=(memory.ToInt64()+15)&~15L;IntPtr context=new IntPtr(aligned);
            for(int i=0;i<1232;i++)Marshal.WriteByte(context,i,0);
            Marshal.WriteInt32(context,48,0x100003);Win(GetThreadContext(child.Thread,context));
            long before=Marshal.ReadInt64(context,248);
            if(action==2){
                Need(frozen,"INITIAL_CONTEXT_REQUIRES_SUSPENDED_CHILD");
                InitialRIPHex=before.ToString("X");long start=Marshal.ReadInt64(context,128);
                InitialStartRCXHex=start.ToString("X");
                Need(start==Main+config.MainEntryRVA,"INITIAL_START_RCX_IS_NOT_PINNED_MAIN_ENTRY");
                Region r=Query(before);Image(before,1,r.AllocationBase.ToInt64());
                var path=new StringBuilder(32768);
                Need(GetMappedFileNameW(child.Process,new IntPtr(before),path,(uint)path.Capacity)!=0 &&
                    path.ToString().EndsWith("\\ntdll.dll",StringComparison.OrdinalIgnoreCase),"INITIAL_THREAD_START_NOT_NTDLL");
            }
            if(action!=0){Need(frozen,"CONTEXT_WRITE_REQUIRES_STOPPED_PROCESS");
                Need(action==1 || action==2,"CONTEXT_ACTION");
                // Before loader startup RCX is the primary thread start address.
                // At the private gate the CALL has already supplied normal Main
                // arguments: preserve them and change ONLY RIP to the entry.
                Marshal.WriteInt64(context,action==2?128:248,value);
                Win(SetThreadContext(child.Thread,context));}
            return before;
        } finally { Marshal.FreeHGlobal(memory); }
    }
    void Queue(string name,long at,byte[] before,byte[] after,long allocation) {
        Need(before.Length==after.Length && before.Length>0 && before.Length<=32,"PATCH_LENGTH");
        Image(at,before.Length,allocation);Need(Equal(Read(at,before.Length),before),"PATCH_INPUT_DIFFERS="+name);
        foreach(Edit e in edits)Need(at+before.Length<=e.At || e.At+e.Before.Length<=at,"PATCH_OVERLAP");
        edits.Add(new Edit{Name=name,At=at,Before=before,After=after});
    }
    public static ulong Decode64(byte[] bytes,ulong seed) {
        Need(bytes!=null && bytes.Length==8,"DECODE64_LENGTH");
        ulong state=seed^0x3c6ef372fe94f82aUL,result=0;byte previous=0x5a;
        unchecked {for(int i=0;i<8;i++){state^=state<<13;state^=state>>7;state^=state<<17;
            byte c=bytes[i];result|=(ulong)(byte)(c^(byte)state^previous)<<(i*8);previous=c;}}
        return result;
    }
    public static ulong HashBuffer(byte[] bytes,ulong seed,ulong prime) {
        unchecked {foreach(byte b in bytes)seed=(seed^b)*prime;}return seed;
    }
    ulong Fnv(long at,int count,ulong seed,ulong prime) {
        Need(count>=0 && count<=32*1024*1024,"HASH_BUDGET");ulong value=seed;
        unchecked {for(int offset=0;offset<count;){int n=Math.Min(65536,count-offset);byte[] b=Read(at+offset,n);
            value=HashBuffer(b,value,prime);offset+=n;}}
        return value;
    }
    bool Overlaps(long at,int n) {
        long end=checked(at+n);foreach(Edit e in edits)if(at<e.At+e.After.Length && e.At<end)return true;return false;
    }
    List<IntegrityRange> IntegrityBefore(out ulong seed,out ulong prime) {
        long obj=sdk+0x9cc320;Image(obj,0x80,sdk);
        RequireInitialIntegrityPhase();
        Need(Read(obj+0x74,1)[0]==0,"INTEGRITY_WORKER_BUSY");
        seed=Decode64(Read(sdk+0x9c4310,8),U64(sdk+0x6bb4d0)^U64(sdk+0x6bb4d8));
        prime=Decode64(Read(sdk+0x9c4318,8),U64(sdk+0x6bb4e8)^U64(sdk+0x6bb4f0));
        Need(prime!=0 && (prime&1)==1,"INTEGRITY_PRIME_DIFFERS");
        var ranges=new List<IntegrityRange>();
        ranges.Add(new IntegrityRange{At=Main+0x1000,Bytes=0xb3049f,HashAt=obj+0x10,Affected=true});
        int[,] layout={{0x38,0x40,0x30},{0x50,0x68,0x18},{0x58,0x6c,0x20},{0x60,0x70,0x28}};
        int[] expectedLengths={0x10000,0x6afae7,0x1d55d2,0x61ee2c};
        int[] expectedRVAs={0,0x1000,0xa6b000,0xc43000};
        for(int i=0;i<4;i++){
            ulong pointer=U64(obj+layout[i,0]);uint n=U32(obj+layout[i,1]);
            Need(n<=32*1024*1024 && pointer<=0x7fffffffffffUL && pointer+n>=pointer,"INTEGRITY_RANGE_BOUNDS");
            Need(n==expectedLengths[i] && pointer>=65536,"INTEGRITY_RANGE_SHAPE="+i+":"+pointer.ToString("X")+":"+n);
            if(i==0){Region pool=Query((long)pointer);Need(pool.AllocationBase.ToInt64()==(long)pointer && pool.Type==0x20000,
                "SDK_DETOURS_POOL_NOT_PRIVATE_ALLOCATION");}
            else {Need((long)pointer==sdk+expectedRVAs[i],"INTEGRITY_IMAGE_RANGE_POINTER="+i);Image((long)pointer,(int)n,sdk);}
            Need(!((long)pointer<gate+4096 && gate<(long)pointer+n),"PRIVATE_START_GATE_IS_CHECKED_BY_SDK");
            ranges.Add(new IntegrityRange{At=(long)pointer,Bytes=(int)n,HashAt=obj+layout[i,2],Affected=Overlaps((long)pointer,(int)n)});
        }
        IntegrityAudit="";
        foreach(IntegrityRange r in ranges){
            Need(characterListBase==0 || !(r.At<characterListBase+0x30000 && characterListBase<r.At+r.Bytes),
                "CHARLIST_REGION_OVERLAPS_SDK_CHECKED_RANGE");
            Need(worldBridgeBase==0 || !(r.At<worldBridgeBase+0x810000 && worldBridgeBase<r.At+r.Bytes),
                "WORLD_BRIDGE_OVERLAPS_SDK_CHECKED_RANGE");
            r.BeforeHash=U64(r.HashAt);
            ulong actual=Fnv(r.At,r.Bytes,seed,prime);
            IntegrityAudit+=r.At.ToString("X")+":"+actual.ToString("X16")+"/"+r.BeforeHash.ToString("X16")+";";
            Need(actual==r.BeforeHash,"INTEGRITY_BASELINE_DIFFERS_AT="+r.At.ToString("X"));}
        IntegrityRangesVerified=ranges.Count;InitialIntegrityState=IntegrityStateNow();
        return ranges;
    }
    // Two fixed Login-only opcode immediates. Keep the verified V4.1 startup,
    // native packet builder, reply handler, and all payload bytes unchanged.
    public static byte[] LoginIWarInstruction(int windowRVA,byte[] file,byte[] live) {
        int bytes,offset,length,immediate;string expected;
        if(windowRVA==0x6a46e0){bytes=67;offset=0x15;length=5;immediate=1;
            expected="194d7efb1dd7da3de301b37cd3df10626e2e6160ad18b24a97caac020c091b25";}
        else if(windowRVA==0x6a0c54){bytes=43;offset=4;length=7;immediate=3;
            expected="125f8e75039d56c8ce356b5770b25f5dcc0c78ec2cf04825714259f1efdb6759";}
        else throw new Exception("UNREVIEWED_LOGIN_IWAR_WINDOW");
        Need(file!=null && live!=null && file.Length==bytes && live.Length==bytes,
            "LOGIN_IWAR_WINDOW_LENGTH");
        Need(Hash(file)==expected && Equal(file,live),"LOGIN_IWAR_WINDOW_DIFFERS");
        byte[] after=new byte[length];Array.Copy(file,offset,after,0,length);
        Need(BitConverter.ToUInt32(after,immediate)==5383,"LOGIN_IWAR_SOURCE_OPCODE");
        Array.Copy(BitConverter.GetBytes(3383),0,after,immediate,4);
        return after;
    }
    void PlanLoginIWar() {
        int[] windows={0x6a46e0,0x6a0c54},sizes={67,43},offsets={0x15,4};
        string[] roles={"LoginC2SIWar3383","LoginS2CIWar3383Registration"};
        for(int i=0;i<windows.Length;i++){
            byte[] file=FileRVA(original,windows[i],sizes[i]);
            byte[] after=LoginIWarInstruction(windows[i],file,Read(Main+windows[i],sizes[i]));
            int rva=windows[i]+offsets[i];
            Queue(roles[i],Main+rva,FileRVA(original,rva,after.Length),after,Main);
        }
    }
    // Native EP36 CompletedStep1 produces S2C2006 subtype17. The original
    // v291 completed-result branch selects13. Select17 in this isolated native
    // server profile; keep the real result/payload and result handler untouched.
    public static byte[] LoginCompletedStepInstruction(byte[] file,byte[] live) {
        Need(file!=null && live!=null && file.Length==32 && live.Length==32,
            "LOGIN_COMPLETED_STEP_WINDOW_LENGTH");
        Need(Hash(file)=="c30d579a8d504b4e1437f2dcb7560da3960721c4821764f377e16751eb5f0ca9" && Equal(file,live),
            "LOGIN_COMPLETED_STEP_WINDOW_DIFFERS");
        byte[] after=new byte[3];Array.Copy(file,13,after,0,3);
        Need(Equal(after,Unhex("83ff0d")),"LOGIN_COMPLETED_STEP_SOURCE_COMPARE");
        after[2]=17;return after;
    }
    void PlanLoginCompletedStep() {
        byte[] file=FileRVA(original,0x6a23f8,32);
        byte[] after=LoginCompletedStepInstruction(file,Read(Main+0x6a23f8,32));
        Queue("NativeCompletedStep1Type17",Main+0x6a2405,FileRVA(original,0x6a2405,3),after,Main);
    }
    // Native Verify102 compares only this public build-profile field at+18.
    // Keep the original packet/session fields and server equality check intact.
    public static byte[] ChannelBuildMarkerInstruction(byte[] file,byte[] live) {
        Need(file!=null && live!=null && file.Length==49 && live.Length==49,
            "CHANNEL_BUILD_WINDOW_LENGTH");
        Need(Hash(file)=="9fc185a9f80c53ecbad4446edc786300f5309d0aa918154280b983ece9e1341e" && Equal(file,live),
            "CHANNEL_BUILD_WINDOW_DIFFERS");
        byte[] before=new byte[5];Array.Copy(file,20,before,0,5);
        Need(Equal(before,Unhex("e8ff08c1ff")),"CHANNEL_BUILD_SOURCE_CALL");
        byte[] after=new byte[5];after[0]=0xb8;
        Array.Copy(BitConverter.GetBytes(620313112),0,after,1,4);return after;
    }
    void PlanChannelBuildMarker() {
        byte[] file=FileRVA(original,0x6a4924,49);
        byte[] after=ChannelBuildMarkerInstruction(file,Read(Main+0x6a4924,49));
        Queue("C2S102PublicBuildProfile",Main+0x6a4938,FileRVA(original,0x6a4938,5),after,Main);
    }
    const string CharacterListCodeSHA="2118548e4ef63c09581926367a18f29bf27d487d0fd9f7e09a11bd205999387e";
    public static byte[] CharacterListRegistration(byte[] file,byte[] live,uint callback) {
        Need(file!=null && live!=null && file.Length==63 && live.Length==63,"CHARLIST_REGISTRATION_LENGTH");
        Need(Hash(file)=="35051b9d67930b18ae80c44aaf27e0a9ed2a8224c6c8f9a1d9518deac4c09564" && Equal(file,live),
            "CHARLIST_REGISTRATION_DIFFERS");
        Need(callback>=65536 && callback<0xffff0000U && (callback&15)==0,"CHARLIST_CALLBACK_BOUNDS");
        byte[] originalLEA=new byte[7];Array.Copy(file,27,originalLEA,0,7);
        Need(Equal(originalLEA,Unhex("488d057a2d0000")),"CHARLIST_SOURCE_CALLBACK");
        byte[] after=Unhex("b8000000009090");Array.Copy(BitConverter.GetBytes(callback),0,after,1,4);return after;
    }
    long NativeSystemImport(int rva) {
        long pointer=(long)U64(Main+rva);Region r=Query(pointer);
        Image(pointer,1,r.AllocationBase.ToInt64());Need((r.Protect&0xf0)!=0,"BRIDGE_API_NOT_EXECUTABLE");
        var path=new StringBuilder(32768);
        Need(GetMappedFileNameW(child.Process,new IntPtr(pointer),path,(uint)path.Capacity)!=0,"BRIDGE_API_NO_MODULE");
        string name=path.ToString();
        Need(name.EndsWith("\\kernelbase.dll",StringComparison.OrdinalIgnoreCase) ||
             name.EndsWith("\\kernel32.dll",StringComparison.OrdinalIgnoreCase) ||
             name.EndsWith("\\ntdll.dll",StringComparison.OrdinalIgnoreCase),"BRIDGE_API_NOT_NATIVE_SYSTEM_IMAGE");
        return pointer;
    }
    void PlanCharacterList() {
        Need(config.CharacterListCode!=null && config.CharacterListCode.Length==16372 &&
            Hash(config.CharacterListCode)==CharacterListCodeSHA,"CHARLIST_OWN_CODE_DIFFERS");
        Need(Hash(Read(Main+0x72b578,32))=="78fe7fb67c21570d5435372dccae6fc5ff7881d28aaea29b3629f5cbffdf78a1",
            "CHARLIST_ORIGINAL_READER_ENTRY_DIFFERS");
        byte[] file=FileRVA(original,0x7287dc,63),live=Read(Main+0x7287dc,63);
        // Check the registration before allocating anything. The native reader
        // remains untouched; only its one callback registration is redirected.
        CharacterListRegistration(file,live,0x20000020U);
        long getModule=NativeSystemImport(0xb32658),getProc=NativeSystemImport(0xb32660);
        foreach(long candidate in new long[]{0x20000000L,0x30000000L,0x40000000L}) {
            long allocated=VirtualAllocEx(child.Process,new IntPtr(candidate),new UIntPtr(0x30000),0x3000,4).ToInt64();
            if(allocated==0)continue;Need(allocated==candidate,"CHARLIST_ALLOCATION_ADDRESS_DIFFERS");characterListBase=allocated;break;
        }
        Need(characterListBase!=0,"CHARLIST_PRIVATE_ADDRESS_UNAVAILABLE");
        Region region=Query(characterListBase);
        Need(region.State==0x1000 && region.Type==0x20000 && region.AllocationBase.ToInt64()==characterListBase &&
             region.Size.ToUInt64()>=0x30000,"CHARLIST_PRIVATE_REGION_DIFFERS");
        Write(characterListBase,config.CharacterListCode);
        byte[] context=new byte[72];
        Array.Copy(BitConverter.GetBytes(Main+0x72b578),0,context,0,8);
        Array.Copy(BitConverter.GetBytes(Main+0x120cb60),0,context,8,8);
        Array.Copy(BitConverter.GetBytes(getModule),0,context,16,8);
        Array.Copy(BitConverter.GetBytes(getProc),0,context,24,8);
        Write(characterListBase+0x4000,context);
        uint previous;Win(VirtualProtectEx(child.Process,new IntPtr(characterListBase),new UIntPtr(0x4000),0x20,out previous));
        Need(Hash(Read(characterListBase,16372))==CharacterListCodeSHA,"CHARLIST_CODE_READBACK_DIFFERS");
        byte[] after=CharacterListRegistration(file,live,(uint)(characterListBase+32));
        Queue("S2C133CharacterListRegistration",Main+0x7287f7,FileRVA(original,0x7287f7,7),after,Main);
    }
    public sealed class WorldProfile {
        public bool Complete;
        public uint Unwind,Busy,Seen,Prepared,Rejected,Dispatched,Status,SourceBytes,TargetBytes,
            Group,Cursor,BadOffset,BadCount,Generation,Hold,AutoRelease,LeasesUsed,ListDeclared,ListRestored,
            PetPositiveMask,PetNegativeMask,QuestCount,LegacyPassNonzeroMask,
            QuestsValidated,QuestProgressBytesAdded,QuestBegin,QuestEnd;
    }
    const string WorldBridgeCodeSHA="09c12d5e6e7a40beb491a5e53864faaea0a2cf0fb25bc6663eae5f81d46c3e6d";
    public static byte[] WorldBridgeRegistration(byte[] file,byte[] live,uint callback) {
        Need(file!=null && live!=null && file.Length==63 && live.Length==63,"WORLD_BRIDGE_REGISTRATION_LENGTH");
        Need(Hash(file)=="aa2ab9052f367537999b21f19a5c48b5d81671f62a4c690a75c76b9d9527e5af" && Equal(file,live),
            "WORLD_BRIDGE_REGISTRATION_DIFFERS");
        Need(callback>=65536 && callback<0xffff0000U && (callback&15)==0,"WORLD_BRIDGE_CALLBACK_BOUNDS");
        byte[] before=new byte[7];Array.Copy(file,23,before,0,7);
        Need(Equal(before,Unhex("488d0552320000")),"WORLD_BRIDGE_SOURCE_CALLBACK");
        byte[] after=Unhex("b8000000009090");Array.Copy(BitConverter.GetBytes(callback),0,after,1,4);return after;
    }
    void PlanWorldBridge() {
        Need(Hash(System.IO.File.ReadAllBytes(Path.Combine(config.Root,@"Data\quest.enc")))==
            "c298999da93d3d1c3e415b1618efeda80362e7247945e26226090a29ee18ea3d","WORLD_QUEST_RESOURCE_PROFILE_DIFFERS");
        Need(config.WorldBridgeCode!=null && config.WorldBridgeCode.Length==16372 && Hash(config.WorldBridgeCode)==WorldBridgeCodeSHA,
            "WORLD_BRIDGE_OWN_CODE_DIFFERS");
        byte[] file=FileRVA(original,0x728730,63),live=Read(Main+0x728730,63);
        WorldBridgeRegistration(file,live,0x50000000U);
        foreach(long candidate in new long[]{0x50000000L,0x60000000L,0x70000000L}) {
            long allocated=VirtualAllocEx(child.Process,new IntPtr(candidate),new UIntPtr(0x810000),0x3000,4).ToInt64();
            if(allocated==0)continue;Need(allocated==candidate,"WORLD_BRIDGE_ALLOCATION_ADDRESS_DIFFERS");worldBridgeBase=allocated;break;
        }
        Need(worldBridgeBase!=0,"WORLD_BRIDGE_PRIVATE_ADDRESS_UNAVAILABLE");
        Region region=Query(worldBridgeBase);
        Need(region.State==0x1000 && region.Type==0x20000 && region.AllocationBase.ToInt64()==worldBridgeBase &&
             region.Size.ToUInt64()>=0x810000,"WORLD_BRIDGE_PRIVATE_REGION_DIFFERS");
        Write(worldBridgeBase,config.WorldBridgeCode);
        byte[] context=new byte[136];
        // Call the unchanged original Main entry; its SDK detour remains active.
        byte[] entry=FileRVA(original,0x72b9a0,32),liveEntry=Read(Main+0x72b9a0,32);
        Need(Hash(entry)=="5e8375ee231a135b9668ca23021837bd5226a0ca3ac8ab37cd5382afdc4a75dd","WORLD_MAIN_ENTRY_FILE_DIFFERS");
        if(!Equal(entry,liveEntry)) {
            Need(liveEntry[0]==0xe9 && Resolve(Main+0x72b9a0)==sdk+0x5e3c90,"WORLD_NATURAL_SDK_ROUTE_DIFFERS");
            for(int i=5;i<32;i++)Need(liveEntry[i]==entry[i],"WORLD_MAIN_ENTRY_TAIL_DIFFERS");
        }
        Need(Hash(Read(sdk+0x5e3c90,32))=="e10e0d58a3f3a050f3d6565dc257b1a224745b4a146fca8491198bf4b57f1a5d","WORLD_SDK_ENTRY_DIFFERS");
        Array.Copy(BitConverter.GetBytes(Main+0x72b9a0),0,context,0,8);
        Array.Copy(BitConverter.GetBytes(NativeSystemImport(0xb32658)),0,context,8,8);
        Array.Copy(BitConverter.GetBytes(NativeSystemImport(0xb32660)),0,context,16,8);
        Write(worldBridgeBase+0x4000,context);
        uint previous;Win(VirtualProtectEx(child.Process,new IntPtr(worldBridgeBase),new UIntPtr(0x4000),0x20,out previous));
        Need(Hash(Read(worldBridgeBase,16372))==WorldBridgeCodeSHA,"WORLD_BRIDGE_CODE_READBACK_DIFFERS");
        byte[] after=WorldBridgeRegistration(file,live,(uint)worldBridgeBase);
        Queue("S2C142CoreWorldBridgeRegistration",Main+0x728747,FileRVA(original,0x728747,7),after,Main);
    }
    public void ReleasePreparedWorld(uint expectedGeneration) {
        Need(completed && worldBridgeBase!=0,"WORLD_BRIDGE_NOT_OWNED");
        WorldProfile w=ReadWorldProfile();
        Need(w.Complete && w.Status==1 && w.Hold==1 && w.Generation==expectedGeneration,"WORLD_NOT_PREPARED_COMPLETE");
        Write(worldBridgeBase+0x405c,BitConverter.GetBytes((uint)1));
        Write(worldBridgeBase+0x4058,BitConverter.GetBytes((uint)0));
    }
    public void FinishRejectedWorld() {
        Need(completed && worldBridgeBase!=0,"WORLD_BRIDGE_NOT_OWNED");
        WorldProfile w=ReadWorldProfile();Need(w.Complete && w.Status>=10 && w.Hold==1,"WORLD_NOT_REFUSED_COMPLETE");
        uint exit;Win(GetExitCodeProcess(child.Process,out exit));Need(exit==259,"WORLD_CHILD_ALREADY_EXITED");
        Win(TerminateProcess(child.Process,0xe2910149));
    }
    public void FinishWorldTestBeforeDispatch() {
        Need(completed && worldBridgeBase!=0,"WORLD_BRIDGE_NOT_OWNED");
        WorldProfile w=ReadWorldProfile();Need(w.Dispatched==0 && w.AutoRelease==0,"WORLD_ALREADY_RELEASED");
        uint exit;Win(GetExitCodeProcess(child.Process,out exit));Need(exit==259,"WORLD_CHILD_ALREADY_EXITED");
        Win(TerminateProcess(child.Process,0xe2911490));
    }
    static uint[] Words(byte[] data,int first,int count) {
        uint[] result=new uint[count];for(int i=0;i<count;i++)result[i]=BitConverter.ToUInt32(data,(first+i)*4);return result;
    }
    WorldProfile ReadWorldProfile() {
        if(worldBridgeBase==0)return null;
        byte[] data=Read(worldBridgeBase+0x4020,104);uint[] v=Words(data,0,26);
        var w=new WorldProfile{Unwind=v[0],Busy=v[1],Seen=v[2],Prepared=v[3],Rejected=v[4],Dispatched=v[5],
            Status=v[6],SourceBytes=v[7],TargetBytes=v[8],Group=v[9],Cursor=v[10],BadOffset=v[11],BadCount=v[12],
            Generation=v[13],Hold=v[14],AutoRelease=v[15],ListDeclared=v[16],ListRestored=v[17],
            PetPositiveMask=v[18],PetNegativeMask=v[19],QuestCount=v[20],LegacyPassNonzeroMask=v[21],
            QuestsValidated=v[22],QuestProgressBytesAdded=v[23],QuestBegin=v[24],QuestEnd=v[25]};
        w.Complete=v[13]!=0 && (v[13]&1)==0 && v[1]==0 && U32(worldBridgeBase+0x4054)==v[13];
        ulong used=U64(worldBridgeBase+0x4018);for(int i=0;i<64;i++)if((used&(1UL<<i))!=0)w.LeasesUsed++;
        return w;
    }
    void Plan() {
        Need(config.MainHooks.Length==12 && config.SDKPatches.Length==3 && config.VersionCalls.Length==2,"MANIFEST_COUNTS");
        SDKReady();
        long socket=(long)U64(Main+0x126a9f0);
        if(socket!=0){Need(socket>=65536 && Read(socket+0x7c,1)[0]==0 && U64(socket+8)==ulong.MaxValue && U64(socket+0x50)==0,
            "LOGIN_SOCKET_ALREADY_INITIALIZED");}
        // First validate every selected prefix. Adjacent verified hooks can
        // occupy another entry's 32-byte tail; they are checked independently.
        foreach(Hook h in config.MainHooks){
            Need(h.RestoreBytes>=5 && h.RestoreBytes<=16,"HOOK_PREFIX_LENGTH");
            byte[] file=FileRVA(original,h.RVA,32),live=Read(Main+h.RVA,32);
            Need(Hash(file)==h.OriginalWindowSHA256,"ORIGINAL_ENTRY_HASH="+h.Role);
            Need(Hash(Read(sdk+h.ExpectedSDKRVA,32))==h.SDKWindowSHA256,"SDK_ENTRY_HASH="+h.Role);
            byte[] prefix=new byte[h.RestoreBytes],native=new byte[h.RestoreBytes];
            Array.Copy(live,prefix,prefix.Length);Array.Copy(file,native,native.Length);
            if(!Equal(prefix,native)){
                Need(live[0]==0xe9 && Resolve(Main+h.RVA)==sdk+h.ExpectedSDKRVA,
                    "HOOK_ROUTE_DIFFERS="+h.Role);
                for(int i=5;i<h.RestoreBytes;i++)Need(live[i]==0xcc,"HOOK_PADDING_DIFFERS="+h.Role);
                byte[] before=new byte[h.RestoreBytes],after=new byte[h.RestoreBytes];Array.Copy(live,before,before.Length);Array.Copy(file,after,after.Length);
                Queue(h.Role,Main+h.RVA,before,after,Main);
            }
            // Verified leaf attach helpers return DetourAttach's success zero.
            // Transaction ownership is zero and the whole child is stopped.
            // Disabling these entries also covers hooks not installed yet.
            Need(h.RegistrarBytes==0x7f,"REGISTRAR_EXTENT_DIFFERS");
            Queue("PreventReattach_"+h.Role,sdk+h.RegistrarRVA,Read(sdk+h.RegistrarRVA,3),Unhex("31c0c3"),sdk);
        }
        foreach(Hook h in config.MainHooks){
            byte[] file=FileRVA(original,h.RVA,32),live=Read(Main+h.RVA,32);
            ValidateTail(file,live,h.RVA,h.RestoreBytes,config.MainHooks);
        }
        foreach(SDKPatch p in config.SDKPatches){byte[] before=Read(sdk+p.RVA,p.Bytes),after=Unhex(p.ReplacementHex);
            Need(Hash(before)==p.ExpectedSHA256,"SDK_PATCH_HASH="+p.Role);Queue(p.Role,sdk+p.RVA,before,after,sdk);}
        Need(config.ServerVersion==282,"UNREVIEWED_SERVER_VERSION_PROFILE");
        foreach(VersionCall p in config.VersionCalls){
            Need(Hash(Read(Main+p.FunctionRVA,p.FunctionBytes))==p.OriginalFunctionSHA256,"VERSION_FUNCTION_DIFFERS");
            byte[] after=new byte[5];after[0]=0xb8;Array.Copy(BitConverter.GetBytes(config.ServerVersion),0,after,1,4);
            Queue(p.Role,Main+p.RVA,FileRVA(original,p.RVA,5),after,Main);
        }
        PlanLoginIWar();
        PlanLoginCompletedStep();
        PlanChannelBuildMarker();
        PlanCharacterList();
        PlanWorldBridge();
    }
    void Commit() {
        Plan();ulong seed,prime;var integrity=IntegrityBefore(out seed,out prime);int applied=0;
        uint currentBefore=U32(sdk+0x9cc328);int updated=0;
        try {
            foreach(Edit edit in edits){applied++;Write(edit.At,edit.After);}
            foreach(IntegrityRange r in integrity)if(r.Affected)r.AfterHash=Fnv(r.At,r.Bytes,seed,prime);
            foreach(IntegrityRange r in integrity)if(r.Affected){Write(r.HashAt,BitConverter.GetBytes(r.AfterHash));updated++;}
            Need(U32(sdk+0x9cc328)==currentBefore,"INTEGRITY_STATUS_CHANGED_WHILE_STOPPED");
            // The private gate was reached through the normal Windows startup
            // CALL. Enter the untouched Main entry with its current arguments.
            ThreadControl(true,Main+config.MainEntryRVA);
            entryReleased=true;CodeEditCount=edits.Count;IntegrityUpdates=updated;completed=true;
        } catch {
            // The owned child is still stopped; restore every attempted edit and digest.
            for(int i=applied-1;i>=0;i--)try{Write(edits[i].At,edits[i].Before);}catch{}
            foreach(IntegrityRange r in integrity)if(r.Affected)try{Write(r.HashAt,BitConverter.GetBytes(r.BeforeHash));}catch{}
            throw;
        }
    }
    public static Client291LoginStartV49 Start(Config cfg) {
        Need(RuntimeEnabled,"LOGIN_START_NOT_RELEASED");
        var self=new Client291LoginStartV49();self.config=cfg;
        try {self.Launch();return self;}catch(Exception e) {
            self.Abort();self.Dispose();throw new Exception("STAGE="+self.Stage+"; PID="+self.PID+"; "+e.Message+
                "; INITIAL_RIP="+self.InitialRIPHex+"; INITIAL_START_RCX="+self.InitialStartRCXHex+"; SDK_BASE="+self.SDKBaseHex+
                "; INITIAL_INTEGRITY="+self.InitialIntegrityState+"; CODE_DIGEST_AUDIT="+self.IntegrityAudit);
        }
    }
    void Launch() {
        Stage="FILES";Need(Environment.Is64BitProcess && Environment.OSVersion.Platform==PlatformID.Win32NT,"WINDOWS_X64_REQUIRED");
        Need(String.Equals(config.Root,@"F:\CABAL_291_TEST",StringComparison.OrdinalIgnoreCase),"ISOLATED_ROOT_ONLY");
        Profile();
        string bin=Path.Combine(config.Root,@"Bin\x64"),exe=Path.Combine(bin,"CabalMain.exe");
        original=System.IO.File.ReadAllBytes(exe);Need(Hash(original)==config.MainSHA256,"MAIN_FILE_DIFFERS");
        Need(Hash(System.IO.File.ReadAllBytes(Path.Combine(bin,"libogg.dll")))==config.SDKSHA256,"SDK_FILE_DIFFERS");
        Need(Hash(System.IO.File.ReadAllBytes(Path.Combine(bin,"d3d9.dll")))==config.DXVKSHA256,"DXVK_FILE_DIFFERS");
        Startup startup=new Startup();startup.Size=(uint)Marshal.SizeOf(typeof(Startup));Need(startup.Size==104,"STARTUP_LAYOUT");
        Stage="CREATE_SUSPENDED";Win(CreateProcessW(exe,new StringBuilder("\""+exe+"\" breaklee"),IntPtr.Zero,IntPtr.Zero,false,4,
            IntPtr.Zero,bin,ref startup,out child));frozen=true;
        Need(config.MainEntryRVA==0x9f9638 && BitConverter.ToInt32(original,BitConverter.ToInt32(original,60)+40)==config.MainEntryRVA,
            "UNREVIEWED_MAIN_ENTRY");
        Stage="ALLOCATE_PRIVATE_START_GATE";
        // Far from the captured SDK Detours pool at100000000 and both images.
        // VirtualAllocEx cannot overwrite an existing allocation at this address.
        gate=VirtualAllocEx(child.Process,new IntPtr(0x300000000L),new UIntPtr(4096),0x3000,4).ToInt64();
        Need(gate==0x300000000L,"PRIVATE_GATE_ADDRESS_UNAVAILABLE");
        Region gateRegion=Query(gate);
        Need(gateRegion.Type==0x20000 && gateRegion.State==0x1000 && gateRegion.AllocationBase.ToInt64()==gate,"PRIVATE_GATE_ALLOCATION_DIFFERS");
        Write(gate,Unhex("f390ebfc"));uint oldProtection;
        Win(VirtualProtectEx(child.Process,new IntPtr(gate),new UIntPtr(4096),0x20,out oldProtection));
        Stage="SELECT_PRIVATE_INITIAL_THREAD_START";ThreadContext(2,gate);
        Need(ResumeThread(child.Thread)!=0xffffffff,"INITIAL_RESUME_FAILED");frozen=false;
        Stage="WAIT_PRIVATE_GATE_AFTER_LOADER";DateTime deadline=DateTime.UtcNow.AddSeconds(25);bool ready=false;
        string lastSDKFailure="MAIN_THREAD_NOT_AT_GATE",printedSDKFailure="";
        Console.WriteLine("V4_GAIDU_ORIGINALO_SDK; MAIN_KODS_PIRMS_INICIALIZACIJAS_NETIEK_MAINITS");
        while(DateTime.UtcNow<deadline){uint exit;Win(GetExitCodeProcess(child.Process,out exit));Need(exit==259,"CLIENT_EXITED_BEFORE_GATE="+exit.ToString("X8"));
            Freeze();long rip=ThreadControl(false,0);
            if(rip==gate || rip==gate+2){
                try {
                    sdk=FindSDK();
                    SDKReady();ready=true;break;
                }
                catch(Exception e) { lastSDKFailure=e.Message; }
            }
            if(lastSDKFailure!=printedSDKFailure){Console.WriteLine("SDK_STATUS="+lastSDKFailure);printedSDKFailure=lastSDKFailure;}
            Thaw();Thread.Sleep(20);
        }
        Need(ready,"PRIVATE_ENTRY_GATE_TIMEOUT; LAST_SDK_REASON="+lastSDKFailure+
            "; SDK_BASE="+sdk.ToString("X")+"; CTOR="+RouteState(0x27b384,0x5e2bb0)+
            "; SETTINGS="+RouteState(0x2820f8,0x5e2bf0)+"; ENDPOINT="+RouteState(0x69afd8,0x5e33d0));
        Stage="PREFLIGHT_AND_COMMIT";Commit();
        Stage="RESUME_PATCHED_CLIENT";Thaw();
        Need(Hash(System.IO.File.ReadAllBytes(exe))==config.MainSHA256 &&
             Hash(System.IO.File.ReadAllBytes(Path.Combine(bin,"libogg.dll")))==config.SDKSHA256 &&
             Hash(System.IO.File.ReadAllBytes(Path.Combine(bin,"d3d9.dll")))==config.DXVKSHA256,"DISK_IDENTITY_CHANGED");
        Stage="APPLIED_RUNTIME_ONLY_WINDOWS_LOGIN_UNVERIFIED";
    }
    string Text(long at) {
        byte[] head=Read(at,32);ulong length=BitConverter.ToUInt64(head,16),capacity=BitConverter.ToUInt64(head,24);
        if(length==0)return "";Need(length<=255 && capacity>=length && capacity<=4096,"ENDPOINT_STRING_SHAPE");
        string text=Encoding.ASCII.GetString(Read(capacity<16?at:(long)BitConverter.ToUInt64(head,0),(int)length));
        foreach(char c in text)Need(char.IsLetterOrDigit(c) || c=='.' || c==':' || c=='-' || c=='_',"ENDPOINT_TEXT_SHAPE");return text;
    }
    public State Snapshot() {
        uint exit;Win(GetExitCodeProcess(child.Process,out exit));var s=new State{PID=PID,Exited=exit!=259,ExitCode=exit};if(s.Exited)return s;
        s.NativeSourceIP=Text(Main+0xd94f78);s.NativeSourcePort=U32(Main+0xdd5b08);
        s.NativeEndpointIP=Text(Main+0x126ad10);s.NativeEndpointPort=U32(Main+0x126ad30);
        s.LastDispatchTable=(int)U32(Main+0x126ace4);s.LastDispatchKey=(int)U32(Main+0x126ace8);
        long socket=(long)U64(Main+0x126a9f0);if(socket>=65536)s.NativeConnected=Read(socket+0x7c,1)[0];
        s.IntegrityState=IntegrityStateNow();s.IntegrityGood=s.IntegrityState=="GOOD";
        s.NativeSecurityUse=Read(Main+0xd94ec8,1)[0];
        if(characterListBase!=0){
            byte[] info=Read(characterListBase+0x4020,40);
            s.CharacterListUnwind=BitConverter.ToUInt32(info,0);s.CharacterListBusy=BitConverter.ToUInt32(info,4);
            s.CharacterListSeen=BitConverter.ToUInt32(info,8);s.CharacterListsConverted=BitConverter.ToUInt32(info,12);
            s.CharacterListsAlready291=BitConverter.ToUInt32(info,16);s.CharacterListsRejected=BitConverter.ToUInt32(info,20);
            s.CharacterListStatus=BitConverter.ToUInt32(info,24);s.CharacterListBytes=BitConverter.ToUInt32(info,28);
            s.CharacterListCharacters=BitConverter.ToUInt32(info,32);s.CharacterListReaderReturned=BitConverter.ToUInt32(info,36);
        }
        s.World=ReadWorldProfile();
        long mode=(long)U64(Main+0x120f7a0);
        s.Mode="UNINITIALIZED";
        if(mode>=65536) {
            byte[] b=Read(mode,12);uint sum=b[4],value=0;
            for(int i=0;i<4;i++){sum+=b[i];value|=(uint)(b[i]^b[4])<<(8*i);}
            s.Mode=sum==BitConverter.ToUInt32(b,8)?value.ToString():"CHECKSUM_DIFFERS";
        }
        return s;
    }
    public bool VerifyCode() {
        Need(completed,"PATCH_NOT_COMMITTED");
        if(characterListBase!=0 && Hash(Read(characterListBase,16372))!=CharacterListCodeSHA)return false;
        if(worldBridgeBase!=0 && Hash(Read(worldBridgeBase,16372))!=WorldBridgeCodeSHA)return false;
        foreach(Edit edit in edits)
            if(!Equal(Read(edit.At,edit.After.Length),edit.After))return false;return true;
    }
    void Abort() {if(child.Process!=IntPtr.Zero){uint exit;if(GetExitCodeProcess(child.Process,out exit) && exit==259)TerminateProcess(child.Process,0xe2910001);frozen=false;} }
    public void Dispose() {
        if(!completed)Abort();
        if(child.Thread!=IntPtr.Zero){CloseHandle(child.Thread);child.Thread=IntPtr.Zero;}
        if(child.Process!=IntPtr.Zero){CloseHandle(child.Process);child.Process=IntPtr.Zero;}
    }
}
