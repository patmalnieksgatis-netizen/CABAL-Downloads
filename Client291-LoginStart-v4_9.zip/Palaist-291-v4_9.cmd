@echo off
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Client291-LoginStart-v4_9.ps1" -Action Run
pause
