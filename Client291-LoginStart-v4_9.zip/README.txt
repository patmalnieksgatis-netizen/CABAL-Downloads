V4.9 - PROFILED QUEST WORLD142 ADAPTER; WINDOWS WORLD ENTRY UNVERIFIED

Only F:\CABAL_291_TEST and test VM192.168.56.101. Original game/server/SQL
files are unchanged. Keeps the verified V4.5 Login/CH/character adapter.

Close CABAL, leave test VM running. Run Palaist-291-v4_9.cmd as administrator.
Use a fresh test account without legacy pet/progress data. If empty, create
one ordinary Warrior in slot0 with an ASCII name, then enter World once.
The actual291 C2S134 layout matches the native slot16/name-length17/name18
layout; this is a static contract check, not gameplay verification.
On accepted conversion the game stays open. Tell us what appears and return
Downloads/Client291-LoginStart-v4_9-*.json (exact path printed as REPORT).
Dispatch does not prove that the original World reader returned or World opened.

Actual decoded v291 quest definitions were compared with the current native
Quest.scp and1186 native loaded count rows.1141 exact objective profiles:
1087 copy all progress unchanged;46 have NO native objective progress and
receive only neutral client progress bytes. This includes quest3028.
Eight partial nonempty objective subsets,31 different objective definitions,
14 missing client definitions and unknown quests are explicitly refused.
Seven-byte quest headers/state/slot remain unchanged; all existing progress
and the complete suffix after quests remain byte-identical. No SQL quest
state, completion, rewards or source packet is changed. Output growth is
bounded by65535. Source is retained privately in the original client process.

Positive first DWORDs in the old83-byte pet/item records still refuse14;
pet migration is not implemented. Legacy EventPass progress still refuses.
No account reset, guard removal or pet data deletion is performed by this tool.
Keeps the original SDK route, settings/file/resource hooks, native caller return
and RDX/R8/R9, ten fixed spans/44 stream checks,64 immutable leases and exact
last15-byte-list count recovery. Five new setting rows have keys0..4.

New statuses21 incompatible/missing quest profile,22 partial nonempty objective
subset;15 invalid quest count/slot. QuestsValidated/QuestProgressBytesAdded/
QuestBegin/QuestEnd explain conversion without exporting active quest IDs.

298 checks run the actual own Win64 blob; World game/SDK reader is a host stub.
C#/PS/native registration guards and nine exact V4.5 baseline methods pass.
Actual full Windows World entry and new character gameplay remain unverified.
Only own code, own compiled callbacks and nonsecret framing metadata included.
