param([ValidateSet('Inspect','Run')][string]$Action='Inspect')
$ErrorActionPreference='Stop'
if ($Action -eq 'Run') { Write-Host 'LOGIN_START_V4_9; PARBAUDU_KOMPILACIJU_UN_ORIGINALOS_FAILUS' }
if (![Environment]::Is64BitProcess) { throw 'USE_X64_POWERSHELL' }
$manifestPath=Join-Path $PSScriptRoot 'client291-login-start-v4_9.json'
if (!(Test-Path -LiteralPath $manifestPath)) {
    $manifestPath=Join-Path (Split-Path -Parent $PSScriptRoot) 'protocol/generated/client291-login-start-v4_9.json'
}
$manifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.Status -ne 'PREPARED_WINDOWS_UNVERIFIED') {
    if ($Action -eq 'Inspect') {
        [ordered]@{Status=$manifest.Status; Reason=$manifest.WithdrawalReason; ProcessStarted=$false; ClientFileChanges=$false} | ConvertTo-Json
        return
    }
    throw 'LOGIN_START_PROFILE_NOT_PREPARED; CLIENT_NOT_STARTED'
}
if (!('Client291LoginStartV49' -as [type])) {
    Add-Type -Path (Join-Path $PSScriptRoot 'Client291-LoginStart-v4_9.cs')
}
$config=New-Object Client291LoginStartV49+Config
$config.Root=$manifest.TargetRoot
foreach ($name in @('MainSHA256','SDKSHA256','DXVKSHA256','MainEntryRVA','ServerVersion')) {
    $config.$name=$manifest.$name
}
$hooks=@()
foreach ($row in $manifest.MainHooks) {
    $hook=New-Object Client291LoginStartV49+Hook
    foreach ($name in @('Role','OriginalWindowSHA256','SDKWindowSHA256','RVA','RestoreBytes','ExpectedSDKRVA','RegistrarRVA','RegistrarBytes','RegistrarWindowSHA256','RegistrarSHA256')) {
        $hook.$name=$row.$name
    }
    $hooks+=$hook
}
$config.MainHooks=$hooks
$patches=@()
foreach ($row in $manifest.SDKPatches) {
    $patch=New-Object Client291LoginStartV49+SDKPatch
    foreach ($name in @('Role','ExpectedSHA256','ReplacementHex','RVA','Bytes')) { $patch.$name=$row.$name }
    $patches+=$patch
}
$config.SDKPatches=$patches
$versions=@()
foreach ($row in $manifest.VersionCalls) {
    $version=New-Object Client291LoginStartV49+VersionCall
    foreach ($name in @('Role','OriginalFunctionSHA256','RVA','FunctionRVA','FunctionBytes')) { $version.$name=$row.$name }
    $versions+=$version
}
$config.VersionCalls=$versions
$bridgePath=Join-Path $PSScriptRoot 'Client291-CharacterListBridge.bin'
if (!(Test-Path -LiteralPath $bridgePath)) { $bridgePath=Join-Path (Split-Path -Parent $PSScriptRoot) 'protocol/generated/client291-characterlist-bridge.bin' }
$config.CharacterListCode=[IO.File]::ReadAllBytes($bridgePath)
if ([Client291LoginStartV49]::Hash($config.CharacterListCode) -ne $manifest.CharacterListBridge.SHA256) { throw 'CHARLIST_OWN_CODE_FILE_DIFFERS' }
$worldPath=Join-Path $PSScriptRoot 'Client291-WorldBridge.bin'
if (!(Test-Path -LiteralPath $worldPath)) { $worldPath=Join-Path (Split-Path -Parent $PSScriptRoot) 'protocol/generated/client291-world-bridge-v4_9.bin' }
$config.WorldBridgeCode=[IO.File]::ReadAllBytes($worldPath)
if ([Client291LoginStartV49]::Hash($config.WorldBridgeCode) -ne $manifest.WorldBridge.sha256) { throw 'WORLD_BRIDGE_OWN_CODE_FILE_DIFFERS' }
if ($Action -eq 'Inspect') {
    [ordered]@{
        Status='CORE_WORLD_BRIDGE_PREPARED_WINDOWS_UNVERIFIED'; WorldEntryEnabled=$true; V45CharacterSelectionUserVerified=$true
        TargetRoot=$config.Root; ServerIP=$manifest.ServerIP; ServerLoginPort=$manifest.ServerLoginPort
        ServerVersionProfile=$config.ServerVersion; ProfileVersionIsLiveReadback=$false
        LoginIWarRequestOpcode=3383; LoginIWarReplyOpcode=3383; LoginIWarEdits=2; NativeCompletedStep1Type=17; ChannelBuildMarkerProfile=620313112
        WorldBridgeBytes=$config.WorldBridgeCode.Length; WorldPacketDispatched=$false; RawPacketExport=$false; WorldSourceProfile="Core2F9B"; WorldTargetProfile="2912FB1"
        QuestExactProfiles=1141; QuestNativeZeroProgressProfiles=46; PositiveLegacyPetStateRefused=$true
        CharacterListBridgeBytes=$config.CharacterListCode.Length; CharacterListTargetBytes=34588
        NativeEntries=$hooks.Count; PreventReattachRegistrars=$hooks.Count
        SDKChanges=$patches.Count; VersionChanges=$versions.Count
        ClientFileChanges=$false; ProcessStarted=$false
    } | ConvertTo-Json
    return
}
if ($env:OS -ne 'Windows_NT') { throw 'USE_WINDOWS_X64_POWERSHELL' }
if (Get-Process -Name CabalMain -ErrorAction SilentlyContinue) { throw 'Vispirms aizver CABAL klientu.' }
$downloads=Join-Path $env:USERPROFILE 'Downloads'
$stamp=(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)
$reportPath=Join-Path $downloads ('Client291-LoginStart-v4_9-'+$stamp+'.json')
$report=[ordered]@{
    Schema=13; ToolVersion='LoginStart-v4.9-core-world-bridge'; StartedUTC=[DateTime]::UtcNow.ToString('o'); Status='STARTING'
    ServerVersionProfile=$config.ServerVersion; ServerVersionLiveReadback=$false
    WorldSourceProfile="Core2F9B"; WorldTargetProfile="2912FB1"
    QuestExactProfiles=1141; QuestSourceCountsAreCollectedSnapshot=$true; QuestClientEncodedSHA256='c298999da93d3d1c3e415b1618efeda80362e7247945e26226090a29ee18ea3d'
    LoginIWarRequestOpcode=3383; LoginIWarReplyOpcode=3383; NativeCompletedStep1Type=17; ChannelBuildMarkerProfile=620313112
    BuildProfileSource='USER_REPORTED_NATIVE_PROFILE_READ'; BuildProfileLiveReadback=$false
    ServerIdentitySource='USER_REPORTED_RUNNING_EXE_SHA256'; ServerIdentityLiveReadback=$false
    ExpectedLoginServerSHA256=$manifest.LoginIWarAlias.ServerSHA256
    WorldEntryEnabled=$true; WorldPacketDispatched=$false; RawPacketExport=$false; WorldClientStoppedAfterRefusal=$false; WorldPreparedReleased=$false; WorldEntryVerified=$false
    ClientDiskChanges=$false; CredentialsCollected=$false; Events=@(); Failure=$null
}
$session=$null
try {
    'ORIGINAL_FAILI_TIKS_SAGLABATI; TIKAI_F_CABAL_291_TEST'
    $probe=New-Object Net.Sockets.TcpClient
    try {
        $connection=$probe.BeginConnect('192.168.56.101',35003,$null,$null)
        if (!$connection.AsyncWaitHandle.WaitOne(5000)) { throw 'CLONE_LOGIN_PORT_UNREACHABLE' }
        $probe.EndConnect($connection)
    } finally { $probe.Dispose() }
    $session=[Client291LoginStartV49]::Start($config)
    $report.PID=$session.PID; $report.SDKBaseHex=$session.SDKBaseHex
    $report.WorldBridgeBaseHex=$session.WorldBridgeBaseHex
    $report.InitialRIPHex=$session.InitialRIPHex; $report.InitialStartRCXHex=$session.InitialStartRCXHex
    $report.PrivateGateHex=$session.GateBaseHex; $report.CharacterListBaseHex=$session.CharacterListBaseHex
    $report.CodeEdits=$session.CodeEditCount; $report.IntegrityRangesRebased=$session.IntegrityUpdates
    $report.IntegrityRangesVerifiedBeforeWrites=$session.IntegrityRangesVerified
    $report.InitialIntegrityState=$session.InitialIntegrityState; $report.IntegrityAudit=$session.IntegrityAudit
    $report.Status=$session.Stage
    'LOGIN_IWAR_SADERIBA=3383; COMPLETED_STEP1_TIPS=17; CH_BUILD_PROFILE=620313112; TIKAI_KLIENTA_ATMINA'
    'CHARACTER_LIST_133_SADERIBA=47_UZ_51; TIKAI_KLIENTA_ATMINA'
    'WORLD_142_CORE_FORMATA_PARVEIDOTAJS; QUEST_PROFILES=1141; TIKAI_KLIENTA_ATMINA'
    'TEST_PID='+$session.PID
    'GAIDI_LOGIN_LOGU_UN_DABISKO_SDK_PARBAUDI; INSTALACIJA_NAV_VEIKTA'
    $deadline=[DateTime]::UtcNow.AddSeconds(90)
    $integrityDeadline=[DateTime]::UtcNow.AddSeconds(10)
    $last=''; $loginPrompted=$false
    while ([DateTime]::UtcNow -lt $deadline) {
        $state=$session.Snapshot()
        $event=[ordered]@{UTC=[DateTime]::UtcNow.ToString('o'); State=$state}
        if (!$state.Exited) { $event.CodeStillMatches=$session.VerifyCode() }
        $current=$state | ConvertTo-Json -Depth 5 -Compress
        if ($current -cne $last -or $state.Exited -or $event.CodeStillMatches -eq $false) {
            $report.Events+=@($event); $current; $last=$current
        }
        if ($state.Exited) { $report.Status='CLIENT_EXITED'; break }
        if (!$event.CodeStillMatches) { $report.Status='PATCH_CHANGED_AFTER_BOOTSTRAP'; break }
        if ($state.IntegrityState -in @('BAD','NOT_INITIALIZED')) { $report.Status='INTEGRITY_STATUS_'+$state.IntegrityState; break }
        if ($null -ne $state.World -and $state.World.Complete) {
            if ($state.World.Status -ge 10 -and $state.World.Hold -eq 1) {
                $session.FinishRejectedWorld(); $report.WorldClientStoppedAfterRefusal=$true
                $report.Status='WORLD_SOURCE_REFUSED'; 'WORLD_ATTEIKTS; STATUS='+$state.World.Status+'; FIELD='+$state.World.BadOffset+'; COUNT_OR_MASK='+$state.World.BadCount+'; CURSOR='+$state.World.Cursor+'; PET_POSITIVE_MASK='+$state.World.PetPositiveMask+'; PET_NEGATIVE_MASK='+$state.World.PetNegativeMask+'; QUEST_COUNT='+$state.World.QuestCount+'; LEGACY_PASS_MASK='+$state.World.LegacyPassNonzeroMask; break
            }
            if ($state.World.Status -eq 1 -and $state.World.Hold -eq 1) {
                $session.ReleasePreparedWorld($state.World.Generation); $report.WorldPreparedReleased=$true
                'WORLD_PARVEIDOTS; NODODU_ORIGINALAJAM_KLIENTA_LASITAJAM'
            }
            if ($state.World.Dispatched -gt 0) { $report.WorldPacketDispatched=$true }
        }
        if (!$loginPrompted -and $state.IntegrityState -eq 'GOOD') {
            'SDK_PARBAUDE_DABISKI_DERIGA; IELOGOJIES_AR_TESTA_KONTU_UN_IZVELIES_TELU'
            'IZVELIES_TELU_UN_SPIED_IEIET_PASAULE; ATSTAJ_SPELI_ATVERTU'
            $loginPrompted=$true
        }
        if (!$loginPrompted -and [DateTime]::UtcNow -gt $integrityDeadline) { $report.Status='NATIVE_INTEGRITY_STILL_PENDING_AFTER_ENTRY'; break }
        Start-Sleep -Milliseconds 500
    }
    if ($report.Status -eq 'WORLD_SOURCE_REFUSED') { 'TESTA_KLIENTS_AIZVERTS_PEC_ATTEIKUMA; ATSUTI_REPORT_JSON' }
    elseif ($report.Status -eq 'CLIENT_EXITED') { 'KLIENTS_AIZVERTS; EXIT_CODE='+$state.ExitCode }
    else { 'SPELE_PALIEK_ATVERTA; CH_UN_PASAULES_REZULTATS_JAAPSTIPRINA_SPELE' }
} catch {
    $report.Status='FAILED'
    $report.Failure=$_.Exception.GetBaseException().Message
    'KLUDA='+$report.Failure
} finally {
    $report.FinishedUTC=[DateTime]::UtcNow.ToString('o')
    $report | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath $reportPath -Encoding UTF8
    if ($null -ne $session) { $session.Dispose() }
    'REPORT='+$reportPath
}
