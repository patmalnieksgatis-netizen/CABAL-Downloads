param([ValidateSet('Apply','Check','Restore')][string]$Action='Check')
$ErrorActionPreference='Stop'
Write-Host ('GUARDIAN: '+$Action+'; TIKAI 291 TESTA VM 192.168.56.101')
if($Action -eq 'Apply'){Write-Host 'AIZVER SPELI; TIKS PARSTARTETS TIKAI WORLD KANALS'}
if($Action -eq 'Restore'){
    $removed=Read-Host 'Vispirms nonem Guardian no visiem testa teliem uz inventaru. Vai tas izdarits? (J/N)'
    if($removed -ine 'J'){throw 'ATJAUNOSANA_ATCELTA; VISPIRMS_NONEM_GUARDIAN'}
}
$code=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Install-Guardian-v1.py'))
$argument='--'+$Action.ToLowerInvariant()
$code | & ssh.exe -o ConnectTimeout=10 root@192.168.56.101 python3 - $argument
if($LASTEXITCODE -ne 0){throw 'GUARDIAN_NAV_APSTIPRINATS; ATSUTI_REDZAMO_IZVADI'}
