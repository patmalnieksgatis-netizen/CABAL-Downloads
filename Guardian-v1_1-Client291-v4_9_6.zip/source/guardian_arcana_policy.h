#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>

// Own integration policy derived from the reviewed EP39 slot mapping and the
// pinned native World. No item ownership, stats or persistence are synthesized.
namespace guardian {
constexpr std::uint32_t client_slot = 50, backing_slot = 12, effect_slot = 34;
constexpr std::uint64_t kind_mask = 0x06000fff, guardian_kind = 33556103;
constexpr std::size_t equipment_offset = 0x4a60, slot_stride = 0x48;
template<class T> T load(const void* at) { T n; std::memcpy(&n,at,sizeof n); return n; }
template<class T> void store(void* at,T n) { std::memcpy(at,&n,sizeof n); }
inline bool is_guardian(std::uint64_t kind) {
    return (kind & kind_mask)==guardian_kind && ((kind>>13)&31)<=20 &&
           !(kind & UINT64_C(0xffffe000e0000000));
}
inline unsigned char* backing(void* user) {
    return static_cast<unsigned char*>(user)+equipment_offset+backing_slot*slot_stride;
}
inline bool occupied(void* user) {
    if (!user) return false;
    const auto* p=backing(user);
    return load<std::uint32_t>(p+4)!=0 && is_guardian(load<std::uint64_t>(p+8));
}
class EffectAlias {
    unsigned char* record_=nullptr;
public:
    EffectAlias(void* user,bool enable) {
        if (enable && user && load<std::uint32_t>(backing(user))==backing_slot) {
            record_=backing(user); store<std::uint32_t>(record_,effect_slot);
        }
    }
    ~EffectAlias() { if(record_) store<std::uint32_t>(record_,backing_slot); }
    EffectAlias(const EffectAlias&)=delete;
    EffectAlias& operator=(const EffectAlias&)=delete;
};
class PacketMap {
    unsigned char* packet_=nullptr;
    unsigned offsets_[4]{};
    unsigned count_=0;
public:
    PacketMap(unsigned char* p,std::size_t bytes,std::uint16_t opcode) {
        if (!p || bytes<10 || load<std::uint16_t>(p)!=0xb7e2 ||
            load<std::uint16_t>(p+2)!=bytes || load<std::uint16_t>(p+8)!=opcode) return;
        // Native move also reads the trailing DWORD at 0x22; swap uses its
        // trailing argument at 0x2a. Do not use the source's short 0x2a bound.
        const unsigned descriptors=opcode==0x875 && bytes>=0x26 ? 2 :
                                   opcode==0x876 && bytes>=0x2e ? 4 : 0;
        if(!descriptors) return;
        packet_=p;
        for(unsigned i=0;i<descriptors;i++) {
            const unsigned type=10+i*8,slot=type+4;
            if(load<std::uint32_t>(p+type)==1 && load<std::uint32_t>(p+slot)==client_slot) {
                offsets_[count_++]=slot; store<std::uint32_t>(p+slot,backing_slot);
            }
        }
    }
    ~PacketMap() {
        for(unsigned i=0;i<count_;i++) store<std::uint32_t>(packet_+offsets_[i],client_slot);
    }
    unsigned count() const { return count_; }
    PacketMap(const PacketMap&)=delete;
    PacketMap& operator=(const PacketMap&)=delete;
};
}
