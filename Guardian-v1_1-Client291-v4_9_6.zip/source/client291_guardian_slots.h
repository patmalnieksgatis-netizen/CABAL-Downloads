#ifndef CLIENT291_GUARDIAN_SLOTS_H
#define CLIENT291_GUARDIAN_SLOTS_H
/* Own wire projection: native persistent slot12 -> v291 display slot50.
 * Kind, serial, options, counts and every non-Guardian item stay unchanged. */
static inline __attribute__((always_inline)) uint32_t guardian_wire32(const unsigned char *p){
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static inline __attribute__((always_inline)) unsigned guardian_wire_slot(const unsigned char *row,unsigned slot_offset,unsigned kind_offset){
    unsigned slot=(unsigned)row[slot_offset]|(unsigned)row[slot_offset+1]<<8;
    uint64_t kind=(uint64_t)guardian_wire32(row+kind_offset)|(uint64_t)guardian_wire32(row+kind_offset+4)<<32;
    return slot==12 && (kind&0x06000fffU)==33556103U && ((kind>>13)&31)<=20 &&
           !(kind&UINT64_C(0xffffe000e0000000)) ? 50 : slot;
}
static inline __attribute__((always_inline)) void guardian_project_rows(unsigned char *p,unsigned count,unsigned stride,unsigned slot_offset,unsigned kind_offset){
    for(unsigned i=0;i<count;i++){
        unsigned char *row=p+i*stride;
        if(guardian_wire_slot(row,slot_offset,kind_offset)==50 && row[slot_offset]==12 && !row[slot_offset+1])row[slot_offset]=50;
    }
}
#endif
