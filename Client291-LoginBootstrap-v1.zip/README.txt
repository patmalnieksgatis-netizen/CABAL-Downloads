LoginBootstrap v1: candidate, Windows execution and Login NOT VERIFIED.
Close CABAL first. Extract every file, run Palaist-Labojumu.cmd from an administrator session.
Only F:\CABAL_291_TEST and clone192.168.56.101:35003. Requires existing Data/internal.txt clone profile.
Original Main/SDK/DXVK SHA256 required. No game-file installation or changes.
Starts original client, waits at entry before application initialization, restores12 native network entries.
Skips ExitLag initialization/worker and keeps native SECURITY/USE off. Preserves SDK resource handling.
Sets only the two network-version operations to282; server version is a configured profile, not a live readback.
Validates and rebases affected SDK code-integrity digests while child is stopped, resumes at original entry.
Uses only the owned process creation handles; no debugger, proxy DLL or remote thread.
On startup failure, stops ONLY its own newly started client. Does not stop existing clients.
When Login appears, use your test account in the game; no password in console.
Observes90seconds; generated JSON is in %USERPROFILE%\Downloads\Client291-LoginBootstrap-*.json.
No credentials collected; no automatic upload. Report actual in-game result.
Closing the game removes runtime changes; original files remain for normal startup.
