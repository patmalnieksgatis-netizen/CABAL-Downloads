// Candidate launch-time adapter for the isolated original v291 client.
// No client file writes, proxy DLL, injected thread or debugger.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

public sealed class Client291LoginBootstrap : IDisposable {
    public sealed class Hook {
        public string Role, OriginalWindowSHA256, SDKWindowSHA256;
        public int RVA, RestoreBytes, ExpectedSDKRVA;
    }
    public sealed class SDKPatch {
        public string Role, ExpectedSHA256, ReplacementHex;
        public int RVA, Bytes;
    }
    public sealed class VersionCall {
        public string Role, OriginalFunctionSHA256;
        public int RVA, FunctionRVA, FunctionBytes;
    }
    public sealed class Config {
        public string Root, MainSHA256, SDKSHA256, DXVKSHA256, BootstrapBarrierOriginalSHA256;
        public int BootstrapBarrierRVA, ServerVersion;
        public Hook[] MainHooks;
        public SDKPatch[] SDKPatches;
        public VersionCall[] VersionCalls;
    }
    public sealed class State {
        public int PID, LastDispatchTable, LastDispatchKey;
        public bool Exited;
        public uint ExitCode, NativeSourcePort;
        public string Mode, NativeSourceIP, NativeEndpointIP;
        public uint NativeEndpointPort;
        public byte NativeConnected;
        public bool IntegrityGood;
        public byte NativeSecurityUse;
    }
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    struct Startup {
        public uint Size; public string Reserved, Desktop, Title;
        public uint X,Y,XSize,YSize,XCount,YCount,Fill,Flags;
        public ushort Show,ReservedSize; public IntPtr ReservedPointer,Input,Output,Error;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct ProcessInfo { public IntPtr Process, Thread; public uint PID, TID; }
    [StructLayout(LayoutKind.Sequential)]
    struct Region {
        public IntPtr Base,AllocationBase;public uint AllocationProtect;
        public ushort Partition,Padding;public UIntPtr Size;public uint State,Protect,Type;
    }
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
    static extern bool CreateProcessW(string file,StringBuilder command,IntPtr pa,IntPtr ta,
        bool inherit,uint flags,IntPtr environment,string directory,ref Startup startup,out ProcessInfo info);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr p,IntPtr at,byte[] data,UIntPtr n,out UIntPtr got);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool WriteProcessMemory(IntPtr p,IntPtr at,byte[] data,UIntPtr n,out UIntPtr got);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool VirtualProtectEx(IntPtr p,IntPtr at,UIntPtr n,uint protection,out uint old);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern UIntPtr VirtualQueryEx(IntPtr p,IntPtr at,out Region region,UIntPtr size);
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool FlushInstructionCache(IntPtr p,IntPtr at,UIntPtr size);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint ResumeThread(IntPtr thread);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetThreadContext(IntPtr thread,IntPtr context);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetThreadContext(IntPtr thread,IntPtr context);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr p,out uint code);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(IntPtr p,uint code);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    [DllImport("psapi.dll",CharSet=CharSet.Unicode,ExactSpelling=true,SetLastError=true)]
    static extern uint GetMappedFileNameW(IntPtr process,IntPtr address,StringBuilder path,uint count);
    [DllImport("ntdll.dll")] static extern int NtSuspendProcess(IntPtr process);
    [DllImport("ntdll.dll")] static extern int NtResumeProcess(IntPtr process);

    const long Main=0x140000000L;
    const int MainSize=0x131c000, SDKSize=0x1264000;
    readonly List<Edit> edits=new List<Edit>();
    sealed class Edit { public string Name;public long At;public byte[] Before,After; }
    sealed class IntegrityRange { public long At,HashAt;public int Bytes;public ulong BeforeHash,AfterHash; }
    ProcessInfo child;
    bool frozen,completed;
    long sdk;
    byte[] original;
    Config config;
    public int PID { get { return (int)child.PID; } }
    public string Stage { get; private set; }
    public int CodeEditCount { get; private set; }
    public int IntegrityUpdates { get; private set; }
    public string SDKBaseHex { get { return sdk.ToString("X"); } }

    static void Need(bool yes,string error) { if (!yes) throw new Exception(error); }
    static void Win(bool yes) { if (!yes) throw new Win32Exception(Marshal.GetLastWin32Error()); }
    public static string Hash(byte[] b) {
        using(SHA256 s=SHA256.Create())return BitConverter.ToString(s.ComputeHash(b)).Replace("-", "").ToLowerInvariant();
    }
    public static byte[] Unhex(string text) {
        Need(text!=null && text.Length%2==0,"HEX_LENGTH");byte[] b=new byte[text.Length/2];
        for(int i=0;i<b.Length;i++)b[i]=Convert.ToByte(text.Substring(i*2,2),16);return b;
    }
    static bool Equal(byte[] a,byte[] b) {
        if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;
    }
    byte[] Read(long at,int n) {
        Need(at>=65536 && n>0 && n<=32*1024*1024 && checked(at+n)<0x7fffffffffffL,"READ_BOUNDS");
        byte[] b=new byte[n];UIntPtr got;
        Win(ReadProcessMemory(child.Process,new IntPtr(at),b,new UIntPtr((uint)n),out got));
        Need(got.ToUInt64()==(ulong)n,"PARTIAL_READ");return b;
    }
    uint U32(long at) { return BitConverter.ToUInt32(Read(at,4),0); }
    ulong U64(long at) { return BitConverter.ToUInt64(Read(at,8),0); }
    Region Query(long at) {
        Region r;int n=Marshal.SizeOf(typeof(Region));Need(n==48,"X64_REGION_LAYOUT");
        Win(VirtualQueryEx(child.Process,new IntPtr(at),out r,new UIntPtr((uint)n)).ToUInt64()==(ulong)n);return r;
    }
    void Image(long at,int n,long allocation) {
        long end=checked(at+n);
        while(at<end){Region r=Query(at);long stop=checked(r.Base.ToInt64()+(long)r.Size.ToUInt64());
            Need(r.State==0x1000 && r.Type==0x1000000 && r.AllocationBase.ToInt64()==allocation &&
                 (r.Protect&0x101)==0 && stop>at,"IMAGE_REGION_DIFFERS");at=Math.Min(stop,end);}
    }
    long Resolve(long at) {
        for(int hop=0;hop<4;hop++){
            Region region=Query(at);Need(region.State==0x1000 && (region.Protect&0x101)==0 &&
                (region.Protect&0xf0)!=0 && (region.Type==0x1000000 || region.Type==0x20000),"HOOK_NOT_EXECUTABLE_IMAGE_OR_RELAY");
            byte[] b=Read(at,6);
            if(b[0]==0xe9){at=checked(at+5+BitConverter.ToInt32(b,1));continue;}
            if(b[0]==0xff && b[1]==0x25){long slot=checked(at+6+BitConverter.ToInt32(b,2));
                Region pointer=Query(slot);Need(pointer.AllocationBase==region.AllocationBase && pointer.State==0x1000 &&
                    (pointer.Protect&0x101)==0,"RELAY_POINTER_ALLOCATION_DIFFERS");at=(long)U64(slot);continue;}
            return at;
        }
        throw new Exception("HOOK_JUMP_LIMIT");
    }
    long FindSDK() {
        long address=checked(Resolve(Main+0x69afd8)-0x5e33d0);Image(address,4096,address);
        byte[] b=Read(address,4096);int pe=BitConverter.ToInt32(b,60);
        Need(b[0]==77 && b[1]==90 && pe>=64 && pe<=2048 && BitConverter.ToUInt32(b,pe)==0x4550 &&
            BitConverter.ToUInt16(b,pe+4)==0x8664 && BitConverter.ToUInt16(b,pe+24)==0x20b &&
            BitConverter.ToUInt32(b,pe+80)==SDKSize,"SDK_PE_DIFFERS");
        var path=new StringBuilder(32768);
        Need(GetMappedFileNameW(child.Process,new IntPtr(address),path,(uint)path.Capacity)!=0 &&
            path.ToString().EndsWith("\\libogg.dll",StringComparison.OrdinalIgnoreCase),"SDK_MAPPED_FILE_DIFFERS");
        return address;
    }
    void Write(long at,byte[] bytes) {
        Need(frozen,"WRITE_REQUIRES_STOPPED_OWN_PROCESS");uint old,discard;UIntPtr got;
        Win(VirtualProtectEx(child.Process,new IntPtr(at),new UIntPtr((uint)bytes.Length),0x40,out old));
        try {
            Win(WriteProcessMemory(child.Process,new IntPtr(at),bytes,new UIntPtr((uint)bytes.Length),out got));
            Need(got.ToUInt64()==(ulong)bytes.Length,"PARTIAL_WRITE");
            Win(FlushInstructionCache(child.Process,new IntPtr(at),new UIntPtr((uint)bytes.Length)));
        } finally { Win(VirtualProtectEx(child.Process,new IntPtr(at),new UIntPtr((uint)bytes.Length),old,out discard)); }
        Need(Equal(Read(at,bytes.Length),bytes),"WRITE_READBACK_DIFFERS");
    }
    public static byte[] FileRVA(byte[] file,int rva,int n) {
        Need(file.Length>256 && file[0]==77 && file[1]==90,"MAIN_NOT_PE");int pe=BitConverter.ToInt32(file,60);
        Need(pe>=64 && pe<=2048 && pe+24<file.Length,"PE_OFFSET");
        int count=BitConverter.ToUInt16(file,pe+6),table=pe+24+BitConverter.ToUInt16(file,pe+20);
        Need(count>0 && count<96 && table+count*40<=file.Length,"SECTION_TABLE");
        for(int i=0;i<count;i++){
            int at=table+i*40,virtualRVA=BitConverter.ToInt32(file,at+12),raw=BitConverter.ToInt32(file,at+16),off=BitConverter.ToInt32(file,at+20);
            if(rva>=virtualRVA && (long)rva+n<=virtualRVA+(long)raw){
                int source=checked(off+rva-virtualRVA);Need(source>=0 && (long)source+n<=file.Length,"FILE_RVA_BOUNDS");
                byte[] b=new byte[n];Array.Copy(file,source,b,0,n);return b;}
        }
        throw new Exception("FILE_RVA_NOT_PRESENT");
    }
    void Profile() {
        string path=Path.Combine(config.Root,@"Data\internal.txt");
        Need(System.IO.File.Exists(path),"LOCAL_INTERNAL_PROFILE_MISSING");
        string section="";var values=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        foreach(string raw in System.IO.File.ReadAllLines(path)) {
            string line=raw.Trim();if(line.Length==0 || line[0]==';' || line[0]=='#')continue;
            if(line[0]=='[' && line.EndsWith("]")){section=line.Substring(1,line.Length-2).Trim();continue;}
            int equals=line.IndexOf('=');if(equals<1)continue;
            string key=section+"/"+line.Substring(0,equals).Trim();
            if(key.Equals("SERVER/IP",StringComparison.OrdinalIgnoreCase) ||
               key.Equals("SERVER/PORT",StringComparison.OrdinalIgnoreCase)) {
                Need(!values.ContainsKey(key),"DUPLICATE_LOCAL_ENDPOINT_SETTING");values.Add(key,line.Substring(equals+1).Trim());
            }
        }
        Need(values.ContainsKey("SERVER/IP") && values["SERVER/IP"]=="192.168.56.101" &&
             values.ContainsKey("SERVER/PORT") && values["SERVER/PORT"]=="35003","LOCAL_ENDPOINT_PROFILE_DIFFERS");
    }
    void Freeze() { int code=NtSuspendProcess(child.Process);Need(code>=0,"NT_SUSPEND="+code.ToString("X8"));frozen=true; }
    void Thaw() { if(!frozen)return;int code=NtResumeProcess(child.Process);Need(code>=0,"NT_RESUME="+code.ToString("X8"));frozen=false; }
    long ThreadControl(bool replace,long instruction) {
        IntPtr memory=Marshal.AllocHGlobal(1280);
        try {long aligned=(memory.ToInt64()+15)&~15L;IntPtr context=new IntPtr(aligned);
            for(int i=0;i<1232;i++)Marshal.WriteByte(context,i,0);
            Marshal.WriteInt32(context,48,0x100001);Win(GetThreadContext(child.Thread,context));
            long before=Marshal.ReadInt64(context,248);
            if(replace){Need(frozen,"CONTEXT_WRITE_REQUIRES_STOPPED_PROCESS");Marshal.WriteInt64(context,248,instruction);
                Win(SetThreadContext(child.Thread,context));}
            return before;
        } finally { Marshal.FreeHGlobal(memory); }
    }
    void Queue(string name,long at,byte[] before,byte[] after,long allocation) {
        Need(before.Length==after.Length && before.Length>0 && before.Length<=32,"PATCH_LENGTH");
        Image(at,before.Length,allocation);Need(Equal(Read(at,before.Length),before),"PATCH_INPUT_DIFFERS="+name);
        foreach(Edit e in edits)Need(at+before.Length<=e.At || e.At+e.Before.Length<=at,"PATCH_OVERLAP");
        edits.Add(new Edit{Name=name,At=at,Before=before,After=after});
    }
    public static ulong Decode64(byte[] bytes,ulong seed) {
        Need(bytes!=null && bytes.Length==8,"DECODE64_LENGTH");
        ulong state=seed^0x3c6ef372fe94f82aUL,result=0;byte previous=0x5a;
        unchecked {for(int i=0;i<8;i++){state^=state<<13;state^=state>>7;state^=state<<17;
            byte c=bytes[i];result|=(ulong)(byte)(c^(byte)state^previous)<<(i*8);previous=c;}}
        return result;
    }
    public static ulong HashBuffer(byte[] bytes,ulong seed,ulong prime) {
        unchecked {foreach(byte b in bytes)seed=(seed^b)*prime;}return seed;
    }
    ulong Fnv(long at,int count,ulong seed,ulong prime) {
        Need(count>=0 && count<=32*1024*1024,"HASH_BUDGET");ulong value=seed;
        unchecked {for(int offset=0;offset<count;){int n=Math.Min(65536,count-offset);byte[] b=Read(at+offset,n);
            value=HashBuffer(b,value,prime);offset+=n;}}
        return value;
    }
    bool Overlaps(long at,int n) {
        long end=checked(at+n);foreach(Edit e in edits)if(at<e.At+e.After.Length && e.At<end)return true;return false;
    }
    List<IntegrityRange> IntegrityBefore(out ulong seed,out ulong prime) {
        long obj=sdk+0x9cc320;Image(obj,0x80,sdk);
        uint good=U32(obj),bad=U32(obj+4);Need(good!=bad && U32(obj+8)==good,"INTEGRITY_NOT_INITIALIZED_OR_BAD");
        Need(Read(obj+0x74,1)[0]==0,"INTEGRITY_WORKER_BUSY");
        seed=Decode64(Read(sdk+0x9c4310,8),U64(sdk+0x6bb4d0)^U64(sdk+0x6bb4d8));
        prime=Decode64(Read(sdk+0x9c4318,8),U64(sdk+0x6bb4e8)^U64(sdk+0x6bb4f0));
        Need(prime!=0 && (prime&1)==1,"INTEGRITY_PRIME_DIFFERS");
        var ranges=new List<IntegrityRange>();
        ranges.Add(new IntegrityRange{At=Main+0x1000,Bytes=0xb3049f,HashAt=obj+0x10});
        int[,] layout={{0x38,0x40,0x30},{0x50,0x68,0x18},{0x58,0x6c,0x20},{0x60,0x70,0x28}};
        for(int i=0;i<4;i++){
            ulong pointer=U64(obj+layout[i,0]);uint n=U32(obj+layout[i,1]);
            Need(n<=32*1024*1024 && pointer<=0x7fffffffffffUL && pointer+n>=pointer,"INTEGRITY_RANGE_BOUNDS");
            if(n==0)continue;Need(pointer>=65536,"INTEGRITY_NULL_RANGE");
            if(Overlaps((long)pointer,(int)n))ranges.Add(new IntegrityRange{At=(long)pointer,Bytes=(int)n,HashAt=obj+layout[i,2]});
        }
        foreach(IntegrityRange r in ranges){r.BeforeHash=U64(r.HashAt);
            Need(Fnv(r.At,r.Bytes,seed,prime)==r.BeforeHash,"INTEGRITY_BASELINE_DIFFERS");}
        return ranges;
    }
    void Plan() {
        Need(config.MainHooks.Length==12 && config.SDKPatches.Length==3 && config.VersionCalls.Length==2,"MANIFEST_COUNTS");
        long socket=(long)U64(Main+0x126a9f0);
        if(socket!=0){Need(socket>=65536 && Read(socket+0x7c,1)[0]==0 && U64(socket+8)==ulong.MaxValue && U64(socket+0x50)==0,
            "LOGIN_SOCKET_ALREADY_INITIALIZED");}
        foreach(Hook h in config.MainHooks){
            Need(h.RestoreBytes>=5 && h.RestoreBytes<=16,"HOOK_PREFIX_LENGTH");
            byte[] file=FileRVA(original,h.RVA,32),live=Read(Main+h.RVA,32);
            Need(Hash(file)==h.OriginalWindowSHA256,"ORIGINAL_ENTRY_HASH="+h.Role);
            Need(Hash(Read(sdk+h.ExpectedSDKRVA,32))==h.SDKWindowSHA256,"SDK_ENTRY_HASH="+h.Role);
            Need(live[0]==0xe9 && Resolve(Main+h.RVA)==sdk+h.ExpectedSDKRVA,
                "HOOK_ROUTE_DIFFERS="+h.Role);
            for(int i=h.RestoreBytes;i<32;i++)Need(live[i]==file[i],"HOOK_TAIL_DIFFERS="+h.Role);
            byte[] before=new byte[h.RestoreBytes],after=new byte[h.RestoreBytes];Array.Copy(live,before,before.Length);Array.Copy(file,after,after.Length);
            Queue(h.Role,Main+h.RVA,before,after,Main);
        }
        foreach(SDKPatch p in config.SDKPatches){byte[] before=Read(sdk+p.RVA,p.Bytes),after=Unhex(p.ReplacementHex);
            Need(Hash(before)==p.ExpectedSHA256,"SDK_PATCH_HASH="+p.Role);Queue(p.Role,sdk+p.RVA,before,after,sdk);}
        Need(config.ServerVersion==282,"UNREVIEWED_SERVER_VERSION_PROFILE");
        foreach(VersionCall p in config.VersionCalls){
            Need(Hash(Read(Main+p.FunctionRVA,p.FunctionBytes))==p.OriginalFunctionSHA256,"VERSION_FUNCTION_DIFFERS");
            byte[] after=new byte[5];after[0]=0xb8;Array.Copy(BitConverter.GetBytes(config.ServerVersion),0,after,1,4);
            Queue(p.Role,Main+p.RVA,FileRVA(original,p.RVA,5),after,Main);
        }
        byte[] gate=Unhex("f390ebfc"),entry=FileRVA(original,config.BootstrapBarrierRVA,4);
        Need(Hash(entry)==config.BootstrapBarrierOriginalSHA256,"BARRIER_FILE_HASH");
        Queue("ReleaseConstructorBarrier",Main+config.BootstrapBarrierRVA,gate,entry,Main);
    }
    void Commit() {
        Plan();ulong seed,prime;var integrity=IntegrityBefore(out seed,out prime);int applied=0;
        try {
            foreach(Edit edit in edits){applied++;Write(edit.At,edit.After);}
            foreach(IntegrityRange r in integrity)r.AfterHash=Fnv(r.At,r.Bytes,seed,prime);
            foreach(IntegrityRange r in integrity)Write(r.HashAt,BitConverter.GetBytes(r.AfterHash));
            Need(U32(sdk+0x9cc328)==U32(sdk+0x9cc320),"INTEGRITY_STATUS_CHANGED_WHILE_STOPPED");
            // PAUSE and JMP are separate gate instructions. Never resume at +2
            // after restoring the original four-byte entry instruction.
            ThreadControl(true,Main+config.BootstrapBarrierRVA);
            CodeEditCount=edits.Count;IntegrityUpdates=integrity.Count;completed=true;
        } catch {
            // The owned child is still stopped; restore every attempted edit and digest.
            for(int i=applied-1;i>=0;i--)try{Write(edits[i].At,edits[i].Before);}catch{}
            foreach(IntegrityRange r in integrity)try{Write(r.HashAt,BitConverter.GetBytes(r.BeforeHash));}catch{}
            throw;
        }
    }
    public static Client291LoginBootstrap Start(Config cfg) {
        var self=new Client291LoginBootstrap();self.config=cfg;
        try {self.Launch();return self;}catch(Exception e) {
            self.Abort();self.Dispose();throw new Exception("STAGE="+self.Stage+"; PID="+self.PID+"; "+e.Message);
        }
    }
    void Launch() {
        Stage="FILES";Need(Environment.Is64BitProcess && Environment.OSVersion.Platform==PlatformID.Win32NT,"WINDOWS_X64_REQUIRED");
        Need(String.Equals(config.Root,@"F:\CABAL_291_TEST",StringComparison.OrdinalIgnoreCase),"ISOLATED_ROOT_ONLY");
        Profile();
        string bin=Path.Combine(config.Root,@"Bin\x64"),exe=Path.Combine(bin,"CabalMain.exe");
        original=System.IO.File.ReadAllBytes(exe);Need(Hash(original)==config.MainSHA256,"MAIN_FILE_DIFFERS");
        Need(Hash(System.IO.File.ReadAllBytes(Path.Combine(bin,"libogg.dll")))==config.SDKSHA256,"SDK_FILE_DIFFERS");
        Need(Hash(System.IO.File.ReadAllBytes(Path.Combine(bin,"d3d9.dll")))==config.DXVKSHA256,"DXVK_FILE_DIFFERS");
        Startup startup=new Startup();startup.Size=(uint)Marshal.SizeOf(typeof(Startup));Need(startup.Size==104,"STARTUP_LAYOUT");
        Stage="CREATE_SUSPENDED";Win(CreateProcessW(exe,new StringBuilder("\""+exe+"\" breaklee"),IntPtr.Zero,IntPtr.Zero,false,4,
            IntPtr.Zero,bin,ref startup,out child));frozen=true;
        Need(config.BootstrapBarrierRVA==0x286ec8,"UNREVIEWED_CONSTRUCTOR_BARRIER");
        byte[] call=FileRVA(original,config.BootstrapBarrierRVA,5);
        Need(call[0]==0xe8 && config.BootstrapBarrierRVA+5+BitConverter.ToInt32(call,1)==0x27b384,"CONSTRUCTOR_CALL_DIFFERS");
        byte[] entry=FileRVA(original,config.BootstrapBarrierRVA,4);
        Need(Hash(entry)==config.BootstrapBarrierOriginalSHA256,"BARRIER_MANIFEST_DIFFERS");
        Image(Main+config.BootstrapBarrierRVA,4,Main);
        Need(Equal(Read(Main+config.BootstrapBarrierRVA,4),entry),"INITIAL_BARRIER_DIFFERS");
        Stage="CONSTRUCTOR_BARRIER";Write(Main+config.BootstrapBarrierRVA,Unhex("f390ebfc"));
        Need(ResumeThread(child.Thread)!=0xffffffff,"INITIAL_RESUME_FAILED");frozen=false;
        Stage="WAIT_SDK_BEFORE_CONSTRUCTOR";DateTime deadline=DateTime.UtcNow.AddSeconds(25);bool ready=false;
        string lastSDKFailure="MAIN_THREAD_NOT_AT_GATE";
        Console.WriteLine("GAIDU_SDK_INICIALIZACIJU; LIMITS_25_SEKUNDES");
        while(DateTime.UtcNow<deadline){uint exit;Win(GetExitCodeProcess(child.Process,out exit));Need(exit==259,"CLIENT_EXITED_BEFORE_GATE="+exit.ToString("X8"));
            Freeze();long rip=ThreadControl(false,0);
            if(rip==Main+config.BootstrapBarrierRVA || rip==Main+config.BootstrapBarrierRVA+2){
                try {
                    sdk=FindSDK();
                    if(Read(sdk+0x9cc394,1)[0]!=0)lastSDKFailure="SDK_INTEGRITY_WORKER_BUSY";
                    else if(U32(sdk+0x9cc320)==U32(sdk+0x9cc324))lastSDKFailure="SDK_INTEGRITY_NOT_INITIALIZED";
                    else if(U32(sdk+0x9cc328)!=U32(sdk+0x9cc320))lastSDKFailure="SDK_INTEGRITY_STATUS_BAD";
                    else {ready=true;break;}
                }
                catch(Exception e) { lastSDKFailure=e.Message; }
            }
            Thaw();Thread.Sleep(20);
        }
        Need(ready,"ENTRY_GATE_TIMEOUT; LAST_SDK_REASON="+lastSDKFailure);
        Stage="PREFLIGHT_AND_COMMIT";Commit();
        Stage="RESUME_PATCHED_CLIENT";Thaw();
        Need(Hash(System.IO.File.ReadAllBytes(exe))==config.MainSHA256 &&
             Hash(System.IO.File.ReadAllBytes(Path.Combine(bin,"libogg.dll")))==config.SDKSHA256 &&
             Hash(System.IO.File.ReadAllBytes(Path.Combine(bin,"d3d9.dll")))==config.DXVKSHA256,"DISK_IDENTITY_CHANGED");
        Stage="APPLIED_RUNTIME_ONLY_WINDOWS_LOGIN_UNVERIFIED";
    }
    string Text(long at) {
        byte[] head=Read(at,32);ulong length=BitConverter.ToUInt64(head,16),capacity=BitConverter.ToUInt64(head,24);
        if(length==0)return "";Need(length<=255 && capacity>=length && capacity<=4096,"ENDPOINT_STRING_SHAPE");
        string text=Encoding.ASCII.GetString(Read(capacity<16?at:(long)BitConverter.ToUInt64(head,0),(int)length));
        foreach(char c in text)Need(char.IsLetterOrDigit(c) || c=='.' || c==':' || c=='-' || c=='_',"ENDPOINT_TEXT_SHAPE");return text;
    }
    public State Snapshot() {
        uint exit;Win(GetExitCodeProcess(child.Process,out exit));var s=new State{PID=PID,Exited=exit!=259,ExitCode=exit};if(s.Exited)return s;
        s.NativeSourceIP=Text(Main+0xd94f78);s.NativeSourcePort=U32(Main+0xdd5b08);
        s.NativeEndpointIP=Text(Main+0x126ad10);s.NativeEndpointPort=U32(Main+0x126ad30);
        s.LastDispatchTable=(int)U32(Main+0x126ace4);s.LastDispatchKey=(int)U32(Main+0x126ace8);
        long socket=(long)U64(Main+0x126a9f0);if(socket>=65536)s.NativeConnected=Read(socket+0x7c,1)[0];
        s.IntegrityGood=U32(sdk+0x9cc320)==U32(sdk+0x9cc328);
        s.NativeSecurityUse=Read(Main+0xd94ec8,1)[0];
        long mode=(long)U64(Main+0x120f7a0);
        s.Mode="UNINITIALIZED";
        if(mode>=65536) {
            byte[] b=Read(mode,12);uint sum=b[4],value=0;
            for(int i=0;i<4;i++){sum+=b[i];value|=(uint)(b[i]^b[4])<<(8*i);}
            s.Mode=sum==BitConverter.ToUInt32(b,8)?value.ToString():"CHECKSUM_DIFFERS";
        }
        return s;
    }
    public bool VerifyCode() {
        Need(completed,"PATCH_NOT_COMMITTED");foreach(Edit edit in edits)
            if(!Equal(Read(edit.At,edit.After.Length),edit.After))return false;return true;
    }
    void Abort() {if(child.Process!=IntPtr.Zero){uint exit;if(GetExitCodeProcess(child.Process,out exit) && exit==259)TerminateProcess(child.Process,0xe2910001);frozen=false;} }
    public void Dispose() {
        if(!completed)Abort();
        if(child.Thread!=IntPtr.Zero){CloseHandle(child.Thread);child.Thread=IntPtr.Zero;}
        if(child.Process!=IntPtr.Zero){CloseHandle(child.Process);child.Process=IntPtr.Zero;}
    }
}
