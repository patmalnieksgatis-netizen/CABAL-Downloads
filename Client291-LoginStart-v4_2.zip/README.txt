Client291 LoginStart v4.2 - Login opcode compatibility candidate.
Close CABAL. Extract ALL files to a NEW folder. Run Palaist-291-v4_2.cmd as administrator.
Keep test VM192.168.56.101:35003 running. Only F:\CABAL_291_TEST and pinned original files.
Preserves V4.1 startup already observed with native integrity GOOD and intended Login connection.
Adds two guarded Login-only opcode changes5383->3383: request builder and reply registration.
User-reported running native LoginSvr SHA8441a568 uses3383; packet payload/handler stay native.
No server installation/restart, SQL changes, or client game-file writes. Close game to discard RAM changes.
Natural SDK integrity worker remains; all5 pre-edit digests required; no good/bad/current marker writes.
When prompted, use your test account inside game, choose channel/character, try entering world.
No password in console. No account/password buffers or packet payload collection/upload.
REPORT= shows Downloads\Client291-LoginStart-v4_2-*.json. Leave game open.
V4.2 Windows/Login/world result is pending. Fixes proved opcode difference; full Login success not claimed.
Server identity is user-reported, version282 is configured; neither is a new live cloud read.
