@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Client291-LoginStart-v4_2.ps1" -Action Run
pause
