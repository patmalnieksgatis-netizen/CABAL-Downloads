@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test-Native-Audio.ps1"
echo.
pause
