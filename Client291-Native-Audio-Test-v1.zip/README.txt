Client291 native-audio comparison, x64 F:\CABAL_291_TEST only.
Close ALL Cabal windows. Extract ALL files to a new folder. Run Palaist-Testu.cmd.
Changes test libogg.dll to a COPY of your EXISTING libogg_d_64bit.dll (377c3572).
This disables the publisher SDK in this dependency path. It is a comparison,
not a proven complete login fix. No DLL is included or downloaded.
Original SDK (ceafa829) is preserved at:
F:\CABAL_291_TEST\.client291-native-audio-v1\original-libogg.dll
Original Main, DXVK, source audio library, Vorbis, configs and server unchanged.
If game fails, close game windows then run Atjaunot-Originalu.cmd to restore SDK.
Wait20s, then at prompt ONE dummy Login: LOCAL291TEST / Test291only. Wait60s.
Test verifies native endpoint entry and samples mode/source/cache and game-owned
clone TCP. Leave game open; return console output or Run-*.txt report.
Cached IP/TCP is not authentication or World success. Native version/crypto/
server compatibility may require work. No process memory writes, hooks,
injection, process termination or server/SQL changes. Inspect/ApplyOnly actions
are available for bounded package checks. Windows behavior remains unverified.
