@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Read-Endpoint-Code.ps1"
echo.
pause
