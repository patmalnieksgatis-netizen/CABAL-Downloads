Original x64 F:\CABAL_291_TEST only. Close game, extract ALL files into a new folder,
then double-click Palaist-Nolasisanu.cmd. Wait20s; at prompt use LOCAL291TEST /
Test291only and click Login once. Wait60s. Leave game open. Return the generated
Client291-Endpoint-Code-*.json and console/run report. No account/password memory
is read. Only mode/source/cache and1024 bytes at known executable SDK RVA0xACF83C
are captured. Native entry jumps are followed at most4 times; SDK image layout,
allocation/type/executable protection and source file hashes are checked. Layout
mismatch is refused. No DLL installation, hooks, process writes, network changes,
process termination or server changes. Only report files are written here.
The code snapshot is not a trace of the writer and does not prove successful
network routing or authentication. Windows capture remains to be verified.
