"""Read only fixed game definitions and the running test World identity.

Executed on the isolated test VM host. No account, logs, database,
configuration credentials or executable bytes are exported. Optional memory
reads cover only three public quest-definition counts per Quest.scp ID.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

VM_UUID = '7632fb78-37a0-f645-97c0-dc322c50b002'
WORLD_SHA = 'caec7772acd22fd8918cfac386845c644451781e48c51975eaefed334c6705c3'

def run(args):
    return subprocess.check_output(args, timeout=30)

if Path('/sys/class/dmi/id/product_uuid').read_text().strip().lower() != VM_UUID:
    raise SystemExit('WRONG_TEST_VM')
# Resolve inside the container; host-side absolute symlinks have different roots.
size = int(run(['docker', 'exec', 'cabal_main', 'stat', '-Lc', '%s', '/etc/cabal/Data/Quest.scp']))
if not 0 < size <= 8 * 1024**2:
    raise SystemExit('QUEST_FILE_EXTENT')
body = run(['docker', 'exec', 'cabal_main', 'cat', '/etc/cabal/Data/Quest.scp'])
if len(body) != size:
    raise SystemExit('QUEST_CHANGED_DURING_READ')
pid = run(['docker', 'exec', 'cabal_main', 'supervisorctl', 'pid', 'WorldSvr_01_01']).decode().strip()
if not pid.isdigit() or int(pid) <= 0:
    raise SystemExit('WORLD_NOT_RUNNING')
found = []
for token in run(['docker', 'top', 'cabal_main', '-eo', 'pid']).decode().split():
    if not token.isdigit():
        continue
    p = Path('/proc') / token
    try:
        ns = re.search(r'^NSpid:\s+([0-9 \t]+)$', (p / 'status').read_text(), re.M)
        if ns and ns[1].split()[-1] == pid:
            found.append(p)
    except FileNotFoundError:
        continue
if len(found) != 1:
    raise SystemExit('WORLD_PROCESS_NOT_UNIQUE')
process = found[0]
digest = hashlib.sha256()
with (process / 'exe').open('rb') as stream:
    for block in iter(lambda: stream.read(65536), b''):
        digest.update(block)
result = dict(Schema=1, Changes=False, QuestBytes=len(body),
    QuestSHA256=hashlib.sha256(body).hexdigest(), QuestBase64=base64.b64encode(body).decode(),
    WorldSHA256=digest.hexdigest(), QuestLoadedAttested=False,
    LoadedQuestStatus='WORLD_PROFILE_DIFFERS', LoadedQuestRows=[])
if result['WorldSHA256'] == WORLD_SHA:
    try:
        ids = set()
        column = None
        for line in body.decode('latin1').splitlines():
            cells = [s.strip() for s in line.split('\t')]
            if cells[0].startswith('['):
                column = cells.index('QuestIdx') if cells[0] == '[Quest]' else None
            elif column is not None and cells[0].isdigit() and len(cells) > column and cells[column].isdigit():
                value = int(cells[column])
                if 0 < value < 65536:
                    ids.add(value)
        if not ids or len(ids) > 10000:
            raise ValueError('QUEST_ID_SET')
        ranges = [tuple(int(v,16) for v in row.split()[0].split('-'))
                  for row in (process / 'maps').read_text().splitlines() if 'r' in row.split()[1]]
        with (process / 'mem').open('rb', buffering=0) as memory:
            def counts():
                rows = []
                for identifier in sorted(ids):
                    values = []
                    for offset in (0x78, 0x94, 0xb0):
                        address = 0x1610e00 + identifier * 264 + offset
                        if not any(a <= address and address + 4 <= b for a,b in ranges):
                            raise ValueError('QUEST_COUNT_NOT_MAPPED')
                        data = os.pread(memory.fileno(), 4, address)
                        if len(data) != 4 or int.from_bytes(data, 'little') > 3:
                            raise ValueError('QUEST_COUNT_EXTENT')
                        values.append(int.from_bytes(data, 'little'))
                    if sum(values) > 3:
                        raise ValueError('QUEST_OBJECTIVE_BOUND')
                    rows.append(dict(ID=identifier, At78=values[0], At94=values[1], AtB0=values[2]))
                return rows
            first = counts()
            if first != counts():
                raise ValueError('QUEST_COUNTS_CHANGED')
        result.update(QuestLoadedAttested=True, LoadedQuestStatus='PINNED_NATIVE_COUNTS_READ_TWICE', LoadedQuestRows=first)
    except (OSError, ValueError):
        result['LoadedQuestStatus'] = 'LOADED_COUNTS_UNAVAILABLE_OR_UNSUPPORTED'
print(json.dumps(result))
