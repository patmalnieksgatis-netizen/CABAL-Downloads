READ-ONLY V291 WORLD DEFINITIONS COPY

No game launch, installation, SQL, server file or process-memory writes.
Copies only F:\CABAL_291_TEST\Data\quest.enc and optional AnimaMastery.enc/pet.enc.
Uses root@192.168.56.101 SSH and verifies the designated test VM UUID first.
Reads cabal_main /etc/cabal/Data/Quest.scp and the running World SHA256.
Only after the exact original World hash matches, reads three public quest
definition counts per ID in Quest.scp, twice, at the pinned native table.
No account/session/progress memory, logs, UserData or credentials are read.
Native loaded counts can be unavailable; the report marks that explicitly.
Client disk definition copies do not attest loaded client objective vectors.
SSH asks for the existing test VM root password; it is not stored.
Run Savakt-Definicijas.cmd and upload Client291-WorldDefinitions-*.zip
from your Downloads folder. Returned game definitions stay private.
