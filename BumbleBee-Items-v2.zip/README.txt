BUMBLEBEE SIX REQUESTED ITEMS: NATIVE GM MAIL
Extract into a fresh folder and run Sutit-BumbleBee-Itemus.cmd.
Enter SSH password at its normal prompt. No separate collector run is needed.
Only isolated VM192.168.56.101 / UUID7632fb78-37a0-f645-97c0-dc322c50b002.

3 Crests: Life/Sky/Earth, each3 filled slots HP/Defense/CriticalDamage.
Sage Belt Chaos+20 and Carnelian Chaos+20.
QW7 ordinary+20,3 open sockets,Extreme+6,Divine+15 (user accepted15).
Sage is resolved from its actual MagicAttack profile; no adjacent-ID guessing.
The sender reads active Chaos_Upgrade and Limit_Upgrade itself and verifies all
requested bonus levels, seven known file hashes and running World executable.
Unsupported/missing/native-changed data stops before any mail grant.

Uses the existing reviewed nativecabal_tool_mail_send with both helper hashes,
bigint itemkind parameter, exact unique BumbleBee identity, transaction lock,
per-attachment postchecks and one6-item receipt. Retry returns ALREADY_SENT
and cannot create duplicate grants. No inventory/level/currency edits or
service restart. Do not change the request/receipt ID to retry.

Success requires BUMBLEBEE_SIX_ITEMS_CONFIRMED. Then open in-game mail and claim.
Receipt saved in Downloads/BumbleBee-Items-Receipt-<stamp>.txt.
If it stops, send the visible output. The live action has not run in Cloud.
