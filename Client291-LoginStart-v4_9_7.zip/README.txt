CLIENT291 V4.9.7: EXACT REJECTED SLOT REPORT
Close CABAL and the old Launcher; extract this ZIP into a NEW folder.
Run Palaist-291-v4_9_7.cmd as administrator. Leave Launcher open.
Make one channel connection attempt. Send the console CharacterListFailure
object or the Client291-LoginStart-v4_9_7-*.json in Downloads after exit.
Section: 1=equipment, 2=appearance. Reason: 1=out of range, 2=duplicate.
Numeric metadata only; no name, account, serial, password or raw packet export.
The V496 slot validation and Guardian mapping are unchanged. This reports
the precise refusal, and does not yet claim to fix it. No server installation,
service restart, database/item edits or original client disk writes.
