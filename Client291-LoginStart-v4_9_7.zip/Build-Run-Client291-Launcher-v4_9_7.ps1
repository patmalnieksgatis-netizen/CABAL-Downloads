param([ValidateSet('Inspect','Run')][string]$Action='Inspect')
$ErrorActionPreference='Stop'
if($Action -eq 'Inspect'){
    [ordered]@{Host='Launcher.exe';UsesInProcessPowerShell=$true;GameParentSpoofed=$false;OriginalParentCheckChanged=$false;GameStarted=$false} | ConvertTo-Json
    return
}
if($env:OS -ne 'Windows_NT' -or ![Environment]::Is64BitProcess){throw 'WINDOWS_X64_POWERSHELL_REQUIRED'}
if(Get-Process -Name CabalMain -ErrorAction SilentlyContinue){throw 'Vispirms aizver CABAL klientu.'}
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if(!(Test-Path -LiteralPath $compiler)){throw 'WINDOWS_DOTNET_FRAMEWORK_COMPILER_MISSING'}
$source=Join-Path $PSScriptRoot 'Client291-LauncherHost-v4_9_7.cs'
$launcher=Join-Path $PSScriptRoot 'Launcher.exe'
$receiptPath=Join-Path $PSScriptRoot 'Launcher-build-v4_9_7.json'
$sourceSHA=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
if(Test-Path -LiteralPath $launcher){
    if(!(Test-Path -LiteralPath $receiptPath)){throw 'IZPAKO_V4_9_7_JAUNA_MAPE; LAUNCHER_BUILD_RECEIPT_MISSING'}
    $receipt=Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
    if($receipt.SourceSHA -cne $sourceSHA -or $receipt.LauncherSHA -cne (Get-FileHash -LiteralPath $launcher -Algorithm SHA256).Hash){throw 'LAUNCHER_BUILD_RECEIPT_DIFFERS; IZPAKO_JAUNA_MAPE'}
    'PALAIJU_JAU_SAKOMPILETO_LAUNCHER'
    Start-Process -FilePath $launcher -WorkingDirectory $PSScriptRoot -Verb RunAs
    return
}
$automation=[System.Management.Automation.PowerShell].Assembly.Location
'KOMPILAJU_MUSU_LAUNCHER; ORIGINALAIS_KLIENTS_NETIEK_PARRAKSTITS'
& $compiler /nologo /target:exe /platform:x64 /optimize+ ("/reference:"+$automation) ("/out:"+$launcher) $source
if($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $launcher)){throw 'LAUNCHER_HOST_BUILD_FAILED'}
[ordered]@{SourceSHA=$sourceSHA;LauncherSHA=(Get-FileHash -LiteralPath $launcher -Algorithm SHA256).Hash} | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding UTF8
Start-Process -FilePath $launcher -WorkingDirectory $PSScriptRoot -Verb RunAs
