@echo off
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-Run-Client291-Launcher-v4_9_7.ps1" -Action Run
if errorlevel 1 pause
